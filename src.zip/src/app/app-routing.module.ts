import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
// import { AuthGuard } from './shared/guards/auth.guard';
import { CallbackComponent } from './callback/callback.component';
import { InvitationAcceptComponent } from './invitation-accept/invitation-accept.component';
import { AppPreloadingStrategy } from './app-preloading-strategy';

// canActivate: [AuthGuard],
const routes: Routes = [
  {
    path: '',
    component: DashboardComponent,
    children: [
      {
        path: '',
        loadChildren: () => import('../app/dashboard/home-section/home.module').then(m => m.HomeModule),
        data: { preload: true, delay: false }
      },
      {
        path: 'devices',
        loadChildren: () => import('../app/dashboard/devices-section/devices.module').then(m => m.DevicesModule),
        data: { preload: true, delay: false }
      },
      {
        path: 'channels',
        loadChildren: () => import('../app/dashboard/playlists-section/playlists.module').then(m => m.PlaylistsModule),
        data: { preload: true, delay: false }
      },
      {
        path: 'content',
        loadChildren: () => import('../app/dashboard/content-section/content.module').then(m => m.ContentModule),
        data: { preload: true, delay: false }
      },
      {
        path: 'apps',
        loadChildren: () => import('../app/dashboard/apps-section/apps.module').then(m => m.AppsModule),
        data: { preload: true, delay: false }
      },
      {
        path: 'accounts',
        loadChildren: () => import('../app/dashboard/accounts-section/accounts.module').then(m => m.AccountsModule),
        data: { preload: false, delay: true }
      },
      {
        path: 'workspaces',
        loadChildren: () => import('../app/dashboard/workspaces-section/workspaces.module').then(m => m.WorkspacesModule),
        data: { preload: true, delay: false }
      },
      {
        path: 'schedules',
        loadChildren: () => import('../app/dashboard/schedules-section/schedules.module').then(m => m.SchedulesModule),
        data: { preload: true, delay: false }
      },
      {
        path: 'support',
        loadChildren: () => import('../app/dashboard/support-section/support.module').then(m => m.SupportModule),
        data: { preload: false, delay: true }
      },
      {
        path: 'profile',
        loadChildren: () => import('../app/dashboard/profile-section/profile.module').then(m => m.ProfileModule),
        data: { preload: true, delay: false }
      },
      {
        path: 'downloads',
        loadChildren: () => import('../app/dashboard/downloads-section/downloads.module').then(m => m.DownloadsModule),
        data: { preload: false, delay: true }
      },
      {
        path: 'notifications',
        loadChildren: () => import('../app/dashboard/notifications-section/notifications.module').then(m => m.NotificationsModule),
        data: { preload: true, delay: false }
      },
      {
        path: 'recipients',
        loadChildren: () => import('../app/dashboard/recipients-section/recipients.module').then(m => m.RecipientsModule),
        data: { preload: true, delay: false }
      },
      {
        path: 'integrations',
        loadChildren: () => import('../app/dashboard/integrations-section/integrations.module').then(m => m.IntegrationsModule),
        data: { preload: true, delay: false }
      }
    ]
  },
  {
    path: 'login/callback',
    component: CallbackComponent
  },
  {
    path: 'invitations/accept/:invitationKey',
    component: InvitationAcceptComponent
  },
  {
    path: '**',
    redirectTo: '',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
    preloadingStrategy: PreloadAllModules,
    relativeLinkResolution: 'legacy'
})
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
