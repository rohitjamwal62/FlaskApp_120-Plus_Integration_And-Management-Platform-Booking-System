import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { CookieService } from 'ngx-cookie-service';
import { AppRoutingModule } from './app-routing.module';
import { Interceptor } from './shared/interceptor/interceptor';
import { AppComponent } from './app.component';
import { GlobalErrorHandler } from './global-error.handler';

import { DashboardComponent } from './dashboard/dashboard.component';
import { SharedModule } from './shared/shared.module';
import { CallbackComponent } from './callback/callback.component';
import { InvitationAcceptComponent } from './invitation-accept/invitation-accept.component';
// import { AuthService } from './shared/services/auth.service';

import { LoggerModule, NgxLoggerLevel } from 'ngx-logger';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { environment } from 'src/environments/environment';
//import { DeviceDetectorModule, DeviceDetectorService } from 'ngx-device-detector';
import { NgxStripeModule } from 'ngx-stripe';

// AoT requires an exported function for factories
export function HttpLoaderFactory(httpClient: HttpClient) {
  //return new TranslateHttpLoader(httpClient);
  return new TranslateHttpLoader(httpClient, "assets/i18n/" , ".json");
}


@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    CallbackComponent,
    InvitationAcceptComponent
  ],
  imports: [
    AppRoutingModule,
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    SharedModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    LoggerModule.forRoot({
      serverLoggingUrl: environment.endPoint+'/logs/cms/',
      level: NgxLoggerLevel.ERROR,
      serverLogLevel: NgxLoggerLevel.ERROR
    }),
    //DeviceDetectorModule,
    NgxStripeModule.forRoot()
  ],
  providers: [
    // AuthService,
    CookieService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: Interceptor,
      multi: true
    },
    {
      provide: ErrorHandler,
      useClass: GlobalErrorHandler
    }
    //DeviceDetectorService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
