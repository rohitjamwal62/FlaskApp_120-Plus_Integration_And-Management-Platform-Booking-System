import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { environment } from 'src/environments/environment';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { Location } from '@angular/common';
import { MatTabChangeEvent } from '@angular/material/tabs';

import { AccountsService } from 'src/app/shared/services/accounts.service';
import { UtilService } from 'src/app/shared/services/util.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { UsersService } from 'src/app/shared/services/users.service';
import { StorageService } from 'src/app/shared/services/storage.service';

import { AccountFeatures } from 'src/app/shared/models/account-models/account-features.model';
import { Account } from 'src/app/shared/models/account-models/account.model';
import { SitebarItem } from 'src/app/shared/models/common-models/sitebar-item.model';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { UserBasic } from 'src/app/shared/models/user-models/user-basic.model';
import { AccountInvitation } from 'src/app/shared/models/account-models/account-invitation.model';
import { UserPersonal } from 'src/app/shared/models/user-models/user-personal.model';
import { BillingInfo } from 'src/app/shared/models/common-models/billing-info.model';
import { AccountGroup } from 'src/app/shared/models/account-models/account-group.model';
import { AccountUpdateRequest } from 'src/app/shared/models/requests-models/account-update.model';
import { BillEstimate } from 'src/app/shared/models/account-models/bill-estimate.model';
import { BillHistory } from 'src/app/shared/models/account-models/bill-history.model';

import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-account-edit',
  templateUrl: './account-edit.component.html',
  styleUrls: ['./account-edit.component.scss']
})
export class AccountEditComponent extends CleanOnDestroy implements OnInit {

  protected baseUrl = environment.endPoint;

  accountFeatures: AccountFeatures;

  selectedIndex: number = null;
  accountEndPoint: string = '';
  accountLogoEndpoint: string = '';
  // store the current account id
  accountId: number;
  // store the current account info
  account: Account = {} as Account;
  // store the account sitebar info
  accountItem: SitebarItem;

  accountWorkspaces: Workspace[] = [];
  accountMembers: UserBasic[] = [];
  accountInvitations: AccountInvitation[] = [];
  accountGroups: AccountGroup[] = [];
  accountBilling: BillingInfo;
  billEstimate: BillEstimate;
  billHistory: BillHistory[] = [];

  typedAccountName: string = '';
  typedCompanyName: string = '';

  requestTimeout = 100; // miliseconds
  timer: any = null;
  currentLocale: any = '';
  activeLink:number = 0;

  constructor(
    private translate: TranslateService,
    private activeRoute: ActivatedRoute,
    private accountsSrv: AccountsService,
    public utilSrv: UtilService,
    private sharedSrv: SharedService,
    public storageSrv: StorageService,
    private location: Location,
    private userSrv: UsersService,
  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }


  ngOnInit() {

    this.currentLocale = this.utilSrv.locale;

    // get accountItem
    this.accountItem = this.utilSrv.getSitebarItem('accounts');
    this.accountEndPoint = `${this.utilSrv.env.endPoint}/api/v3/orgs/`;
    // subscribe to the route params changes
    //
    this.subscriber = this.activeRoute.params.subscribe(params => {
      this.selectedIndex = null;
      if (params['accountId']) {
        this.accountId = +params['accountId'];
        // change account logo
        this.changeAccountLogo();
        // get account info by account id
        this.getCurrentAccountById();
      }
      if (params['tabName']) {
        switch (params['tabName']) {
          case 'workspaces':
            this.selectedIndex = 0;
            break;
          case 'users':
            this.selectedIndex = 1;
            break;
          case 'billing':
            this.selectedIndex = 2;
            break;
        }
      }
    });

    this.subscriber = this.storageSrv.accountFeaturesSubject.subscribe( accountFeatures => {
      if (accountFeatures) {
        this.accountFeatures = accountFeatures;
      }
    });

  }

  /**
   * change account logo path
   *
   * @param null
   *
   * @return `null`
   */
  changeAccountLogo() {
    this.accountLogoEndpoint = '';
    // settimeout need for a update existing image
    setTimeout(() => {
      this.accountLogoEndpoint = `${this.accountEndPoint}${this.accountId}/logo/`;
    })
  }

  /**
   * get account info by `accountId`
   *
   * @param accountId with type `number` (by default equal to `this.accountId`)
   *
   * @return `null`
   */
  getCurrentAccountById(accountId: number = this.accountId) {
    this.account = {} as Account;
    this.typedAccountName = '';
    this.typedCompanyName = '';
    this.subscriber = this.storageSrv.userAccountsSubject.subscribe(accounts => {
      if (accounts) {
        let isFindedAccount = false;
        accounts.every(account => {
          if (account.id === this.accountId) {
            this.account = account;
            this.typedAccountName = this.account.accountName;
            this.typedCompanyName = this.account.company;
            isFindedAccount = true;
            this.accountInvitations = this.account.invitations;
            return false;
          }
          return true;
        });
        if (!isFindedAccount) {
          this.location.back();
        }
      }
    });
  }

  /**
   * get account workspaces by `accountId`
   *
   * @param accountId with type `number` (by default equal to `this.accountId`)
   *
   * @return `null`
   */
  getAccountWorkspaces(accountId: number = this.accountId) {
    this.accountWorkspaces = [];
    this.accountsSrv.getWorkspacesByAccountId(accountId)
      .subscribe(workspaces => {
        if (workspaces) {
          this.accountWorkspaces = workspaces;
        }
      })
  }

  /**
   * calls from template when user change the selected tab
   * replace the current url for a store user selected tab and helper for mobile app
   * @param event is a output event object of tab group `selectedTabChange` event
   * @return `null`
   */
  onChangeTab(event: MatTabChangeEvent) {
    switch (event.index) {
      case 0:
        history.replaceState(location.href, '', `${this.baseUrl}/accounts/${this.accountId}/workspaces`);
        break;
      case 1:
        history.replaceState(location.href, '', `${this.baseUrl}/accounts/${this.accountId}/users`);
        break;
      case 2:
        history.replaceState(location.href, '', `${this.baseUrl}/accounts/${this.accountId}/billing`);
        break;
    }
  }

  /**
   * get account users by `accountId`
   * @param accountId with type `number` (by default equal to `this.accountId`)
   * @return `null`
   */
  getAccountMembers(accountId: number = this.accountId) {
    this.accountMembers = [];
    this.accountsSrv.getAccountUsers(accountId)
      .subscribe(users => {
        if (users) {
          this.accountMembers = users;
          /*this.accountMembers.forEach(user => {
            this.userSrv.getCurrentUserInfo().subscribe(response => {
            })
          });*/
        }
      })
  }

  /**
   * get account billing info by `accountId`
   *
   * @param accountId with type `number` (by default equal to `this.accountId`)
   *
   * @return `null`
   */
  getAccountBilling(accountId: number = this.accountId) {
    this.accountBilling = null;
    this.accountsSrv.getAccountBilling(accountId)
      .subscribe(billingInfo => {
        if (billingInfo) {
          this.accountBilling = billingInfo;
        }
      })
  }

  getAccountGroups(accountid: number = this.accountId) {
    this.accountGroups = [];
    this.accountsSrv.getAccountGroups(accountid).subscribe(accountGroups => {
      this.accountGroups = accountGroups;
    })
  }

    // get estimate for the account
  getAccountBillEstimate(){
    this.accountsSrv.getAccountBillingEstimate(this.accountId)
      .subscribe(billEstimate => {
        this.billEstimate = billEstimate;
      });
  }

  // bill history
  getAccountBillHistory(){
    this.accountsSrv.getAccountBillingHistory(this.accountId, 0)
      .subscribe(billHistory => {
        this.billHistory = billHistory;
      });
  }


  /**
   * calls from template
   * when user choose a new account logo
   *
   * @param accountImageInput with type `HTMLInputElement`
   *
   * @return `null`
   */
  onChangeAccountImage(accountImageInput: HTMLInputElement) {
    // get choosed image
    let accountNewImage: File = accountImageInput.files[0];

    // check image extension
    let isValidExtension = this.utilSrv.checkImageExtension(accountNewImage);

    if (isValidExtension) {
      // uplaod in case validity
      let accountLogoForm = new FormData();
      accountLogoForm.append('file', accountNewImage);
      this.accountsSrv.changeAccountLogo(accountLogoForm, this.accountId)
        .subscribe(response => {
          if (response) {
            this.changeAccountLogo();
          }
        })
    }
  }

  /**
   * calls from template
   * when user type account name
   *
   * @param accountName is a new typed account name
   *
   * @return `null`
   */
  onChangeAccountName(accountName: string) {
    if (accountName && accountName !== this.account.accountName) {
      this.typedAccountName = accountName;
      this.updateAccountInfo();
    }
  }

  /**
   * calls from template
   * when user type company name
   *
   * @param companyName is a new typed company name
   *
   * @return `null`
   */
  onChangeCompanyName(companyName: string) {

    if (companyName && companyName !== this.account.company) {
      this.typedCompanyName = companyName;
      this.updateAccountInfo();
    }
  }

  /**
   * calls when changed account name or company name
   *
   * send request to the server for a update account info
   *
   * @param null
   *
   * @return `null`
   */
  updateAccountInfo() {
    let accountInfo: AccountUpdateRequest = {
      accountName: this.typedAccountName,
      company: this.typedCompanyName
    }
    this.accountsSrv.updateAccoutById(accountInfo, this.account.id)
      .subscribe(updatedAccount => {
        this.storageSrv.currentUserAccounts.every((account, index) => {
          if (account.id === this.account.id) {
            this.storageSrv.currentUserAccounts[index] = updatedAccount;
            this.account = this.storageSrv.currentUserAccounts[index];
            this.typedAccountName = this.account.accountName;
            this.typedCompanyName = this.account.company;
            return false;
          }
          return true;

        });

        if (this.storageSrv.currentAccount.id === +this.account.id) {
          this.storageSrv.currentAccount = updatedAccount;
        }
      },
        error => {
          this.typedAccountName = this.account.accountName;
          this.typedCompanyName = this.account.company;
          this.sharedSrv.errorDialog(error.error.message);
        })

  }

}
