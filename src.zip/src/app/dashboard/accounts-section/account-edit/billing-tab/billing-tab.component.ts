import { Component, OnInit, ViewChild, ElementRef, ChangeDetectorRef, Input, OnDestroy, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { environment } from 'src/environments/environment';
import { MatSelectChange } from '@angular/material/select';
import { MatTable } from '@angular/material/table';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AccountUpdateFailedEvent } from 'src/app/shared/events/account-update-failed.event';
import { MatPaginatorModule } from '@angular/material/paginator';
import { debounceTime } from 'rxjs/operators';
import { ArraySortPipe } from 'src/app/shared/pipes/sorted.pipe';
import { TranslateService } from '@ngx-translate/core';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';
import { phoneValidator } from 'src/app/shared/utils/phone-validator';

import { StripeFactoryService, StripeInstance, StripeCardComponent } from 'ngx-stripe';
import { StripeCardElementOptions, StripeElementsOptions } from '@stripe/stripe-js';

import { Subscription } from 'src/app/shared/models/subscription-models/subscription.model';
import { StripeChangeEvent } from 'src/app/shared/models/common-models/stripe-change-event.model';
import { BillingInfo } from 'src/app/shared/models/billing-models/billing-info.model';
import { Country } from 'src/app/shared/models/common-models/country.model';
//import { BillingRequest } from 'src/app/shared/models/requests-models/billing-create-update.model';
import { BillingUpdateRequest } from 'src/app/shared/models/requests-models/billing-update.model';
import { Account } from 'src/app/shared/models/account-models/account.model';
import { DefaultDialogInputData } from 'src/app/shared/models/common-models/default-dialog-input-data.model';
import { BillingEstimate } from 'src/app/shared/models/billing-models/billing-estimate.model';
import { BillingHistory } from 'src/app/shared/models/billing-models/billing-history.model';
import { Pagination } from 'src/app/shared/models/common-models/pagination.model';

import { UtilService } from 'src/app/shared/services/util.service';
import { SubscriptionsService } from 'src/app/shared/services/subscriptions.service';
import { LocalRequestsService } from 'src/app/shared/services/local-requests.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { AccountsService } from 'src/app/shared/services/accounts.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { BillingService } from 'src/app/shared/services/billing.service';

import { BillingPlanIntervalChangeComponent } from 'src/app/shared/components/billing-plan-interval-change/billing-plan-interval-change.component';

@Component({
  selector: 'app-billing-tab',
  templateUrl: './billing-tab.component.html',
  styleUrls: ['./billing-tab.component.scss']
})
export class BillingTabComponent implements OnInit, OnDestroy, OnChanges {

  billingForm: FormGroup;
  billingFormSubmitted: boolean = false;

  //billingHistoryPageSize = 10;
  //billingHistoryPage = 0;
  //views = [450, 200];

  // coming from parent component
  @Input() account: Account;
  //@Input() accountBilling: BillingInfo;
  //@Input() accountSubscription: Subscription;
  //@Output() accountBillingChange: EventEmitter<BillingInfo> = new EventEmitter();
  //@Input() billEstimate: BillingEstimate;
  //@Input() billHistory: BillingHistory[];

  accountBilling: BillingInfo;
  billEstimate: BillingEstimate;
  billHistory: BillingHistory[] = [];
  billHistoryPaginate: Pagination = { count: 0, limit: 0, next: '', offset: 0 };
  accountSubscription: Subscription;

  @ViewChild(MatTable) billHistoryTable: MatTable<BillingHistory>;

  // store the subscriptionPlans
  subscriptions: Subscription[];

  // stripe card html element
  //@ViewChild('cardInfo', { static: true }) cardInfo: ElementRef;

  @ViewChild(StripeCardComponent) card: StripeCardComponent;
  stripe: StripeInstance;

  cardOptions: StripeCardElementOptions = {
    style: {
      base: {
        iconColor: '#666EE8',
        color: '#31325F',
        fontWeight: '300',
        fontFamily: 'Montserrat, sans-serif',
        fontSize: '18px',
        '::placeholder': {
          color: '#525252'
        }
      }
    },
    hidePostalCode: true
  };
  elementsOptions: StripeElementsOptions = {
    locale: 'en'
  };

  // stripe card
  // card: any;
  // card data haldler
  cardHandler = this.onHandleStripeErrors.bind(this);
  // stores the card error text
  error: string;
  // store the status of stripe form complition
  isCompleteStripeForm: boolean;
  // store the getted countries list
  countries: Country[] = [];
  // points out should create or update billing account info
  isBillinAccountExists: boolean = false;
  serviceEventListener = null;
  // pie chart color scheme
  colorScheme: {domain:['#d784b5', '#f08b39', '#e52b62', '#ef503c']}
  collectionMethod: { label: string; value: string; }[] = [
    { label: 'Charge Automatically', value: 'charge_automatically' },
    { label: 'Send Invoice', value: 'send_invoice' }
  ];

  transNotice: string = '';
  transNoticeDesc: string = '';
  transInvalidCard: string = '';
  transBillingChanges: string = '';
  transBillingChangesDesc: string = '';
  transOrgChanges: string = '';
  transOrgChanges2: string = '';
  transSuccess: string = '';
  transBillingDetails: string = '';
  transErrorBillingDetails: string = '';
  transCancelSub: string = '';
  transConfirmCancelSub: string = '';
  transNo: string = '';
  transYes: string = '';
  transYesCancel: string = '';
  transNoTrialPeriod: string = '';
  transContinue: string = '';
  transNevermind: string = '';
  transConfirm: string = '';
  transPaymentError: string = '';
  transReactivateAcc: string = '';
  transReactivateAccDesc: string = '';

  constructor(
    public translate: TranslateService,
    public utilSrv: UtilService,
    private cd: ChangeDetectorRef,
    private fb: FormBuilder,
    private subscriptionsSrv: SubscriptionsService,
    private sharedSrv: SharedService,
    private accountSrv: AccountsService,
    private localRequestsSrv: LocalRequestsService,
    private storageSrv: StorageService,
    private billingSrv: BillingService,
    private stripeFactory: StripeFactoryService
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    if (window.document.location.host === "dev.rocketscreens.com" || window.document.location.host === "localhost:8000"){
      this.stripe = this.stripeFactory.create(environment.stripeTest);
    } else {
      this.stripe = this.stripeFactory.create(environment.stripe);
    }

    this.tsTranslations();

    this.generateBillingForm();
    this.loadSubscriptions();
    this.getCountries();

    // subscribe to account error event to toggle enable.disable of button
    this.serviceEventListener = this.sharedSrv.accountFailed.subscribe({
      next: (event: AccountUpdateFailedEvent) => {
        this.billingFormSubmitted = false;
      }
    });

  }

  ngOnChanges(changes: SimpleChanges) {

    for(const changePropName in changes) {
      if(changes.hasOwnProperty(changePropName)) {
        switch(changePropName) {
          case 'account': {
            if(Object.keys(this.account).length > 0 && this.account.constructor === Object) {
              this.getAccountBilling();
              this.getAccountBillEstimate();
              this.getAccountBillHistory();
            }
          }
        }
      }
    }
  }

  ngOnDestroy() {
    // destroy the cart when destroys the component
    // To Do check ngx-stripe on how to destroy this.card.
    // this.card.destroy();
  }

  tsTranslations() {
    this.translate.get('BILLINGTAB.NOTICE').subscribe((string) => {
      this.transNotice = string;
    });
    this.translate.get('BILLINGTAB.NOTICEDESC').subscribe((string) => {
      this.transNoticeDesc = string;
    });
    this.translate.get('BILLINGTAB.INVALIDCARD').subscribe((string) => {
      this.transInvalidCard = string;
    });
    this.translate.get('BILLINGTAB.BILLINGCHANGES').subscribe((string) => {
      this.transBillingChanges = string;
    });
    this.translate.get('BILLINGTAB.BILLINGCHANGESDESC').subscribe((string) => {
      this.transBillingChangesDesc = string;
    });
    this.translate.get('BILLINGTAB.ORGCHANGES').subscribe((string) => {
      this.transOrgChanges = string;
    });
    this.translate.get('BILLINGTAB.ORGCHANGES2').subscribe((string) => {
      this.transOrgChanges2 = string;
    });
    this.translate.get('BILLINGTAB.SUCCESS').subscribe((string) => {
      this.transSuccess = string;
    });
    this.translate.get('BILLINGTAB.BILLINGDETAILS').subscribe((string) => {
      this.transBillingDetails = string;
    });
    this.translate.get('BILLINGTAB.ERRORBILLINGDETAILS').subscribe((string) => {
      this.transErrorBillingDetails = string;
    });
    this.translate.get('BILLINGTAB.CANCELSUBSCRIPTION').subscribe((string) => {
      this.transCancelSub = string;
    });
    this.translate.get('BILLINGTAB.CONFIRMCANCELSUBSCRIPTION').subscribe((string) => {
      this.transConfirmCancelSub = string;
    });
    this.translate.get('BILLINGTAB.NO').subscribe((string) => {
      this.transNo = string;
    });
    this.translate.get('BILLINGTAB.YES').subscribe((string) => {
      this.transYes = string;
    });
    this.translate.get('BILLINGTAB.YESCANCEL').subscribe((string) => {
      this.transYesCancel = string;
    });
    this.translate.get('BILLINGTAB.NOTRIALPERIOD').subscribe((string) => {
      this.transNoTrialPeriod = string;
    });
    this.translate.get('BILLINGTAB.CONTINUE').subscribe((string) => {
      this.transContinue = string;
    });
    this.translate.get('BILLINGTAB.NEVERMIND').subscribe((string) => {
      this.transNevermind = string;
    });
    this.translate.get('BILLINGTAB.CONFIRM').subscribe((string) => {
      this.transConfirm = string;
    });
    this.translate.get('BILLINGTAB.PAYMENTERROR').subscribe((string) => {
      this.transPaymentError = string;
    });
    this.translate.get('BILLINGTAB.REACTIVATEACC').subscribe((string) => {
      this.transReactivateAcc = string;
    });
    this.translate.get('BILLINGTAB.REACTIVATEACCDESC').subscribe((string) => {
      this.transReactivateAccDesc = string;
    });
  }

  /**
   * prepare `billingForm` for a billing update request
   * @param null
   * @return `null`
   */
  prepareFormForBillingUpdate() {
    // change property value to true for a update billing info
    // when user clicked on the update button
    this.isBillinAccountExists = true;

    // set billing info into form
    this.billingForm.patchValue(this.accountBilling);
    this.billingForm.get('billingName').markAsTouched();
    this.billingForm.get('billingEmail').markAsTouched();
    this.billingForm.get('billingPhone').markAsTouched();
    this.billingForm.get('billingAddressLine1').markAsTouched();
    this.billingForm.get('billingAddressCountry').markAsTouched();
    this.billingForm.get('billingAddressState').markAsTouched();

    this.addPhoneNumberPrefix();

    // set subscription id into form
    this.billingForm.get('subscription').patchValue(this.accountSubscription?.id);

    // update formControl validators
    this.billingForm.get('billingEmail').updateValueAndValidity();

    this.billingForm.get('physicalLicenses').patchValue(this.accountBilling.numPhysicalLicenses);
    this.billingForm.get('virtualLicenses').patchValue(this.accountBilling.numVirtualLicenses);
    this.billingForm.get('recipientLicenses').patchValue(this.accountBilling.numStreamLicenses);
    this.billingForm.get('webLicenses').patchValue(this.accountBilling.numWebLicenses);


    //mark these fields with errors immediately
    if (this.accountBilling.billingAddressLine1 == null ||
      this.accountBilling.billingAddressLine1 === ""){
      this.billingForm.get('billingAddressLine1').markAsDirty();
      this.billingForm.get('billingAddressLine1').markAsTouched();
      this.billingForm.get('billingAddressLine1').setErrors({'required': true});
    }

    if (this.accountBilling.billingAddressCountry == null ||
      this.accountBilling.billingAddressCountry === ""){
      this.billingForm.get('billingAddressCountry').markAsDirty();
      this.billingForm.get('billingAddressCountry').markAsTouched();
      this.billingForm.get('billingAddressCountry').setErrors({'required': true});
    }

    if (this.accountBilling.billingAddressState == null ||
      this.accountBilling.billingAddressState === ""){
      this.billingForm.get('billingAddressState').markAsDirty();
      this.billingForm.get('billingAddressState').markAsTouched();
      this.billingForm.get('billingAddressState').setErrors({'required': true});
    }

    if (this.accountBilling.billingPhone == null ||
      this.accountBilling.billingPhone === ""){
      this.billingForm.get('billingPhone').markAsDirty();
      this.billingForm.get('billingPhone').markAsTouched();
      this.billingForm.get('billingPhone').setErrors({'required': true});
    }

    if (this.accountBilling.billingEmail == null ||
      this.accountBilling.billingEmail === ""){
      this.billingForm.get('billingEmail').markAsDirty();
      this.billingForm.get('billingEmail').markAsTouched();
      this.billingForm.get('billingEmail').setErrors({'required': true});
    }

    // if (this.accountBilling.billingName == null || this.accountBilling.billingName.trim().length == 0){
    if (this.accountBilling.billingName == null ||
      this.accountBilling.billingName === ""){
      this.billingForm.get('billingName').markAsDirty();
      this.billingForm.get('billingName').markAsTouched();
      this.billingForm.get('billingName').setErrors({'required': true});
    }

  }

  /**
   * prepare `billingForm` for a billing creation request
   * @param null
   * @return `null`
   */
  prepareFormForBillingCreation() {
    // in this case billing info not exists
    // and should change property value to false
    this.isBillinAccountExists = false;
    // fix first time error
    // ngOnChanges calls before billingForm initialization
    if (this.billingForm) {
      // reset previous selected account form fields
      this.billingForm.reset();
      // set email validators
      this.billingForm.get('billingEmail').setValidators([Validators.required, Validators.email, removeWhitespaceValidator]);
      // update formControl validators
      this.billingForm.get('billingEmail').updateValueAndValidity();
    }
  }

  /**
   * generate `billingForm`
   * @param null
   * @return `null`
   */
  generateBillingForm() {
    this.billingForm = this.fb.group({
      subscription: ['', Validators.required],
      billingName: ['', [Validators.required, removeWhitespaceValidator]],
      billingEmail: ['', [Validators.required, Validators.email, removeWhitespaceValidator]],
      billingPhone: ['', [Validators.required, removeWhitespaceValidator, phoneValidator]],
      billingAddressLine1: ['', [Validators.required, removeWhitespaceValidator]],
      billingAddressLine2: '',
      billingAddressPostalCode: '',
      billingAddressCity: '',
      billingAddressState: ['', [Validators.required, removeWhitespaceValidator]],
      billingAddressCountry: ['', [Validators.required, removeWhitespaceValidator]],
      stripeToken: '',
      physicalLicenses: [''],
      virtualLicenses: [''],
      recipientLicenses: [''],
      webLicenses: [''],
      collectionMethod: ['']
    });
  }

  loadSubscriptions(){
    this.subscriptionsSrv.getSubscriptions()
      .subscribe(subscriptions => {
        if(subscriptions) {
          this.subscriptions = subscriptions;
          if (this.accountBilling && this.accountSubscription){
            // check if already in list of subscriptions
            var found = false;
            for (var i = 0; i < this.subscriptions.length; i++){
              if (this.subscriptions[i].id == this.accountSubscription.id){
                found = true;
                break;
              }
            }
            if (!found){
              this.subscriptions.push(this.accountSubscription);
            }
          }
        }
      });
  }

  /**
   * get country list from json
   * @param null
   * @return `null`
   */
  getCountries() {
    this.localRequestsSrv.getCountries().subscribe(countries => {
      if (countries) {
        this.countries = countries;
      }
    });
  }

  /**
  * calls every time on type card info
  * @param null
  * @return `null`
  */
  generateStripe() {
    // To do - migrate to ngx-stripe approach.
    // first destroy if card already exists
    // if (this.card) {
    //   this.card.destroy();
    // }
    // const style = {
    //   base: {
    //     fontFamily: 'Montserrat, sans-serif',
    //     fontSmoothing: 'antialiased',
    //     fontSize: '17px'
    //   }
    // };
    // create card
    // this.card = elements.create('card', {
    //   style: style,
    //   hidePostalCode: true,
    // });
    // if (this.cardInfo) {
    //   this.card.mount(this.cardInfo.nativeElement);
    //   this.card.addEventListener('change', this.cardHandler);
    // }
  }

  /**
   * calls every time on type card info
   * @param stripeHandler with type `StripeChangeEvent`
   * @return `null`
   */
  onHandleStripeErrors(stripeHandler: StripeChangeEvent) {
    // show error message if card info is invalid
    if (stripeHandler.error) {
      this.error = stripeHandler.error.message;
    } else {
      // remove errors
      this.error = null;
    }
    // store the compleate status into property
    this.isCompleteStripeForm = stripeHandler.complete;
    // manualy update view
    // need for a corectly show error messages
    this.cd.detectChanges();
  }

  /**
   * calls from template
   * check selected subscription plan
   * disabled button when he choose payable subscription plan
   * but stripe form is incomplete
   * @param null
   * @return `boolean`
   */
  isValidStripForm() {
    let invalid = false;
    // just abbreviate property name
    let selectedSubP = this.accountSubscription;

    if (selectedSubP) {
      if (this.isBillinAccountExists && this.accountSubscription.id === selectedSubP.id) {
        invalid = false;
      } else if (this.isCompleteStripeForm) {
        invalid = false;
      } else {
        invalid = true;
      }
    }
    return invalid;
  }

  /**
   * calls from template
   * when user clicked on the update button
   *
   * check form validity status
   * call `createBillingContact` or `updateBillingContact` depends on
   * `isBillinAccountExists` value
   * @param null
   * @return `null`
   */
  onSubmitBillingForm() {
    if (this.billingForm.valid) {
      if (this.isBillinAccountExists) {
        this.updateBillingContact();
      } else {
        this.createBillingContact();
      }
    } else {
      // just only in case of
      // if user removes disabled attribut from button in html
      this.sharedSrv.openDialog(
        {
          title: this.transNotice,
          description: this.transNoticeDesc,
          template: 1
        },
        false,
        { width: '30%' }
      );
    }
  }

  /**
   * send request to the server for a create account billing contact
   * @param null
   * @return `null`
   */
  createBillingContact() {
    this.billingFormSubmitted = true;
    this.stripe
      .createToken(this.card.element)
      .subscribe((response) => {
        if (response.token) {
          // Use the token
          this.billingForm.get('stripeToken').patchValue(response.token.id);
          let billingInfo: BillingUpdateRequest = this.billingForm.getRawValue() as BillingUpdateRequest;

          this.billingSrv.updateBillingInfo(
            this.account.id,
            billingInfo
          )
            .subscribe(updatedBillingInfo => {
              this.accountBilling = updatedBillingInfo;
              this.getAccountBillEstimate();
              this.getAccountBillHistory();
              this.billingFormSubmitted = false;
              this.storageSrv.currentAccountBilling = this.accountBilling;
              this.storageSrv.updateProfessional();
            });

        } else if (response.error) {
          // Error creating the token
          let dialogInputData: DefaultDialogInputData = {
            title: this.transPaymentError,
            description: response.error.message,
            template: 1,
            confirm: 'ok'
          }
          this.sharedSrv.openDialog(dialogInputData, false, { minWidth: '300px', width: '30px' });
          this.billingFormSubmitted = false;
        }
      });
  }

  /**
   * send request to the server for update account billing contact
   * @param null
   * @return `null`
   */
  updateBillingContact() {
    if (!this.card){
      // do nothing
      this.sharedSrv.errorDialog(this.transInvalidCard);
      return;
    }

    var showTrialEndMessage = false;
    if (showTrialEndMessage){
      this.sharedSrv.openDialog(
        {
          title: this.transBillingChanges,
          description: this.transBillingChangesDesc,
          template: 0,
          confirm: this.transContinue,
          cancel: this.transNevermind
        },
        true
      ).subscribe(response => {
        // change url to link
        if (response.continue){
          this.readFormValuesForSubmission();
        } else {
          this.billingFormSubmitted = false;
        }
      });
    } else {
      this.readFormValuesForSubmission();
    }
  }

  readFormValuesForSubmission(){
    // if subscription tier is changed or if annual and number of licenses has changed
    if (this.billingForm.get('subscription').value != this.accountSubscription.id ||
      (this.accountSubscription.interval==='year' &&
        (this.billingForm.get('physicalLicenses').value != this.accountBilling.numPhysicalLicenses ||
        this.billingForm.get('virtualLicenses').value != this.accountBilling.numVirtualLicenses ||
        this.billingForm.get('recipientLicenses').value != this.accountBilling.numStreamLicenses ||
        this.billingForm.get('webLicenses').value != this.accountBilling.numWebLicenses))) {
      var description = this.transOrgChanges;
      if (this.accountSubscription.interval==='year'){
        description = this.transOrgChanges2;
      }
      this.sharedSrv.openDialog(
        {
          title: this.transBillingChanges,
          description: description,
          template: 0,
          confirm: this.transConfirm,
          cancel: this.transNevermind
        },
        true
        ).subscribe(response => {
          // change url to link
          if (response.continue){
            this.submitBillingUpdate();
          } else {
            this.billingFormSubmitted = false;
          }
      });
    } else {
      this.submitBillingUpdate();
    }
  }

  submitBillingUpdate(){
    this.billingFormSubmitted = true;
    if (this.card.stripeElementRef.nativeElement.classList.value.indexOf("StripeElement--empty") == -1){
      this.stripe
        .createToken(this.card.element)
        .subscribe((response) => {
          if (response.token) {
            this.billingForm.get('stripeToken').patchValue(response.token.id);
            let billingInfo: BillingUpdateRequest = this.billingForm.getRawValue() as BillingUpdateRequest;
            this.updateBillingInfo(billingInfo);
          } else if (response.error) {
            // Error creating the token
            let dialogInputData: DefaultDialogInputData = {
              title: this.transErrorBillingDetails,
              description: response.error.message,
              template: 1,
              confirm: 'ok'
            }
            this.sharedSrv.openDialog(dialogInputData, false, { minWidth: '300px', width: '30px' });
            this.billingFormSubmitted = false;
          }
        });
    } else {
      // otherwise do default
      // need to reset stripe to empty token
      this.billingForm.get('stripeToken').patchValue('');
      let billingInfo: BillingUpdateRequest = this.billingForm.getRawValue() as BillingUpdateRequest;
      this.updateBillingInfo(billingInfo);
    }
  }

  updateBillingInfo(billingInfo: BillingUpdateRequest) {
    this.billingSrv.updateBillingInfo(
      this.account.id,
      billingInfo
    )
      .subscribe(updatedBillingInfo => {
        if (updatedBillingInfo){
          let dialogInputData: DefaultDialogInputData = {
            title: this.transSuccess,
            description: this.transBillingDetails,
            template: 1,
            confirm: 'ok'
          };
          this.sharedSrv.openDialog(dialogInputData, false, { minWidth: '300px', width: '30px' });
          this.accountBilling = updatedBillingInfo;
          this.getAccountBillEstimate();
          this.getAccountBillHistory();
          this.storageSrv.currentAccountBilling = this.accountBilling;
          this.storageSrv.updateProfessional();
        }
        this.billingFormSubmitted = false;
      });
  }

  onCancelSubscription() {
    this.sharedSrv.openDialog(
      {
        title: this.transCancelSub,
        description: this.transConfirmCancelSub,
        cancel: this.transNo,
        confirm: this.transYesCancel,
        template: 0
      },
      true
    )
      .subscribe(response => {
        if (response.continue) {
          this.confirmCancelSubscription();
        }
      });
  }

  confirmCancelSubscription() {
    this.billingSrv.cancelSubscription(
      this.account.id
    )
      .subscribe(updatedBillingInfo => {
        if (updatedBillingInfo) {
          this.accountBilling = updatedBillingInfo;
          this.billEstimate = null;
          this.storageSrv.currentAccountBilling = this.accountBilling;

          //I think we don't need to pull these info.
          //this.getAccountBillHistory();
          //this.getAccountSubscription();
          //this.storageSrv.updateProfessional();
        }
      });
  }

  dateFormat(epoch){
    let d = new Date(epoch);
    let day: number = d.getDate();
    let monthNum: number = d.getMonth();
    let year: number = d.getFullYear();
    let months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    return months[monthNum] + " " + day + ", " + year;
  }

  dollarFormat(num){
    return "$"+ num.toFixed(2);
  }

  dollarFormatMin(num, min){
    if (num < min){
      num = min;
    }
    return this.dollarFormat(num);
  }

  reactivateSubscription(){
    this.sharedSrv.openDialog({
      title: this.transReactivateAcc,
      description: this.transReactivateAccDesc,
      cancel: this.transNo,
      confirm: this.transYes,
      template: 0
    }, true).subscribe(response => {
      if (response.continue) {
        this.confirmActivateSubscription();
      }
    });
  }

  confirmActivateSubscription() {
    this.billingSrv.activateSubscription(
      this.account.id
    )
      .subscribe(updatedBillingInfo => {
        if (updatedBillingInfo) {
          this.accountBilling = updatedBillingInfo;
          this.getAccountSubscription();
          this.getAccountBillEstimate();
          this.getAccountBillHistory();
          this.storageSrv.currentAccountBilling = this.accountBilling;
          this.storageSrv.updateProfessional();
        }
      });
  }

  // pageChangeEvent(pageIndex){
  //   this.billingSrv.retrieveBillingHistory(this.account.id)
  //     .subscribe(results => {
  //       if(results) {
  //         this.billHistory = results;
  //       }
  //     });
  // }

  /**
   * get account billing info by `accountId`
   * @param accountId with type `number` (by default equal to `this.accountId`)
   * @return `null`
   */
  getAccountBilling() {
    this.accountBilling = null;
    this.billingSrv.retrieveBillingInfo(
      this.account.id
    )
      .subscribe(billingInfo => {
        if (billingInfo) {
          this.accountBilling = billingInfo;
          this.getAccountSubscription();
          if (this.accountBilling) {
            this.prepareFormForBillingUpdate();
          } else {
            this.prepareFormForBillingCreation();
          }
        }
      })
  }

  // get estimate for the account
  getAccountBillEstimate(){
    this.billingSrv.retrieveBillingEstimate(
      this.account.id
    )
      .subscribe(billEstimate => {
        if(billEstimate) {
          this.billEstimate = billEstimate;
        }
      });
  }

  // bill history
  getAccountBillHistory(){
    let limit = 10;
    this.billingSrv.retrieveBillingHistory(
      this.account.id,
      limit
    )
      .subscribe(response => {
        if(response) {
          //this.billHistory = billHistory;
          this.billHistory = response.message;
          this.billHistoryPaginate = response.pagination;
          this.billHistoryTable.renderRows();
        }
      });
  }
  getAccountBillHistoryNext() {
    this.billingSrv.retrieveBillHistoryNext(
      this.billHistoryPaginate.next
    )
      .subscribe( response => {
        if(response) {
          if(response.message.length > 0) {
            this.billHistory.push(...response.message);
            this.billHistoryPaginate = response.pagination;
          } else {
            this.billHistoryPaginate['next'] = '';
          }
          this.billHistoryTable.renderRows();
        }
      });
  }

  // Account subscription
  getAccountSubscription() {
    this.billingSrv.getSubscription(this.account.id)
      .subscribe( subscription => {
        if(subscription) {
          this.accountSubscription = subscription;
          this.billingForm.get('subscription').patchValue(subscription?.id);

          // subscriptions might be populated so see if we need to add
          if (this.subscriptions){
            var found = false;
            for (var i = 0; i < this.subscriptions.length; i++){
              if (this.subscriptions[i].id == this.accountSubscription.id){
                found = true;
                break;
              }
            }
            if (!found){
              this.subscriptions.push(this.accountSubscription);
            }
          }
        }
      });
  }

  convertInterval(){
    this.sharedSrv.openDialog(
      {
        subscriptions: this.subscriptions,
        interval: this.accountSubscription.interval,
        tier: this.accountSubscription.tier,
        mode: "interval"
      },
      true,
      null,
      BillingPlanIntervalChangeComponent
    ).subscribe(response => {
      if (response.continue){

        // need to make sure they are aware we might cancel their trial
        let showTrialEndMessage = false;
        let subId = response.outputData["subscriptionId"]
        let selectedSubscription = null;

        this.billingForm.get('subscription').patchValue(subId);

        for (let i = 0; i < this.subscriptions.length; i++){
          if (this.subscriptions[i].id == subId){
            selectedSubscription = this.subscriptions[i];
            break;
          }
        }

        if (!selectedSubscription.hasTrial && this.accountBilling.trialEnd != null){
          showTrialEndMessage = true;
        }

        if (showTrialEndMessage){
          this.sharedSrv.openDialog(
            {
              title: this.transBillingChanges,
              //title: this.transBillingDetails,
              description: this.transNoTrialPeriod,
              template: 0,
              confirm: this.transContinue,
              cancel: this.transNevermind
            },
            true
          )
            .subscribe(confirmResponse => {
              // change url to link
              if (confirmResponse.continue){
                this.billingFormSubmitted = true;
                this.convertToMonthlyPlan(subId);
              }
            });

        } else {
          this.billingFormSubmitted = true;
          this.convertToMonthlyPlan(subId);
        }
      }
    });
  }

  convertToMonthlyPlan(subscriptionId: number) {
    this.billingSrv.convertToMonthlyPlan(
      this.account.id,
      { subscriptionId: subscriptionId }
    )
      .subscribe(updatedBillingInfo => {
        if(updatedBillingInfo) {
          this.accountBilling = updatedBillingInfo;
          this.getAccountSubscription();
          this.getAccountBillEstimate();
          this.getAccountBillHistory();
          this.billingFormSubmitted = false;
          this.storageSrv.currentAccountBilling = this.accountBilling;
          this.storageSrv.updateProfessional();
          this.updateConfirmationDialog("Billing has been updated successfully!");
        }
      });
  }

  convertTier(){
    this.sharedSrv.openDialog(
      {
        subscriptions: this.subscriptions,
        interval: this.accountSubscription.interval,
        tier: this.accountSubscription.tier,
        mode: "tier"
      },
      true,
      null,
      BillingPlanIntervalChangeComponent
    )
      .subscribe(response => {
        if (response.continue){
          // need to make sure they are aware we might cancel their trial
          let showTrialEndMessage = false;
          let subId = response.outputData["subscriptionId"];
          let selectedSubscription = null;

          this.billingForm.get('subscription').patchValue(subId);

          for (var i = 0; i < this.subscriptions.length; i++){
            if (this.subscriptions[i].id == subId){
              selectedSubscription = this.subscriptions[i];
              break;
            }
          }
          if (!selectedSubscription.hasTrial && this.accountBilling.trialEnd != null){
            showTrialEndMessage = true;
          }
          if (showTrialEndMessage){
            this.sharedSrv.openDialog(
              {
                title: this.transBillingChanges,
                //title: this.transBillingDetails,
                description: this.transNoTrialPeriod,
                template: 0,
                confirm: this.transContinue,
                cancel: this.transNevermind
              },
              true
            )
              .subscribe(confirmResponse => {
                // change url to link
                if (confirmResponse.continue){
                  this.billingFormSubmitted = true;
                  this.convertToProPlan(subId);
                }
              });
          } else {
            this.billingFormSubmitted = true;
            this.convertToProPlan(subId);
          }
        }
      });
  }

  convertToProPlan(subscriptionId: number) {
    this.billingSrv.convertToProfessionalPlan(
      this.account.id,
      { subscriptionId: subscriptionId }
    )
      .subscribe(updatedBillingInfo => {
        if(updatedBillingInfo) {
          this.accountBilling = updatedBillingInfo;
          this.getAccountSubscription();
          this.getAccountBillEstimate();
          this.getAccountBillHistory();
          this.billingFormSubmitted = false;
          this.storageSrv.currentAccountBilling = this.accountBilling;
          this.storageSrv.updateProfessional();
          this.updateConfirmationDialog("Billing has been updated successfully!");
        }
      });
  }

  updateConfirmationDialog(dialogMessage) {
    this.sharedSrv.openDialog({
      title: this.transBillingDetails,
      description: dialogMessage,
      template: 1,
      confirm: 'ok'
    }, true).subscribe( response => {

    });
  }

  addPhoneNumberPrefix() {
    let phoneNumber = this.billingForm.get('billingPhone').value;
    if(phoneNumber.length > 2) {
      let first2 = phoneNumber.slice(0, 2);
      if(!phoneNumber.includes('+', 0)) {
        this.billingForm.get('billingPhone').patchValue('+1'+phoneNumber);
      }
    }
  }

}
