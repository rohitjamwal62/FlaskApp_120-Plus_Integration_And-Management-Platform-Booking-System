import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeManagementTabComponent } from './change-management-tab.component';

describe('ChangeManagementTabComponent', () => {
  let component: ChangeManagementTabComponent;
  let fixture: ComponentFixture<ChangeManagementTabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChangeManagementTabComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeManagementTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
