import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { AccountsService } from 'src/app/shared/services/accounts.service';

import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { AccountFeaturesFlags } from 'src/app/shared/models/account-models/account-features-flags.model';

@Component({
  selector: 'app-change-management-tab',
  templateUrl: './change-management-tab.component.html',
  styleUrls: ['./change-management-tab.component.scss']
})
export class ChangeManagementTabComponent extends CleanOnDestroy implements OnInit {

  currentLocale: any = '';
  currentWorkspace: Workspace;
  currentWorkspaceId: number;
  featuresFlags: AccountFeaturesFlags[];
  featuresForm: FormGroup;

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private router: Router,
    private storageSrv: StorageService,
    private accountsSrv: AccountsService,
    private fb: FormBuilder,
  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit(): void {
    this.currentLocale = this.utilSrv.locale;
    this.generateFeaturesForm();
    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe(workspace => {
        if(workspace) {
          this.currentWorkspace = workspace;
          this.getAccountFeaturesFlags();
        }
      });
    // this.subscriber = this.storageSrv.currentWorkspaceSubject
    //   .subscribe( workspaceId => {
    //     if(workspaceId) {
    //       this.currentWorkspaceId = Number(workspaceId);
    //       this.getAccountFeaturesFlags();
    //     }
    //   });
  }

  generateFeaturesForm() {
    this.featuresForm = this.fb.group({});
  }

  patchFeaturesForm() {
    this.featuresFlags.forEach( flag => {
      (this.featuresForm as FormGroup).setControl(
        flag.key,
        this.fb.control(flag.value, [])
      );
    });
  }

  getAccountFeaturesFlags() {
    this.subscriber = this.accountsSrv.retrieveFeaturesFlags(
      this.currentWorkspace.account.id
    )
      .subscribe( featuresFlags => {
        if(featuresFlags) {
          this.featuresFlags = featuresFlags;
          this.patchFeaturesForm();
        }
      });
  }

  onToggleSlideField(event, flagKey: string) {
    console.log('onToggleSlideField', event, flagKey);
    this.setFeaturesFlag(flagKey, event);
  }

  setFeaturesFlag(flagKey: string, flagValue: boolean) {
    let storeFlagVal:boolean = (flagValue) ? false : true;
    this.subscriber = this.accountsSrv.setFeaturesFlags(
      this.currentWorkspace.account.id,
      { key: flagKey, value: flagValue }
    )
      .subscribe( flag => {
        if(flag) {
          // Do nothing
        }
      }, 
      err => {
        this.featuresForm.get(flagKey).patchValue(storeFlagVal);
      });
  }

}
