import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { TranslateService } from '@ngx-translate/core';

import { UserBasic } from 'src/app/shared/models/user-models/user-basic.model';
import { UserBasicV3 } from 'src/app/shared/models/user-models/user-basic-v3.model';

import { UserPersonal } from 'src/app/shared/models/user-models/user-personal.model';
import { Account } from 'src/app/shared/models/account-models/account.model';
import { InvitationSendRequest } from 'src/app/shared/models/requests-models/invitation-send.model';
import { AccountInvitation } from 'src/app/shared/models/account-models/account-invitation.model';
import { AccountInvitationV3 } from 'src/app/shared/models/account-models/account-invitation-v3.model';
import { AccountGroup } from 'src/app/shared/models/account-models/account-group.model';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { WorkspaceV3 } from 'src/app/shared/models/workspace-models/workspace-v3.model';
import { WorkspaceRole } from 'src/app/shared/models/workspace-models/workspace-role.model';
import { Pagination } from 'src/app/shared/models/common-models/pagination.model';

import { UtilService } from 'src/app/shared/services/util.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { InvitationsService } from 'src/app/shared/services/invitations.service';
import { AccountsService } from 'src/app/shared/services/accounts.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { WorkspacesService } from 'src/app/shared/services/workspaces.service';

import { InviteMemberComponent } from 'src/app/shared/components/invite-member/invite-member.component';


@Component({
  selector: 'app-users-tab',
  templateUrl: './users-tab.component.html',
  styleUrls: ['./users-tab.component.scss']
})
export class UsersTabComponent extends CleanOnDestroy implements OnInit, OnChanges {

  accountWorkspaces: WorkspaceV3[];

  accountUsers: UserBasicV3[];
  accountUsersPaginate: Pagination;
  
  accountRoles: WorkspaceRole[] = [];

  accountInvitations: AccountInvitationV3[];
  accountInvitationsPaginate: Pagination;

  @Input() account: Account;
  @Input() accountLogoEndpoint: string;

  currentAccount: Account;
  currentWorkspace: WorkspaceV3;
  currentWorkspaceId: number;

  //accountRolesByUsersIds: {[key:number]: WorkspaceRole } = {};

  isCurrentUserAdmin = false;
  transDeleteWorkspace: string = '';
  transDeleteWorkspaceTitle: string = '';
  transResendInvite: string = '';
  transResendInviteDesc: string = '';
  transDeleteInvite: string = '';
  transDeleteInviteDesc: string = '';
  confirmString: string = '';
  cancelString: string = '';

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private sharedSrv: SharedService,
    private invitationsSrv: InvitationsService,
    private accountsSrv: AccountsService,
    private storageSrv: StorageService,
    private workspacesSrv: WorkspacesService
  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.tsTranslations();

    this.subscriber = this.storageSrv.currentWorkspaceSubject
      .subscribe( workspaceId => {
        if(workspaceId) {
          // Converting string workspace id from localstorage.
          this.currentWorkspaceId = Number(workspaceId);
        }
      });

  }

  ngOnChanges(changes: SimpleChanges) {
    for(const changePropName in changes) {
      if(changes.hasOwnProperty(changePropName)) {
        switch(changePropName) {
          case 'account': {
            if(Object.keys(this.account).length > 0 && this.account.constructor === Object) {
              this.subscriber = this.storageSrv.currentWorkspaceSubject
                .subscribe( workspaceId => {
                  if(workspaceId) {
                    this.currentWorkspaceId = Number(workspaceId);
                    this.getAccountUsers();
                    //this.getWorkspaceRoles();
                    this.getAccountInvitations();
                  }
                });
            }
          }
          case 'accountLogoEndpoint': {
            
          }
        }
      }
    }
  }

  tsTranslations() {
    this.translate.get('USERSTAB.DELETEWORKSPACE').subscribe((string) => {
      this.transDeleteWorkspace = string;
    });
    this.translate.get('USERSTAB.DELETEMEMBER').subscribe((string) => {
      this.transDeleteWorkspaceTitle = string;
    });
    this.translate.get('USERSTAB.RESENDINVITATION').subscribe((string) => {
      this.transResendInvite = string;
    });
    this.translate.get('USERSTAB.RESENDINVITEDESC').subscribe((string) => {
      this.transResendInviteDesc = string;
    });
    this.translate.get('USERSTAB.DELETEINVITE').subscribe((string) => {
      this.transDeleteInvite = string;
    });
    this.translate.get('USERSTAB.DELETEINVITEDESC').subscribe((string) => {
      this.transDeleteInviteDesc = string;
    });
    this.translate.get('CONFIRMBUTTON').subscribe((string) => {
      this.confirmString = string;
    });
    this.translate.get('CANCELBUTTON').subscribe((string) => {
      this.cancelString = string;
    });
  }

  // mapAccountRoles() {
  //   this.accountRolesByUsersIds = {};
  //   this.accountRoles.forEach( role => {
  //     if(role.members.length > 0) {
  //       role.members.forEach( member => {
  //         this.accountRolesByUsersIds[member.id] = role;
  //       });
  //     }
  //   })
  // }

  /**
   * get account users by `accountId`
   * @param accountId with type `number` (by default equal to `this.accountId`)
   * @return `null`
   */
  getAccountUsers() {
    this.accountUsers = [];
    this.accountsSrv.retrieveAccountUsers(
      this.account.id
    )
      .subscribe(response => {
        if (response.message) {
          this.accountUsers = response.message;
          this.accountUsersPaginate = response.pagination;
          this.checkIsAdmin();
        }
      })
  }

  getAccountUsersNext() {
    this.accountsSrv.getAccountUsersNext(
      this.accountUsersPaginate.next
    )
      .subscribe( response => {
        if(response) {
          if(response.message.length > 0) {
            this.accountUsers.push(...response.message);
            this.accountUsersPaginate = response.pagination;
          } else {
            this.accountUsersPaginate['next'] = '';
          }
          this.checkIsAdmin();
        }
      });
  }

  /*
  * get account invitations by accountId
  */
  getAccountInvitations() {
    this.invitationsSrv.retrieveInvitations(
      this.account.id
    )
      .subscribe( response => {
        if(response.message) {
          this.accountInvitations = response.message;
          this.accountInvitationsPaginate = response.pagination;
        }
      });
  }

  getAccountInvitationsNext() {
    this.invitationsSrv.getAccountInvitationsNext(
      this.accountInvitationsPaginate.next
    )
      .subscribe( response => {
        if(response) {
          if(response.message) {
            this.accountInvitations.push(...response.message);
            this.accountInvitationsPaginate = response.pagination;
          } else {
            this.accountInvitationsPaginate['next'] = '';
          }
        }
      });
  }

  /**
   * check the current user role for the current account
   * @param null
   * @return `number`
   */
  // checkIsAdmin() {
  //   this.accountRoles.forEach(accountRole => {
  //     if (accountRole.name === 'Admin') {
  //       accountRole.members.some(member => {
  //         if (member.id === this.storageSrv.currentUserInfo.id) {
  //           this.isCurrentUserAdmin = true;
  //         }
  //         return this.isCurrentUserAdmin;
  //       });
  //     }
  //   });
  // }
  checkIsAdmin() {
    for(let key in this.accountUsers) {
      if(this.accountUsers[key].id === this.storageSrv.currentUserInfo.id) {
        this.isCurrentUserAdmin = true;
        break;
      }
    }
  }

  /**
   * calls from template
   * helper for a optimizing *ngFor
   * @param index is a current element index with type `number`
   * @param item is a current element info with type `UserBasic | AccountInvitation`
   * @return `number`
   */
  onTrackById(index: number, item: UserBasic | AccountInvitation) {
    return item.id;
  }

  /**
   * calls from template
   * hide the delete member button on current user item
   * @param memberId is a checked member id (type `number`)
   * @return `boolean`
   *
   */
  onCheckCurrentUser(memberId: number) {
    let currentUser = this.storageSrv.currentUserInfo;
    // check member id with current user Id
    // return false when member id equal to the current user Id
    return currentUser && currentUser.id === memberId;
  }

  onChangeUserRole(user: UserBasicV3) {
    let roleId: number;
    let role: string = (user.isAdmin) ? 'Viewer' : 'Admin';
    this.accountsSrv.updateUser(
      this.account.id,
      user.id,
      { isAdmin: (user.isAdmin) ? false : true }
    ).subscribe(response => {
      if (response) {
        this.getAccountUsers(); 
      }
    })
  }

  // getWorkspaceRoles() {
  //   this.subscriber = this.workspacesSrv.getWorkspaceRoles(
  //     this.account.id,
  //     this.currentWorkspaceId
  //   ).subscribe(roles => {
  //     if(roles) {
  //       this.accountRoles = roles;
  //     }
  //   })
  // }

  /**
   * calls from template
   * when user clicked on the delete button of member options
   * first open dialog for a confirmation
   * after delete user in case of confirm
   * @param memberId is a member id wich should be deleted (type `number`)
   * @return `null`
   */
  onDeleteUser(memberId: number) {
    if (
      this.isCurrentUserAdmin &&
      memberId !== this.storageSrv.currentUserInfo.id
    ) {
      this.subscriber = this.sharedSrv.openDialog(
        {
          title: this.transDeleteWorkspace,
          description: this.transDeleteWorkspaceTitle,
          confirm: this.confirmString,
          cancel: this.cancelString,
          template: 0
        }, 
        true, 
        { width: '45%' }
      ).subscribe(response => {
        if (response.continue) {
          this.accountsSrv.removeUserFromAccount(
            this.account.id,
            memberId
          )
            .subscribe(response => {
              if (response) {
                let memberIndex: number;
                this.accountUsers.every((member, index) => {
                  if (member.id === memberId) {
                    memberIndex = index;
                    return false;
                  }
                  return true
                })
                this.accountUsers.splice(memberIndex, 1);
              }
            });
        }
      });
    }

  }

  /**
   * calls from template
   * when user clicked on the invite members button
   * @param null
   * @return `null`
   */
  onInviteMember() {
    this.subscriber = this.sharedSrv.openDialog<AccountInvitationV3>(
      { accountId: this.account.id },
      true,
      { width: '40%' },
      InviteMemberComponent,
    )
      .subscribe(response => {
        if (response.continue) {
          this.accountInvitations.push(response.outputData);
        }
      })
  }

  /**
   * calls from template
   * when user clicked on the resend button of invitation options
   * send request to the server for a resend invitation
   * @param invitationId type `number`
   * @return `null`
   */
  onResendInvitation(invitationId: number) {
    this.subscriber = this.sharedSrv.openDialog(
      {
        title: this.transResendInvite,
        description: this.transResendInviteDesc,
        confirm: 'Confirm',
        cancel: 'No',
        template: 0
      },
      true,
      {
        width: '45%',
      }
    ).subscribe(response => {
      if (response.continue) {
        this.subscriber = this.invitationsSrv.reSendInvitation(
          this.account.id, 
          invitationId
        )
          .subscribe(response => {
            // Do nothing
          });
      }
    });
  }

  /**
   * calls from template
   * when user clicked on the delete button of invitation options
   * send request to the server for a delete invitation
   * @param invitationId type `number`
   * @return `null`
   */
  onDeleteInvitation(invitationId: number, inviteIndex: number) {
    this.subscriber = this.sharedSrv.openDialog(
      {
        title: this.transDeleteInvite,
        description: this.transDeleteInviteDesc,
        confirm: this.confirmString,
        cancel: this.cancelString,
        template: 0
      },
      true,
      {
        width: '45%',
        minWidth: '300px'
      }
    ).subscribe(response => {
      if (response.continue) {
        this.invitationsSrv.deleteInvitation(
          this.account.id,
          invitationId
        )
          .subscribe(response => {
            this.accountInvitations.splice(inviteIndex, 1);
          });
      }
    });
  }

}
