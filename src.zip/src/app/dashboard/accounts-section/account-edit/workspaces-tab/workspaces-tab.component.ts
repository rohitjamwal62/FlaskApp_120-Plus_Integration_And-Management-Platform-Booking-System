import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';

import { StorageService } from 'src/app/shared/services/storage.service';
import { UtilService } from 'src/app/shared/services/util.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { WorkspacesService } from 'src/app/shared/services/workspaces.service';

import { Account } from 'src/app/shared/models/account-models/account.model';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { WorkspaceV3 } from 'src/app/shared/models/workspace-models/workspace-v3.model';
import { UserBasic } from 'src/app/shared/models/user-models/user-basic.model';
import { UserBasicV3 } from 'src/app/shared/models/user-models/user-basic-v3.model';

import { WorkspaceCreateRequest } from 'src/app/shared/models/requests-models/workspace-create.model';

import { WorkspaceNewComponent } from 'src/app/shared/components/workspace-new/workspace-new.component';

@Component({
  selector: 'app-workspaces-tab',
  templateUrl: './workspaces-tab.component.html',
  styleUrls: ['./workspaces-tab.component.scss']
})
export class WorkspacesTabComponent extends CleanOnDestroy implements OnInit {

  accountEndPoint: string = '';

  @Input() accountLogoEndpoint: string;
  @Output() accountWorkspacesChange: EventEmitter<WorkspaceV3[]> = new EventEmitter();
  @Input() account: Account;

  accountWorkspaces: WorkspaceV3[];

  currentLocale: any = '';
  desc: string = '';
  secondDesc: string = '';
  deleteWorkspace: string = '';
  confirmString: string = '';
  cancelString: string = '';

  constructor(
    private translate: TranslateService,
    public sharedSrv: SharedService,
    private workspacesSrv: WorkspacesService,
    private router: Router,
    private storageSrv: StorageService,
    public utilSrv: UtilService
  ) {
    super();

    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.currentLocale = this.utilSrv.locale;
    this.accountEndPoint = `${this.utilSrv.env.endPoint}/api/v3/`;
    this.tsTranslations();
  }

  ngOnChanges(changes: SimpleChanges) {
    for(const changePropName in changes) {
      if(changes.hasOwnProperty(changePropName)) {
        switch(changePropName) {
          case 'account': {
            if(Object.keys(this.account).length > 0 && this.account.constructor === Object) {
              this.getAccountWorkspaces();
            }
          }
          case 'accountLogoEndpoint': {
            
          }
          case 'accountMembers': {

          }
        }
      }
    }
  }

  tsTranslations() {
    this.translate.get('WORKSPACESTAB.DESC').subscribe((string) => {
      this.desc = string;
    });
    this.translate.get('WORKSPACESTAB.SECONDDESC').subscribe((string) => {
      this.secondDesc = string;
    });
    this.translate.get('WORKSPACESTAB.DELETEWORKSPACE').subscribe((string) => {
      this.deleteWorkspace = string;
    });
    this.translate.get('CONFIRMBUTTON').subscribe((string) => {
      this.confirmString = string;
    });
    this.translate.get('CANCELBUTTON').subscribe((string) => {
      this.cancelString = string;
    });
  }

  /**
   * get account workspaces by `accountId`
   * @param accountId with type `number` (by default equal to `this.accountId`)
   * @return `null`
   */
  getAccountWorkspaces() {
    this.accountWorkspaces = [];
    this.subscriber = this.workspacesSrv.getWorkspaces(this.account.id)
      .subscribe(workspaces => {
        if (workspaces) {
          this.accountWorkspaces = workspaces;
        }
      })
  }

  /**
   * calls from template
   * helper for a optimizing *ngFor
   *
   * @param index is a current element index with type `number`
   * @param item is a current element info with type `Workspace`
   *
   * @return `number`
   */
  onTrackById(index: number, item: Workspace) {
    return item.id;
  }

  /**
   * calls from template
   * when user clicked on the new workspace button
   *
   * @param null
   *
   * @return `null`
   */
  onCreateNewWorkspae() {
    this.subscriber = this.sharedSrv.openDialog<WorkspaceV3>(
      {
        accountId: this.account.id,
        currentUser: this.storageSrv.currentUserInfo
      },
      true,
      { width: '40%' },
      WorkspaceNewComponent
    ).subscribe(response => {
      if (response.continue) {
        this.setWorkspace(response.outputData);
      }
    })
  }

  /**
   * calls from template
   * when user clicked on edit button from workspace options menu
   *
   *  redirect to the workspace settings page
   *
   * @param workspace Id is a workspace id
   *
   * @return `null`
   */
  onNavigateToTheWorkspace(workspaceId: number) {
    this.router.navigate(['/workspaces', workspaceId, 'details']);
  }

  /**
   * calls from template
   * when user clicked on select button from workspace options menu
   *
   * change selected workspace
   *
   * @param workspace is a workspace which one user select, type `Workspace`
   *
   * @return `null`
   */
  onSelectWorkspace(workspace: WorkspaceV3) {
    // Note - need to figureout on how to get away from storing selected workspace in local storage.
    // this.storageSrv.selectedWorkspace = workspace;
    
    this.storageSrv.currentWorkspace = String(workspace.id);
  }

  /**
   * calls when new workspace succesfully created
   *
   * set created workspace into the sharedService `workspacesByAccountsId` array
   * set created workspace into `accountWorkspaces`
   * update workspaces on the parent component
   *
   * @param createdWorkspace new created workspace with type `Workspace`
   *
   * @return `null`
   */
  setWorkspace(createdWorkspace: WorkspaceV3) {
    if (!this.storageSrv.workspacesByAccountsId[this.account.id]) {
      this.storageSrv.workspacesByAccountsId[this.account.id] = [];
    }
    // Note - not storing the accounts workspaces anymore in storage.service
    // this.storageSrv.workspacesByAccountsId[this.account.id].push(createdWorkspace);

    // set new ceeated workspace into this component workspaces list
    this.accountWorkspaces.push(createdWorkspace);

    // update on the parent component
    this.accountWorkspacesChange.emit(this.accountWorkspaces);
  }

  /**
   * calls from template
   * when user clicked on the delete button of workspace options
   *
   * @param workspaceId is a workspace id wich should be deleted (type `number`)
   * @param workspaceIndex is a index of item
   *        in `accountWorkspaces` array (type `number`)
   *
   * @return `null`
   */
  onDeleteWorkspace(workspaceId: number, workspaceIndex: number) {
    let desc = this.desc;
    let secondDesc = this.secondDesc;
    this.subscriber = this.sharedSrv.openDialog(
      {
        title: this.deleteWorkspace,
        description: desc,
        secondaryDescription: secondDesc,
        cancel: this.cancelString,
        template: 0,
        confirm: this.confirmString
      },
      true,
      {
        width: '45%',
        minWidth: '300px'
      }
    ).subscribe(response => {
      if (response.continue) {
        this.workspacesSrv.deleteWorkspace(this.account.id, workspaceId)
          .subscribe(response => {
            if (response) {
              this.deleteWorkspaceFromEveryWhere(workspaceId, workspaceIndex);
            }
          })
      }
    });
  }

  /**
   * calls when user succesfully remove workspace
   *
   * remove workspace by id  `workspaceId` every where
   *
   * @param workspaceId with type `number`
   * @param workspaceIndex is a index of item
   *        in `accountWorkspaces` array (type `number`)
   *
   * @return `null`
   */
  deleteWorkspaceFromEveryWhere(workspaceId: number, workspaceIndex: number) {
    // get stored account workspaces
    let account = this.storageSrv.workspacesByAccountsId[this.account.id];
    // find and remove workspace from account workspaces list
    account.every((workspace: Workspace, index: number) => {
      if (workspace.id === workspaceId) {
        account.splice(index, 1);
        return false;
      }
      return true;
    })
    // replace on the component existing workspaces list
    this.accountWorkspaces.splice(workspaceIndex, 1);
    // update accountWorkspaces on parent component
    this.accountWorkspacesChange.emit(this.accountWorkspaces);
  }



}
