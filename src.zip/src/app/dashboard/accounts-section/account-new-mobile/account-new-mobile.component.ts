import { Component, OnInit, ElementRef, ChangeDetectorRef, ViewChild } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Location } from '@angular/common';
import { UtilService } from 'src/app/shared/services/util.service';
import { StripeChangeEvent } from 'src/app/shared/models/common-models/stripe-change-event.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { Subscription } from 'src/app/shared/models/common-models/subscription.model';
import { Subscription } from 'src/app/shared/models/subscription-models/subscription.model';
import { SubscriptionsService } from 'src/app/shared/services/subscriptions.service';
import { MatSelectChange } from '@angular/material/select';
import { LocalRequestsService } from 'src/app/shared/services/local-requests.service';
import { Country } from 'src/app/shared/models/common-models/country.model';
import { SharedService } from 'src/app/shared/services/shared.service';
import { DefaultDialogInputData } from 'src/app/shared/models/common-models/default-dialog-input-data.model';
import { AccountsService } from 'src/app/shared/services/accounts.service';
import { AccountCreateRequest } from 'src/app/shared/models/requests-models/account-create.model';
import { Account } from 'src/app/shared/models/account-models/account.model';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { Router } from '@angular/router';
import { StorageService } from 'src/app/shared/services/storage.service';
import { WorkspacesService } from 'src/app/shared/services/workspaces.service';
import { take } from 'rxjs/internal/operators/take';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { AppWelcomeService } from 'src/app/shared/services/app-welcome.service'
import { AccountUpdateFailedEvent } from 'src/app/shared/events/account-update-failed.event';
import { ArraySortPipe } from 'src/app/shared/pipes/sorted.pipe';
import { AccountInvitationsComponent } from 'src/app/shared/components/account-invitations/account-invitations.component';
import { TranslateService } from '@ngx-translate/core';
// Utils
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';
// Stripe
import { StripeFactoryService, StripeInstance, StripeCardComponent } from 'ngx-stripe';
import { StripeCardElementOptions, StripeElementsOptions } from '@stripe/stripe-js';

@Component({
  selector: 'app-account-new-mobile',
  templateUrl: './account-new-mobile.component.html',
  styleUrls: ['./account-new-mobile.component.scss']
})
export class AccountNewMobileComponent extends CleanOnDestroy implements OnInit {

  redirectURI = "com.usanalyticssolutionsgroup.boldcast://"

    error: string;
  // store the selected account image as base 64 for a quick show
  uploadedImageBase64: string = '';
  defaultImage: string = '';
  selectedInterval: string = 'month';

  formSubmitted: boolean = false;

  //  stripe card element wher should be initialize stripe card form
  //@ViewChild('cardInfo') cardInfo: ElementRef;
  @ViewChild('intervalToggle', { static: true }) intervalToggle: any;
  // stripe card
  //card: any;
  //cardHandler = this.onHandleStripeErrors.bind(this);

  stripe:StripeInstance;
  @ViewChild(StripeCardComponent) card: StripeCardComponent;
  cardOptions: StripeCardElementOptions = {
    style: {
      base: {
        iconColor: '#666EE8',
        color: '#31325F',
        fontWeight: '300',
        fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
        fontSize: '18px',
        '::placeholder': {
          color: '#CFD7E0'
        }
      }
    },
    hidePostalCode: true
  };
  elementsOptions: StripeElementsOptions = {
    locale: 'en'
  };

  accountForm: FormGroup;

  // store the account image for
  // upload it when he create the account
  accountImage: File;

  // store the subscriptionPlans
  subscriptionsList: Subscription[] = [];

  // store the selected subscription plan info

  // store the stripe form complete status
  isCompleteStripeForm: boolean = false;
  serviceEventListener = null;

  countries: Country[] = [];
  maxLicenses: number = 10000;
  maxRecipientLicenses = 50000;

  selectedSubscriptionPlan: Subscription;


  accountSavedEvent = new CustomEvent('accountSaved', { detail: '' });
  currentLocale: any = '';
  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private subscriptionsSrv: SubscriptionsService,
    private cd: ChangeDetectorRef,
    private location: Location,
    private fb: FormBuilder,
    private localRequests: LocalRequestsService,
    private sharedSrv: SharedService,
    public storageSrv: StorageService,
    private accountSrv: AccountsService,
    private router: Router,
    private workspaceSrv: WorkspacesService,
    private appWelcomeService: AppWelcomeService,
    private stripeFactory: StripeFactoryService
  ) {
    super();

    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.stripe = this.stripeFactory.create(environment.stripe);
    this.currentLocale = this.utilSrv.locale;
    this.generateAccountForm();
    this.defaultImage = this.utilSrv.appImages.defaultImageWithMargin;
    this.getSubscriptonPlansList();
    this.getCountries();
    this.subscriber = this.storageSrv.currentUserSubject.subscribe(user => {
      if (user) {
        this.accountForm.get('billingEmail').patchValue(user.email);
      }
    });

    this.serviceEventListener = this.sharedSrv.accountFailed.subscribe({
      next: (event: AccountUpdateFailedEvent) => {
        this.formSubmitted = false;
      }
    });

  }


  /**
   * get country list from json
   *
   * @param null
   *
   * @return `null`
   */
  getCountries() {
    this.localRequests.getCountries().subscribe(countries => {
      if (countries) {
        this.countries = countries;
      }
    })
  }

  /**
   * generate `accountForm`
   *
   * @param null
   *
   * @return `null`
   */
  generateAccountForm() {
   this.accountForm = this.fb.group({
      physicalLicenses: [0, [Validators.required, Validators.min(0), Validators.max(this.maxLicenses)]],
      virtualLicenses: [0, [Validators.required, Validators.min(0), Validators.max(this.maxLicenses)]],
      recipientLicenses: [0, [Validators.required, Validators.min(0), Validators.max(this.maxRecipientLicenses)]],
      webLicenses: [0, [Validators.required, Validators.min(0), Validators.max(this.maxRecipientLicenses)]],
      accountName: ['', [Validators.required, removeWhitespaceValidator]],
      subscriptionId: [null, Validators.required],
      billingName: ['', [Validators.required, removeWhitespaceValidator]],
      billingPhone: ['', [Validators.required, Validators.pattern('[2-9]\\d{9}'), removeWhitespaceValidator]],
      billingEmail: ['', [Validators.required, Validators.email, removeWhitespaceValidator]],
      billingAddressCountry: ['', [Validators.required, removeWhitespaceValidator]],
      billingAddressCity: '',
      billingAddressLine1: ['', [Validators.required, removeWhitespaceValidator]],
      billingAddressLine2: '',
      billingAddressState: ['', [Validators.required, removeWhitespaceValidator]],
      billingAddressPostalCode: '',
      stripeToken: '',
      couponCode: '',
      tocAccepted: ['', Validators.requiredTrue],
    });
  }

  /**
   * calls from template
   * when user choose the subscription plan
   *
   * generate stripe form in case of user select subscription which id IS NOT 2
   *
   * @param event is a mat select selectionCHnage object
   *
   * @return `null`
   */
  onCooseSubscriptionPlan(selectedId: number) {
    if (this.selectedSubscriptionPlan != null && this.selectedSubscriptionPlan.id == selectedId){
      return;
    }

    this.selectedSubscriptionPlan =
      this.subscriptionsList.find(plan => plan.id === selectedId);

     this.accountForm.get("subscriptionId").patchValue(selectedId);

     // reset quantities
     this.accountForm.get("physicalLicenses").patchValue(0);
     this.accountForm.get("virtualLicenses").patchValue(0);
     this.accountForm.get("recipientLicenses").patchValue(0);
     this.accountForm.get("webLicenses").patchValue(0);

    if (!this.selectedSubscriptionPlan.hasTrial) {
      setTimeout(() => {
        this.generateStripe();
      }, 100);
    }

    if (this.selectedSubscriptionPlan.hasTrial) {
      this.prepareAccountFormForTrial();
    } else {
      this.prepareAccountFormForPayedSubscription();
    }
  }



  /**
   * change the form requirements for trial account
   *
   * @param null
   *
   * @return `null`
   */
  prepareAccountFormForTrial() {
    this.accountForm.get('billingAddressCountry').clearValidators();
    this.accountForm.get('billingAddressCountry').updateValueAndValidity();
    this.accountForm.get('billingAddressLine1').clearValidators();
    this.accountForm.get('billingAddressLine1').updateValueAndValidity();
    this.accountForm.get('billingAddressState').clearValidators();
    this.accountForm.get('billingAddressState').updateValueAndValidity();
  }

  /**
   * change the form requirements for accounts with billing details
   *
   * @param null
   *
   * @return `null`
   */
  prepareAccountFormForPayedSubscription() {
    this.accountForm.get('billingAddressCountry').setValidators(Validators.required);
    this.accountForm.get('billingAddressCountry').updateValueAndValidity();
    this.accountForm.get('billingAddressLine1').setValidators(Validators.required);
    this.accountForm.get('billingAddressLine1').updateValueAndValidity();
    this.accountForm.get('billingAddressState').setValidators(Validators.required);
    this.accountForm.get('billingAddressState').updateValueAndValidity();
  }

  /**
   * calls from template
   * when user clicked on the back button
   *
   * redirect user to the previous page
   *
   * @param null
   *
   * @return `null`
   */
  onGoBack() {
    this.location.back();
  }

  /**
   * send request to the server foa get subscription plans list
   *
   * @param null
   *
   * @return `null`
   */
  getSubscriptonPlansList() {
    this.subscriptionsSrv.getSubscriptionsList().subscribe(subscriptionsList => {
      this.subscriptionsList = subscriptionsList;
    })
  }

  /**
   * calls from template
   *
   * check selected subscription plan
   * disabled button when he choose payable subscription plan
   * but stripe form is incomplete
   *
   * @param null
   *
   * @return `boolean`
   */
  isValidStripForm() {

    let invalid = false;

    if (this.selectedSubscriptionPlan
      && !this.selectedSubscriptionPlan.hasTrial
      && !this.isCompleteStripeForm
    ) {
      invalid = true;
    }

    return invalid;
  }

  /**
   * calls every time on type card info
   *
   * @param null
   *
   * @return `null`
   */
  generateStripe() {
    // To do - migrate to ngx-stripe approach.
    // if (this.card) {
    //   this.card.destroy();
    // }
    // const style = {
    //   base: {
    //     fontFamily: 'Montserrat, sans-serif',
    //     fontSmoothing: 'antialiased',
    //     fontSize: '17px'
    //   }
    // };
    // create card
    // this.card = elements.create('card', {
    //   style: style,
    //   hidePostalCode: true,
    // });
    // if (this.cardInfo) {
    //   this.card.mount(this.cardInfo.nativeElement);
    //   this.card.addEventListener('change', this.cardHandler);
    // }
  }

  /**
   * calls every time on type card info
   *
   * @param stripeHandler with type `StripeChangeEvent`
   *
   * @return `null`
   */
  onHandleStripeErrors(stripeHandler: StripeChangeEvent) {
    // show error message if card info is invalid
    if (stripeHandler.error) {
      this.error = stripeHandler.error.message;

    } else {
      // remove errors
      this.error = null;
    }
    // store the compleate status into property
    this.isCompleteStripeForm = stripeHandler.complete;
    // manualy update view
    // need for a corectly show error messages
    this.cd.detectChanges();
  }

  /**
   * store the image as base64 into `uploadedImageBase64` property
   *
   * @param null
   *
   * @return `null`
   */
  transformImageToBase64() {
    let reader = new FileReader();
    reader.onload = (event): void => {
      // called once when readAsDataURL is completed
      this.uploadedImageBase64 = event.target['result'] as string;
      reader.onload = null
    }
    reader.readAsDataURL(this.accountImage);
  }

  /**
   * delete selected image
   *
   * @param null
   *
   * @return `null`
   */
  onDeleteSelectedImage() {
    this.uploadedImageBase64 = '';
    this.accountImage = null
  }


  /**
   * delete selected image
   *
   * @param input `HTMLInputElement`
   *
   * @return `null`
   */
  onSelectDeviceImage(input: HTMLInputElement) {
    this.accountImage = input.files[0];
    let isValidExtension = this.utilSrv.checkImageExtension(this.accountImage);
    // set image into form  when extension is allowed
    if (isValidExtension) {
      this.transformImageToBase64();
    }
  }

  /**
   * calls from template
   * when user clicked on the submit button
   *
   * if user choose payable subscription plan
   * check complete status of stripe form
   * and call `stripe.createToken` for a get paymant token
   * after call `createAccount`
   *
   * @param null
   *
   * @return `null`
   */
  async onSubmitAccountForm() {
    // isValidStripForm returned boolean value for a disable button
    // false when stripe form valid or subscription paln is not payable
    // true when invalid
    this.formSubmitted = true;

    if (this.accountForm.valid && !this.isValidStripForm()) {
      if (
        this.accountForm.get('subscriptionId').value
        && !this.selectedSubscriptionPlan.hasTrial
      ) {
        try {
          //let response = await stripe.createToken(this.card);
          this.stripe.createToken(this.card.element).subscribe( (response) => {
            if(response){
              this.accountForm.get('stripeToken').patchValue(response.token.id);
              this.createAccount();
            }
          });

        } catch (error) {
          let dialogInputData: DefaultDialogInputData = {
            title: 'Payment was not proceed',
            description: error.message,
            template: 1,
            confirm: 'ok'
          }

          this.sharedSrv.openDialog(dialogInputData, false, {
            minWidth: '300px',
            width: '30px'
          })

          this.formSubmitted = false;
        }
      } else {
        this.createAccount();
      }
    }
  }


  /**
   * send request to the server for a create new account
   * aftet upload image in case of neccessary
   *
   * @param null
   *
   * @return `null`
   */
  createAccount() {
    let accountCreationForm =
      this.accountForm.getRawValue() as AccountCreateRequest;
      this.accountSrv.createAccount(accountCreationForm)
      .subscribe(async createdAccount => {
        if (createdAccount) {
          //document.dispatchEvent(this.accountSavedEvent);
          //this.formSubmitted = false;
          //this.storageSrv.currentUserAccounts.unshift(createdAccount);
          //this.getWorkspacesForCreatedAccount(createdAccount);
          window.location.href = this.redirectURI;
        }
      });
  }


  setWorkspace(workspace: Workspace) {
    this.storageSrv.selectedWorkspace = workspace;
  }

  /**
   * send request to the server for a get the account workspaces
   *
   * @param account is a new created account with type `Account`
   *
   * @return `null`
   */
  getWorkspacesForCreatedAccount(account: Account) {
    this.workspaceSrv.getWorkspaceById(account.workspaces[0].id)
      .subscribe(workspace => {
        if (workspace) {
          this.storageSrv.workspacesByAccountsId[account.id] = [workspace];
          this.setWorkspace(workspace);
          this.router.navigate(['/']);
          this.appWelcomeService.getComponent().startIfAvailable();
        }
      })
  }

  /**
   * send request to the server for a upload account image
   *
   * @param account is a new created account with type account
   *
   * @return `null`
   */
  async uploadAccountImage(account: Account) {
    let accountImageForm = new FormData();
    accountImageForm.append('file', this.accountImage);
    let isUplaoded = await this.accountSrv.changeAccountLogo(
      accountImageForm, account.id
    ).toPromise();
    return isUplaoded;
  }

  ngOnDestroy() {
    // destroy the cart when destroys the component when card initialized
    // To do - migrate to ngx-stripe
    // if (this.card) {
    //   this.card.destroy();
    // }
  }

  onGetUserAccountInvitations() {
    if (this.storageSrv.currentUserInvitations) {
      return this.storageSrv.currentUserInvitations;
    } else {
      return []
    }
  }

  openInvitationsModal() {
    this.sharedSrv.openDialog<{ id: number }[]>(
      {
        accountInvitations: this.onGetUserAccountInvitations()
      },
      true,
      null,
      AccountInvitationsComponent
    ).subscribe(response => {
      if (response.continue){
       window.location.href = this.redirectURI;
      }
    })
  }

  dollarFormat(num){
    return "$"+ num.toFixed(2);
  }

  toggleSelectedInterval(){
    if (this.selectedInterval === "month"){
      this.selectedInterval = "year";
    } else {
      this.selectedInterval = "month";
    }

    // deselect current option
    this.selectedSubscriptionPlan = null;
    this.accountForm.get("subscriptionId").patchValue(null);
  }

  getEstimate(){
    var price = 0;
    if (this.selectedSubscriptionPlan != null && this.selectedSubscriptionPlan.interval === "year"){
      if (this.selectedSubscriptionPlan.tier === "standard"){
        // if standard
        this.selectedSubscriptionPlan.products.forEach(product => {
          if (product.productName.indexOf("Physical") > -1){
            price += product.productInfo.amount * this.accountForm.get("physicalLicenses").value;
          }
          if (product.productName.indexOf("Virtual") > -1){
            price += product.productInfo.amount * this.accountForm.get("virtualLicenses").value;
          }
        });


      } else {
        // if professional
        this.selectedSubscriptionPlan.products.forEach(product => {
          if (product.productName.indexOf("Physical") > -1){
            price += (product.productInfo.amount * this.accountForm.get("physicalLicenses").value);
          }
          if (product.productName.indexOf("Virtual") > -1){
            price += (product.productInfo.amount * this.accountForm.get("virtualLicenses").value);
          }
          if (product.productName.indexOf("Stream") > -1){
            // need to get price from tiers
            var amount = this.accountForm.get("recipientLicenses").value;
            for (var i = 0; i < product.productInfo.tiers.length; i++){
              if (product.productInfo.tiers[i]["up_to"] != null && product.productInfo.tiers[i]["up_to"] < amount){
                continue;
              } else {
                price += (product.productInfo.tiers[i]["unit_amount"] * amount);
                break;
              }
            }
          }
          if (product.productName.indexOf("Web") > -1) {
            var numberOfGroups = this.accountForm.get("webLicenses").value / product.productInfo.groupSize;
            var units = Math.ceil(numberOfGroups);
            price += (product.productInfo.amount * units);
          }
        });

      }
    }

    return price;
  }


  addUnitsToPrice(controlName: string){
    var control = this.accountForm.get(controlName);
    control.patchValue(control.value+1);
  }

  removeUnitsFromPrice(controlName: string){
    var control = this.accountForm.get(controlName);
    if (control.value > 0){
      control.patchValue(control.value-1);
    }
  }

  onOpenTiersModal(productInfo, container: HTMLDivElement){
    container.classList.remove('d-none');

    var html = '<h4 style="margin:0px; text-align:center;">'+productInfo.nickname+'</h4>';

    html += '<div><table style="width: 100%;">'
    for (var i = 0; i < productInfo.tiers.length; i++){
      html += '<tr>';
      if (productInfo.tiers[i].up_to != null){
        html += '<td>Up to '+productInfo.tiers[i].up_to+'</td>';
      } else {
        html += '<td>More than '+productInfo.tiers[i-1].up_to+'</td>';
      }
      html += '<td style="text-align: right;">'+this.dollarFormat(productInfo.tiers[i].unit_amount / 100)+'</td>';
      html += '</tr>';
    }
    html += '</table></div>';

    container.innerHTML = html;
  }

  onCloseTiersModal(container: HTMLDivElement) {
    container.innerHTML = '';
  }

  onStopPropagation(event: MouseEvent) {
    event.stopPropagation();
  }

}
