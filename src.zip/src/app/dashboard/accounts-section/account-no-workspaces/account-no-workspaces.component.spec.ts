import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { AccountNoWorkspacesComponent } from './account-no-workspaces.component';

describe('AccountNoWorkspacesComponent', () => {
  let component: AccountNoWorkspacesComponent;
  let fixture: ComponentFixture<AccountNoWorkspacesComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountsNoWorkspacesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountsNoWorkspacesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
