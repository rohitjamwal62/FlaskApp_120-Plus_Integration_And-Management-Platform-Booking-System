import { Component, OnInit } from '@angular/core';
import { StorageService } from 'src/app/shared/services/storage.service';
import { UserPersonal } from 'src/app/shared/models/user-models/user-personal.model';

@Component({
  selector: 'app-account-no-workspaces',
  templateUrl: './account-no-workspaces.component.html',
  styleUrls: ['./account-no-workspaces.component.scss']
})
export class AccountNoWorkspacesComponent implements OnInit {

	currentUserInfo: UserPersonal;
  constructor(
  	public storageSrv: StorageService
  ) { }

  currentAccount = null;

  ngOnInit() {
    this.storageSrv.userAccountsSubject.subscribe(accounts => {
      if (this.storageSrv.currentUserAccounts != null && this.storageSrv.currentUserAccounts.length > 0){
          this.currentAccount = this.storageSrv.currentUserAccounts[0];
        }
    });
  }

}
