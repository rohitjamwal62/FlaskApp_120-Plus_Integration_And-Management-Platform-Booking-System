import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccountsSectionComponent } from './accounts-section.component';
import { AccountNewComponent } from './account-new/account-new.component';
import { AccountNewMobileComponent } from './account-new-mobile/account-new-mobile.component';

import { AccountEditComponent } from './account-edit/account-edit.component';
import { AllowedChangeRouteGuard } from 'src/app/shared/guards/allowed-change-route.guard';
import { AccountNoWorkspacesComponent } from './account-no-workspaces/account-no-workspaces.component';

const routes: Routes = [
  {
    path: '', 
    component: AccountsSectionComponent, 
    children: [
      {
        path: 'new',
        //canDeactivate: [AllowedChangeRouteGuard],
        component: AccountNewComponent
      },
      {
        path: 'new/mobile',
        canDeactivate: [AllowedChangeRouteGuard],
        component: AccountNewMobileComponent
      },
      {
        path: 'noworkspaces',
        component: AccountNoWorkspacesComponent
      },
      {
        path: ':accountId',
        component: AccountEditComponent
      },
      {
        path: ':accountId/:tabName',
        component: AccountEditComponent
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccountsRoutingModule { }
