import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accounts-section',
  templateUrl: './accounts-section.component.html',
  styleUrls: ['./accounts-section.component.scss']
})
export class AccountsSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
