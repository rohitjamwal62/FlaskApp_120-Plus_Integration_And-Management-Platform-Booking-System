import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from 'src/app/shared/shared.module';
import { AccountsRoutingModule } from './accounts-routing.module';

import { AccountsSectionComponent } from './accounts-section.component';
import { AccountNewComponent } from './account-new/account-new.component';
import { AccountNewMobileComponent } from './account-new-mobile/account-new-mobile.component';

import { AccountEditComponent } from './account-edit/account-edit.component';
import { BillingTabComponent } from './account-edit/billing-tab/billing-tab.component';
import { UsersTabComponent } from './account-edit/users-tab/users-tab.component';
import { WorkspacesTabComponent } from './account-edit/workspaces-tab/workspaces-tab.component';
import { MatTableModule } from '@angular/material/table';
import { AccountNoWorkspacesComponent } from './account-no-workspaces/account-no-workspaces.component';
import { ChangeManagementTabComponent } from './account-edit/change-management-tab/change-management-tab.component';

@NgModule({
  declarations: [
    AccountsSectionComponent,
    AccountNewComponent,
    AccountNewMobileComponent,
    AccountEditComponent,
    BillingTabComponent,
    UsersTabComponent,
    WorkspacesTabComponent,
    AccountNoWorkspacesComponent,
    ChangeManagementTabComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    AccountsRoutingModule,
    MatTableModule
  ]
})
export class AccountsModule { }
