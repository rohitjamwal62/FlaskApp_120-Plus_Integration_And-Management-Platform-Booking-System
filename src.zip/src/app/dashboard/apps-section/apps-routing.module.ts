import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppsSectionComponent } from './apps-section.component';
import { AppsComponent } from './apps/apps.component';

const routes: Routes = [
  {
    path: '', component: AppsSectionComponent, children: [
      {
        path: '',
        component: AppsComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppsRoutingModule { }
 