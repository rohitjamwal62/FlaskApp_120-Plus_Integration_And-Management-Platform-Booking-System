import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apps-section',
  templateUrl: './apps-section.component.html',
  styleUrls: ['./apps-section.component.scss']
})
export class AppsSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
