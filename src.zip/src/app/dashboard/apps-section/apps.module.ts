import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from 'src/app/shared/shared.module';
import { AppsRoutingModule } from './apps-routing.module';

import { AppsSectionComponent } from './apps-section.component';
import { AppsComponent } from './apps/apps.component';

@NgModule({
  declarations: [
    AppsSectionComponent,
    AppsComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    AppsRoutingModule
  ]
})
export class AppsModule { }
