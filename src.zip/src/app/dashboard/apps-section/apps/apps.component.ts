import { Component, OnInit, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { forkJoin, of, fromEvent } from 'rxjs';
import { debounceTime, filter, map, distinctUntilChanged, tap } from 'rxjs/operators';
import { FormControl } from '@angular/forms';

import { UtilService } from 'src/app/shared/services/util.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { AppFoldersService } from 'src/app/shared/services/app-folders.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { AppsService } from 'src/app/shared/services/apps.service';

import { SitebarItem } from 'src/app/shared/models/common-models/sitebar-item.model';
import { Apps } from 'src/app/shared/models/apps-models/apps.model';
import { AppFolder } from 'src/app/shared/models/app-folders/app-folder.model';
import { AppFolderCreateRequest } from 'src/app/shared/models/requests-models/app-folder-create.model';
import { AppFolderUpdateRequest } from 'src/app/shared/models/requests-models/app-folder-update.model';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { Pagination } from 'src/app/shared/models/common-models/pagination.model';

import { ChangeDetectorRef } from '@angular/core';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { PageState } from 'src/app/shared/enums/page-state.enum';
import { TemplateFlaggEvent } from 'src/app/shared/events/template-flagg.event';
import { TranslateService } from '@ngx-translate/core';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort} from '@angular/material/sort';
import * as filestack from 'filestack-js';

import { SelectAppComponent } from 'src/app/shared/components/select-app/select-app.component';
import { CreateAppFolderComponent } from 'src/app/shared/components/create-app-folder/create-app-folder.component';
import { MoveAppFolderComponent } from 'src/app/shared/components/move-app-folder/move-app-folder.component';
import { EditAppFolderComponent } from 'src/app/shared/components/edit-app-folder/edit-app-folder.component';

@Component({
  selector: 'app-apps',
  templateUrl: './apps.component.html',
  styleUrls: ['./apps.component.scss']
})
export class AppsComponent extends CleanOnDestroy implements OnInit, AfterViewInit {

  @ViewChild('search', {static: true}) search: ElementRef;

  currentWorkspace: Workspace;
  sitebarAppItem: SitebarItem;

  parentFolderId: number = null;
  folderImage: string = '';
  appFolders: AppFolder[] = [];
  appFoldersPaginate: Pagination = { count: 0, limit: 0, next: '', offset: 0 };
  apps: Apps[] = [];
  appsPaginate: Pagination = { count: 0, limit: 0, next: '', offset: 0 };

  initialSelection = [];
  initialAppSelection = [];
  allowMultiSelect = true;
  appFolderSelection = new SelectionModel<AppFolder>(this.allowMultiSelect, this.initialSelection);
  appSelection = new SelectionModel<Apps>(this.allowMultiSelect, this.initialAppSelection);

  //appFoldersChildren: any[] = [];
  appFoldersChildrenPaginate: Pagination = { count: 0, limit: 0, next: '', offset: 0 };

  //isAssetFilesSearch = false;
  //storedAppFolders: AppFolder[] = [];
  //storedApps: Apps[] = [];
  //selectedAppFolders: AppFolder[] = [];
  //selectedApps: Apps[] = [];
  
  requestEndpoint: string = '';

  folderTrails: AppFolder[] = [];
  currentParentFolder: AppFolder;
  selectedChildFolder: AppFolder;

  searchControl = new FormControl();

  isSortDir: number = 0;
  breakpoint: number;
  dialogWidth: string = '51.15%';

  // Flaggs
  isLoading: boolean = false;
  serviceEventListener = null;
  pageState = PageState.loading;
  isFolderChildren: boolean = false;

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private sharedSrv: SharedService,
    private storageSrv: StorageService,
    private appFoldersSrv: AppFoldersService,
    private appsSrv: AppsService,
    private cdr: ChangeDetectorRef
  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.breakpoint = (window.innerWidth <= 400) ? 1 : 6;
    this.requestEndpoint = this.utilSrv.env.endPoint;
    this.sitebarAppItem = this.utilSrv.getSitebarItem('apps');
    this.folderImage = this.utilSrv.appImages.folder;

    // Listening to API request errors
    this.serviceEventListener = this.sharedSrv.templateFlagg.subscribe({
      next: (event: TemplateFlaggEvent) => {
      }
    });

    if(window.innerWidth <= 400) {
      this.breakpoint = 1;
    } else if(window.innerWidth > 400 && window.innerWidth <= 900) {
      this.breakpoint = 2;
      this.dialogWidth = '85%';
    } else if(window.innerWidth > 900 && window.innerWidth <= 1200) {
      this.breakpoint = 3;
    } else if(window.innerWidth > 1200 && window.innerWidth <= 1600) {
      this.breakpoint = 4;
    } else {
      this.breakpoint = 6;
    }

    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe( workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;
          this.tsTranslation();
          this.getAppFolders();
          this.getApps();
        }
      });
  }

  ngAfterViewInit() {

    fromEvent(this.search.nativeElement,'keyup')
      .pipe(
        filter(Boolean),
        debounceTime(1500),
        distinctUntilChanged(),
        tap((event:KeyboardEvent) => {
          let word = this.search.nativeElement.value;
          word = word.toLowerCase();
          if(word) {
            this.appFolders = [];
            this.apps = [];
            if(this.isFolderChildren) {
              this.searchAppsInFolders(word);
            } else {
              this.searchApps(word);
              this.searchAppFolder(word);
            }

          } else {
            if(this.selectedChildFolder) {
              this.getAppsInFolders();
            } else {
              this.getAppFolders();
              this.getApps();
            }
          }
        })
      )
      .subscribe();
  }

  //-------------------------------------------------------------------------------
  // Commons Methods
  //-------------------------------------------------------------------------------
  tsTranslation() {

  }

  onResize(event) {
    if(event.target.innerWidth <= 400) {
      this.breakpoint = 1;
    } else if(event.target.innerWidth > 400 && event.target.innerWidth <= 900) {
      this.breakpoint = 2;
      this.dialogWidth = '85%';
    } else if(event.target.innerWidth > 900 && event.target.innerWidth <= 1200) {
      this.breakpoint = 3;
    } else if(event.target.innerWidth > 1200 && event.target.innerWidth <= 1600) {
      this.breakpoint = 4;
    } else {
      this.breakpoint = 6;
    }
  }

  emptyFolderAppSelection() {
    this.appFolderSelection.clear();
    this.appSelection.clear();
  }

  onSort() {
    if(this.isSortDir == 0) {
      this.isSortDir = 1;
      this.appFolders.sort( (a, b) => {
        let aName = a.name.toLowerCase();
        let bName = b.name.toLowerCase();
        return aName > bName ? -1 : bName > aName ? 1 : 0;
      });
      this.apps.sort( (a, b) => {
        let aName = a.name.toLowerCase();
        let bName = b.name.toLowerCase();
        return aName > bName ? -1 : bName > aName ? 1 : 0;
      });
    } else {
      this.isSortDir = 0;
      this.appFolders.sort( (a, b) => {
        let aName = a.name.toLowerCase();
        let bName = b.name.toLowerCase();
        return aName > bName ? 1 : bName > aName ? -1 : 0;
      });
      this.apps.sort( (a, b) => {
        let aName = a.name.toLowerCase();
        let bName = b.name.toLowerCase();
        return aName > bName ? 1 : bName > aName ? -1 : 0;
      });
    }
  }

  onMove() {
    if(this.appFolderSelection.selected.length > 0 || 
      this.appSelection.selected.length > 0 ) {
      this.sharedSrv.openDialog<any>(
        {
          selectedAppFolders: this.appFolderSelection.selected,
          selectedApps: this.appSelection.selected,
          parentFolderId: this.parentFolderId
        },
        true,
        {
          width: '80%'
          //height: 'calc(100vh - 120px)'
        },
        MoveAppFolderComponent
      ).subscribe(dialogResponse => {
        if (dialogResponse.continue) {
          if(this.selectedChildFolder) {
            this.getAppsInFolders();
          } else {
            this.getAppFolders();
            this.getApps();
          }
        }
        this.emptyFolderAppSelection();
      });
    }
  }

  onDelete() {
    if(this.appFolderSelection.selected.length > 0 || this.appSelection.selected.length > 0 ) {
      this.subscriber = this.sharedSrv.openDialog(
        {
          title: 'Delete Folders / Apps',
          description: 'You are about to delete these Folders / Apps. Do you want to confirm?',
          confirm: 'Confirm',
          cancel: 'Cancel',
          template: 0
        },
        true
      ).subscribe(response => {
        if (response.continue) {
          if(this.appSelection.selected.length > 0) {
            this.confirmDeleteApps();
          }
          if(this.appFolderSelection.selected.length > 0) {
            this.confirmDeleteAppFolders();
          }
        }
        this.emptyFolderAppSelection();
      });
    }
  }

  onDeleteAppFolder(folder: AppFolder, index: number) {
    this.subscriber = this.sharedSrv.openDialog(
      {
        title: 'Delete Folder',
        description: 'You are about to delete this Folder. Do you want to confirm?',
        confirm: 'Confirm',
        cancel: 'Cancel',
        template: 0
      },
      true
    ).subscribe(response => {
      if (response.continue) {
        this.subscriber = this.appFoldersSrv.deleteAppFolder(
          this.currentWorkspace.account.id, 
          this.currentWorkspace.id, 
          folder.id
        )
          .subscribe( deletedAppFolders => {
            if(deletedAppFolders) {
              if(this.selectedChildFolder) {
                this.getAppsInFolders();
              } else {
                this.getAppFolders();
              }
            }
          });
      }
    });
  }

  onDeleteApp(app: Apps, index: number) {
    this.subscriber = this.sharedSrv.openDialog(
      {
        title: 'Delete App',
        description: 'You are about to delete this App. Do you want to confirm?',
        confirm: 'Confirm',
        cancel: 'Cancel',
        template: 0
      },
      true
    ).subscribe(response => {
      if (response.continue) {
        this.subscriber = this.appsSrv.deleteApp(
          this.currentWorkspace.account.id, 
          this.currentWorkspace.id, 
          app.id
        )
          .subscribe( deletedApp => {
            if(deletedApp) {
              if(this.selectedChildFolder) {
                this.getAppsInFolders();
              } else {
                this.getApps();
              }
            }
          });
      }
    });
  }

  //-------------------------------------------------------------------------------
  // Commons Methods
  //-------------------------------------------------------------------------------

  //-------------------------------------------------------------------------------
  // App Folder Methods
  //-------------------------------------------------------------------------------

  backToFolders() {
    this.folderTrails.length = 0;
    this.selectedChildFolder = null;
    this.isFolderChildren = false;
    this.getAppFolders();
    this.getApps();
  }

  onTrailsClick(folder, index) {
    if(this.folderTrails && this.folderTrails.length != 0) {
      this.folderTrails.length = parseInt(index) + 1;
    } else {
      this.folderTrails.length = 0;
    }
    this.onOpenAppFolder(folder, index);
  }

  searchAppFolder(word: string) {
    this.subscriber = this.appFoldersSrv.searchAppFolder(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      word
    )
      .subscribe( response => {
        if(response) {
          this.appFolders = response.message;
          this.appFoldersPaginate = response.pagination;
        }
      });
  }

  getAppFolders() {
    this.subscriber = this.appFoldersSrv.getAppsFolders(
      this.currentWorkspace.account.id, 
      this.currentWorkspace.id
    )
      .subscribe( response => {
        if(response) {
          this.appFolders = response.message;
          this.appFoldersPaginate = response.pagination;
        }
      });
  }

  getAppFoldersNext() {
    this.subscriber = this.appFoldersSrv.getAppsFoldersNext(this.appFoldersPaginate.next)
      .subscribe( response => {
        if(response) {
          this.appFolders.push(...response.message);
          this.appFoldersPaginate = response.pagination;
        }
      });
  }

  getAppsInFolders() {
    this.subscriber = this.appFoldersSrv.getAppsInFolders(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.selectedChildFolder.id
    ).subscribe( response => {
      if(response) {
        let rawData: any = response.message;
        let apps: any = rawData.filter( app => app.type.name != 'folder');
        let folders: any = rawData.filter( app => app.type.name == 'folder');
        this.apps = apps;
        this.appFolders = folders;
        this.appFoldersChildrenPaginate = response.pagination;
      }
    }, err => {

    });
  }

  getAppsInFoldersNext() {
    this.subscriber = this.appFoldersSrv.getAppsInFoldersNext(this.appFoldersChildrenPaginate.next)
      .subscribe( response => {
        if(response) {
          let rawData: any = response.message;
          let apps: any = rawData.filter( app => app.type.name != 'folder');
          let folders: any = rawData.filter( app => app.type.name == 'folder');
          this.apps.push(...apps)
          this.appFolders.push(...folders);
          this.appFoldersChildrenPaginate = response.pagination;
        }
    }, err => {
    });
  }

  onOpenAppFolder(selectedFolder: AppFolder, index: number) {
    let folderTrails = this.folderTrails;
    let folderIndex = folderTrails.findIndex( index => index.id == selectedFolder.id);
    if(folderIndex == -1) {
      this.folderTrails.push(selectedFolder);
    }
    this.isFolderChildren = true;
    this.selectedChildFolder = selectedFolder;
    this.getAppsInFolders();
  }

  onCreateAppFolder() {
    let parentFolderId: number = (this.selectedChildFolder) ? this.selectedChildFolder.id : null;
    this.subscriber = this.sharedSrv.openDialog(
        { parentId: parentFolderId },
        true,
        null,
        CreateAppFolderComponent
      )
      .subscribe(response => {
        if (response.continue) {
          this.subscriber = this.appFoldersSrv.createAppFolder(
            this.currentWorkspace.account.id,
            this.currentWorkspace.id,
            response.outputData as AppFolderCreateRequest
          )
            .subscribe(createdFolder => {
              if(createdFolder) {
                if(this.selectedChildFolder) {
                  this.getAppsInFolders();
                } else {
                  this.getAppFolders();
                }
              }
            })
          }
        }
      );
  }

  onEditAppFolder(selectedFolder: AppFolder, index: number) {
    this.subscriber = this.sharedSrv.openDialog(
      {
        folder: selectedFolder,
        parentId: this.parentFolderId
      },
      true,
      null,
      EditAppFolderComponent
    )
      .subscribe(response => {
        if (response.continue) {
          this.subscriber = this.appFoldersSrv.updateAppFolder(
            this.currentWorkspace.account.id,
            this.currentWorkspace.id,
            response.outputData as AppFolderUpdateRequest,
            selectedFolder.id
          )
            .subscribe(updateFolder => {
              if(updateFolder) {
                if(this.selectedChildFolder) {
                  this.getAppsInFolders();
                } else {
                  this.getAppFolders();
                }
                this.emptyFolderAppSelection();
              }
            })
          }
        }
      );
  }

  confirmDeleteAppFolders() {
    let selectedAppFolders: number[] = this.appFolderSelection.selected.map( appFolder => appFolder.id );
    let appFoldersForDelete: { folders: number[] } = {
      folders: selectedAppFolders
    };
    this.subscriber = this.appFoldersSrv.deleteAppFolders(
      this.currentWorkspace.account.id, 
      this.currentWorkspace.id, 
      appFoldersForDelete
    )
      .subscribe( deletedAppFolders => {
        if(deletedAppFolders) {
          if(this.selectedChildFolder) {
            this.getAppsInFolders();
          } else {
            this.getAppFolders();
          }
          this.emptyFolderAppSelection();
        }
      });
  }

  //-------------------------------------------------------------------------------
  // App Folder Methods
  //-------------------------------------------------------------------------------

  //-------------------------------------------------------------------------------
  // Apps Methods
  //-------------------------------------------------------------------------------
  searchApps(word: string) {
    this.subscriber = this.appsSrv.searchApps(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      word
    )
      .subscribe( response => {
        if(response) {
          this.apps = response.message;
          this.appsPaginate = response.pagination;
        }
      });
  }

  searchAppsInFolders(word: string) {
    this.subscriber = this.appsSrv.searchAppsInFolders(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.selectedChildFolder.id,
      word
    )
      .subscribe( response => {
        if(response) {
          let rawData: any = response.message;
          let apps: any = rawData.filter( app => app.type.name != 'folder');
          let folders: any = rawData.filter( app => app.type.name == 'folder');
          this.apps = apps;
          this.appFolders = folders;
          this.appFoldersChildrenPaginate = response.pagination;
        }
      });
  }

  getApps() {
    this.subscriber = this.appsSrv.getApps(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    ).subscribe( response => {
      if(response) {
        this.apps = response.message;
        this.appsPaginate = response.pagination;
        if(this.appFolders || this.apps) {
          this.pageState = PageState.withItems;
        }
      }
    });
  }

  getAppsNext() {
    this.subscriber = this.appsSrv.getAppsNext(this.appsPaginate.next)
      .subscribe( response => {
        if(response) {
          this.apps.push(...response.message);
          this.appsPaginate = response.pagination;
        }
      });
  }

  onApps() {
    let parentFolderId: number = (this.selectedChildFolder) ? this.selectedChildFolder.id : null;
    this.subscriber = this.sharedSrv.openDialog(
      {
        isNew: true,
        app: null,
        parentFolderId: parentFolderId,
        allowSelectApp: true
      },
      true,
      { 
        width: this.dialogWidth,
        height: '90%' 
      },
      SelectAppComponent
    )
    .subscribe(response => {
      if (response.continue) {
        let app: Apps = response.outputData as Apps;
        this.apps.push(app);
      }
    });
  }

  onEditApp(selectedApp: Apps, index: number) {
    this.subscriber = this.sharedSrv.openDialog(
      {
        isNew: false,
        app: selectedApp,
        appIndex: index,
        allowSelectApp: false
      },
      true,
      { width: '51.15%' },
      SelectAppComponent
    )
    .subscribe(response => {
      let updatedApp: any = response.outputData;
      if (response.continue) {
        this.apps[index] = updatedApp;
      }
    });
  }

  confirmDeleteApps() {
    let selectedApps: number[] = this.appSelection.selected.map( app => app.id );
    let appsForDelete: { apps: number[] } = {
      apps: selectedApps
    };
    this.subscriber = this.appsSrv.deleteApps(
      this.currentWorkspace.account.id, 
      this.currentWorkspace.id, 
      appsForDelete
    )
      .subscribe( deletedApps => {
        if(deletedApps) {
          // Delete selectedApps in this.apps
          selectedApps.forEach( id => {
            let foundApp = this.apps.findIndex( app => app.id == id);
            if(foundApp != -1) {
              this.apps.splice(foundApp, 1);
            }
          });
          if(this.selectedChildFolder) {
            this.getAppsInFolders();
          } else {
            this.getApps();
          }
          this.emptyFolderAppSelection();
        }
      });
  }

  onPreviewApp(app: Apps, previewContainer: HTMLDivElement) {
    previewContainer.classList.remove('d-none');
    previewContainer.innerHTML = `<iframe src="${this.requestEndpoint}/api/v3/orgs/${this.currentWorkspace.account.id}/workspaces/${this.currentWorkspace.id}/apps/${app.id}/preview/"
    class="preview-image" autoplay muted></iframe>`;
  }

  onShowAppImage(app: Apps) {
    return this.requestEndpoint + app.type.icon;
  }

  onCloseImageModal(previewContainer: HTMLDivElement) {
    previewContainer.innerHTML = '';
  }

  onTemplates() {

  }

  //-------------------------------------------------------------------------------
  // Apps Methods
  //-------------------------------------------------------------------------------

  canUpdate(){
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.content);
  }

  canRead(){
    return this.storageSrv.getWorkspaceReadPermission(Resource.content);
  }

  canWrite() {
    return this.storageSrv.getWorkspaceWritePermission(Resource.content);
  }

  canUpload() {
    //return this.uploadPicker != null && this.storageSrv.getWorkspaceWritePermission(Resource.content);
  }

  canDelete() {
    return this.storageSrv.getWorkspaceDeletePermission(Resource.content);
  }

}
