import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from 'src/app/shared/shared.module';
import { ContentRoutingModule } from './content-routing.module';

import { ContentSectionComponent } from './content-section.component';
import { ContentComponent } from './content/content.component';

@NgModule({
  declarations: [
    ContentSectionComponent,
    ContentComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    ContentRoutingModule
  ]
})
export class ContentModule { }
