import { Component, OnInit, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { forkJoin, of, fromEvent } from 'rxjs';
import { debounceTime, filter, map, distinctUntilChanged, tap } from 'rxjs/operators';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { ChangeDetectorRef } from '@angular/core';
import { TemplateFlaggEvent } from 'src/app/shared/events/template-flagg.event';
import { TranslateService } from '@ngx-translate/core';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort} from '@angular/material/sort';
import * as filestack from 'filestack-js';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { PageState } from 'src/app/shared/enums/page-state.enum';

import { SitebarItem } from 'src/app/shared/models/common-models/sitebar-item.model';
import { FilesStoreRequest } from 'src/app/shared/models/requests-models/files-store.model';
import { FilesStoreV3Request } from 'src/app/shared/models/requests-models/files-store-v3.model';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';

import { Pagination } from 'src/app/shared/models/common-models/pagination.model';
import { AssetFolder } from 'src/app/shared/models/asset-models/asset-folder.model';
import { FolderCreateRequest } from 'src/app/shared/models/requests-models/folder-create.model';
import { AssetFolderV3 } from 'src/app/shared/models/asset-models/asset-folder-v3.model';
import { AssetFolderCreateRequest } from 'src/app/shared/models/requests-models/asset-folder-create.model';
import { AssetFile } from 'src/app/shared/models/asset-models/asset-file.model';
import { AssetFileV3 } from 'src/app/shared/models/asset-models/asset-file-v3.model';
import { AssetFileUpdateRequest } from 'src/app/shared/models/requests-models/asset-file-update.model';
import { UserFavorite } from 'src/app/shared/models/user-models/user-favorite.model';

import { UtilService } from 'src/app/shared/services/util.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { LocalRequestsService } from 'src/app/shared/services/local-requests.service';
import { ContentService } from 'src/app/shared/services/content.service';
import { AssetFoldersService } from 'src/app/shared/services/asset-folders.service';
import { AssetFilesService } from 'src/app/shared/services/asset-files.service';
import { AssetsMetadataService } from 'src/app/shared/services/assets-metadata.service';

import { ChooseFoldersComponent } from 'src/app/shared/components/choose-folders/choose-folders.component';
import { EditFolderComponent } from 'src/app/shared/components/edit-folder/edit-folder.component';
import { FolderCreateComponent } from 'src/app/shared/components/folder-create/folder-create.component';


@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.scss']
})
export class ContentComponent extends CleanOnDestroy implements OnInit {

  @ViewChild('search', {static: true}) search: ElementRef;

  currentWorkspace: Workspace;
  availableSpace: number;
  sitebarContentItem: SitebarItem;

  assetFolders: AssetFolderV3[];
  //assetFoldersPaginate: Pagination;
  assetFiles: AssetFileV3[];
  //assetFilesPaginate: Pagination;
  assetFolderFiles: AssetFolderV3[] | AssetFileV3[];
  assetChildPaginate: Pagination;
  assetPaginate: Pagination;

  defaultParentFolderId: number;
  selectedChildFolder: AssetFolderV3;
  uploadPicker: any;

  // Tabular Folders & Files
  @ViewChild(MatSort) sort: MatSort;

  displayedColumns: string[] = ['select', 'folder_name', 'created_date', 'action'];
  initialSelection = [];
  allowMultiSelect = true;
  selection = new SelectionModel<AssetFolderV3>(this.allowMultiSelect, this.initialSelection);
  dataSource: MatTableDataSource<AssetFolderV3>;

  displayedColumnsFiles: string[] = ['select', 'file_name', 'created_date', 'action'];
  initialFileSelection = [];
  fileSelection = new SelectionModel<AssetFileV3>(this.allowMultiSelect, this.initialFileSelection);
  dataSourceFiles: MatTableDataSource<AssetFileV3>;

  tempFiles: any[] = [];

  // Breadcrumbs
  folderTrails: AssetFolderV3[] = [];

  // folder default image
  folderImage: string = '';
  userFavorites: UserFavorite[] = [];

  // Flagg
  serviceEventListener = null;

  // Ts translation
  transErrorCreatingFolder: string = '';
  transDeleteFolder: string = '';
  transDeleteFolderDesc: string = '';
  transCantDeleteFolder: string = '';
  transDeleteFile: string = '';
  transDeleteFileDesc: string = '';
  transDeleteFileErr: string = '';
  transPreviewUn: string = '';
  confirmString: string = '';
  cancelString: string = '';
  pageState = PageState.loading;

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private sharedSrv: SharedService,
    private storageSrv: StorageService,
    private contentSrv: ContentService,
    private assetsMetadataSrv: AssetsMetadataService,
    private assetFolderSrv: AssetFoldersService,
    private assetFilesSrv: AssetFilesService,
    private localRequestsSrv: LocalRequestsService,
    private router: Router,
    private activeRoute: ActivatedRoute,
    private cdr: ChangeDetectorRef
  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.sitebarContentItem = this.utilSrv.getSitebarItem('content');
    this.folderImage = this.utilSrv.appImages.folder;
    this.tsTranslation();
    this.getContent();

    // Listening to API request errors
    this.serviceEventListener = this.sharedSrv.templateFlagg.subscribe({
      next: (event: TemplateFlaggEvent) => {
        
      }
    });
  }

  ngAfterViewInit() {

    fromEvent(this.search.nativeElement,'keyup')
      .pipe(
        filter(Boolean),
        debounceTime(1500),
        distinctUntilChanged(),
        tap((event:KeyboardEvent) => {
          let word = this.search.nativeElement.value;
          word = word.toLowerCase();
          if(word) {
            this.emptyFoldersAndFiles();
            if(this.selectedChildFolder) {
              this.searchChildrenFilesAndFolders(word);
            } else {
              this.searchWorkspaceFoldersAndFiles(word);
            }
          } else {
            if(this.selectedChildFolder) {
              this.getChildrenFilesFolders();
            } else {
              this.getWorkspaceFoldersAndFiles();
            }
          }
        })
      )
      .subscribe();
  }

  tsTranslation() {
    this.translate.get('CONTENT.ERRORCREATINGFOLDER').subscribe((string) => {
      this.transErrorCreatingFolder = string;
    });
    this.translate.get('CONTENT.DELETEFOLDER').subscribe((string) => {
      this.transDeleteFolder = string;
    });
    this.translate.get('CONTENT.DELETEFOLDERDESC').subscribe((string) => {
      this.transDeleteFolderDesc = string;
    });
    this.translate.get('CONTENT.CANTDELETEFOLDER').subscribe((string) => {
      this.transCantDeleteFolder = string;
    });
    this.translate.get('CONTENT.DELETEFILE').subscribe((string) => {
      this.transDeleteFile = string;
    });
    this.translate.get('CONTENT.DELETEFILEDESC').subscribe((string) => {
      this.transDeleteFileDesc = string;
    });
    this.translate.get('CONTENT.DELETEFILEERR').subscribe((string) => {
      this.transDeleteFileErr = string;
    });
    this.translate.get('CONTENT.PREVIEWUN').subscribe((string) => {
      this.transPreviewUn = string;
    });
    this.translate.get('CONFIRMBUTTON').subscribe((string) => {
      this.confirmString = string;
    });
    this.translate.get('CANCELBUTTON').subscribe((string) => {
      this.cancelString = string;
    });
  }

  emptyFoldersAndFiles() {
    this.assetFolders = [];
    this.assetFiles = [];
    this.dataSource = new MatTableDataSource(this.assetFolders);
    this.dataSourceFiles = new MatTableDataSource(this.assetFiles);
  }

  searchWorkspaceFoldersAndFiles(searchKey: string){
    this.assetFolderSrv.searchFolders(
      this.currentWorkspace.account.id, 
      this.currentWorkspace.id,
      'name',
      searchKey
    )
      .subscribe( response => {
        if(response.message) {
          let assets: any = response.message;
          let assetFolders: AssetFolderV3[] = [];
          let assetFiles: AssetFileV3[] = [];

          this.assetFolderFiles = assets;
          this.assetFolders = [];
          this.assetFiles = [];
          this.dataSource = new MatTableDataSource(this.assetFolders);
          this.dataSourceFiles = new MatTableDataSource(this.assetFiles);
          this.assetPaginate = response.pagination;
          this.pageState = PageState.withItems;

          assets.forEach( asset => {
            if(asset.type == 'boldcast/folder') {
              assetFolders.push(asset);
            } else {
              assetFiles.push(asset);
            }
          });

          if(assetFolders.length > 0) {
            this.assetFolders = assetFolders;
            this.assetFolders.sort( (a, b) => a.name.localeCompare(b.name));
            this.dataSource = new MatTableDataSource(this.assetFolders);
          }

          if(assetFiles.length > 0) {
            this.assetFiles = assetFiles;
            this.assetFiles.sort( (a, b) => a.name.localeCompare(b.name));
            this.dataSourceFiles = new MatTableDataSource(this.assetFiles);
          }
        }
      });
  }

  searchChildrenFilesAndFolders(searchKey: string) {
    this.assetFolderSrv.searchChildrenFilesFolders(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.selectedChildFolder.id,
      'name',
      searchKey
    )
      .subscribe( assets => {
        if(assets) {
          let assetFolders: AssetFolderV3[] = [];
          let assetFiles: AssetFileV3[] = [];

          assets.forEach( asset => {
            if(asset.type == 'boldcast/folder') {
              assetFolders.push(asset);
            } else {
              assetFiles.push(asset);
            }
          });

          if(assetFolders.length > 0) {
            this.assetFolders = assetFolders;
            this.assetFolders.sort( (a, b) => a.name.localeCompare(b.name));
            this.dataSource = new MatTableDataSource(this.assetFolders);
          }

          if(assetFiles.length > 0) {
            this.assetFiles = assetFiles;
            this.assetFiles.sort( (a, b) => a.name.localeCompare(b.name));
            this.dataSourceFiles = new MatTableDataSource(this.assetFiles);
          }
        }
      });
  }

  // Folder checkbox toggle
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected == numRows;
  }
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }
  selectFolder(row) {
    this.selection.clear();
    this.selection.toggle(row);
  }
  // End - Folder checkbox toggle

  // File checkbox toggle
  isAllFileSelected() {
    const numSelected = this.fileSelection.selected.length;
    const numRows = this.dataSourceFiles.data.length;
    return numSelected == numRows;
  }
  fileMasterToggle() {
    this.isAllFileSelected() ?
      this.fileSelection.clear() :
      this.dataSourceFiles.data.forEach(row => this.fileSelection.select(row));
  }
  selectFile(row) {
    this.fileSelection.clear();
    this.fileSelection.toggle(row);
  }
  // End - File checkbox toggle

  emptySelection() {
    this.selection.clear();
    this.fileSelection.clear();
  }

  backToContent() {
    this.folderTrails.length = 0;
    this.selectedChildFolder = null;
    this.emptySelection();
    this.getWorkspaceFoldersAndFiles();
  }

  onTrailsClick(folder, index) {
    if(this.folderTrails && this.folderTrails.length != 0) {
      this.folderTrails.length = parseInt(index) + 1;
    } else {
      this.folderTrails.length = 0;
    }
    this.selectedChildFolder = folder;
    this.emptySelection();
    this.getChildrenFilesFolders();
  }

  getContent() {
    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe(async(workspace) => {
        if (workspace) {
          this.currentWorkspace = workspace;
          if(this.canRead()) {
            this.initializeFilestack(workspace);
            this.getWorkspaceStorageSpace();
            this.getWorkspaceFoldersAndFiles();
          } else {
            this.pageState = PageState.noReadPermission;
          }
        }
      });
  }

  /**
   * calls when changed selected workspace
   * get workspace signature initialize filestack and set options
   * @param workspaceId is a workspace id which signature should be retrive
   * @return `null`
   */
  // initializeFilestack(workspace: Workspace) {
  //   this.contentSrv.getWorkspaceSignature(workspace.id).subscribe(security => {
  //     this.uploadPicker = filestack.init('AyICa710SKHijIQhQZ2UQz', { "security": security });
  //   });
  // }
  initializeFilestack(workspace: Workspace) {
    this.assetsMetadataSrv.getUploadPolicySignature(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    ).subscribe(security => {
      if(security) {
        this.uploadPicker = filestack.init('AyICa710SKHijIQhQZ2UQz', { "security": security });
      }
    });
  }

  /**
   * calls when changed selected workspace
   * get workspace storage info with type `AssetSizeInfo`
   * which contains used space and total space infos
   * @param null
   * @return `null`
   */
  // getWorkspaceStorageSpace() {
  //   this.contentSrv.getAssetsSize(this.currentWorkspace.id).subscribe(assetsSize => {
  //     let availableSpace = assetsSize.total - assetsSize.used;
  //     this.availableSpace = (availableSpace / 1024 / 1024 / 1024);
  //   });
  // }

  getWorkspaceStorageSpace() {
    this.assetsMetadataSrv.getSizeOfAssets(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    ).subscribe(assetsSize => {
      if(assetsSize) {
        let availableSpace = assetsSize.total - assetsSize.used;
        this.availableSpace = (availableSpace / 1024 / 1024 / 1024);
      }
    });
  }  

  getWorkspaceFoldersAndFiles(){
    this.assetFolderSrv.getFolders(
      this.currentWorkspace.account.id, 
      this.currentWorkspace.id
    )
      .subscribe( response => {
        if(response.message) {
          let assets: any = response.message;
          let assetFolders: AssetFolderV3[] = [];
          let assetFiles: AssetFileV3[] = [];

          if(assets.length > 0 && assets[0].hasOwnProperty('parentFolder')) {
            this.defaultParentFolderId = assets[0]?.parentFolder;
          }

          this.assetFolderFiles = assets;
          this.assetFolders = [];
          this.assetFiles = [];
          this.dataSource = new MatTableDataSource(this.assetFolders);
          this.dataSourceFiles = new MatTableDataSource(this.assetFiles);
          this.assetPaginate = response.pagination;
          this.pageState = PageState.withItems;

          assets.forEach( asset => {
            if(asset.type == 'boldcast/folder') {
              assetFolders.push(asset);
            } else {
              assetFiles.push(asset);
            }
          });

          if(assetFolders.length > 0) {
            this.assetFolders = assetFolders;
            this.assetFolders.sort( (a, b) => a.name.localeCompare(b.name));
            this.dataSource = new MatTableDataSource(this.assetFolders);
          }

          if(assetFiles.length > 0) {
            this.assetFiles = assetFiles;
            this.assetFiles.sort( (a, b) => a.name.localeCompare(b.name));
            this.dataSourceFiles = new MatTableDataSource(this.assetFiles);
          }
        }
      });
  }

  getFoldersAndFilesNext() {
    this.assetFolderSrv.getFoldersNext(
      this.assetPaginate.next
    )
      .subscribe( response => {
        if(response.message) {
          let assets: any = response.message;
          let assetFolders: AssetFolderV3[] = [];
          let assetFiles: AssetFileV3[] = [];

          this.assetPaginate = response.pagination;
          this.assetFolderFiles.push(...assets);

          assets.forEach( asset => {
            if(asset.type == 'boldcast/folder') {
              assetFolders.push(asset);
            } else {
              assetFiles.push(asset);
            }
          });

          if(assetFolders.length > 0) {
            this.assetFolders.push(...assetFolders);
            this.assetFolders.sort( (a, b) => a.name.localeCompare(b.name));
            this.dataSource = new MatTableDataSource(this.assetFolders);
          }

          if(assetFiles.length > 0) {
            this.assetFiles.push(...assetFiles);
            this.assetFiles.sort( (a, b) => a.name.localeCompare(b.name));
            this.dataSourceFiles = new MatTableDataSource(this.assetFiles);
          }
        }
      });
  }

  /**
   * calls from template
   * when user clicked on the `Create Folder` button
   *
   * open dialog for a type folder name
   * after closed popup create folder
   * in case of user clicked on the save button
   *
   * @param null
   * @return `null`
   */
  onCreateFolder() {
    if (this.currentWorkspace) {
      this.subscriber = this.sharedSrv.openDialog(
        { parentId: (this.selectedChildFolder) ? this.selectedChildFolder.id : this.defaultParentFolderId },
        true,
        null,
        FolderCreateComponent
      )
        .subscribe(response => {
          if (response.continue) {
            if(this.selectedChildFolder) {
              this.getChildrenFilesFolders();
            } else {
              this.getWorkspaceFoldersAndFiles();
            }
          }
        })
    } else {
      let desc = this.transErrorCreatingFolder;
      this.sharedSrv.errorDialog(desc);
    }
  }

  /**
   * calls from template
   * when user clicked on the open button in folder options
   * change route
   * @param folderId with type `number` which should be opened
   * @return `null`
   */
  onOpenFolder(folder: AssetFolderV3) {
    let folderTrails = this.folderTrails;
    let folderIndex = folderTrails.findIndex( index => index.id == folder.id);
    if(folderIndex == -1) {
      this.folderTrails.push(folder);
    }
    this.selectedChildFolder = folder;
    this.emptySelection();
    this.getChildrenFilesFolders();
  }

  getChildrenFilesFolders() {
    this.assetFolderSrv.retrieveChildrenFilesFolders(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.selectedChildFolder.id
    )
      .subscribe( response => {
        if(response.message) {
          let assets: any = response.message;
          let assetFolders: AssetFolderV3[] = [];
          let assetFiles: AssetFileV3[] = [];

          this.assetFolders = [];
          this.assetFiles = [];
          this.dataSource = new MatTableDataSource(this.assetFolders);
          this.dataSourceFiles = new MatTableDataSource(this.assetFiles);
          this.assetChildPaginate = response.pagination;

          this.assetFolderFiles = assets;

          assets.forEach( asset => {
            if(asset.type == 'boldcast/folder') {
              assetFolders.push(asset);
            } else {
              assetFiles.push(asset);
            }
          });

          if(assetFolders.length > 0) {
            this.assetFolders = assetFolders;
            this.assetFolders.sort( (a, b) => a.name.localeCompare(b.name));
            this.dataSource = new MatTableDataSource(this.assetFolders);
          }

          if(assetFiles.length > 0) {
            this.assetFiles = assetFiles;
            this.assetFiles.sort( (a, b) => a.name.localeCompare(b.name));
            this.dataSourceFiles = new MatTableDataSource(this.assetFiles);
          }
        }
      });
  }

  getFoldersChildNext() {
    this.assetFolderSrv.retrieveChildrenFilesFoldersNext(
      this.assetChildPaginate.next
    )
      .subscribe( response => {
        if(response.message) {
          let assets: any = response.message;
          let assetFolders: AssetFolderV3[] = [];
          let assetFiles: AssetFileV3[] = [];
          this.assetChildPaginate = response.pagination;
          this.assetFolderFiles.push(...assets);

          assets.forEach( asset => {
            if(asset.type == 'boldcast/folder') {
              assetFolders.push(asset);
            } else {
              assetFiles.push(asset);
            }
          });

          if(assetFolders.length > 0) {
            this.assetFolders.push(...assetFolders);
            this.assetFolders.sort( (a, b) => a.name.localeCompare(b.name));
            this.dataSource = new MatTableDataSource(this.assetFolders);
          }

          if(assetFiles.length > 0) {
            this.assetFiles.push(...assetFiles);
            this.assetFiles.sort( (a, b) => a.name.localeCompare(b.name));
            this.dataSourceFiles = new MatTableDataSource(this.assetFiles);
          }
        }
      });
  }

  /**
   * calls from template
   * when user clicked on the move button in folder options
   * change route
   *
   * @param folder is a folder which user want move into another folder (type `AssetFolder`)
   * @param folderIndex is a folder index from `assetFolders` (type `number`)
   * @return `null`
   */

  onMoveFolder() {
    if(this.selection.selected.length > 0 || this.fileSelection.selected.length > 0) {
      this.sharedSrv.openDialog<any>(
        {
          folderSelection: this.selection.selected,
          fileSelection: this.fileSelection.selected,
          parentFolderId: this.defaultParentFolderId
        },
        true,
        {
          width: '90%',
          height: 'calc(100vh - 120px)'
        },
        ChooseFoldersComponent
      ).subscribe(dialogResponse => {
        if (dialogResponse.continue) {
          if(this.selectedChildFolder) {
            this.getChildrenFilesFolders();
          } else {
            this.getWorkspaceFoldersAndFiles();
          }
        }
        this.emptySelection();
      });
    }
  }

  onEditFolder(folder: AssetFolderV3) {
    this.sharedSrv.openDialog<AssetFolderV3>(
      {
        folder: folder
      },
      true,
      { width: '45%' },
      EditFolderComponent
    ).subscribe(dialogResponse => {
      if (dialogResponse.continue) {
        let updatedFolder = dialogResponse.outputData;
        // To Dos - Update edited folder
        for(let key in this.assetFolders) {
          if(this.assetFolders[key].id == updatedFolder.id) {
            this.assetFolders[key] = updatedFolder;
            break;
          }
        }
        this.assetFolders.sort( (a, b) => a.name.localeCompare(b.name));
        this.dataSource = new MatTableDataSource(this.assetFolders);
      }
      this.emptySelection();
    });
  }

  /**
   * calls from template
   * when user clicked on the delete button in folder options
   *
   * open dialog for a confirmation
   * and delete folder after confirm
   *
   * @param folder with type `AssetFolder` which should be deleted
   * @param folderIndex with type `number` index of `assetFolders` array
   * @return `null`
   */

  onDeleteFolders() {
    if(this.selection.selected.length > 0 || this.fileSelection.selected.length > 0) {
      this.subscriber = this.sharedSrv.openDialog(
        {
          title: this.transDeleteFolder,
          description: this.transDeleteFolderDesc,
          template: 0,
          confirm: this.confirmString,
          cancel: this.cancelString
        },
        true,
        { width: '45%' }
      ).subscribe(response => {
        if (response.continue) {
          this.deleteFolders();
          this.deleteFiles();
        }
        this.emptySelection();
      })
    }
  }

  deleteFolders() {
    let selectedFolders = this.selection.selected;
    let folderIds:number[] = selectedFolders.map( folder => folder.id);
    let deleteBody: { folders: number[] } = { folders: folderIds };
    if(deleteBody.folders.length > 0) {
      this.assetFolderSrv.deleteFolders(
        this.currentWorkspace.account.id,
        this.currentWorkspace.id,
        deleteBody
      )
        .subscribe(response => {
          if (response) {
            if(this.selectedChildFolder) {
              this.getChildrenFilesFolders();
            } else {
              this.getWorkspaceFoldersAndFiles();
            }
          } else {
            this.sharedSrv.errorDialog(this.transCantDeleteFolder);
          }
      })
    }
  }

  deleteFiles() {
    let selectedFiles = this.fileSelection.selected;
    let fileIds:number[] = selectedFiles.map( file => file.id);
    let deleteBody: { files: number[] } = { files: fileIds };
    if(deleteBody.files.length > 0) {
      this.assetFilesSrv.deleteFiles(
        this.currentWorkspace.account.id,
        this.currentWorkspace.id,
        deleteBody
      )
        .subscribe(response => {
          if (response) {
            if(this.selectedChildFolder) {
              this.getChildrenFilesFolders();
            } else {
              this.getWorkspaceFoldersAndFiles();
            }
          } else {
            this.sharedSrv.errorDialog(this.transDeleteFileErr);
          }
        })
    }
  }

  /**
   * calls from template
   * helper for a optimizing *ngFor
   * @param index is a current element index with type `number`
   * @param item is a current element info with type `Workspace`
   * @return `number`
   */
  onTrackById(index: number, item: AssetFileV3 | AssetFolderV3) {
    return item.id;
  }


  /**
   * calls from template
   * when user clicked on the `Upload` button
   *
   * open dialog for a choose some files,
   * copy and past or drang and drop files
   *
   * after closed dialog upload chosed files
   * in case of user clicked on the upload button
   *
   * @param null
   * @return `null`
   */
  onUploadFile() {
    let parentFolderId = (this.selectedChildFolder) ? this.selectedChildFolder.id : this.defaultParentFolderId;
    if (this.uploadPicker && this.defaultParentFolderId) {
      if (this.storageSrv.currentAccount && this.currentWorkspace) {
        let uploadPicker = this.uploadPicker.picker(
          this.utilSrv.fileStackOptionsInitV3(
            this.currentWorkspace,
            this.storageSrv.currentAccount,
            parentFolderId,
            //this.uploadFiles.bind(this),
            this.uploadFilesV3.bind(this),
            this.sharedSrv.errorDialog
          )
        );
        uploadPicker.open();
      }
    }
  }

  /**
   * `utilSrv.fileStackOptionsInit` callback function
   * calls from filestackApi `options.onUploadDone`
   * upload user select files and update `assetFiles` property
   * @param uplodFileForm is array of files which already uploaded on the
   * storage and should be store files info in the server
   * (type `FilesStoreRequest`)
   * @return `null`
   */
  // uploadFiles(uploadFileForm: FilesStoreRequest) {

  //   for (let f in uploadFileForm['assets']) {
  //     this.tempFiles.push(uploadFileForm['assets'][f]);
  //   }

  //   this.contentSrv.uploadFilesV3(
  //     uploadFileForm
  //   )
  //     .subscribe(uploadedFiles => {
  //       if(uploadedFiles) {
  //         if(this.selectedChildFolder) {
  //           this.getChildrenFilesFolders();
  //         } else {
  //           this.getWorkspaceFoldersAndFiles();
  //         }
  //         this.cdr.detectChanges();
  //         this.tempFiles = [];
  //         this.getWorkspaceStorageSpace();
  //       }
  //     })
  // }

  uploadFilesV3(uploadFileForm: FilesStoreV3Request) {

    for (let f in uploadFileForm['files']) {
      this.tempFiles.push(uploadFileForm['files'][f]);
    }

    this.assetFilesSrv.addAssetsToWorkspace(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      uploadFileForm
    )
      .subscribe(uploadedFiles => {
        if(uploadedFiles) {
          if(this.selectedChildFolder) {
            this.getChildrenFilesFolders();
          } else {
            this.getWorkspaceFoldersAndFiles();
          }
          this.cdr.detectChanges();
          this.tempFiles = [];
          this.getWorkspaceStorageSpace();
          this.emptySelection();
        }
      })
  }

  /**
   * calls from template
   * check file type and return corresponding image url
   * @param file with type `AssetFile`
   * @return `null`
   */
  onShowFileImage(file: AssetFileV3) {
    let orgId = this.currentWorkspace.account.id;
    let workspaceId = this.currentWorkspace.id;
    let imageEndpoint = `${this.utilSrv.env.endPoint}/api/v3/orgs/${orgId}/workspaces/${workspaceId}/assets/files/`;
    let fileImage: string = '';
    if (file.type == 'image/jpg' ||
      file.type == 'image/jpeg' ||
      file.type == 'image/png' ||
      file.type == 'image/gif' ) {
      fileImage = imageEndpoint + file.id + '/thumbnail/';
    } else {
      fileImage = this.utilSrv.fileIcons[file.type];
    }
    return fileImage;
  }

  /**
   * calls from template
   * when user clicked on the `Download` button in file options
   * @param file is a file with type `AssetFile`
   * which option user clicked
   * @return `null`
   */
  onDownloadFile(file: AssetFileV3) {
    let imageEndpoint = `${this.utilSrv.env.endPoint}/api/v3/`;
    let downloadEndpoint = `${imageEndpoint}orgs/${this.currentWorkspace.account.id}/workspaces/${this.currentWorkspace.id}/assets/files/${file.id}/download/`;
    this.localRequestsSrv.downloadFile(downloadEndpoint, file.name);
  }

  onStopPropagation(event: MouseEvent) {
    event.stopPropagation();
  }

  onOpenImageForPreview(file: AssetFileV3, previewContainer: HTMLDivElement) {
    previewContainer.classList.remove('d-none');
    previewContainer.innerHTML = this.onCanShowFileImage(file);
  }

  onCloseImageModal(previewContainer: HTMLDivElement) {
    previewContainer.innerHTML = '';
  }

  onCanShowFileImage(file: AssetFileV3) {
    let innerHtml = `<h3 class="mat-h3 mb-0 font-weight-semibold">${this.transPreviewUn}</h3>`;
    let allowedPreviewExtensions = [
      {
        extension: 'image/png',
        tag: 'img',
        attribute: 'src',
        shouldCloseTag: false,
        classList: 'preview-image'
      },
      {
        extension: 'image/jpg',
        tag: 'img',
        attribute: 'src',
        shouldCloseTag: false,
        classList: 'preview-image'
      },
      {
        extension: 'image/jpeg',
        tag: 'img',
        attribute: 'src',
        shouldCloseTag: false,
        classList: 'preview-image'
      },
      {
        extension: 'video',
        tag: 'video',
        attribute: 'src',
        shouldCloseTag: true,
        classList: 'preview-image',
      },
    ];

    allowedPreviewExtensions.every(allowedPreviewExtension => {
      if (file.type.indexOf(allowedPreviewExtension.extension) >= 0) {
        innerHtml = '';
        innerHtml =
          `<${allowedPreviewExtension.tag}
          ${allowedPreviewExtension.attribute}="${this.utilSrv.env.endPoint}/api/v3/orgs/${this.currentWorkspace.account.id}/workspaces/${this.currentWorkspace.id}/assets/files/${file.id}/thumbnail/"
          class="${allowedPreviewExtension.classList}" autoplay muted>`;
        if (allowedPreviewExtension.shouldCloseTag) {
          innerHtml = innerHtml + `</${allowedPreviewExtension.tag}>`;
        }
        return false;
      }
      return true;
    });
    return innerHtml;
  }

  canUpdate(){
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.content);
  }

  canRead(){
    return this.storageSrv.getWorkspaceReadPermission(Resource.content);
  }

  canWrite() {
    return this.storageSrv.getWorkspaceWritePermission(Resource.content);
  }

  canUpload() {
    return this.uploadPicker != null && this.storageSrv.getWorkspaceWritePermission(Resource.content);
  }

  canDelete() {
    return this.storageSrv.getWorkspaceDeletePermission(Resource.content);
  }

}
