import { Component, OnInit, HostListener, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { forkJoin, of } from 'rxjs';
import { CleanOnDestroy } from '../shared/classes/clean-destroy';

import { UtilService } from '../shared/services/util.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { WorkspacesService } from '../shared/services/workspaces.service';
import { AuthService } from '../shared/services/auth.service';
import { StorageService } from '../shared/services/storage.service';
import { UsersService } from '../shared/services/users.service';
import { AccountsService } from '../shared/services/accounts.service';
import { BillingService } from '../shared/services/billing.service';
import { SubscriptionsService } from '../shared/services/subscriptions.service';
import { PlaylistsService } from '../shared/services/playlists.service';
import { VersioningService } from 'src/app/shared/services/versioning.service';

import { Workspace } from '../shared/models/workspace-models/workspace.model';
import { SitebarItem } from '../shared/models/common-models/sitebar-item.model';
import { Account } from '../shared/models/account-models/account.model';
import { Subscription } from '../shared/models/subscription-models/subscription.model';
import { Versioning } from 'src/app/shared/models/versioning-models/versioning.model';
import { AccountFeatures } from 'src/app/shared/models/account-models/account-features.model';

import { AppWelcomeComponent } from '../shared/components/app-welcome/app-welcome.component';
import { AccountInvitationsComponent } from 'src/app/shared/components/account-invitations/account-invitations.component';
import { AccountsComponent } from 'src/app/shared/components/accounts/accounts.component';
import { TryMobileAppComponent } from 'src/app/shared/components/try-mobile-app/try-mobile-app.component';

// new addition
import { environment } from 'src/environments/environment';
import { v4 as uuid } from 'uuid';
import { TranslateService } from '@ngx-translate/core';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { DeviceDetectorService } from 'ngx-device-detector';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  host: {
    "(window:click)": "onClickOutside()"
  }
})
export class DashboardComponent extends CleanOnDestroy implements OnInit {

  protected baseUrl = environment.endPoint;
  logoutUrl: string = '/logout/';
  affiliateUrl: string = 'https://boldcast.firstpromoter.com/';
  supportUrl: string = '';
  supportIcon: string = '';

  isSiteBarVisible: boolean = true;
  sitebarMode: 'over' | 'push' | 'side' = 'side';
  shouldOpenSitebar: boolean = true;
  activeSitebarSub: string = '';

  isMobileView: boolean;

  accountLogoEndpoint: string = '';

  // show this image when user not have profile image
  profileDefaultImage: string = '';

  mobileWidth: number = 767;

  selectedIndex: number = 0;
  // boldcast white logo
  whiteLogo: string = '';
  // logout image
  logoutLogo: string = '';
  // show this image if workspace haven't logo

  // depends property value open or close workspace menu
  shouldOpenWorkspaceMenu: boolean = false;

  // store sitebar items info
  sitebarItems: SitebarItem[];

  // referance of storageSrv.selectedWorkspace
  selectedWorkspace: Workspace;

  // referance of storageSrv.workspacesByAccountsId
  workspacesByAccountsId: {
    [key: number]: Workspace[]
  }

  accountFeatures: AccountFeatures;

  version: string = '';
  isNewVersion: boolean = false;
  intervalId: any;
  currentLocale: any = '';
  isCookie: boolean = false;

  @ViewChild(AppWelcomeComponent, { static: true }) appWelcome: AppWelcomeComponent;

  constructor(
    public translate: TranslateService,
    private sharedSrv: SharedService,
    public storageSrv: StorageService,
    private router: Router,
    public utilSrv: UtilService,
    private workspacesSrv: WorkspacesService,
    private userSrv: UsersService,
    private accountSrv: AccountsService,
    private billingSrv: BillingService,
    private subscriptionSrv: SubscriptionsService,
    private authService: AuthService,
    private versioningSvc: VersioningService,
    private playlistsSrv: PlaylistsService,
    private deviceService: DeviceDetectorService
  ) {
    super();

    translate.setDefaultLang(this.utilSrv.locale);
    translate.use(this.utilSrv.locale);
    this.mobileDetection();
  }

  ngOnInit() {

    this.currentLocale = this.utilSrv.locale;
    this.logoutUrl = this.utilSrv.env.logoutUrl;
    this.supportUrl = this.utilSrv.sitebarItems[8].route;
    this.supportIcon = this.utilSrv.sitebarItems[8].icon;

    // get the component images
    this.whiteLogo = this.utilSrv.appImages.whiteLogo;
    this.profileDefaultImage = this.utilSrv.appImages.profileDefaultImage;
    this.logoutLogo = this.utilSrv.appImages.logout;
    // get the sitebar items from shared service
    this.sitebarItems = this.utilSrv.sitebarItems;

    this.accountLogoEndpoint = `${this.utilSrv.env.endPoint}/api/v1/accounts/`;

    // Testing UUID's
    // this.testing();

    // get current user info and store the user info into property
    this.getCurrentUserInfo();

    //this.getAccountAndWorkspacesData();

    // this.subscribeToTheWorkspaceChanges(); // now doing this inside the above function to avoid race conditions

    // call once before add event listener
    this.onCheckDeviceWidth(window.innerWidth);

    // get app version
    this.showVersion();

    this.intervalId = window.setInterval(() => {
      this.showVersion();
    }, 60 * 60 * 1000);

    this.checkCookie();

  }

  ngOnDestroy() {
    clearInterval(this.intervalId);
  }

  mobileDetection() {
    const isMobile = this.deviceService.isMobile();
    if(isMobile) {
      this.sharedSrv.openDialog(
        {},
        true,
        null,
        TryMobileAppComponent).subscribe(response => {
          if (response.continue){
          }
      });
    }
  }

  testing() {
    // this.versioningSvc.testing().subscribe(data => {
    // });
  }

  checkCookie() {
    this.isCookie = (navigator.cookieEnabled) ? true : false;
  }

  /**
   * get current app version from the server
   * @param null
   * @return `null`
   */
  showVersion() {
    let currentVersion = environment.appVersion;
    this.versioningSvc.getVersion().subscribe(data => {
      if(data) {
        currentVersion = data["version"];
        if (this.version === ''){
          this.version = currentVersion;
        }
        else if (this.version != currentVersion) {
          this.isNewVersion = true;
          this.version = currentVersion;
        }
      }
    });
  }

  /**
   * Refresh entire app
   * @param null
   * @return `null`
   */
  reloadApp() {
    window.location.reload(true);
  }

  /**
   * send request to the server for a get logged in user info
   * and store into `storageSrv.currentUserInfo`
   * @param null
   * @return `null`
   */
  getCurrentUserInfo() {
    this.userSrv.getCurrentUserInfo()
      .subscribe(userInfo => {
        if(userInfo) {
          this.storageSrv.currentUserInfo = userInfo;
          this.getAccountAndWorkspacesData();
        }
      });

    this.userSrv.getCurrentUserInvitations()
      .subscribe(invitations => {
        if(invitations) {
          this.storageSrv.currentUserInvitations = invitations;
        }
      });
  }

  subscribeToTheWorkspaceChanges() {
    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe(workspace => {
        if (workspace) {
          if (this.selectedWorkspace && this.selectedWorkspace.account.id !== workspace.account.id) {
            this.storageSrv.enableTrialNotifications();
            this.storageSrv.enableSubscribtionEndNotifications();
            this.storageSrv.shouldShowTrialNotification = '';
            this.storageSrv.shouldShowSubscriptionNotification = '';
          }
          this.selectedWorkspace = workspace;
          if (this.storageSrv.currentUserAccounts) {
            this.storageSrv.currentAccount = this.storageSrv.currentUserAccounts.find(account => account.id === this.selectedWorkspace.account.id);
            this.getAccountBilling(this.selectedWorkspace.account.id);
            this.checkSsoClientKey();
          }

          // load new features
          this.accountSrv.retrieveAccountFeatures(this.selectedWorkspace.account.id)
          .subscribe( accountFeatures => {
            if(accountFeatures) {
              this.accountFeatures = accountFeatures;
              this.storageSrv.accountFeatures = accountFeatures;
            }
          });

          this.loadCustomCSS();
        }
      })
  }

  /**
   * get account billing info from server
   * @param null
   * @return `null`
   */
  getAccountBilling(accountId: number) {
    //this.accountSrv.getAccountBilling(accountId)
    this.billingSrv.retrieveBillingInfo(accountId)
      .subscribe(accountBilling => {
        if (accountBilling) {
          this.storageSrv.currentAccountBilling = accountBilling;
          this.getAccountSubscription(accountBilling.subscription);
        }
      })
  }

  /* Get account subscription */
  getAccountSubscription(subscriptionId: number) {
    this.subscriptionSrv.getSubscription(subscriptionId)
      .subscribe( subscription => {
        if(subscription) {
          this.storageSrv.currentAccountSubscription = subscription;
          this.storageSrv.updateProfessional();
        }
      });
  }

  onGetUserAccountInvitations(){
    if (this.storageSrv.currentUserInvitations){
      return this.storageSrv.currentUserInvitations;
    } else {
      return [];
    }
  }

  onGetUserName() {
    let name = '';
    if (this.storageSrv.currentUserInfo) {
      let user = this.storageSrv.currentUserInfo;
      if (user.firstName && user.lastName) {
        name = `${user.firstName} ${user.lastName}`;
      } else {
        name = `${user.email}`;
      }
    }

    if(name.length > 23) {
      return name.substring(0, 23) + '...';
    }
    return name;
  }

  /**
   * get accounts and workspaces
   * after sorted worskpaces by accounts id
   * @param null
   * @return `null`
   */
  getAccountAndWorkspacesData() {
    forkJoin(
      of(this.accountSrv.getUserAccouts()),
      of(this.workspacesSrv.getAllWorkspases())
    ).subscribe(accountsAndWorkspaces => {

      accountsAndWorkspaces[0].subscribe(accounts => {
        this.storageSrv.currentUserAccounts = accounts;
        if (this.storageSrv.currentUserAccounts.length === 0) {
          if(this.router.url != '/profile') {
            this.router.navigate(['/new/']);
          }
        } else {
          this.appWelcome.startIfAvailable();
        }
        this.subscribeToTheWorkspaceChanges();
        accountsAndWorkspaces[1].subscribe(workspaces => {
          if (workspaces.length == 0 && accounts.length > 0) {
            this.isSiteBarVisible = false;
            // Should redirect to the new route.
            this.router.navigate(['accounts/noworkspaces']);
          }
        });
      });

      accountsAndWorkspaces[1].subscribe(workspaces => {
        this.isSiteBarVisible = true;
        this.storageSrv.currentUserWorkspaces = workspaces;
        let selectedWorkspace: Workspace;
        let workspaceId = this.storageSrv.getSelectedWorkspaceId();
        if (workspaceId >= 0 && this.storageSrv.currentUserWorkspaces) {
          this.storageSrv.currentUserWorkspaces.every(workspace => {
            if (workspace.id === workspaceId) {
              selectedWorkspace = workspace;
              return false;
            }

            return true;
          });

          if (selectedWorkspace == null){
            selectedWorkspace = this.storageSrv.currentUserWorkspaces[0];
          }
        } else {
          // No selected workspace yet
          selectedWorkspace = this.storageSrv.currentUserWorkspaces[0];
        }

        // Calling first the Account Features
        if (selectedWorkspace){
          this.accountSrv.retrieveAccountFeatures(selectedWorkspace.account.id)
          .subscribe( accountFeatures => {
            if(accountFeatures) {
              // Testing purposes only
              // let testAccountFeatures: AccountFeatures = {
              //   announcements: true,
              //   api_access: true,
              //   custom_refresh_rate: true,
              //   num_apps: 5000,
              //   num_channels: 4000,
              //   num_integrations: 2000,
              //   num_storage_gbs: 300,
              //   num_users: 20,
              //   num_workspaces: 1000,
              //   offline_notifications: true,
              //   onboarding: false,
              //   premium_casts: true,
              //   schedules: true,
              //   sso: false,
              //   streams: false,
              //   web_player: false,
              //   whitelabel: false,
              //   change_management: false
              // };
              //this.accountFeatures = testAccountFeatures;
              //this.storageSrv.accountFeatures = testAccountFeatures;
              this.accountFeatures = accountFeatures;
              this.storageSrv.accountFeatures = accountFeatures;
              // Note: responsible for sending multiple api request: this.storageSrv.selectedWorkspace()
              this.storageSrv.selectedWorkspace = selectedWorkspace;
              this.moveSelectedWorkspaceToTop(selectedWorkspace);
              // Storing selected workspace id for v3 endpoint
              this.storageSrv.currentWorkspace = String(selectedWorkspace.id);
              // Check if admin for current workspace
              if (this.storageSrv.selectedWorkspace){
                this.checkIsAdmin(this.storageSrv.selectedWorkspace.account.id);
              }
            }
          });
        }

        // Check if admin for current workspace
        // if (this.storageSrv.selectedWorkspace){
        //   this.checkIsAdmin(this.storageSrv.selectedWorkspace.account.id);
        // }
        // Avoid async issue
        if(!this.storageSrv.userAccountsSubject) {
          let subscription = this.storageSrv.userAccountsSubject
            .subscribe(accounts => {
              if (accounts) {
                if(this.storageSrv.selectedWorkspace != undefined) {
                  this.storageSrv.currentAccount = this.storageSrv.currentUserAccounts.find(account => account.id === this.storageSrv.selectedWorkspace.account.id);
                  this.checkSsoClientKey();
                }
                if (subscription) {
                  subscription.unsubscribe();
                }
              }
            });
        }

        //this.getAccountFeatures();
        this.sortWorkspacesByAccountId();
        this.loadCustomCSS();
      });
    });
  }

  checkSsoClientKey() {
    if(this.storageSrv.currentAccount) {
      let ssoEnabled = this.storageSrv.currentAccount.ssoEnabled;
      if(ssoEnabled) {
        this.logoutUrl = `${this.utilSrv.env.endPoint}/logout/sso/`;
      }
    }
  }

  // getAccountFeatures() {
  //   let accountId = this.storageSrv.selectedWorkspace.account.id;
  //   this.subscriber = this.accountSrv.retrieveAccountFeatures(accountId)
  //     .subscribe( features => {
  //       if(features) {
  //         this.storageSrv.accountFeatures = features;
  //       }
  //     });
  // }

  // For change management page
  // getAccountFeaturesFlags() {
  //   let accountId = this.storageSrv.selectedWorkspace.account.id;
  //   this.subscriber = this.accountSrv.retrieveFeaturesFlags(accountId)
  //     .subscribe( flags => {
  //       if(flags) {
  //         this.storageSrv.accountFeaturesFlags = flags;
  //       }
  //     });
  // }

  /**
   * Sorting workspaces by account id
   * @param null
   * @return `null`
   */
  sortWorkspacesByAccountId() {
    // reset workspacesByAccountsId object
    this.storageSrv.workspacesByAccountsId = {};

    // Sorted workspaces by workpsace account id
    this.storageSrv.currentUserWorkspaces.forEach(workpsace => {
      if (!this.storageSrv.workspacesByAccountsId[workpsace.account.id]) {
        this.storageSrv.workspacesByAccountsId[workpsace.account.id] = [];
      }
      this.storageSrv.workspacesByAccountsId[workpsace.account.id].push(workpsace);
    });
    this.workspacesByAccountsId = this.storageSrv.workspacesByAccountsId;
  }

  onChangeSelectedWorkspace(workspace: Workspace) {
    this.storageSrv.selectedWorkspace = workspace;
    this.selectedWorkspace = workspace;
    this.checkIsAdmin(workspace.account.id);
    this.moveSelectedWorkspaceToTop(workspace);
  }

  moveSelectedWorkspaceToTop(workspace: Workspace){
    // find selected workspace/account and put them at the top of the currentUserAccounts
    if(workspace != undefined) {
      if (this.storageSrv.currentUserAccounts){
        for (var i = 0; i < this.storageSrv.currentUserAccounts.length; i++){
          if (workspace.account.id == this.storageSrv.currentUserAccounts[i].id){
            var item = this.storageSrv.currentUserAccounts[i];
            this.storageSrv.currentUserAccounts.splice(i,1);
            this.storageSrv.currentUserAccounts.unshift(item);
            break;
          }
        }
      }
    }
  }


  /**
   * calls from template
   * logout with route changes
   * @param null
   * @return `null`
   */
  onLogout() {
    this.authService.logout();
  }

  /**
   * calls from template
   * open workspace menu
   *
   * @param null
   *
   * @return `null`
   */
  onOpenWorkspaceMenu() {
    this.shouldOpenWorkspaceMenu = true;
    if (this.selectedWorkspace){
      this.checkIsAdmin(this.selectedWorkspace.account.id);
    }
  }

  /**
   * calls from template
   * close workspace menu
   *
   * @param null
   *
   * @return `null`
   */
  onCloseWorkspaceMenu() {
    this.shouldOpenWorkspaceMenu = false;
  }

  /**
   * calls from template
   * navigate to the account view without opening expansion panel
   *
   * @param null
   *
   * @return `null`
   */
  onViewAccount(accountId: number, event) {
    if (this.storageSrv.getAdminAccount(accountId)){
      event.stopPropagation();
      this.onCloseWorkspaceMenu();
      this.router.navigate(['/accounts', accountId]);
    }
  }

  /**
   * calls from template
   * redirect user to the create new account page
   *
   * @param null
   *
   * @return `null`
   */
  onCreateNewAccount() {
    this.onCloseWorkspaceMenu();
    window.location.href = window.location.protocol + "//"+window.location.hostname+'/new/';
  }

  /**
   * calls from template
   * set the user profile image
   *
   * @param null
   *
   * @return `string`
   */
  onSetUserLogo(): string {
    let userPicture = this.profileDefaultImage
    if (
      this.storageSrv.currentUserInfo
      && this.storageSrv.currentUserInfo.picture
    ) {
      userPicture = this.storageSrv.currentUserInfo.picture;
    }

    return userPicture;
  }

  /**
   * calls every time when changed window size
   *
   * @param event is a resize Event
   *
   * @return `null`
   */
  @HostListener('window:resize', ['$event'])
  onResizeWindow(event: any) {
    this.onCheckDeviceWidth(event.srcElement.innerWidth);
  }


  /**
   * helper function for a detect screen size
   *
   * @param deviceWidth is a width of device
   *
   * @return `null`
   */
  onCheckDeviceWidth(deviceWidth: number) {

    if (deviceWidth > this.mobileWidth) {
      this.sitebarMode = 'side';
      this.shouldOpenSitebar = true;
      this.isMobileView = false;
    } else {
      this.shouldOpenSitebar = false;
      this.sitebarMode = 'over';
      this.isMobileView = true;
    }
    this.storageSrv.windowWidthChange.next(deviceWidth);
  }

  /**
   * change state of sitebar
   *
   * sitebar is opened in case of `this.shouldOpenSitebar === true`
   *
   * @param null
   *
   * @return `null`
   */
  onToggleSitebar() {
    if (this.storageSrv.currentUserAccounts
      && this.storageSrv.currentUserAccounts.length) {
      this.shouldOpenSitebar = !this.shouldOpenSitebar;
    }
  }

  /**
   * close sitebar in small devices
   *
   * @param null
   *
   * @return `null`
   */
  onCloseSitebar() {
    if (this.isMobileView) {
      this.shouldOpenSitebar = false;
    }
  }

  onExpandSitebarSub(sitebarItemId, $event) {
    $event.stopPropagation();
    if(sitebarItemId == this.activeSitebarSub) {
      this.activeSitebarSub = '';
    } else {
      this.activeSitebarSub = sitebarItemId;
    }
  }

  onClickOutside() {
    this.activeSitebarSub = '';
  }

  /**
   * calls from template
   * redirect user to the profile page
   * @param null
   * @return `null`
   */
  onGoToTheProfilePage() {
    this.router.navigate(['/profile'])
    this.onCloseWorkspaceMenu();
  }

  onGoToPage(url: string) {
    this.router.navigate([url])
    this.onCloseWorkspaceMenu();
  }

  /**
   * calls from template
   * ignote event triggering to up
   *
   * @param event is a `MouseEvent`
   *
   * @return null
   */
  onStopPropagation(event: MouseEvent) {
    event.stopPropagation();
  }


  // check if user is an admin for the account
  checkIsAdmin(accountId: number) {
    if (this.storageSrv.getAdminAccount(accountId) == null){
      this.accountSrv.getAccountGroups(accountId).subscribe(accountGroups => {
        if(accountGroups) {
          accountGroups.forEach(accountGroup => {
            if (accountGroup.groupName === 'Admin') {
              accountGroup.users.some(user => {
                if(user.hasOwnProperty('id') && user?.id === this.storageSrv.currentUserInfo?.id) {
                  this.storageSrv.setAdminAccounts(accountId, true);
                  return true;
                } else {
                  this.storageSrv.setAdminAccounts(accountId, false);
                  return false;
                }
              });
            }
          });
        }
      });
    }
  }

  onGetUserAccountInvites(){
    if (this.storageSrv.currentUserInvitations){
      return this.storageSrv.currentUserInvitations;
    } else {
      return []
    }
  }

  /**
   * Show invites in modal
   *
   * @param null
   *
   * @return null
   */
  openOrgInvitation() {
    this.sharedSrv.openDialog<{ id: number }[]>(
      {
        accountInvitations: this.onGetUserAccountInvites()
      },
      true,
      null,
      AccountInvitationsComponent
    ).subscribe(response => {
      // do nothing
    })
  }

  /**
   * Show list of organizations in modal
   * @param null
   * @return null
   */
  openOrgList() {

    // Prevent from sending another api request
    if(!Object.keys(this.storageSrv.adminAccounts).length) {
      this.checkAdminOverAccounts();
    }

    // Open dialog box
    this.sharedSrv.openDialog(
      {
        title: 'Organizations',
      },
      true,
      null,
      AccountsComponent
    ).subscribe(response => {
      if (response.continue) {
        this.onCloseWorkspaceMenu();
      }
    })
  }

  /**
   * Check what accounts we admin over.
   * @param null
   * @return null
   */
  checkAdminOverAccounts() {
    this.storageSrv.currentUserAccounts.every(account => {
      this.checkIsAdmin(account.id);
      return true;
    });
  }

  loadCustomCSS() {
    let cssId = 'customcss';
    if (this.storageSrv.currentAccount &&
      this.accountFeatures['whitelabel']){
      let styles = this.storageSrv.currentAccount.customCSS;
      let element = document.getElementById(cssId);
      let customCSS = document.createElement('style');
      customCSS.id = cssId;
      customCSS.type = 'text/css';
      customCSS.innerHTML = styles;

      if (!element){
        document.getElementsByTagName("head")[0].appendChild(customCSS);
      } else {
        // remove previous
        element.parentNode.removeChild(element);
        // append new one
        document.getElementsByTagName("head")[0].appendChild(customCSS);
      }
    }
  }

  canRead(resource: number){
    return this.storageSrv.getWorkspaceReadPermission(resource);
  }
}
