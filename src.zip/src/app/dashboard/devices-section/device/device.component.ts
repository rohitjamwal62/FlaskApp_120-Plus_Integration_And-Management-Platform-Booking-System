import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { MatSelectChange } from '@angular/material/select';
import { TranslateService } from '@ngx-translate/core';

import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { TimelineOptions } from 'src/app/shared/models/timeline-models/timeline-options.model';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { DefaultDialogInputData } from 'src/app/shared/models/common-models/default-dialog-input-data.model';
import { Device } from 'src/app/shared/models/device-models/device.model';
import { DeviceUpdateRequestModel } from 'src/app/shared/models/requests-models/device-update.model';
import { Playlist } from 'src/app/shared/models/playlist-models/playlist.model';
import { Schedule } from 'src/app/shared/models/schedule-models/schedule.model';

import { DeviceV3 } from 'src/app/shared/models/device-models/device-v3.model';
import { DeviceUpdateV3Request } from 'src/app/shared/models/requests-models/device-update-v3.model';
import { ScheduleV3 } from 'src/app/shared/models/schedule-models/schedule-v3.model';

import { UtilService } from 'src/app/shared/services/util.service';
import { DevicesService } from 'src/app/shared/services/devices.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { ReportsService } from 'src/app/shared/services/reports.service';
import { PlaylistsService } from 'src/app/shared/services/playlists.service';

import { DeviceEditComponent } from 'src/app/shared/components/device-edit/device-edit.component';
import { AssignScheduleComponent } from 'src/app/shared/components/assign-schedule/assign-schedule.component';
import { WebPlayerComponent } from 'src/app/shared/components/web-player/web-player.component';
import { TimelineEvent } from 'src/app/shared/models/timeline-models/timeline-event';


@Component({
  selector: 'app-device',
  templateUrl: './device.component.html',
  styleUrls: ['./device.component.scss']
})
export class DeviceComponent extends CleanOnDestroy implements OnInit {

  currentLocale: any = '';
  currentWorkspace: Workspace;
  currentDevice: DeviceV3 = {} as DeviceV3;
  startDate = this.sharedSrv.getThisMonday();

  endDate = new Date(
    new Date(this.startDate).getFullYear(),
    new Date(this.startDate).getMonth(),
    new Date(this.startDate).getDate() + 6
  ).getTime();

  // deviceImageEndpoint: string = `${this.utilSrv.env.endPoint}/api/v1/devices/`;
  deviceImageEndpoint: string = '';
  deviceImage: string = '';

  deviceId: number;
  hourInMiliseconds: number = 60 * 60 * 1000;

  playlists: Playlist[];
  schedules: Schedule[];
  playlistsByIds: {
    [key: number]: Playlist
  } = {};
  schedulesByIds: {
    [key: number]: Schedule
  } = {};
  currentPlaylist: Playlist;
  currentSchedule: Schedule;

  timelineOptions: TimelineOptions = {
    directionsName: '',
    dayFormat1: 'EEEE',
    dayFormat2: 'MMM dd',
    directionDescription: ''
  }

  //timelineItems: TimelineEvent[] = [];
  timelineItems: {
    id: number;
    name: string;
    timeline: {};
  }[] = [];

  changePlaylistTimer = null;
  updateDeviceTimer = null;

  transStartPlayer: string = '';
  transStartPlayerDesc: string = '';
  transStopPlayer: string = '';
  transStopPlayerDesc: string = '';
  transNewPlayer: string = '';
  transDeletePlayerTs: string = '';
  transDeletePlayerDescTs: string = '';
  transClearSession: string = '';
  transClearSessionDesc: string = '';
  confirmString: string = '';
  cancelString: string = '';

  constructor(
    private translate: TranslateService,
    private devicesSrv: DevicesService,
    private sharedSrv: SharedService,
    private activeRoute: ActivatedRoute,
    public utilSrv: UtilService,
    private location: Location,
    private storageSrv: StorageService,
    private reportsSrv: ReportsService,
    private playlistsSrv: PlaylistsService,
    private router: Router
  ) {
    super();

    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {

    this.currentLocale = this.utilSrv.locale;
    this.deviceId = +this.activeRoute.snapshot.params['deviceId'];

    this.tsTranslation();

    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe(workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;
          this.deviceImageEndpoint = `${this.utilSrv.env.endPoint}/api/v3/orgs/${this.currentWorkspace.account.id}/workspaces/${this.currentWorkspace.id}/devices/`;
          this.deviceImage = `${this.deviceImageEndpoint}${this.deviceId}/image/`;
          //this.getCurrentDevice(this.deviceId);
          this.getPlaylists();
          this.startTimerForChangeWeek();
        }
      });
  }

  tsTranslation() {
    this.translate.get('DEVICES.STARTPLAYER').subscribe((string) => {
      this.transStartPlayer = string;
    });
    this.translate.get('DEVICES.STARTPLAYERDESC').subscribe((string) => {
      this.transStartPlayerDesc = string;
    });
    this.translate.get('DEVICES.STOPPLAYER').subscribe((string) => {
      this.transStopPlayer = string;
    });
    this.translate.get('DEVICES.STOPPLAYERDESC').subscribe((string) => {
      this.transStopPlayerDesc = string;
    });
    this.translate.get('DEVICES.NEWPLAYER').subscribe((string) => {
      this.transNewPlayer = string;
    });
    this.translate.get('DEVICES.DELETEPLAYERTS').subscribe((string) => {
      this.transDeletePlayerTs = string;
    });
    this.translate.get('DEVICES.DELETEPLAYERDESCTS').subscribe((string) => {
      this.transDeletePlayerDescTs = string;
    });
    this.translate.get('DEVICES.CLEARSESSION').subscribe((string) => {
      this.transClearSession = string;
    });
    this.translate.get('DEVICES.CLEARSESSIONDESC').subscribe((string) => {
      this.transClearSessionDesc = string;
    });
    this.translate.get('CONFIRMBUTTON').subscribe((string) => {
      this.confirmString = string;
    });
    this.translate.get('CANCELBUTTON').subscribe((string) => {
      this.cancelString = string;
    });
  }

  /**
   * get playlists from storage service
   * @param null
   * @return `null`
   */
  getPlaylists() {
    this.subscriber = this.playlistsSrv.getPlaylists(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    ).subscribe(playlists => {
      if (playlists) {
        this.playlists = playlists;
        this.getCurrentDevice(this.deviceId);
      }
    })
  }

  getTimelineReport() {
    this.subscriber = this.reportsSrv.getDeviceTimelineReport(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.currentDevice.id
    )
      .subscribe( timelines => {
        if(timelines) {
          this.timelineOptions.directionDescription = `Players`;
          this.timelineItems.push( { id: this.currentDevice.id, name: this.currentDevice.name, timeline: timelines });
        }
    });
  }

  /**
   * start timer for a change week in case of week ended
   * @param null
   * @return null
   */
  startTimerForChangeWeek() {
    setInterval(() => {
      this.startDate = this.sharedSrv.getThisMonday();
      this.endDate = new Date(
        new Date(this.startDate).getFullYear(),
        new Date(this.startDate).getMonth(),
        new Date(this.startDate).getDate() + 6
      ).getTime();
      if (this.playlistsByIds && this.schedulesByIds) {
        //this.currentPlaylist = this.getCurrentPlaylist();
        if(this.currentDevice.playlist) {
          this.getDevicePlaylist(this.currentDevice.playlist);
        }
      }
    }, (this.endDate + 24 * this.hourInMiliseconds) - new Date().getTime());
  }

  prepareTimelineItems(){
    // load playlists
    // let playlistSubject = this.storageSrv.playlistsSubject
    // this.subscriber = this.storageSrv.playlistsSubject
    //   .subscribe(playlists => {
    //     if (playlists){
    //       this.playlists = playlists;
    //       playlists.forEach(playlist => {
    //         this.playlistsByIds[playlist.id] = playlist;
    //       });

    //       this.subscriber = this.storageSrv.schedulesSubject
    //         .subscribe(schedules => {
    //             this.schedules = schedules;
    //             schedules.forEach(schedule => {
    //               this.schedulesByIds[schedule.id] = schedule;
    //             });
    //             // load current playlistt
    //             this.currentPlaylist = this.getCurrentPlaylist();
    //             // render timeline
    //             //this.timelineRendering([this.currentDevice]);
    //         });
    //       }
    //   });

    let playlists = this.playlists;

    playlists.forEach(playlist => {
      this.playlistsByIds[playlist.id] = playlist;
    });

    // load schedules// load playlists
    // let schedulesSubject = this.storageSrv.schedulesSubject
    this.subscriber = this.storageSrv.schedulesSubject
      .subscribe(schedules => {
        if(schedules) {
          this.schedules = schedules;
          schedules.forEach(schedule => {
            this.schedulesByIds[schedule.id] = schedule;
          });
          //load current playlistt
          //this.currentPlaylist = this.getCurrentPlaylist();
          if(this.currentDevice.playlist) {
            this.getDevicePlaylist(this.currentDevice.playlist);
          }
        }
      });
  }

  /**
   * calls from template
   * when user pressed on the open virtual player button
   * @param device with type `Device`
   * @return `null`
   */
  onOpenVirtualPlayer(device: Device) {
    window.open(
      `${this.utilSrv.env.endPoint}/player/device/${device.secretCode}/`,
      'BoldcastTV Preview',
      'width=1280,height=720'
    );
  }

  /* copy the url to clipboard */
  onCopyPlayerURL(device: Device) {
    this.sharedSrv.openDialog<Device>(
      { device: device },
      true,
      null,
      WebPlayerComponent
    ).subscribe(response => {
      if (response.continue) {
      }
    });
  }


  /**
   * get the current device info from server by url deviceId
   * @param null
   * @return null
   */
  getCurrentDevice(deviceId: number) {
    // To do's - update to v3 api
    // this.subscriber = this.storageSrv.devicesSubject.subscribe(devices => {
    //   if (devices) {
    //     this.currentDevice = this.storageSrv.devices.find(device => device.id === deviceId);
    //     if (this.currentDevice && this.currentDevice.id >= 0) {
    //       this.prepareTimelineItems();
    //       this.getTimelineReport();
    //     } else {
    //       this.location.back();
    //     }
    //   }
    // });

    this.subscriber = this.devicesSrv.getDevice(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      deviceId
    )
      .subscribe( device => {
        if(device) {
          this.currentDevice = device;
          this.prepareTimelineItems();
          this.getTimelineReport();
        } else {
          this.location.back();
        }
      })
  }

  getDevicePlaylist(playlistId: number) {
    this.subscriber = this.playlistsSrv.getPlaylist(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      playlistId
    )
      .subscribe( playlist => {
        if(playlist) {
          this.currentPlaylist = playlist;
        }
      })
  }

  //Note: commented for now while migrating to v3 api
  /**
   * calls when change device image or
   * get device infi
   * @param deviceId
   * @return `Playlist`
   */
  // getCurrentPlaylist() {
  //   this.currentPlaylist = null;
  //   this.currentSchedule = null;
  //   if (this.changePlaylistTimer) {
  //     clearInterval(this.changePlaylistTimer);
  //     this.changePlaylistTimer = null;
  //   }
  //   let playlist = null;
  //   if (this.currentDevice && this.currentDevice.assignedSchedules) {
  //     if (this.currentDevice.assignedSchedules.length > 0) {
  //       let now = new Date().getTime();
  //     }
  //     if (!playlist) {
  //       if (this.currentDevice.playlist) {
  //         playlist = this.playlistsByIds[this.currentDevice.playlist.id];
  //       }
  //     }
  //   }
  //   return playlist;
  // }


  /**
   * calls from template
   * change device default playlist
   * @param playlist is a current playlist which slide image should be take
   * @return `string`
   */
  onChangeDevicePlaylist(event: MatSelectChange) {
    if (this.currentDevice) {
      // this.devicesSrv.updateDeviceInfo({
      //   playlistId: event.value
      // }, this.currentDevice.id).subscribe(updatedDevice => {
      //   if (updatedDevice && updatedDevice.id >= 0) {
      //     this.storageSrv.devices.every((device, index) => {
      //       if (device.id === updatedDevice.id) {
      //         this.storageSrv.devices[index] = updatedDevice;
      //         this.currentDevice = this.storageSrv.devices[index];
      //         if (this.playlistsByIds && event.value >= 0) {
      //           this.currentPlaylist = this.playlistsByIds[event.value];
      //         }
      //         return false;
      //       }
      //       return true;
      //     });
      //   }
      // });
      let deviceForm:DeviceUpdateV3Request = { playlistId: event.value };
      this.subscriber = this.devicesSrv.updateDevice(
        this.currentWorkspace.account.id,
        this.currentWorkspace.id,
        this.currentDevice.id,
        deviceForm
      )
        .subscribe(updatedDevice => {
          if(updatedDevice) {
            this.currentDevice = updatedDevice;
            if(this.currentDevice.playlist) {
              this.getDevicePlaylist(this.currentDevice.playlist);
            }
          }
        });
    }

  }

  /**
   * calls from template
   * send request to the server for stop / start current device
   * after user confirmation
   * @param deviceGroup is a current device group which devices
   * should be turn off(pause playling playlists)
   * @return `null`
   */
  onToggleDeviceStatus() {
    let statusId = 1;
    let title = this.transStartPlayer;
    let description = this.transStartPlayerDesc;
    if (this.currentDevice.deviceStatus.id === 1) {
      statusId = 2;
      title = this.transStopPlayer;
      description = this.transStopPlayerDesc;
    }

    this.sharedSrv.openDialog({
      title: title,
      description: description,
      template: 0,
      confirm: 'Confirm',
      cancel: 'No'
    },
      true).subscribe(response => {
        if (response.continue) {
          this.devicesSrv.updateDevice(
            this.currentWorkspace.account.id,
            this.currentWorkspace.id,
            this.currentDevice.id,
            { statusId: statusId }
          )
            .subscribe(updatedDevice => {
              if(updatedDevice) {
                this.currentDevice.deviceStatus.id = statusId;
                this.currentDevice.deviceStatus.name = statusId === 2 ? "Stopped" : "Playing";
              }
            })
        }
      });
  }

  /**
   * calls from template
   * when user pressed on the edit device button
   * open dialog for a change device data
   * and update device info after dialog closed
   * @param null
   * @return `null`
   */
  onEditDevice() {
    this.subscriber = this.sharedSrv.openDialog<DeviceV3>(
      this.currentDevice,
      true,
      null,
      DeviceEditComponent
    ).subscribe(response => {
      if (response.continue) {
        this.currentDevice = response.outputData;
        this.deviceImage = `${this.deviceImageEndpoint}${this.currentDevice.id}/image/`;
      }
    })
  }

  /**
   * calls from template
   * when user pressed on the delete device button
   * open dialog for a confirm before send request for a delete
   * @param null
   * @return `null`
   */
  onDeleteDevice() {
    let data: DefaultDialogInputData = {
      title: this.transDeletePlayerTs,
      description: this.transDeletePlayerDescTs,
      template: 0,
      confirm: this.confirmString,
      cancel: this.cancelString
    }

    this.subscriber = this.sharedSrv.openDialog<null>(
      data,
      true,
      { width: '45%' }
    ).subscribe(response => {
      if (response.continue) {
        this.confirmDeleteDevice();
      }
    });
  }

  confirmDeleteDevice() {
    this.devicesSrv.removeDevice(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.currentDevice.id
    )
      .subscribe(response => {
        if (response) {
          this.router.navigate(['/devices']);
        }
      });
  }

  /**
   * calls from template
   * when user changed the device name
   * @param deviceName is a changed device name
   * @return `null`
   */
  onChangeDeviceName(deviceName: string) {
    if (this.updateDeviceTimer) {
      clearInterval(this.updateDeviceTimer);
      this.updateDeviceTimer = null;
    }
    this.updateDeviceTimer = setTimeout(() => {
      this.currentDevice.name = deviceName;
      deviceName = deviceName ? deviceName : this.transNewPlayer;

      let deviceForm:DeviceUpdateV3Request = { name: deviceName };
      this.subscriber = this.devicesSrv.updateDevice(
        this.currentWorkspace.account.id,
        this.currentWorkspace.id,
        this.currentDevice.id,
        deviceForm
      )
        .subscribe(updatedDevice => {
          if(updatedDevice) {
            this.currentDevice = updatedDevice;
          }
        });

    }, 300);

  }

  /**
   * calls from template
   * when user want create schedule with assigned device `currentDevice`
   * @param null
   * @return `null`
   */
  onCreateSchedule() {
    this.router.navigate(['/schedules/new'], {
      queryParams: {
        deviceId: this.currentDevice.id
      }
    })
  }

  /**
   * calls from template
   * when user want assign schedule tho the device
   * @param null
   * @return `null`
   */
  onAssignSchedule() {
    if (this.currentDevice && this.currentDevice.id >= 0) {
      this.sharedSrv.openDialog<{
        device: DeviceV3,
        schedules: number[]
      }>(
        {
          device: this.currentDevice,
          deviceSchedules: null
        },
        true,
        null,
        AssignScheduleComponent
      ).subscribe(response => {
        if (response.continue) {
          this.subscriber = this.devicesSrv.assignSchedulesToDevice(
            this.currentWorkspace.account.id,
            this.currentWorkspace.id,
            this.currentDevice.id,
            { schedules: response.outputData.schedules }
          ).subscribe(assignedSchedules => {
            if (assignedSchedules) {
              //Note: Disabling device schedules for now while migrating to v3 endpoint.
              //this.currentDevice.assignedSchedules = response.outputData.schedules;
              //this.storageSrv.getSchedules(this.storageSrv.selectedWorkspace.id);
              this.getTimelineReport();
            }
          });
        }
      });
    }
  }

  // release a virtual device session
  releaseDevice(device){
    if (!device.isVirtual){
      return;
    }

    let data: DefaultDialogInputData = {
      title: this.transClearSession,
      description: this.transClearSessionDesc,
      template: 0,
      confirm: 'Yes',
      cancel: 'no'
    }

    this.subscriber = this.sharedSrv.openDialog<null>(
      data,
      true,
      { width: '45%' }
    ).subscribe(response => {
      if (response.continue){
        //Note: No equivalent v3 endpoint.
        this.devicesSrv.clearDeviceSession(device)
          .subscribe(response => {
            // just continue on our merry way
          });
      }
    });
  }

  // lock the device
  lockDevice(deviceId: number){
    let deviceForm:DeviceUpdateV3Request = { lock: (this.currentDevice.isLocked) ? false : true };
    this.subscriber = this.devicesSrv.updateDevice(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      deviceId,
      deviceForm
    )
      .subscribe(updatedDevice => {
        if(updatedDevice) {
          this.currentDevice = updatedDevice;
        }
      });
  }

  onSendCommand(commandType: string) {
    let deviceInfo: DeviceUpdateV3Request = { command: commandType };
    this.subscriber = this.devicesSrv.updateDevice(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.currentDevice.id,
      deviceInfo,
    )
      .subscribe(updatedDevice => {
        if (updatedDevice) {
          this.subscriber = this.sharedSrv.openDialog(
            {
              title: 'Command Delivered',
              description: 'Remote command successfully sent to Player.',
              cancel: 'Close',
              confirm: 'Ok',
              template: 0
            },
            true,
            { width: '30%' }
          ).subscribe(response => {
            // Do nothing
          });
        }
      },
      err => {
        this.subscriber = this.sharedSrv.openDialog(
          {
            title: 'Error',
            description: 'An error occurred while sending remote command to Player.',
            cancel: 'Close',
            confirm: 'Ok',
            template: 0
          },
          true,
          { width: '30%' }
        ).subscribe(response => {
          // Do nothing
        });
      });
  }

  /**
   * stop event triggering for a
   * ignore some changes on the UI
   * @param null
   * @return `null`
   */
  onOpenMoreActions() {
    event.stopPropagation();
  }

  onGoToTheDevices() {
    this.router.navigate(['/devices']);
  }

  canUpdate(device){
    if (typeof device !== "undefined" && device.isLocked){
      return false;
    }
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.devices);
  }

  canRead(){
    return this.storageSrv.getWorkspaceReadPermission(Resource.devices);
  }

  canWrite() {
    return this.storageSrv.getWorkspaceWritePermission(Resource.devices);
  }

  canDelete(device) {
    if (typeof device !== "undefined" && device.isLocked){
      return false;
    }

    return this.storageSrv.getWorkspaceDeletePermission(Resource.devices);
  }

  canUpdateChannel(){
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.channels);
  }

}
