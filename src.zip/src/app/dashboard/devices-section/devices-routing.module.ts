import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


import { DevicesSectionComponent } from './devices-section.component';

import { DevicesComponent } from './devices/devices.component';
import { DeviceComponent } from './device/device.component';

const routes: Routes = [
  {
    path: '', component: DevicesSectionComponent, children: [
      { path: '', component: DevicesComponent },
      { path: ':deviceId', component: DeviceComponent },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DevicesRoutingModule { }
