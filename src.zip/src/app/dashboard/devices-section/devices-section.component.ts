import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-devices-section',
  templateUrl: './devices-section.component.html',
  styleUrls: ['./devices-section.component.scss']
})
export class DevicesSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
