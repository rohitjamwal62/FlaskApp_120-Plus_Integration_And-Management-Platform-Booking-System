import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { DevicesRoutingModule } from './devices-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';


import { DevicesSectionComponent } from './devices-section.component';

import { DevicesComponent } from './devices/devices.component';
import { DeviceComponent } from './device/device.component';

@NgModule({
  declarations: [
    DevicesSectionComponent,
    DevicesComponent,
    DeviceComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    DevicesRoutingModule
  ]
})
export class DevicesModule { }
