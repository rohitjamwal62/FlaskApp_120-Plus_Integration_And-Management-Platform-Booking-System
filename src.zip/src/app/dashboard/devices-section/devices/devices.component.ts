import { Component, OnInit, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { MatAccordion } from '@angular/material/expansion';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { PageState } from 'src/app/shared/enums/page-state.enum';
import { TemplateFlaggEvent } from 'src/app/shared/events/template-flagg.event';
import { TranslateService } from '@ngx-translate/core';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { forkJoin, of, fromEvent } from 'rxjs';
import { debounceTime, filter, map, distinctUntilChanged, tap } from 'rxjs/operators';

import { UtilService } from 'src/app/shared/services/util.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { AccountsService } from 'src/app/shared/services/accounts.service';
import { BillingService } from 'src/app/shared/services/billing.service';
import { DevicesService } from 'src/app/shared/services/devices.service';
import { DeviceGroupsService } from 'src/app/shared/services/device-groups.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { PlaylistsService } from 'src/app/shared/services/playlists.service';
import { SchedulesService } from 'src/app/shared/services/schedules.service';

import { Pagination } from 'src/app/shared/models/common-models/pagination.model';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { SitebarItem } from 'src/app/shared/models/common-models/sitebar-item.model';
import { Device } from 'src/app/shared/models/device-models/device.model';
import { DeviceGroup } from 'src/app/shared/models/device-models/device-group.model';
import { DefaultDialogInputData } from 'src/app/shared/models/common-models/default-dialog-input-data.model';
import { RegisterDeviceRequest } from 'src/app/shared/models/common-models/register-device-request.model';
import { DeviceUpdateRequestModel } from 'src/app/shared/models/requests-models/device-update.model';
import { PlaylistV1 } from 'src/app/shared/models/playlist-models/playlist-v1.model';
import { Schedule } from 'src/app/shared/models/schedule-models/schedule.model';
import { ScheduleEvent } from 'src/app/shared/models/event-scheduler-models/schedule-event';

import { Playlist } from 'src/app/shared/models/playlist-models/playlist.model';
import { DeviceV3 } from 'src/app/shared/models/device-models/device-v3.model';
import { DeviceGroupV3 } from 'src/app/shared/models/device-models/device-group-v3.model';
import { DeviceUpdateV3Request } from 'src/app/shared/models/requests-models/device-update-v3.model';
import { ScheduleV3 } from 'src/app/shared/models/schedule-models/schedule-v3.model';

import { DeviceGroupNewComponent } from 'src/app/shared/components/device-group-new/device-group-new.component';
import { DeviceGroupEditComponent } from 'src/app/shared/components/device-group-edit/device-group-edit.component';
import { CreatePlayerComponent } from 'src/app/shared/components/create-player/create-player.component';
import { WebPlayerComponent } from 'src/app/shared/components/web-player/web-player.component';


@Component({
  selector: 'app-devices',
  templateUrl: './devices.component.html',
  styleUrls: ['./devices.component.scss']
})
export class DevicesComponent extends CleanOnDestroy implements OnInit {

  @ViewChild('search', {static: true}) search: ElementRef;

  currentWorkspace: Workspace;
  deviceItem: SitebarItem;
  devices: DeviceV3[] = [];
  devicesPaginate: Pagination = { count: 0, limit: 0, next: '', offset: 0 };
  deviceGroups: DeviceGroupV3[] = [];
  deviceGroupsPaginate: Pagination = { count: 0, limit: 0, next: '', offset: 0 };
  sortedDevicesByGroup: { [key: number]: DeviceV3[] } = {};

  deviceImageEndpoint: string = '';
  isDragedAnyElement: boolean = false;
  expansionPanelIndex: number = 0;
  hourInMiliseconds: number = 60 * 60 * 1000;
  timer = null;
  timeoutDuration: 50; // miliseconds
  startDate = this.sharedSrv.getThisMonday();
  endDate = new Date(
    new Date(this.startDate).getFullYear(),
    new Date(this.startDate).getMonth(),
    new Date(this.startDate).getDate() + 6
  ).getTime();

  playlists: Playlist[];
  schedules: ScheduleV3[];
  playlistsByIds: { [key: number]: Playlist } = {};
  schedulesByIds: { [key: number]: ScheduleV3 } = {};

  // Flags / Others / etc..
  currentLocale: any = '';
  filterValue: string = '';
  areDeviceGroupsCollapsed = false;
  LIST_IDS: string[] = [];
  serviceEventListener = null;
  isDeviceGroups = false;
  isDeviceGroupsSearch = false;
  pageState = PageState.loading;

  // Translations
  transStartPlayerGroup: string = '';
  transStartPlayerGroupDesc: string = '';
  transStopPlayerGroup: string = '';
  transStopPlayerGroupDesc: string = '';
  transDeleteGroup: string = '';
  transDeleteGroupDesc: string = '';
  transNewPlayer: string = '';
  transDeletePlayerTs: string = '';
  transDeletePlayerDescTs: string = '';
  transClearSession: string = '';
  transClearSessionDesc: string = '';
  confirmString: string = '';
  cancelString: string = '';
  visitOrganization: string = '';

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    public sharedSrv: SharedService,
    public storageSrv: StorageService,
    private accountsSrv: AccountsService,
    private billingSrv: BillingService,
    private devicesSrv: DevicesService,
    private devicesGroupSrv: DeviceGroupsService,
    private playlistsSrv: PlaylistsService,
    private schedulesSrv: SchedulesService,
    private router: Router
  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {

    this.currentLocale = this.utilSrv.locale;
    // this.deviceItem = this.utilSrv.getSitebarItem('devices');
    this.deviceItem = this.utilSrv.getSitebarItem('devices');
    // this.deviceImageEndpoint = `${this.utilSrv.env.endPoint}/api/v1/devices/`;

    this.tsTranslation();

    // Listening to API request errors
    this.serviceEventListener = this.sharedSrv.templateFlagg.subscribe({
      next: (event: TemplateFlaggEvent) => {
        this.isDeviceGroups = true;
      }
    });

    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe( workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;
          this.deviceImageEndpoint = `${this.utilSrv.env.endPoint}/api/v3/orgs/${this.currentWorkspace.account.id}/workspaces/${this.currentWorkspace.id}/devices/`;
          this.getDeviceGroups();
          this.getSchedules();
          this.getPlaylists();
        }
      });
  }

  ngAfterViewInit() {

    fromEvent(this.search.nativeElement,'keyup')
      .pipe(
        filter(Boolean),
        debounceTime(1000),
        distinctUntilChanged(),
        tap((event:KeyboardEvent) => {
          let word = this.search.nativeElement.value;
          word = word.toLowerCase();
          if(word) {
            //this.deviceGroups = [];
            //this.devices = [];
            this.searchDeviceGroups(word);
          } else {
            this.getDeviceGroups();
          }
        })
      )
      .subscribe();
  }

  searchDeviceGroups(word: string) {
    this.subscriber = this.devicesGroupSrv.searchDeviceGroups(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      word
    )
      .subscribe( response => {
        if(response) {
          this.deviceGroups = response.message;
          this.deviceGroupsPaginate = response.pagination;
          this.sortDeviceGroups();
          this.searchDevices(word);
        }
      });
  }

  searchDevices(word: string) {
    this.subscriber = this.devicesSrv.searchDevices(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      word
    )
      .subscribe( response => {
        if(response) {
          this.devices = response.message;
          this.devicesPaginate = response.pagination;
          this.pageState = (this.deviceGroups && this.deviceGroups.length > 0) ? PageState.withItems : PageState.noItems;
        }
      });
  }

  //-------------------------------------------------------------------------------
  // Commons
  //-------------------------------------------------------------------------------

  tsTranslation() {
    this.translate.get('DEVICES.STARTPLAYERGROUP').subscribe((string) => {
      this.transStartPlayerGroup = string;
    });
    this.translate.get('DEVICES.STARTPLAYERGROUPDESC').subscribe((string) => {
      this.transStartPlayerGroupDesc = string;
    });
    this.translate.get('DEVICES.STOPPLAYERGROUP').subscribe((string) => {
      this.transStopPlayerGroup = string;
    });
    this.translate.get('DEVICES.STOPPLAYERGROUPDESC').subscribe((string) => {
      this.transStopPlayerGroupDesc = string;
    });
    this.translate.get('DEVICES.DELETEGROUP').subscribe((string) => {
      this.transDeleteGroup = string;
    });
    this.translate.get('DEVICES.DELETEGROUPDESC').subscribe((string) => {
      this.transDeleteGroupDesc = string;
    });
    this.translate.get('DEVICES.DELETEPLAYERTS').subscribe((string) => {
      this.transDeletePlayerTs = string;
    });
    this.translate.get('DEVICES.DELETEPLAYERDESCTS').subscribe((string) => {
      this.transDeletePlayerDescTs = string;
    });
    this.translate.get('DEVICES.CLEARSESSION').subscribe((string) => {
      this.transClearSession = string;
    });
    this.translate.get('DEVICES.CLEARSESSIONDESC').subscribe((string) => {
      this.transClearSessionDesc = string;
    });
    this.translate.get('VISITACCOUNT').subscribe((string) => {
      this.visitOrganization = string;
    });
    this.translate.get('CONFIRMBUTTON').subscribe((string) => {
      this.confirmString = string;
    });
    this.translate.get('CANCELBUTTON').subscribe((string) => {
      this.cancelString = string;
    });
  }

  /**
   * get playlists from StorageService
   * @param null
   * @return null
   */
  getPlaylists() {
    this.subscriber = this.playlistsSrv.getPlaylists(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    ).subscribe(playlists => {
      if (playlists) {
        this.playlists = playlists;
        this.playlistsByIds = {};
        this.playlists.forEach(playlist => {
          this.playlistsByIds[playlist.id] = playlist
        });
      }
    })
  }

  /**
   * get schedules from StorageService
   * @param null
   * @return null
   */
  getSchedules() {
    // this.subscriber = this.storageSrv.schedulesSubject.subscribe(schedules => {
    //   if (schedules) {
    //     this.schedules = schedules;
    //     this.schedulesByIds = {}
    //     this.schedules.forEach(schedules => {
    //       this.schedulesByIds[schedules.id] = schedules;
    //     });
    //   }
    // })
    this.subscriber = this.schedulesSrv.getSchedules(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
    )
      .subscribe( schedules => {
        if(schedules) {
          this.schedules = schedules;
          this.schedulesByIds = {}
          this.schedules.forEach(schedules => {
            this.schedulesByIds[schedules.id] = schedules;
          });
        }
      })
  }

  /**
   * calls when change device image or
   * get device infi
   * @param deviceId
   * @return `null`
   */
  getCurrentPlaylistName(device: DeviceV3) {
    let playlistName = '';
    if (!playlistName) {
      let playlist: Playlist;
      if (device.playlist) {
        playlist = this.playlistsByIds[device.playlist];
        if (playlist != null){
          playlistName = this.getPlaylistName(playlist);
        }
      }
    }
    return playlistName;
  }

  /**
   * get playlist first enabled slide image
   * @param playlist is a current playlist which slide image should be take
   * @return `string`
   */
  getPlaylistName(playlist: Playlist) {
    let playlistName = 'None';
    if (playlist) {
      playlistName = playlist.name;
    }
    return playlistName;
  }

  /**
   * calls from template
   * filter devices and device groups by schedule name
   * @param name is a user typed name
   * @return `null`
   */
  // onSearchByDeviceAndDeviceGroupName(name: string) {
  //   name = name.toLowerCase();
  //   this.filterValue = name;
  //   this.sortedDevicesByGroupsId();
  //   if(name) {
  //     this.isDeviceGroupsSearch = true;
  //   } else {
  //     this.isDeviceGroupsSearch = false;
  //   }
  // }

  /**
   * calls from template
   * helper for a optimizing *ngFor
   * @param index is a current element index with type `number`
   * @param deviceGroup is a current element info with type `DeviceGroup`
   * @return `number`
   */
  onTrackById(index: number, item: { id: number }) {
    return item.id;
  }

  /**
   * calls from template
   * store the expansion panel index
   * @param expansionPanelIndex with type `number`
   * @return `null`
   */
  onOpenContainerOnDrag(
    deviceGroupIndex: number, 
    accordeon: MatAccordion
  ) {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      if (this.isDragedAnyElement) {
        this.expansionPanelIndex = deviceGroupIndex;
      }
    }, this.timeoutDuration);
  }

  /**
   * calls from template
   * Changes the value of `isDragedAnyElement` property
   * when the user moves the draggable items over the expansion panel header.
   * @param null
   * @return `null`
   */
  userStartDragSomeElement() {
    this.isDragedAnyElement = true;
  }

  /**
   * calls from template
   * Change the value of `isDragedAnyElement` property to `false`
   * when the user dropped the draged element
   * @param null
   * @return `null`
   */
  onDropElement() {
    this.isDragedAnyElement = false;
  }

  /**
   * calls from template
   * when user drag and dropes some item
   * @param event with type `CdkDragDrop<Device[]>`
   * @return `null`
   */
  async drop(
    event: CdkDragDrop<DeviceV3[]>, 
    deviceGroupId: number, 
    expansionPanelIndex: number
  ) {

    this.expansionPanelIndex = expansionPanelIndex;

    if (!this.canUpdate(null)){
      return;
    }

    let draggedDevice: DeviceV3 = event.item.data as DeviceV3;
    // check is changed device group
    if (event.previousContainer === event.container) {
      // reorder devices list into device group
      moveItemInArray(
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );

      // send request to the server for a reordering device list
      // await this.reorderDevicesIntoGroup(deviceGroupId);
      this.updateDeviceOrder(draggedDevice.id, event.currentIndex);
    } else {

      // change device into choosed device group
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );

      // update device  deviceGroup id
      await this.changeDeviceGroup({ groupId: deviceGroupId }, draggedDevice.id);

      // remap device group id
      draggedDevice.deviceGroup = deviceGroupId;

      // send request to the server for a reordering device list
      // await this.reorderDevicesIntoGroup(deviceGroupId);
      this.updateDeviceOrder(draggedDevice.id, event.currentIndex);
    }
  }

  updateDeviceOrder(
    deviceId: number, 
    currentIndex: number
  ) {
    let deviceForm:DeviceUpdateV3Request = { positionNumber: currentIndex };
    this.subscriber = this.devicesSrv.updateDevice(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      deviceId,
      deviceForm
    )
      .subscribe(updatedDevice => {
        if(updatedDevice) {
          // Do nothing
        }
      });
  }

  // Hacks for nested dragging of list items
  addId() {
    //var e = document.getElementsByClassName("device-items");
    var e = document.getElementsByClassName("item-devices");
    this.LIST_IDS = [];
    for (var i = 0; i < e.length; i++){
      /*if (this.LIST_IDS.indexOf(e[i].id > 0){
        continue;
      }*/
      this.LIST_IDS.push(e[i].id);
    }
    return "ok";
  }

  /**
   * stop event triggering for a
   * ignore some changes on the UI
   * @param null
   * @return `null`
   */
  onOpenMoreActions() {
    event.stopPropagation();
  }

  //-------------------------------------------------------------------------------
  // Device
  //-------------------------------------------------------------------------------

  getDevices() {
    this.subscriber = this.devicesSrv.getDevices(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    )
      .subscribe( response => {
        if(response) {
          this.devices = response.message;
          this.devicesPaginate = response.pagination;
          this.sortedDevicesByGroupsId();
        }
      });
  }

  /**
   * open dialog for a register new device
   * @param null
   * @return `null`
   */
  createAPlayer() {
    var gotoLink = false;
    var continueOption = true;
    this.sharedSrv.openDialog<DeviceV3>(
      { title: this.transNewPlayer },
      true,
      { width: '70%'},
      CreatePlayerComponent
    )
    .subscribe(response => {
      if (response.continue){
        //this.integrateDeviceIntoList(response.outputData);
        //this.pageState = PageState.withItems;
        this.getDeviceGroups();
      }
    });
  }

  /**
   * calls from template
   * when user pressed on the edit device button
   *
   * @param deviceGroupIndex // TODO comment
   * @param deviceGroupIndex // TODO comment
   * @param deviceGroupIndex // TODO comment
   * @return `null`
   */
  onEditDevice(device: DeviceV3) {
    this.router.navigate(['devices', device.id])
  }

  lockDevice(
    device: DeviceV3, 
    deviceGroupIndex: number, 
    deviceIndex: number
  ){
    let deviceForm:DeviceUpdateV3Request = { lock: (device.isLocked) ? false : true };
    this.subscriber = this.devicesSrv.updateDevice(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      device.id,
      deviceForm
    )
      .subscribe(updatedDevice => {
        if(updatedDevice) {
          this.sortedDevicesByGroup[deviceGroupIndex][deviceIndex] = updatedDevice;
        }
      });
  }

  onSendCommand(
    device: DeviceV3, 
    commandType: string
  ) {
    let deviceInfo: DeviceUpdateV3Request = {
      command: commandType
    };
    this.subscriber = this.devicesSrv.updateDevice(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      device.id,
      deviceInfo,
    )
      .subscribe(updatedDevice => {
        if (updatedDevice) {
          // To Do - show confirmation
          this.subscriber = this.sharedSrv.openDialog(
            {
              title: 'Command Delivered',
              description: 'Remote command successfully sent to Player.',
              cancel: 'Close',
              confirm: 'Ok',
              template: 0
            },
            true,
            { width: '30%' }
          ).subscribe(response => {
            // Do nothing
          });
        }
      },
      err => {
        this.subscriber = this.sharedSrv.openDialog(
          {
            title: 'Error',
            description: 'An error occurred while sending remote command to Player.',
            cancel: 'Close',
            confirm: 'Ok',
            template: 0
          },
          true,
          { width: '30%' }
        ).subscribe(response => {
          // Do nothing
        });
      });
  }

  /**
   * add new device into deviceGroup
   * @param deviceInfo with type `Device`  (updated device info)
   * @return `null`
   */
  // async integrateDeviceIntoList(deviceInfo: DeviceV3) {
  //   if (deviceInfo.deviceGroup) {
  //     if (!this.sortedDevicesByGroup[deviceInfo.deviceGroup]) {
  //       this.devicesGroupSrv.getDeviceGroup(
  //         this.currentWorkspace.account.id,
  //         this.currentWorkspace.id,
  //         deviceInfo.deviceGroup
  //       )
  //         .subscribe( deviceGroup => {
  //           if(deviceGroup) {
  //             this.sortedDevicesByGroup[deviceInfo.deviceGroup] = [];
  //             this.deviceGroups.unshift(deviceGroup);
  //           }
  //         });
  //     }
  //     this.devices.push(deviceInfo);
  //     this.sortedDevicesByGroup[deviceInfo.deviceGroup].push(deviceInfo);
  //   }
  // }

  /**
   * sort devices by device groups id
   * @param null
   * @return `null`
   */
  // sortedDevicesByGroupsId(filter: string = this.filterValue) {
  //   filter = filter.toLowerCase()
  //   this.sortedDevicesByGroup = {};

  //   this.deviceGroups.forEach((deviceGroup) => {
  //     this.sortedDevicesByGroup[deviceGroup.id] = [];
  //   });

  //   if (filter) {
  //     let devices = this.devices;
  //     this.devices = devices.filter(device => {
  //       let name = device.name.toLowerCase();
  //       return name.indexOf(filter) >= 0;
  //     });
  //   } else {
  //     this.subscriber = this.devicesSrv.getDevices(
  //       this.currentWorkspace.account.id,
  //       this.currentWorkspace.id
  //     )
  //       .subscribe( response => {
  //         if(response) {
  //           this.devices = response.message;
  //           this.devicesPaginate = response.pagination;
  //         }
  //       });
  //   }

  //   this.devices.forEach(device => {
  //     if (this.sortedDevicesByGroup[device.deviceGroup]) {
  //       this.sortedDevicesByGroup[device.deviceGroup].push(device);
  //     }
  //   });

  //   this.deviceGroups.forEach((deviceGroup) => {
  //     this.sortedDevicesByGroup[deviceGroup.id].sort(
  //       (prevDevice, nextDevice) => {
  //         return prevDevice.positionNumber - nextDevice.positionNumber;
  //       });
  //   });

  //   if (filter) {
  //     for (let i = 0; i < this.deviceGroups.length; i++) {
  //       let devGr = this.deviceGroups[i];
  //       let devGrName = devGr.name.toLowerCase();
  //       if (
  //         this.sortedDevicesByGroup[devGr.id]
  //         && this.sortedDevicesByGroup[devGr.id].length === 0
  //         && devGrName.indexOf(filter) == -1
  //       ) {
  //         delete this.sortedDevicesByGroup[devGr.id];
  //         this.deviceGroups.splice(i, 1);
  //         i = i - 1;
  //       }
  //     }
  //   }
  // }

  sortedDevicesByGroupsId() {
    this.sortedDevicesByGroup = {};
    this.deviceGroups.forEach((deviceGroup) => {
      this.sortedDevicesByGroup[deviceGroup.id] = [];
    });
    this.devices.forEach(device => {
      if (this.sortedDevicesByGroup[device.deviceGroup]) {
        this.sortedDevicesByGroup[device.deviceGroup].push(device);
      }
    });
    this.deviceGroups.forEach((deviceGroup) => {
      this.sortedDevicesByGroup[deviceGroup.id].sort(
        (prevDevice, nextDevice) => {
          return prevDevice.positionNumber - nextDevice.positionNumber;
        });
    });
  }

  /**
   * calls when user dropes dragged item into same device group
   * reorder items and send request to the server for a update `positionNumber`s
   * of dragged items
   * @param device dragged device info with type `device`
   * @param draggedDeviceIndex dragged device index from `deviceGroupDevices` array with type `number`
   * @param draggedInsteadOfDeviceIndex dragged instead id device index from `deviceGroupDevices` array with type `number`
   * @return `null`
   */
  // reorderDevicesIntoGroup(deviceGroupId: number) {
  //   let newOrderOfDevices: {
  //     devices: { id: number, positionNumber: number }[]
  //   };
  //   newOrderOfDevices = {
  //     devices: []
  //   };
  //   let draggedDeviceGroup = this.sortedDevicesByGroup[deviceGroupId];
  //   let devices: { id: number, positionNumber: number }[] = [];
  //   let devicesCount = draggedDeviceGroup.length - 1;
  //   for (let i = 0; i <= devicesCount; i++) {
  //     draggedDeviceGroup[i].positionNumber = i;
  //     devices.push({
  //       id: draggedDeviceGroup[i].id,
  //       positionNumber: draggedDeviceGroup[i].positionNumber
  //     });
  //   }
  //   newOrderOfDevices.devices = devices;
  //   return this.devicesSrv.devicesOrder(newOrderOfDevices).toPromise();
  // }

  /**
   * calls from template
   * when user clicked on the "start all devices" option
   * send request to the server for start playlists on all devices after user confirmation
   * @param deviceGroup is a current device group which devices
   * should be turn on(start playling playlists)
   * @return `null`
   */
  onStartAllDevices(deviceGroup: DeviceGroupV3) {
    this.sharedSrv.openDialog({
      title: this.transStartPlayerGroup,
      description: this.transStartPlayerGroupDesc,
      template: 0,
      confirm: this.confirmString,
      cancel: this.cancelString
    },
      true).subscribe(response => {
        if (response.continue) {

          let deviceForm:{ statusId: number } = { statusId: 1 };
          this.devicesGroupSrv.updateDeviceGroup(
            this.currentWorkspace.account.id,
            this.currentWorkspace.id,
            deviceGroup.id,
            deviceForm
          )
            .subscribe( updatedDeviceGroup => {
              if(updatedDeviceGroup) {
                let deviceGroupDevices = this.sortedDevicesByGroup[deviceGroup.id];
                if (deviceGroupDevices) {
                  deviceGroupDevices.forEach(device => {
                    device.deviceStatus.id = 1;
                    device.deviceStatus.name = "Playing";
                  });
                }
              }
            })
        }
      })

  }

  /**
   * calls from template
   * when user clicked on the "stop all devices" option
   * send request to the server for stop all devices from Player group
   * after user confirmation
   * @param deviceGroup is a current Player group which devices
   * should be turn off(pause playling playlists)
   * @return `null`
   */
  onStopAllDevices(deviceGroup: DeviceGroupV3) {
    this.sharedSrv.openDialog({
      title: this.transStopPlayerGroup,
      description: this.transStopPlayerGroupDesc,
      template: 0,
      confirm: this.confirmString,
      cancel: this.cancelString
    },
      true).subscribe(response => {
        if (response.continue) {

          let deviceForm:{ statusId: number } = { statusId: 2 };
          this.devicesGroupSrv.updateDeviceGroup(
            this.currentWorkspace.account.id,
            this.currentWorkspace.id,
            deviceGroup.id,
            deviceForm
          )
            .subscribe( updatedDeviceGroup => {
              if(updatedDeviceGroup) {
                let deviceGroupDevices = this.sortedDevicesByGroup[deviceGroup.id];
                if (deviceGroupDevices) {
                  deviceGroupDevices.forEach(device => {
                    device.deviceStatus.id = 2;
                    device.deviceStatus.name = "Stopped";
                  });
                }
              }
            })
        }
      });
  }

  /**
   * calls from template
   * when user clicked on the "stop/play" button
   * send request to the server for pause playlists on device
   * @param device is a current device which
   * should be stop/play
   * @return `null`
   */
  onToggleDeviceStatus(device: DeviceV3) {
    let statusId = 1;
    if (device.deviceStatus.id === 1) {
      statusId = 2;
    }
    if(device.deviceStatus.id === 3) {
      return false;
    }
    if (statusId == 2){
      this.sharedSrv.openDialog({
        title: "Pause Player",
        description: "Are you sure you want to Pause this Player?",
        template: 0,
        confirm: this.confirmString,
        cancel: this.cancelString
      }, true).subscribe(response => {
        if (response.continue){
          this.submitDeviceStatus(device, statusId);
        }
      });
    } else {
      this.submitDeviceStatus(device, statusId);
    }
  }

  submitDeviceStatus(
    device: DeviceV3, 
    statusId
  ){
    let deviceForm:DeviceUpdateV3Request = { statusId: statusId };
    this.subscriber = this.devicesSrv.updateDevice(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      device.id,
      deviceForm
    )
      .subscribe(updatedDevice => {
        if(updatedDevice) {
          device.deviceStatus.id = statusId;
          device.deviceStatus.name = statusId === 2 ? "Stopped" : "Playing";
        }
      });
  }

  /**
   * calls from template
   * when user pressed on the delete device button
   * open dialog for a confirm before send request for a delete
   * @param deviceGroupId with type `number`
   * @param deviceIndexFromArray is a index of device object from  `sortedDevicesByGroup[deviceGroupId]`
   * @param device  is a device object with type `Device` which should be deleted
   * @return `null`
   */
  onDeleteDevice(
    deviceGroupId: number,
    deviceIndexFromArray: number,
    device: DeviceV3
  ) {
    let data: DefaultDialogInputData = {
      title: this.transDeletePlayerTs,
      description: this.transDeletePlayerDescTs,
      template: 0,
      confirm: this.translate.instant("DELETEBUTTON"),
      cancel: this.translate.instant("CANCELBUTTON")
    }

    this.subscriber = this.sharedSrv.openDialog<null>(
      data,
      true,
      { width: '45%' }
    ).subscribe(response => {
      if (response.continue) {
        this.confirmDeleteDevice(device.id, deviceGroupId, deviceIndexFromArray);
      }
    });
  }

  confirmDeleteDevice(
    deviceId: number, 
    deviceGroupId: number, 
    index: number
  ) {
    this.subscriber = this.devicesSrv.removeDevice(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      deviceId
    )
      .subscribe(response => {
        if (response) {
          //this.sortedDevicesByGroup[deviceGroupId].splice(index, 1);
          this.getDeviceGroups();
        }
      });
  }

  /**
   * calls from template
   * when user pressed on the open virtual player button
   * @param device with type `Device`
   * @return `null`
   */
  onOpenVirtualPlayer(device: DeviceV3) {
    window.open(
      `${this.utilSrv.env.endPoint}/player/device/${device.secretCode}/`,
      'BoldcastTV Preview',
      'width=1280,height=720'
    );
  }

  /* copy the url to clipboard */
  onCopyPlayerURL(device: DeviceV3) {
    this.sharedSrv.openDialog<DeviceV3>(
      { device: device },
      true,
      null,
      WebPlayerComponent
    ).subscribe(response => {
      if (response.continue) {
        // Do nothing
      }
    });
  }

  /**
   * calls from template
   * generete device image url
   * and get it
   * @param deviceId with type `number`
   * @return `null`
   */
  getDeviceImage(deviceId: number) {
    return this.deviceImageEndpoint + deviceId + '/image/';
  }

  //-------------------------------------------------------------------------------
  // Device Groups
  //-------------------------------------------------------------------------------

  /**
   * get devices and devices groups
   * after receiving the data call `sortedDevicesByGroupsId`
   * @param null
   * @return `null`
   */
  getDeviceGroups() {
    this.subscriber = this.devicesGroupSrv.getDeviceGroups(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    )
      .subscribe( response => {
        if(response) {
          this.deviceGroups = response.message;
          this.deviceGroupsPaginate = response.pagination;
          this.sortDeviceGroups();
          this.getDevices();
          if (this.deviceGroups != null && this.deviceGroups.length > 0) {
            this.pageState = PageState.withItems;
          } else {
            this.pageState = PageState.noItems;
          }
        }
      });
  }

  createAGroup() {
    if (this.storageSrv.selectedWorkspace) {
      this.subscriber = this.sharedSrv.openDialog<DeviceGroupV3>(
        null,
        true,
        null,
        DeviceGroupNewComponent
      ).subscribe(response => {
        if (response.continue) {
          this.getDeviceGroups();
        }
      });
    }
  }

  /**
   * open dialog for a change device group name
   * after dialog colsed send request to the server
   * for a update device group info
   * @param deviceGroup is a device group info wiht type `DeviceGroup` which one should be edited
   * @param index is aproperty with type number, which one shows the index of deviceGroup into `this.deviceGroups`
   * @return `null`
   */
  onEditDeviceGroup(
    deviceGroup: DeviceGroupV3, 
    index: number
  ) {
    this.subscriber = this.sharedSrv.openDialog<DeviceGroupV3>(
      deviceGroup,
      true,
      null,
      DeviceGroupEditComponent
    )
      .subscribe(response => {
        if (response.continue) {
          let updatedDeviceGroup = response.outputData;
          this.deviceGroups.splice(index, 1, updatedDeviceGroup);
        }
      })
  }

  /**
   * calls when user drops dragged item into another deviceGroup
   * send request to the server for a change device group id
   *
   * @param device dragged device info with type `device`
   * @param draggedDeviceIndex dragged device index from
   *        `deviceGroupDevices` array with type `number`
   * @param draggedInsteadOfDeviceIndex dragged instead id device index from
   *        `deviceGroupDevices` array with type `number`
   * @return `null`
   */
  changeDeviceGroup(
    deviceUpdateableItems: DeviceUpdateV3Request,
    deviceId: number
  ) {
    this.devicesSrv.updateDevice(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      deviceId,
      deviceUpdateableItems
    )
      .subscribe(updatedDevice => {
        if(updatedDevice) {
          // Do nothing
        }
      });
  }

  async dropGroup(event: CdkDragDrop<DeviceGroupV3[]>){
    let draggedDeviceGroup = event.item.data as DeviceGroupV3;

    // reorder device groups list
    moveItemInArray(
      event.container.data,
      event.previousIndex,
      event.currentIndex
    );

    // send request to the server for a reordering device groups
    //await this.reorderDeviceGroups();
    let deviceGroupId = event.item.data.id;
    this.updateDeviceGroupPosition(deviceGroupId, event.currentIndex);
  }

  sortDeviceGroups() {
    this.deviceGroups.sort((deviceGrp1, deviceGrp2) => {
      return deviceGrp1.positionNumber - deviceGrp2.positionNumber;
    });
  }

  // reorderDeviceGroups(){
  //   let newOrderOfGroups: {
  //     deviceGroups: { id: number, positionNumber: number}[]
  //   };
  //   newOrderOfGroups = { deviceGroups: [] };
  //   let groups: { id: number, positionNumber: number }[] = [];
  //   for (var i = 0; i < this.deviceGroups.length; i++){
  //     this.deviceGroups[i].positionNumber = i;
  //     groups.push({
  //       id: this.deviceGroups[i].id,
  //       positionNumber: this.deviceGroups[i].positionNumber
  //     });
  //   }
  //   newOrderOfGroups.deviceGroups = groups;
  //   return this.devicesSrv.deviceGroupsOrder(newOrderOfGroups).toPromise();
  // }

  updateDeviceGroupPosition(
    deviceGroupId: number, 
    currentIndex: number
  ) {
    this.devicesGroupSrv.updateDeviceGroup(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      deviceGroupId,
      { positionNumber: currentIndex }
    )
      .subscribe(updatedDevice => {
        if(updatedDevice) {
          // Do nothing
        }
      });
  }

  /**
   * open dialog for a confirm before deleteing device group
   * after confirmation send request to the server for a delete device group
   * @param deviceGroup is a device group info wiht type `DeviceGroup` which one should be deleted
   * @param index is aproperty with type number, which one shows the index of deviceGroup into `this.deviceGroups`
   * @return `null`
   */
  onDeleteDeviceGroup(
    deviceGroup: DeviceGroupV3, 
    index: number
  ) {
    let data: DefaultDialogInputData = {
      title: this.transDeleteGroup,
      description: this.transDeleteGroupDesc,
      template: 0,
      confirm: this.confirmString,
      cancel: this.cancelString
    }
    this.subscriber = this.sharedSrv.openDialog<null>(
      data, 
      true, 
      { width: '45%' }
    )
      .subscribe(response => {
        if (response.continue) {
          this.confirmDeleteDeviceGroup(deviceGroup.id, index);
        }
      })
  }

  confirmDeleteDeviceGroup(deviceGroupId: number, index: number) {
    this.devicesGroupSrv.deleteDeviceGroup(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      deviceGroupId
    )
      .subscribe(response => {
        if (response) {
          this.getDeviceGroups();
        }
      })
  }

  //-------------------------------------------------------------------------------
  // Un-used methods
  //-------------------------------------------------------------------------------


  //-------------------------------------------------------------------------------
  // Permissions
  //-------------------------------------------------------------------------------
  canUpdate(device){
    if (device != null && device.isLocked){
      return false;
    }
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.devices);
  }

  canRead(){
    return this.storageSrv.getWorkspaceReadPermission(Resource.devices);
  }

  canWrite() {
    return this.storageSrv.getWorkspaceWritePermission(Resource.devices);
  }

  canDelete(device) {
    if (device != null && device.isLocked){
      return false;
    }
    return this.storageSrv.getWorkspaceDeletePermission(Resource.devices);
  }


}
