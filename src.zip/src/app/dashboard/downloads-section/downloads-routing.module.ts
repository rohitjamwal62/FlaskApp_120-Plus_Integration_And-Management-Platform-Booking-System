import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


import { DownloadsSectionComponent } from './downloads-section.component';

import { DownloadsComponent } from './downloads/downloads.component';

const routes: Routes = [
  {
    path: '', component: DownloadsSectionComponent, children: [
      { path: '', component: DownloadsComponent },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DownloadsRoutingModule { }
