import { Component } from '@angular/core';


@Component({
  selector: 'app-downloads-section',
  templateUrl: './downloads-section.component.html',
  styleUrls: ['./downloads-section.component.scss']
})
export class DownloadsSectionComponent {
}
