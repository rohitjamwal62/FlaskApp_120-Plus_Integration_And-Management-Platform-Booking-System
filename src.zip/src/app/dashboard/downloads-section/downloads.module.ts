import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { DownloadsRoutingModule } from './downloads-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';


import { DownloadsSectionComponent } from './downloads-section.component';

import { DownloadsComponent } from './downloads/downloads.component';

@NgModule({
  declarations: [
    DownloadsSectionComponent,
    DownloadsComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    DownloadsRoutingModule
  ]
})
export class DownloadsModule { }
