import { Component, OnInit } from '@angular/core';
import { SitebarItem } from 'src/app/shared/models/common-models/sitebar-item.model';
import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { SharedService } from 'src/app/shared/services/shared.service';
import { RegisterDeviceRequest } from 'src/app/shared/models/common-models/register-device-request.model';
import { DeviceRegisterComponent } from 'src/app/shared/components/device-register/device-register.component';
import { DevicesService } from 'src/app/shared/services/devices.service';
import { Device } from 'src/app/shared/models/device-models/device.model';
import { DeviceGroupsService } from 'src/app/shared/services/device-groups.service';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { Account } from 'src/app/shared/models/account-models/account.model';
import { AccountsService } from 'src/app/shared/services/accounts.service';
import { FavoritesService } from 'src/app/shared/services/favorites.service';
import { UserFavorite } from 'src/app/shared/models/user-models/user-favorite.model';
import { Playlist } from 'src/app/shared/models/playlist-models/playlist.model';
import { ScheduleEvent } from 'src/app/shared/models/event-scheduler-models/schedule-event';
import { ReportsService } from 'src/app/shared/services/reports.service';
import { PopularReport } from 'src/app/shared/models/reports-models/popular-report.model';
import { Schedule } from 'src/app/shared/models/schedule-models/schedule.model';
import { Router } from '@angular/router';
import { Slide } from 'src/app/shared/models/slide-models/slide.model';
import { debounceTime } from 'rxjs/operators';
import { Message } from 'src/app/shared/models/message-models/message.model';
import { MessageType } from 'src/app/shared/models/message-models/message-type.model';
import { MessageService } from 'src/app/shared/services/messagecenter.service';

import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-downloads',
  templateUrl: './downloads.component.html',
  styleUrls: ['./downloads.component.scss']
})
export class DownloadsComponent extends CleanOnDestroy implements OnInit {

  currentLocale: any = '';

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private storageSrv: StorageService,
    private sharedSrv: SharedService,
    private devicesSrv: DevicesService,
    private devicesGroupSrv: DeviceGroupsService,
    private accountSrv: AccountsService,
    private favoritesSrv: FavoritesService,
    private reportsSrv: ReportsService,
    private router: Router,
    private messageSrv: MessageService

  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  downloadsItem: SitebarItem;

  ngOnInit() {
    this.currentLocale = this.utilSrv.locale;
    this.downloadsItem = this.utilSrv.getSitebarItem('downloads');
  }

}
