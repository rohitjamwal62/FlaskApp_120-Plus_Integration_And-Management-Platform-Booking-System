import { Component, OnInit } from '@angular/core';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { Router } from '@angular/router';
import { of, concat } from 'rxjs';
import { delay, tap, take, mergeMap, switchMap, debounceTime } from 'rxjs/operators';
import { forkJoin } from 'rxjs/internal/observable/forkJoin';
//import { of } from 'rxjs/internal/observable/of';

import { TimelineEvent } from 'src/app/shared/models/timeline-models/timeline-event';
import { ScheduleEvent } from 'src/app/shared/models/event-scheduler-models/schedule-event';

import { Resource } from 'src/app/shared/enums/resource.enum';
import { PageState } from 'src/app/shared/enums/page-state.enum';
import { OnboardingProcess } from 'src/app/shared/enums/onboarding-process.enum';

import { Pagination } from 'src/app/shared/models/common-models/pagination.model';
import { SitebarItem } from 'src/app/shared/models/common-models/sitebar-item.model';
import { Slide } from 'src/app/shared/models/slide-models/slide.model';
import { Message } from 'src/app/shared/models/message-models/message.model';
import { MessageType } from 'src/app/shared/models/message-models/message-type.model';
import { PopularReport } from 'src/app/shared/models/reports-models/popular-report.model';
import { DisconnectedReport } from 'src/app/shared/models/reports-models/disconnected-report.model';
import { Schedule } from 'src/app/shared/models/schedule-models/schedule.model';
import { UserFavorite } from 'src/app/shared/models/user-models/user-favorite.model';
import { TimelineOptions } from 'src/app/shared/models/timeline-models/timeline-options.model';
import { Playlist } from 'src/app/shared/models/playlist-models/playlist.model';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { Account } from 'src/app/shared/models/account-models/account.model';
import { Device } from 'src/app/shared/models/device-models/device.model';
import { RegisterDeviceRequest } from 'src/app/shared/models/common-models/register-device-request.model';
import { AssetFile } from 'src/app/shared/models/asset-models/asset-file.model';

import { DeviceV3 } from 'src/app/shared/models/device-models/device-v3.model';

import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { MessageService } from 'src/app/shared/services/messagecenter.service';
import { ReportsService } from 'src/app/shared/services/reports.service';
import { AccountsService } from 'src/app/shared/services/accounts.service';
import { FavoritesService } from 'src/app/shared/services/favorites.service';
import { DeviceGroupsService } from 'src/app/shared/services/device-groups.service';
import { DevicesService } from 'src/app/shared/services/devices.service';
import { ContentService } from 'src/app/shared/services/content.service';
import { SchedulesService } from 'src/app/shared/services/schedules.service';
import { PlaylistsService } from 'src/app/shared/services/playlists.service';

import { AccountInvitationsComponent } from 'src/app/shared/components/account-invitations/account-invitations.component';
import { DeviceRegisterComponent } from 'src/app/shared/components/device-register/device-register.component';
import { SystemMessagesComponent } from 'src/app/shared/components/system-messages/system-messages.component';
//import { DeviceMapStatusComponent } from 'src/app/shared/components/device-map-status/device-map-status.component';

import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent extends CleanOnDestroy implements OnInit {

  currentLocale: any = '';
  defaultScheduleImage: string = '';
  startDate = this.sharedSrv.getThisMonday();

  endDate = new Date(
    new Date(this.startDate).getFullYear(),
    new Date(this.startDate).getMonth(),
    new Date(this.startDate).getDate() + 6
  ).getTime();

  hourInMiliseconds: number = 60 * 60 * 1000;
  homeItem: SitebarItem;
  selectedWorkspace: Workspace
  account: Account;
  userFavorites: UserFavorite[] = [];
  systemMessages: Message[] = [];
  timelineOptions: TimelineOptions = {
    directionsName: '',
    dayFormat1: 'EEE',
    dayFormat2: 'MMM dd',
    directionDescription: '',
    showPlayers: true
  }
  timelineItems: any[] = [];

  disconnectedReport: DisconnectedReport[] = [];
  popularPlaylists: PopularReport[] = [];
  popularSlides: PopularReport[] = [];
  popularSlidesLength: number = 0;
  newestDevices: DeviceV3[] = [];
  devices: DeviceV3[];
  devicesPaginate: Pagination = { count: 0, limit: 0, next: '', offset: 0 };
  playlistsByIds: { [key: number]: Playlist } = {};
  schedulesByIds: {
    [key: number]: Schedule
  } = {}

  slidesHundredPercentValue = 0;
  playlistsHundredPercentValue = 0;
  upCommingSchedule: Schedule;
  deviceImageEndpoint: string = '';
  views = [400, 300];
  transCreatedToday: string = '';
  playersTerm: string = '';
  isSchedules = false;
  pageState = PageState.loading;
  onboardingProcess = OnboardingProcess.default;
  playlists: Playlist[];
  players: DeviceV3[];
  assetFiles: AssetFile[] = [];

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private storageSrv: StorageService,
    private sharedSrv: SharedService,
    private devicesSrv: DevicesService,
    private devicesGroupSrv: DeviceGroupsService,
    private contentSrv: ContentService,
    private accountSrv: AccountsService,
    private favoritesSrv: FavoritesService,
    private reportsSrv: ReportsService,
    private router: Router,
    private messageSrv: MessageService,
    private schedulesSrv: SchedulesService,
    private playlistsSrv: PlaylistsService

  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {

    this.currentLocale = this.utilSrv.locale;
    this.timelineOptions.directionsName = "";
    this.timelineOptions.directionDescription = "";
    this.homeItem = this.utilSrv.getSitebarItem('home');
    this.defaultScheduleImage = this.utilSrv.appImages.websiteDefault;
    this.deviceImageEndpoint = `${this.utilSrv.env.endPoint}/api/v1/devices/`;

    this.tsTranslation();

    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe(workspace => {

        if (workspace) {

          this.selectedWorkspace = workspace;

          // avoid asyncronous problem
          if (!this.storageSrv.currentUserAccounts) {
            this.storageSrv.userAccountsSubject.subscribe(accounts => {
              if (accounts) {
                this.account = this.storageSrv.currentUserAccounts.find(
                  account => account.id === this.selectedWorkspace.account.id
                );
              }
            })
          } else {
            this.account = this.storageSrv.currentUserAccounts.find(
              account => account.id === this.selectedWorkspace.account.id
            );
          }

          this.getTimelineReport();
          // Note - hidden these for now.
          //this.getUserFavorites();
          //this.getPlayersPlaylistsFiles();
          //this.getPopularPlaylists(this.selectedWorkspace.id);
          //this.getPopularSlides(this.selectedWorkspace.id);
          this.getMessages();
          this.pageState = PageState.withItems;
        }

      });

    this.subscriber = this.storageSrv.windowWidthChange
      .pipe(
        debounceTime(250)
      ).subscribe(windowWidth => {
        if (windowWidth > 0) {
          if (windowWidth < 500) {
            this.views = [290, 250];
          } else {
            this.views = [400, 300];
          }
        }
      });
  }

  tsTranslation() {
    this.translate.get('HOME.CREATEDTODAY').subscribe((string) => {
      this.transCreatedToday = string;
    });
    this.translate.get('DEFAULTTERMS.PLAYER').subscribe((string) => {
      this.playersTerm = string;
    });
  }

  getTimelineReport() {
    this.subscriber = this.reportsSrv.getTimelineReport(
      this.selectedWorkspace.account.id,
      this.selectedWorkspace.id
    )
      .subscribe( timelineReport => {
        if(timelineReport) {
          this.timelineOptions.directionDescription = `Players`;
          this.timelineItems = timelineReport;
        }
      });
  }

  loadOnboardingProcess() {
    if(this.players && this.players.length == 0) {
      this.onboardingProcess = OnboardingProcess.setupFirstPlayer;
    }
    // Commented Temporarily
    // Show customize channel
    // else if (this.playlists && (this.playlists.length < 1 || (this.playlists.length == 1 && this.playlists[0].slides.length == 4))) {
    //   this.onboardingProcess = OnboardingProcess.customizeChannel;
    // }
    // Show customize channel
    else if (this.playlists && (this.playlists.length < 1 || this.playlists.length == 1)) {
      this.onboardingProcess = OnboardingProcess.customizeChannel;
    }
    // Show Upload Your Content
    else if (this.assetFiles && this.assetFiles.length == 0) {
      this.onboardingProcess = OnboardingProcess.uploadContent;
    }
    else {
      this.onboardingProcess = OnboardingProcess.default;
    }
  }

  checkSchedules() {
    this.subscriber = this.schedulesSrv.getSchedules(
      this.selectedWorkspace.account.id,
      this.selectedWorkspace.id
    )
    .subscribe(async(schedules) => {
      if (schedules) {
        this.sortAssignedSchedulesByDevices();
        if(this.canRead()) {
          if(schedules.length == 0) {
            this.pageState = PageState.noItems;
          } else {
            this.pageState = PageState.withItems;
          }
        } else {
          this.pageState = PageState.noReadPermission;
        }
      }
    });
  }

  getDisconnectedDevices(workspaceId: number) {
    // Note: Commented for now as endpoint returns 404.
    // this.subscriber = this.reportsSrv.getDisconnectedDevices(
    //   this.selectedWorkspace.account.id,
    //   this.selectedWorkspace.id
    // )
    //   .subscribe(devices => {
    //     if(devices) {
    //       this.disconnectedReport = devices;
    //       this.sortDisconnectedDevices();
    //     }
    //   }, (err) => {
    //     // Do nothing
    //   });
  }

  sortDisconnectedDevices() {
    if(this.disconnectedReport) {
      this.disconnectedReport.sort( (prev, next) => {
        return prev.lastCheckinTimestamp - next.lastCheckinTimestamp;
      });
    }
  }

  onEditDevice(device: DeviceV3) {
    this.router.navigate(['devices', device.id])
  }

  /**
   * send request to the server for get user favorites
   * @param
   * @return `null`
   */
  getUserFavorites() {
    this.subscriber = this.favoritesSrv.getUserFavorites(
      this.selectedWorkspace.account.id,
      this.selectedWorkspace.id,
      'playlist'
    )
      .subscribe(userFavorites => {
        if(userFavorites) {
          this.userFavorites = userFavorites;
        }
      })
  }

  /**
   * send request to the server for get workspace popular playlists
   * @param workspaceId is a current workspace id
   * which popular playlists should be received
   * @return `null`
   */
  getPopularPlaylists(workspaceId: number) {
    this.subscriber = this.reportsSrv.getPopularPlaylists(workspaceId)
      .subscribe(popularPlaylists => {
        if(popularPlaylists) {
          popularPlaylists.sort((playlist1, playlist2) => {
            return playlist2.value - playlist1.value;
          });
          this.popularPlaylists = popularPlaylists;
          this.playlistsHundredPercentValue = 0;
          this.popularPlaylists.forEach(playlist => {
            this.playlistsHundredPercentValue =
              this.playlistsHundredPercentValue + playlist.value
          });
        }
      });
  }

  /**
   * send request to the server for get workspace popular slides
   * @param workspaceId is a current workspace id
   * which popular slides should be received
   * @return `null`
   */
  getPopularSlides(workspaceId: number) {
    this.subscriber = this.reportsSrv.getPopularSlides(workspaceId)
      .subscribe(popularSlides => {
        if(popularSlides) {
          popularSlides.sort((slide1, slide2) => {
            return slide2.value - slide1.value;
          });
          this.popularSlides = popularSlides;
          this.popularSlidesLength = this.popularSlides.length;
          // show only top 9 popular playlists
          // remaining into others
          if (this.popularSlides.length > 10) {
            let otherSlides = this.popularSlides.splice(9, this.popularSlides.length - 1);
            let otherSlide = {
              name: 'Other',
              value: 0,
              count: otherSlides.length
            }
            // calculate sum of remaining slide values
            otherSlides.forEach(slide => {
              otherSlide.value = otherSlide.value + slide.value;
            });
            // set into list
            this.popularSlides.push(otherSlide);
          }
          this.slidesHundredPercentValue = 0;
          this.popularSlides.forEach(slide => {
            this.slidesHundredPercentValue = this.slidesHundredPercentValue + slide.value
          })
        }
      })
  }

  /**
   * calcualte and return percent from `slidesHundredPercentValue`
   * @param value is a slide usage count
   * @return `number`
   */
  onGetSlidePercent(value: number) {
    return (value * 100 / this.slidesHundredPercentValue).toFixed(1);
  }

  /**
   * calcualte and return percent from `playlistsHundredPercentValue`
   * @param value is a playlist usage count
   * @return `number`
   */
  onGetPlaylistPercent(value: number) {
    return (value * 100 / this.playlistsHundredPercentValue).toFixed(1);
  }

  /**
   * calculate and return remaining days until trial end
   * @param dateInNumber is a trial end date in miliseconds
   * @return `string`
   */
  onTakeThePastDays(dateInNumber: number) {
    let now = new Date().getTime();
    let pastDays = Math.floor((now - dateInNumber) / (24 * this.hourInMiliseconds));
    let text = `Created ${pastDays} Days ago`;
    if (pastDays === 0) {
      text = this.transCreatedToday;
    }
    return text;
  }

  /**
   * separate  devices which have assigned schedules from list
   * and get assigned schedules for every devices
   * @param null
   * @return `null`
   */
  async sortAssignedSchedulesByDevices() {
    this.subscriber = this.devicesSrv.getDevices(
      this.selectedWorkspace.account.id,
      this.selectedWorkspace.id
    )
      .subscribe(response => {
        if(response) {
          this.devices = response.message;
          this.devicesPaginate = response.pagination;
          this.getPlaylists();
        }
      })
  }

  getPlaylists() {
    this.subscriber = this.playlistsSrv.getPlaylists(
      this.selectedWorkspace.account.id,
      this.selectedWorkspace.id
    ).subscribe( playlists => {
      if(playlists) {
        let playlistsByIds = {};
        playlists.forEach(playlist => {
          playlistsByIds[playlist.id] = playlist;
        });
        this.playlistsByIds = playlistsByIds;
      }
    });
  }

  /**
   * calls from template for each scheudle item
   * helper function for ngFor optimization
   * @param index is a index of each item
   * @param item is a each item
   * @return `string`
   */
  onTrackById(index: number, item: { id: number }) {
    return item.id;
  }

  /**
   * calls from template
   * generete device image url
   * and get it
   * @param deviceId with type `number`
   * @return `null`
   */
  getDeviceImage(deviceId: number) {
    return this.deviceImageEndpoint + deviceId + '/image/';
  }

  getMessages(){
    this.subscriber = this.messageSrv.getMessages().subscribe(messages => {
      if (messages) {
        this.systemMessages = messages;
      }
    });
  }

  onGetUserAccountInvitations(){
    if (this.storageSrv.currentUserInvitations){
      return this.storageSrv.currentUserInvitations;
    } else {
      return []
    }
  }

  openInvitationsModal(){
    this.sharedSrv.openDialog<{ id: number }[]>(
      {
        accountInvitations: this.onGetUserAccountInvitations()
      },
      true,
      null,
      AccountInvitationsComponent
    ).subscribe(response => {
      // do nothing
    })
  }

  openSystemMessagesModal() {
    this.sharedSrv.openDialog(
      {
        title: "System Messages",
        systemMessages: this.systemMessages,
        template: 0,
        confirm: 'Ok',
        cancel: 'Cancel'
      },
      true,
      null,
      SystemMessagesComponent
    ).subscribe(response => {
      if (response.continue){
        // do nothing
      }
    });
  }

  filterUnreadSystemMessages() {
    let unReadSystemMessages = this.systemMessages.filter( (message) => message.read == false);
    return unReadSystemMessages.length;
  }

  // Unused Method
  // getPlayersPlaylistsFiles() {
  //   const getDevices = of(this.storageSrv.devicesSubject)
  //     .pipe(
  //       delay(3000),
  //       tap( (res) => {
  //         if(res) {
  //           this.players = res.getValue();
  //         }
  //       }
  //     ));
  //   const getPlaylists = of(this.storageSrv.playlistsSubject)
  //     .pipe(
  //       delay(2000),
  //       tap( (res) => {
  //         if(res) {
  //           this.playlists = res.getValue();
  //         }
  //       }
  //     ));
  //   const getFiles = of(this.storageSrv.assetFilesSubject)
  //     .pipe(
  //       delay(1000),
  //       tap( (res) => {
  //         if(res) {
  //           this.assetFiles = res.getValue();
  //         }
  //       }
  //     ));

  //   getDevices
  //     .pipe( switchMap(() => getPlaylists))
  //     .pipe( switchMap(() => getFiles) )
  //     .subscribe((res) => {
  //       this.checkSchedules();
  //     });
  // }

  /**
   * Method not being used
   * send request to the server for get workspace newest devices
   * @param workspaceId is a current workspace id
   * which newest devices should be received
   * @return `null`
   */
  // getNewestDevices(workspaceId: number) {
  //   this.subscriber = this.reportsSrv.getNewestDevices(
  //     this.selectedWorkspace.account.id,
  //     this.selectedWorkspace.id,
  //   )
  //     .subscribe(newestDevices => {
  //       this.newestDevices = newestDevices;
  //       this.newestDevices.sort((device1, device2) => {
  //         return device2.createdTimestamp - device1.createdTimestamp;
  //       })
  //     })
  // }

  //Note: No longer storing devices in storage svc.
  /**
   * add new device into deviceGroup
   * @param deviceInfo with type `Device`  (updated device info)
   * @return `null`
   */
  // async integrateDeviceIntoList(deviceInfo: DeviceV3) {
  //   if (deviceInfo.deviceGroup) {
  //     let deviceGroup = this.storageSrv.deviceGroups.find(deviceGroup => deviceGroup.id === deviceInfo.deviceGroup.id);
  //     if (!deviceGroup) {
  //       try {
  //         deviceGroup = await this.devicesGroupSrv.getDeviceGroupInfo(deviceInfo.deviceGroup.id).toPromise();
  //         if (deviceGroup && deviceGroup.id >= 0) {
  //           this.storageSrv.deviceGroups.push(deviceGroup);
  //         }
  //       } catch (e) {
  //         //console.warn(e);
  //       }
  //     }
  //     this.storageSrv.devices.push(deviceInfo);
  //   }
  // }

  //prepareTimelineItems(){
    // load devices
    // this.subscriber = this.storageSrv.devicesSubject
    //   .subscribe(devices => {
    //     if (devices) {
    //       // Avoid async issue
    //       if (!this.storageSrv.playlistsSubject) {
    //         let playlistSubject = this.storageSrv.playlistsSubject.subscribe(playlists => {
    //           if (playlists){
    //             let playlistsByIds = {};
    //             playlists.forEach(playlist => {
    //               this.playlistsByIds[playlist.id] = playlist;
    //             });
    //             let schedulesSubject = this.storageSrv.schedulesSubject.subscribe(schedules => {
    //               let schedulesByIds = {};
    //               schedules.forEach(schedule => {
    //                 this.schedulesByIds[schedule.id] = schedule;
    //               });
    //               this.timelineRendering(devices);
    //               if (schedulesSubject) {
    //                 schedulesSubject.unsubscribe()
    //               }
    //             });
    //           }
    //           if (playlistSubject) {
    //             playlistSubject.unsubscribe()
    //           }
    //         });
    //       }
    //     }
    //   });
  //}

  canUpdate(){
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.content);
  }

  canRead(){
    return this.storageSrv.getWorkspaceReadPermission(Resource.content);
  }

  canWriteDevices() {
    return this.storageSrv.getWorkspaceWritePermission(Resource.devices);
  }

  canDelete() {
    return this.storageSrv.getWorkspaceDeletePermission(Resource.content);
  }

}
