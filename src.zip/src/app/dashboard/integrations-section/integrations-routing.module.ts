import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IntegrationsSectionComponent } from './integrations-section.component';
import { WorkspaceIntegrationsComponent } from './workspace-integrations/workspace-integrations.component';

const routes: Routes = [
  {
    path: '', component: IntegrationsSectionComponent, children: [
      {
        path: 'workspace',
        component:WorkspaceIntegrationsComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class IntegrationsRoutingModule { }
