import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-integrations-section',
  templateUrl: './integrations-section.component.html',
  styleUrls: ['./integrations-section.component.scss']
})
export class IntegrationsSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
