import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { IntegrationsRoutingModule } from './integrations-routing.module';
import { IntegrationsSectionComponent } from './integrations-section.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { WorkspaceIntegrationsComponent } from './workspace-integrations/workspace-integrations.component';


@NgModule({
  declarations: [
    IntegrationsSectionComponent,
    WorkspaceIntegrationsComponent

  ],
  imports: [
    CommonModule,
    SharedModule,
    IntegrationsRoutingModule
  ]
})
export class IntegrationsModule { }
