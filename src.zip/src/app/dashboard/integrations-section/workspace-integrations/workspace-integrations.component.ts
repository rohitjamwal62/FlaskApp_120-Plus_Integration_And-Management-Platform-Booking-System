import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { TemplateFlaggEvent } from 'src/app/shared/events/template-flagg.event';
import { take } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { PageState } from 'src/app/shared/enums/page-state.enum';

import { UtilService } from 'src/app/shared/services/util.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { IntegrationsService } from 'src/app/shared/services/integrations.service';
import { IntegrationsOptService } from 'src/app/shared/services/integrations-opt.service';

import { SitebarItem } from 'src/app/shared/models/common-models/sitebar-item.model';
import { Reorder } from 'src/app/shared/models/common-models/reorder.model';
import { ClientToken } from 'src/app/shared/models/integration-models/client-token.model';
import { IntegrationUpdate } from 'src/app/shared/models/requests-models/integration-update.model';
import { OAuthConnection } from 'src/app/shared/models/common-models/o-auth-connection.model';

import { NewIntegrationComponent } from 'src/app/shared/components/new-integration/new-integration.component';
import { GenericIntegrationComponent } from 'src/app/shared/components/new-integration/generic-integration/generic-integration.component';

@Component({
  selector: 'app-workspace-integrations',
  templateUrl: './workspace-integrations.component.html',
  styleUrls: ['./workspace-integrations.component.scss']
})
export class WorkspaceIntegrationsComponent extends CleanOnDestroy implements OnInit {
  siteItem: SitebarItem;
  tokenIntegrations: ClientToken[];
  storedTokenIntegrations: ClientToken[];
  oauthIntegrations: OAuthConnection[];
  storedOauthIntegrations: OAuthConnection[];
  currentUserInfo;
  pageState = PageState.loading;
  isIntegrationsSearch = false;

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private integrationsSrv: IntegrationsService,
    private integrationsOptSrv: IntegrationsOptService,
    private sharedSrv: SharedService,
    public storageSrv: StorageService,
    private router: Router
  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.siteItem = this.utilSrv.getSitebarItem("Integrations");
    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe(async(workspace) => {
        if (workspace) {
          if(this.canRead()) {
            this.getWorkspaceIntegrations();
            this.getWorkspaceConnections();
            this.getCurrentUserInfo();
          } else {
            this.pageState = PageState.noReadPermission;
          }
        }
      });
  }

  checkPageState() {
    if(this.tokenIntegrations != null && this.oauthIntegrations !=  null) {
      if(this.tokenIntegrations.length == 0 && this.oauthIntegrations.length == 0) {
        this.pageState = (this.canRead()) ? PageState.noItems : PageState.noReadPermission;
      }
    }
  }

  getWorkspaceIntegrations(){
    this.storageSrv.workspaceIntegrationsSubject.subscribe(async(integrations) => {
      if(integrations != null) {
        this.storedTokenIntegrations = integrations;
        this.tokenIntegrations = integrations;
        this.pageState = PageState.withItems;
        this.checkPageState();
      }
    });
  }

  getWorkspaceConnections(){
    this.storageSrv.workspaceConnectionsSubject.subscribe(async(integrations) => {
      if(integrations != null) {
        this.storedOauthIntegrations = integrations;
        this.oauthIntegrations = integrations;
        this.pageState = PageState.withItems;
        this.checkPageState();
      }
    });
  }

  onSearchByWord(word: string) {
    if (word) {
      word = word.toLowerCase();
      this.oauthIntegrations = this.storedOauthIntegrations.filter(oauth => {
        let shouldTaken = false;
        let oauthName = oauth.name.toLowerCase();
        if (oauthName.indexOf(word) >= 0) {
          shouldTaken = true;
        }
        let oauthType = oauth.type.toLowerCase();
        if (oauthType.indexOf(word) >= 0) {
          shouldTaken = true;
        }
        return shouldTaken;
      });
      this.tokenIntegrations = this.storedTokenIntegrations.filter(token => {
        let shouldTaken = false;
        let tokenName = token.name.toLowerCase();
        if (tokenName.indexOf(word) >= 0) {
          shouldTaken = true;
        }
        let tokenType = token.type.toLowerCase();
        if (tokenType.indexOf(word) >= 0) {
          shouldTaken = true;
        }
        return shouldTaken;
      });
      this.isIntegrationsSearch = true;
    } else {
      this.tokenIntegrations = this.storedTokenIntegrations;
      this.oauthIntegrations = this.storedOauthIntegrations;
      this.isIntegrationsSearch = false;
    }
    //this.filterValue = word;
  }

  addIntegration() {
    this.subscriber = this.sharedSrv.openDialog(
      {},
      true,
      null,
      NewIntegrationComponent
    ).subscribe(response => {
      if (response.outputData) {
        this.getWorkspaceIntegrations();
      }
    });
  }

  onEditIntegration(integration: ClientToken) {
    this.subscriber = this.sharedSrv.openDialog(
      {integration: integration, integrationType: integration.integrationType},
      true,
      null,
      GenericIntegrationComponent
    ).subscribe(response => {
      if (response.outputData) {
        this.getWorkspaceIntegrations();
      }
    });
  }

  onDeleteIntegration(integration: ClientToken, integrationIndex: number){
    this.subscriber = this.sharedSrv.openDialog(
      {
        title: 'Delete Integration',
        description: 'You are about to delete this Integration. Do you want to confirm?',
        confirm: 'Confirm',
        cancel: 'Cancel',
        template: 0
      },
      true
    ).subscribe(response => {
      if (response.continue) {
        this.proceedDeleteIntegration(integration, integrationIndex);
      }
    });
  }

  getCurrentUserInfo() {
    this.storageSrv.currentUserSubject.pipe(take(2))
      .subscribe(currentUserInfo => {
        this.currentUserInfo = currentUserInfo;
      });
  }


  // revoke oauth integration
  onRevokeIntegration(integration: OAuthConnection, integrationIndex: number){
      this.sharedSrv.openDialog(
        {
            title: "OAuth Integration",
            description: "Are you sure you want to delete this integration?",
            confirm: "Delete",
            cancel: null,
            template: 0
          },
          true
      ).subscribe(response => {
        if (response.continue) {
            window.open(
              this.utilSrv.env.endPoint + '/'+integration.type+"/"+integration.id+'/revoke/',
              'BOLDcast OAuth Integration',
              'width=720,height=600'
            );
        }
      });
  }


  proceedDeleteIntegration(integration: ClientToken, integrationIndex: number) {
    this.integrationsSrv.deleteIntegration(integration.id).subscribe( isDeleted => {
      if(isDeleted) {
        this.tokenIntegrations.splice(integrationIndex, 1);
        this.storageSrv.workspaceIntegrations = this.tokenIntegrations;
      }
    });
  }

  canRead(){
    return this.storageSrv.getWorkspaceReadPermission(Resource.channels);
  }

  canUpdate(){
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.channels);
  }

  canWrite() {
    return this.storageSrv.getWorkspaceWritePermission(Resource.channels);
  }

  canDelete() {
    return this.storageSrv.getWorkspaceDeletePermission(Resource.channels);
  }

}
