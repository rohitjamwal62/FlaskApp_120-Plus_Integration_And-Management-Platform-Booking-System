import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UtilService } from 'src/app/shared/services/util.service';
import { NotificationsService } from 'src/app/shared/services/notifications.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { FavoritesService } from 'src/app/shared/services/favorites.service';
import { StorageService } from 'src/app/shared/services/storage.service';

import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';

import { Resource } from 'src/app/shared/enums/resource.enum';
import { PageState } from 'src/app/shared/enums/page-state.enum';

import { SitebarItemSub } from 'src/app/shared/models/common-models/sitebar-item-sub.model';
import { Notification } from 'src/app/shared/models/notification-models/notification.model';
import { Reorder } from 'src/app/shared/models/common-models/reorder.model';
import { FavoriteCreateRequest } from 'src/app/shared/models/requests-models/favorite-create.model';
import { UserFavorite } from 'src/app/shared/models/user-models/user-favorite.model';
import { NotificationCreateRequest } from 'src/app/shared/models/requests-models/notification-create.model';
import { NotificationUpdateRequest } from 'src/app/shared/models/requests-models/notification-update.model';

//import { NotificationUpdateRequest } from 'src/app/shared/models/requests-models/notification-update.model';
import { PaylistOptionsComponent } from 'src/app/shared/components/paylist-options/paylist-options.component';
import { ReadConfirmationsComponent } from 'src/app/shared/components/read-confirmations/read-confirmations.component';
import { NotificationEditComponent } from 'src/app/shared/components/notification-edit/notification-edit.component';

import { TemplateFlaggEvent } from 'src/app/shared/events/template-flagg.event';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.scss']
})
export class NotificationsComponent extends CleanOnDestroy implements OnInit {
  scrollDisalbed: boolean = false;
  // sitebar playlist item
  notificationItem: SitebarItemSub;

  // messages list
  notifications: Notification[] = [];

  filterValue: string = '';

  // for large filter
  //areDeliveredMessagesHidden = true;
  areDeliveredMessagesHidden = false;

  serviceEventListener = null;
  allMessagesSent = true;
  isNotifications = false;
  isNotificationsSearch = false;
  currentLocale: any = '';

  transChooseStream: string = '';
  transDeleteStream: string = '';
  transDeleteStreamDesc: string = '';
  confirmString: string = '';
  cancelString: string = '';

  pageState = PageState.loading;

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private notificationsSrv: NotificationsService,
    private sharedSrv: SharedService,
    public storageSrv: StorageService,
    private router: Router
  ) {
    super();

    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    let notificationItem = this.utilSrv.getSitebarItem("streams");
    this.notificationItem = notificationItem.submenu[1];
    this.currentLocale = this.utilSrv.locale;

    // Listening to API request errors
    this.serviceEventListener = this.sharedSrv.templateFlagg.subscribe({
      next: (event: TemplateFlaggEvent) => {
        this.isNotifications = true;
      }
    });

    // Translation
    this.tsTranslations();

    // // listen to the selected workspace changing
    // this.subscriber = this.storageSrv.selectedWorkspaceSubject
    //   .subscribe(selectedWorkspace => {
    //     if (selectedWorkspace) {
    //       this.getWorkspaceFavorites(selectedWorkspace.id);
    //     }
    //   });

    this.getNotifications();
  }

  tsTranslations() {
    this.translate.get('NOTIFICATIONS.CHOOSEWORKSPACE').subscribe((string) => {
      this.transChooseStream = string;
    });
    this.translate.get('NOTIFICATIONS.DELETESTREAM').subscribe((string) => {
      this.transDeleteStream = string;
    });
    this.translate.get('NOTIFICATIONS.DELETESTREAMDESC').subscribe((string) => {
      this.transDeleteStreamDesc = string;
    });
    this.translate.get('CONFIRMBUTTON').subscribe((string) => {
      this.confirmString = string;
    });
    this.translate.get('CANCELBUTTON').subscribe((string) => {
      this.cancelString = string;
    });
  }

  getNotifications(){
    // this.subscriber = await this.storageSrv.notificationsSubject.subscribe(notifications => {
    //   if (notifications){
    //     this.notifications = this.updateSortingNotification(notifications.slice());
    //   }
    // });

    const notifications = this.storageSrv.notificationsSubject.subscribe(async(notifications) => {
      if (notifications){
        this.notifications = this.updateSortingNotification(notifications.slice());

        // Checking for delivered messages.
        for(const n of this.notifications) {
          if(this.isMessageDelivered(n) == false) {
            this.allMessagesSent = false;
            break;
          }
        }

        // Show page skeleton
        this.pageState = PageState.withItems;

        if(notifications.length == 0) {
          if(this.canRead()) {
            this.pageState = PageState.noItems;
          } else {
            this.pageState = PageState.noReadPermission;
          }
        }
      }
    });
  }

  updateSortingNotification(notifications: Notification[]) {
    notifications.sort((firstNotification, secondNotification) => {
      if (secondNotification.publishTimestamp == null){
        return 1;
      } else if (firstNotification.publishTimestamp == null){
        return -1
      } else {
        return secondNotification.publishTimestamp - firstNotification.publishTimestamp;
      }
    });
    return notifications;
  }

  isMessageDelivered(message){
    if (message.publishTimestamp == null){
      return false;
    }

    var currentTime = new Date().getTime();
    if (message.publishTimestamp < currentTime){
      return true;
    }
    return false;
  }

  isMessageScheduled(message){
    if (message.publishTimestamp == null){
      return false;
    }

    var currentTime = new Date().getTime();
    if (message.publishTimestamp >= currentTime){
      return true;
    }
    return false;
  }

  isMessageRepeatScheduled(message){
    if (message.publishTimestamp == null && message.schedules.length > 0){
      return true;
     } else {
      return false;
     }
  }

  dayFormat(message){
    var responses = "";
    var daysOfWeek = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
    for (var i = 0; i < message.schedules.length; i++){
      var s = message.schedules[i];
      if (s.publishDay > daysOfWeek.length){
        continue;
      }
      var dayOfWeek = daysOfWeek[s.publishDay];
      responses += dayOfWeek+","
    }
    return responses.substring(0, responses.length-1);
  }

  onSearchByWord(word){
    if (word) {
      word = word.toLowerCase();
      this.notifications = this.updateSortingNotification(this.storageSrv.notifications).filter(notification => {
        let shouldTaken = false;
        let notificationName = notification.notificationName.toLowerCase();
        if (notificationName.indexOf(word) >= 0) {
          shouldTaken = true;
        }
        if (notification.author.email.toLowerCase().indexOf(word) >= 0){
          shouldTaken = true;
        }
        notification.tags.every(tag => {
          if (tag.toLowerCase().indexOf(word) >= 0) {
            shouldTaken = true;
            return false;
          }
          return true;
        });
        return shouldTaken;
      });
      this.isNotificationsSearch = true;
    } else {
      this.notifications = this.updateSortingNotification(this.storageSrv.notifications);
      this.isNotificationsSearch = false;
    }
    this.filterValue = word;
  }

  onCreateMessage(){
    if (
      this.storageSrv.selectedWorkspace
      && this.storageSrv.selectedWorkspace.id >= 0
    ) {
      this.subscriber = this.sharedSrv
        .openDialog<NotificationCreateRequest>(
          {
            workspaceId: this.storageSrv.selectedWorkspace.id,
            isNew: true
          },
          true,
          { width: '60%' },
          NotificationEditComponent
        ).subscribe(response => {
          if (response.outputData){
              this.notifications.unshift(response.outputData.notification);
              this.notifications = this.updateSortingNotification(this.notifications);
              this.storageSrv.notifications = this.notifications;
              this.pageState = PageState.withItems;
          }
        });
    } else {
      this.sharedSrv.errorDialog('Please choose your workspace before creating a new Stream.');
    }
  }

  onEditNotification(notification: Notification, notificationIndex: number){
    if (
      this.storageSrv.selectedWorkspace
      && this.storageSrv.selectedWorkspace.id >= 0
    ) {
      this.subscriber = this.sharedSrv
        .openDialog<NotificationCreateRequest>(
          {
            workspaceId: this.storageSrv.selectedWorkspace.id,
            isNew: false,
            notification: notification
          },
          true,
          { width: '60%' },
          NotificationEditComponent
        ).subscribe(response => {
          if (response.outputData){
              this.notifications.splice(notificationIndex, 1, response.outputData.notification);
              this.notifications = this.updateSortingNotification(this.notifications);
              this.storageSrv.notifications = this.notifications;
          }
        });
    } else {
      this.sharedSrv.errorDialog('Please choose your workspace before creating a new Stream.');
    }
  }

  onDuplicateNotification(notification: Notification){
    if (
      this.storageSrv.selectedWorkspace
      && this.storageSrv.selectedWorkspace.id >= 0
    ) {
      this.subscriber = this.sharedSrv
        .openDialog<NotificationCreateRequest>(
          {
            workspaceId: this.storageSrv.selectedWorkspace.id,
            isNew: true,
            notification: notification
          },
          true,
          { width: '60%' },
          NotificationEditComponent
        ).subscribe(response => {
          if (response.outputData){
              this.notifications.unshift(response.outputData.notification);
              this.notifications = this.updateSortingNotification(this.notifications);
              this.storageSrv.notifications = this.notifications;
          }
        });
    } else {
      this.sharedSrv.errorDialog(this.transChooseStream);
    }
  }


  onDeleteNotification(notification: Notification, notificationIndex: number){
    this.subscriber = this.sharedSrv.openDialog<null>(
      {
        title: this.transDeleteStream,
        description: this.transDeleteStreamDesc,
        template: 0,
        cancel: this.cancelString,
        confirm: this.confirmString,
      },
      true
    ).subscribe(response => {
      if (response && response.continue) {
        this.notificationsSrv.deleteNotification(notification.id).subscribe(isDeleted => {
          if (isDeleted) {
            this.notifications.splice(notificationIndex, 1);
            this.storageSrv.notifications = this.notifications;

            if (this.notifications.length == 0){
              this.pageState = PageState.noItems;
            }
          }
        });
      }
    });
  }

  onOpenReadConfirmations(notification){
    if (
      this.storageSrv.selectedWorkspace
      && this.storageSrv.selectedWorkspace.id >= 0
    ) {
      this.subscriber = this.sharedSrv
        .openDialog<ReadConfirmationsComponent>(
          {
            notification: notification
          },
          true,
          { width: '80%' },
          ReadConfirmationsComponent
        ).subscribe(response => {
          // can't do anything
        });
    } else {
      this.sharedSrv.errorDialog(this.transChooseStream);
    }
  }

  dateFormat(timestamp){
    var d = new Date(timestamp);
    var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    var hours = d.getHours();
    var ampm = hours >= 12 ? 'PM' : 'AM';
    var minutes = d.getMinutes();
    hours = hours % 12;
    hours = hours ? hours : 12;
    var finalMinutes = minutes < 10 ? '0'+minutes : minutes;

    // March 20, 2020 2:00 PM
    return months[d.getMonth()]+" "+d.getDate()+", "+d.getFullYear()+" "+hours+":"+finalMinutes+" "+ampm;
  }

  lockNotification(notification, i){
    this.notificationsSrv.lockNotification(notification.id)
    .subscribe(response => {
        this.notifications[i].isLocked = response.isLocked;
        this.storageSrv.notifications = this.notifications;
    });
  }

  canUpdate(notification){
    if (notification.isLocked){
      return false;
    }
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.notifications);
  }

  canRead(){
    return this.storageSrv.getWorkspaceReadPermission(Resource.notifications);
  }

  canWrite() {
    return this.storageSrv.getWorkspaceWritePermission(Resource.notifications);
  }

  canDelete(notification) {
    if (notification.isLocked){
      return false;
    }
    return this.storageSrv.getWorkspaceDeletePermission(Resource.notifications);
  }

}
