import { Component, OnInit, HostListener, AfterViewInit, ViewChild, ElementRef, EventEmitter, Output } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Subject, fromEvent } from 'rxjs';
import { debounceTime, filter, map, distinctUntilChanged, tap } from 'rxjs/operators';
import { ArraySortPipe } from 'src/app/shared/pipes/sorted.pipe';
import { TimePipe } from 'src/app/shared/pipes/time.pipe';
import { ENTER, TAB } from '@angular/cdk/keycodes';
import { MatChipInputEvent } from '@angular/material/chips';
import { MatAccordion } from '@angular/material/expansion';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { TranslateService } from '@ngx-translate/core';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';
import { MatTabChangeEvent } from '@angular/material/tabs';

import { AccountFeatures } from 'src/app/shared/models/account-models/account-features.model';
import { PlaylistTemplate } from 'src/app/shared/models/playlist-models/playlist-template.model';
import { Slide } from 'src/app/shared/models/slide-models/slide.model';
import { SlideTypeFull } from 'src/app/shared/models/slide-models/slide-type-full.model';
import { UserFavorite } from 'src/app/shared/models/user-models/user-favorite.model';
import { WorkspaceFavorite } from 'src/app/shared/models/workspace-models/workspace-favorite.model';
import { Playlist } from 'src/app/shared/models/playlist-models/playlist.model';
import { AssetFile } from 'src/app/shared/models/asset-models/asset-file.model';
import { Reorder } from 'src/app/shared/models/common-models/reorder.model';
import { SlideCreateRequest } from 'src/app/shared/models/requests-models/slide-create.model';
import { SlideUpdateRequest } from 'src/app/shared/models/requests-models/slide-update.model';
import { SlideCopyRequest } from 'src/app/shared/models/requests-models/slide-copy.model';
import { PlaylistUpdateRequest } from 'src/app/shared/models/requests-models/playlist-update.model';
import { FavoriteCreateRequest } from 'src/app/shared/models/requests-models/favorite-create.model';
import { AppsTypes } from 'src/app/shared/models/apps-models/apps-types.model';
import { Apps } from 'src/app/shared/models/apps-models/apps.model';
import { AppFolder } from 'src/app/shared/models/app-folders/app-folder.model';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { Pagination } from 'src/app/shared/models/common-models/pagination.model';
import { DeviceUpdateRequestModel } from 'src/app/shared/models/requests-models/device-update.model';

import { SlideUpdateRequestV3 } from 'src/app/shared/models/requests-models/slide-update-v3.model';
import { SlideCopyRequestV3 } from 'src/app/shared/models/requests-models//slide-copy-v3.model';
import { SlideCreateRequestV3 } from 'src/app/shared/models/requests-models/slide-create-v3.model';

import { SlidesService } from 'src/app/shared/services/slides.service';
import { UtilService } from 'src/app/shared/services/util.service';
import { PlaylistsService } from 'src/app/shared/services/playlists.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { FavoritesService } from 'src/app/shared/services/favorites.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { DevicesService } from 'src/app/shared/services/devices.service';
import { AppsService } from 'src/app/shared/services/apps.service';
import { AppFoldersService } from 'src/app/shared/services/app-folders.service';

import { SlideEditComponent } from 'src/app/shared/components/slide-edit/slide-edit.component';
import { PaylistOptionsComponent } from 'src/app/shared/components/paylist-options/paylist-options.component';
import { SlideScheduleComponent } from 'src/app/shared/components/slide-schedule/slide-schedule.component';
import { AssignPlaylistToDeviceComponent } from 'src/app/shared/components/assign-playlist-to-device/assign-playlist-to-device.component';
import { SlideErrorsComponent } from 'src/app/shared/components/slide-errors/slide-errors.component';
import { CreateSlideComponent } from 'src/app/shared/components/create-slide/create-slide.component';
import { SelectAppComponent } from 'src/app/shared/components/select-app/select-app.component';

@Component({
  selector: 'app-playlist',
  templateUrl: './playlist.component.html',
  styleUrls: ['./playlist.component.scss']
})
export class PlaylistComponent extends CleanOnDestroy implements OnInit, AfterViewInit {

  @ViewChild('search', {static: true}) search: ElementRef;

  accountFeatures: AccountFeatures;

  env = environment;
  endPoint = this.env.endPoint;

  currentLocale: any = '';
  addOnBlur = true;
  separatorKeysCodes: number[] = [ENTER, TAB];
  subject: Subject<any> = new Subject();
  requestTimeout: number = 300;
  isMobileView: boolean;
  isOpenedSidenav: boolean = true;
  holdingElementTimer = null;
  holdingElementDuration = 1500;
  timerForClosingContent = null;
  inActivityDuration: number = 0;
  inActivityTimer = null;
  inActivityTimerDuration: number = 1000; // in miliseconds
  maxInactiveDuration: number = 10;
  isSnakbarAlreadyShowed: boolean = false;
  snackbarShowingDuration: number = 5000;
  currentDurationTime: any = null;

  playlistForm: FormGroup;

  filterValue = '';
  isAppsCollapsed = false;
  isNewAppCollapsed = true;
  isExpandedNewApp = false;
  @ViewChild('myApps') myApps: MatAccordion;
  @ViewChild('newApp') newApp: MatAccordion;
  @Output() selectedTabChange: EventEmitter<MatTabChangeEvent>;

  isCurrentPlaylist = false;
  transOpenSnackBar: string = '';
  transRemoveFavorite: string = '';
  transRemoveFavoriteDesc: string = '';
  transDeleteFavorite: string = '';
  transDeleteFavoriteDesc: string = '';
  transDeleteCast: string = '';
  transDeleteCastDesc: string = '';
  confirmString: string = '';
  cancelString: string = '';

  /*--------------------------------------------------
  * V3 API integrations
  * --------------------------------------------------
  */

  searchControl = new FormControl();

  currentWorkspace: Workspace;
  breakpoint: number;
  requestEndpoint: string = '';

  folderTrails: AppFolder[] = [];
  currentParentFolder: AppFolder;

  appFolders: AppFolder[] = [];
  selectedAppFolders: AppFolder[] = [];
  storedAppFolders: AppFolder[] = [];
  appFoldersPaginate: Pagination = { count: 0, limit: 0, next: '', offset: 0 };

  isFolderChildren: boolean = false;
  appFoldersChildren: any[] = [];
  appFoldersChildrenPaginate: Pagination = { count: 0, limit: 0, next: '', offset: 0 };

  appTypes: AppsTypes[] = [];
  storedAppTypes: AppsTypes[] = [];
  appTypesCategories: string[] = [];
  storedAppTypesCategories: string[] = [];
  appTypesByCategories: { [key: string]: AppsTypes[] };
  storedAppTypesByCategories: { [key: string]: AppsTypes[] };

  apps: Apps[] = [];
  storedApps: Apps[] = [];
  selectedApps: Apps[] = [];
  appsByIds: { [key: number]: Apps } = {};
  appsPaginate: Pagination = { count: 0, limit: 0, next: '', offset: 0 };

  playlists: Playlist[] = [];
  storedPlaylists: Playlist[] = [];

  playlistId: number;
  playlist: Playlist;
  playlistSlides: Slide[];
  playlistSlideAppsByIds: { [key: number]: Apps } = {};

  isUserFavorite: boolean = null;
  favoriteApps: UserFavorite[] = [];
  storedFavoriteApps: UserFavorite[] = [];
  favoriteAppsIndexes: { [key: number]: boolean } = {};
  favoriteAppsByIds: { [key: number]: Apps } = {};

  favoritePlaylists: UserFavorite[] = [];
  storedFavoritePlaylists: UserFavorite[];
  favoritePlaylistsByIds: { [key: number]: Playlist } = {};
  storedFavoritePlaylistsByIds: { [key: number]: Playlist } = {};
  favoritePlaylistsSlides: { [key: number]: Slide[] } = [];
  storedFavoritePlaylistsSlides: { [key: number]: Slide[] } = [];

  folderLoader = false;
  appsLoader = false;

  constructor(
    public translate: TranslateService,
    public utilSrv: UtilService,
    private router: Router,
    private slidesSrv: SlidesService,
    private sharedSrv: SharedService,
    private playlistsSrv: PlaylistsService,
    private favoritesSrv: FavoritesService,
    private fb: FormBuilder,
    private activeRoute: ActivatedRoute,
    private snackbar: MatSnackBar,
    private storageSrv: StorageService,
    private devicesSrv: DevicesService,
    private appFoldersSrv: AppFoldersService,
    private appsSrv: AppsService,
    private timePipe: TimePipe,
  ) {
    super();

    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.playlistId = +this.activeRoute.snapshot.params['playlistId'];
    this.currentLocale = this.utilSrv.locale;
    this.requestEndpoint = this.utilSrv.env.endPoint;
    this.tsTranslation();

    this.subscriber = this.storageSrv.accountFeaturesSubject.subscribe( accountFeatures => {
      if (accountFeatures) {
        this.accountFeatures = accountFeatures;
      }
    });

    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe( workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;
          this.getApps();
          this.getAppFolders();
          this.getAppsType();
          this.generatePlaylistForm();
        }
      });

    if(window.innerWidth <= 400) {
      this.breakpoint = 1;
    } else {
      this.breakpoint = 2;
    }
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.onResize(window);
    });

    fromEvent(this.search.nativeElement,'keyup')
      .pipe(
        filter(Boolean),
        debounceTime(1500),
        distinctUntilChanged(),
        tap((event:KeyboardEvent) => {

          let word = this.search.nativeElement.value;
          word = word.toLowerCase();
          if(word) {

            this.myApps.openAll();
            this.isExpandedNewApp = true;

            // Filtering Folders
            this.appFolders = this.storedAppFolders.filter((folder) => {
              let shouldTaken: boolean = false;
              let folderName = folder.name.toLowerCase();
              if (folderName.indexOf(word) >= 0) {
                shouldTaken = true;
              }
              return shouldTaken;
            });

            // Filtering Apps
            if(this.isFolderChildren) {
              this.searchAppsInFolders(word);
            } else {
              this.searchApps(word);
            }

            // Filtering New App
            let appTypesByCategories: { [key: string]: AppsTypes[] } = this.storedAppTypesByCategories;
            let filterAppTypesByCategories: { [key: string]: AppsTypes[] } = {};
            for(const app in appTypesByCategories) {
              let appTypes = appTypesByCategories[app];
              let appTypeApps = appTypes.filter( (appType) => {
                let shouldTaken: boolean = false;
                if (appType.name.toLowerCase().indexOf(word) >= 0) {
                  shouldTaken = true;
                }
                appType.tags.every(tag => {
                  if (tag.indexOf(word) >= 0) {
                    shouldTaken = true;
                    return false;
                  }
                  return true
                })
                return shouldTaken;
              });
              if(appTypeApps.length > 0) {
                filterAppTypesByCategories[app] = appTypeApps;
              }
            }
            this.appTypesByCategories = filterAppTypesByCategories;

            // Filtering favorite apps
            this.favoriteApps = this.storedFavoriteApps.filter((favorite) => {
              let shouldTaken: boolean = false;
              let favoriteApp = this.favoriteAppsByIds[favorite.resourceId];
              if(favoriteApp) {
                let slideName = favoriteApp.name.toLowerCase();
                if (slideName.indexOf(word) >= 0) {
                  shouldTaken = true;
                }
                favoriteApp.tags.every( tag => {
                  if(tag.indexOf(word) >= 0 ) {
                    shouldTaken = true;
                    return false;
                  }
                  return true;
                })
              }
              return shouldTaken;
            });

            // Filtering playlist slides
            let newFavoritePlaylistSlides: { [key: number]: Slide[] } = this.storedFavoritePlaylistsSlides;
            let filterFavoritePlaylistSlides: { [key: number]: Slide[] } = {};
            for(const playlistSlide in newFavoritePlaylistSlides) {
              let appSlides = newFavoritePlaylistSlides[playlistSlide];
              let newAppSlides = appSlides.filter( (slide) => {
                let shouldTaken: boolean = false;
                if (slide.app.name.toLowerCase().indexOf(word) >= 0) {
                  shouldTaken = true;
                }
                slide.app.tags.every(tag => {
                  if (tag.indexOf(word) >= 0) {
                    shouldTaken = true;
                    return false;
                  }
                  return true
                })
                return shouldTaken;
              });
              if(newAppSlides.length > 0) {
                filterFavoritePlaylistSlides[playlistSlide] = newAppSlides;
              }
            }
            this.favoritePlaylistsSlides = filterFavoritePlaylistSlides;

          } else {

            if(this.currentParentFolder) {
              this.getAppsInFolders();
            } else {
              this.getAppFolders();
              this.getApps();
            }

            this.playlists = this.storedPlaylists;
            this.appTypes = this.storedAppTypes;
            this.groupAppTypesByCategories();
            this.favoriteApps = this.storedFavoriteApps;
            this.favoritePlaylistsByIds = this.storedFavoritePlaylistsByIds;
            this.favoritePlaylistsSlides = this.storedFavoritePlaylistsSlides;
          }
        })
      )
      .subscribe();
  }

  searchApps(word: string) {
    this.subscriber = this.appsSrv.searchApps(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      word
    )
      .subscribe( response => {
        if(response) {
          this.apps = response.message;
          this.appsPaginate = response.pagination;
        }
      });
  }

  searchAppsInFolders(word: string) {
    this.subscriber = this.appsSrv.searchAppsInFolders(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.currentParentFolder.id,
      word
    )
      .subscribe( response => {
        if(response) {
          this.appFoldersChildren = response.message;
          this.appFoldersChildrenPaginate = response.pagination;
          let apps: any = this.appFoldersChildren.filter( app => app.type.name != 'folder');
          let folders: any = this.appFoldersChildren.filter( app => app.type.name == 'folder');
          this.apps = apps;
          this.appFolders = folders;
        }
      });
  }

  /*------------------------------------------------------------
  * Commons / Helpers
  * ------------------------------------------------------------
  */

  /**
   * TS File Translation
   * @param null
   * @return `null`
   */
  tsTranslation() {
    this.translate.get('PLAYLIST.OPENSNACKBAR').subscribe((string) => {
      this.transOpenSnackBar = string;
    });
    this.translate.get('PLAYLIST.REMOVEFAVORITE').subscribe((string) => {
      this.transRemoveFavorite = string;
    });
    this.translate.get('PLAYLIST.REMOVEFAVORITEDESC2').subscribe((string) => {
      this.transRemoveFavoriteDesc = string;
    });
    this.translate.get('PLAYLIST.DELETEFAVORITE').subscribe((string) => {
      this.transDeleteFavorite = string;
    });
    this.translate.get('PLAYLIST.DELETEFAVORITEDESC').subscribe((string) => {
      this.transDeleteFavoriteDesc = string;
    });
    this.translate.get('PLAYLIST.DELETECAST').subscribe((string) => {
      this.transDeleteCast = string;
    });
    this.translate.get('PLAYLIST.DELETECASTDESC').subscribe((string) => {
      this.transDeleteCastDesc = string;
    });
    this.translate.get('CONFIRMBUTTON').subscribe((string) => {
      this.confirmString = string;
    });
    this.translate.get('CANCELBUTTON').subscribe((string) => {
      this.cancelString = string;
    });
  }

  /**
   * calls from template
   * helper for a optimizing *ngFor
   * @param index is a current element index with type `number`
   * @param item is a current element info
   *        with type `PlaylistTemplate | AssetFile`
   * @return `number`
   */
  onTrackById(index: number, item: PlaylistTemplate | AssetFile) {
    return item.id;
  }

  /**
   * calls from template
   * helper for a optimizing *ngFor
   * @param index is a current element index with type `number`
   * @param item is a current element info
   *        with type `PlaylistTemplate | AssetFile`
   * @return `number`
   */
  onTrackByresourceId(index: number, item: WorkspaceFavorite) {
    return item.resource.id;
  }

  /**
   * calls from template
   * redirect user to the playlists ('/channels') page
   * @param null
   * @return `null`
   */
  onGoToThePlaylists() {
    this.router.navigate(['/channels']);
  }

  /**
   * calls from template
   * helper function
   * ignore trigger event to up
   * @param null
   * @return `null`
   */
  onStopTriggeringEvent() {
    event.stopPropagation();
  }

  /**
   * create and return image for slide item
   * take image from first active slide
   * or default image of slide
   * @param slideId with type `number`
   * @return `string`
   */
  onShowSlideImage(slide: Slide) {
    let slideImageUrl: string = '';
    let endpoint = `${this.utilSrv.env.endPoint}/api/v1/slides/`;
    slideImageUrl = endpoint + slide.id + '/preview/';
    slideImageUrl += "?t="+(slide.modifiedTimestamp);
    return slideImageUrl;
  }

  onShowSlideIdImage(slideId: number) {
    let playlistImageUrl: string = '';
    let endpoint = `${this.utilSrv.env.endPoint}/api/v1/slides/`;
    playlistImageUrl = endpoint + slideId + '/preview/';
    return playlistImageUrl;
  }

  onShowUserFavoriteImage(slide: UserFavorite) {
    let slideImageUrl: string = '';
    let endpoint = `${this.utilSrv.env.endPoint}/api/v1/slides/`;
    slideImageUrl = endpoint + slide.resourceId + '/preview/';
    return slideImageUrl;
  }

  /**
   * calls from template
   * return correcponded image
   * @param item with type `SlideTypeFull`
   * @return `string`
   */
  onShowSlideTypeImage(slideType: SlideTypeFull) {
    return this.requestEndpoint + slideType.icon;
  }

  /**
   * calls from template
   * @param element is a current element which active classes should be deleted
   * @return `null`
   */
  onCancelSlideCreation(element: HTMLDivElement) {
    clearTimeout(this.holdingElementTimer);
    this.holdingElementTimer = null;
    clearTimeout(this.timerForClosingContent);
    this.timerForClosingContent = null;
    if (this.isMobileView) {

      // remove active classes
      element.classList.remove('transition');
      element.classList.remove('primary-bg')
      element.classList.remove('white');

      if (!this.isSnakbarAlreadyShowed) {
        this.openSnackbar(this.transOpenSnackBar);
        this.isSnakbarAlreadyShowed = true;
      }
    }
  }

  /**
   * helper function for a make element active in a some time
   * @param element is a current element which should be marked
   * @return `null`
   */
  makeElementActive(element: HTMLDivElement) {
    element.classList.add('transition-for-item');
    element.classList.add('primary-bg');
    element.classList.add('white');

    this.timerForClosingContent = setTimeout(() => {
      this.isOpenedSidenav = false;
      this.clearInActiveInterval();
    }, this.holdingElementDuration + 500);

    setTimeout(() => {
      element.classList.remove('transition-for-item');
      element.classList.remove('primary-bg')
      element.classList.remove('white')
    }, this.holdingElementDuration + 1000);
  }

  /**
   * close sidenav drawer for a take give acces to user for a drag item
   * @param null
   * @return `null`
   */
  onCloseDrawerForMobile() {
    this.isOpenedSidenav = false;
    this.clearInActiveInterval();
  }

  /**
   * open sidenav drawer for a take give acces to user for a drag item
   * @param null
   * @return `null`
   */
  onOpenDrawerForMobile() {
    this.isOpenedSidenav = true;
  }

  /**
   * listen to the window resize change
   * @param window with type `Window`
   * @return `null`
   */
  @HostListener('window:resize', ['$event.target'])
  onResize(window: Window) {
    if (window.innerWidth < 992) {
      this.isMobileView = true;
      this.isOpenedSidenav = false;
    } else {
      this.isMobileView = false;
      this.isOpenedSidenav = false;
      this.clearInActiveInterval();
    }

    if(window.innerWidth <= 400) {
      this.breakpoint = 1;
    } else {
      this.breakpoint = 2;
    }
  }

  /**
   * listen to the window click
   * @param window with type `Window`
   * @return `null`
   */
  @HostListener('window:click', ['$event.target'])
  onClickWindow(window: Window) {
    if (!this.isMobileView || this.isSnakbarAlreadyShowed) {
      return;
    }
    setTimeout(() => {
      this.clearInActiveInterval();
      if (this.isOpenedSidenav && this.isMobileView) {
        this.inActivityTimer = setInterval(() => {
          this.inActivityDuration = this.inActivityDuration + 1;
          if (this.inActivityDuration === this.maxInactiveDuration) {
            this.clearInActiveInterval();
            this.isSnakbarAlreadyShowed = true;
            this.openSnackbar(this.transOpenSnackBar);
          }
        }, this.inActivityTimerDuration);
      }
    }, 100)
  }


  /**
   * open snackbar with text `message`
   * @param null
   * @return `null`
   */
  openSnackbar(message: string) {
    this.snackbar.open(
      message,
      '',
      {
        duration: this.snackbarShowingDuration,
        panelClass: [
          'primary-bg',
          'white',
          'd-flex',
          'justify-content-center',
          'align-items-center'
        ]
      }
    );
  }

  /**
   * listen to the window click
   * destroy inactivity timer
   * @param null
   * @return `null`
   */
  clearInActiveInterval() {
    clearInterval(this.inActivityTimer);
    this.inActivityTimer = null;
    this.inActivityDuration = 0;
  }

  /**
   * calls from template
   * helper function for a block event triggering to up
   * @param event is a current event
   * @return `null`
   */
  onStopPropagation(event: MouseEvent) {
    event.stopPropagation();
  }

  onCloseImageModal(previewContainer: HTMLDivElement) {
    previewContainer.innerHTML = '';
  }
  /*------------------------------------------------------------
  * End Commons / Helpers
  * ------------------------------------------------------------
  */

  /*------------------------------------------------------------
  * Sidebar methods
  * ------------------------------------------------------------
  */

  /**
   * calls from template
   * store searched word and call `filterBySearchWord` for a filter by word
   * @param input is a `HTMLInputElement`
   * @return `null`
   */
  onFilterContent(input: HTMLInputElement) {
    //this.filterBySearchWord(input.value.toLowerCase());
    this.toggleAppsAccordion('open');
  }

  /**
   * Toggle accordion tabs
   * @param state
   * @return `null`
   */
  toggleAppsAccordion(state: string) {
    if(state == 'open') {
      this.myApps.openAll();
      this.isAppsCollapsed = false;
    } else {
      this.myApps.closeAll();
      this.isAppsCollapsed = true;
    }
  }

  toggleNewAppAccordion(state: string) {
    if(state == 'open') {
      this.newApp.openAll();
      this.isNewAppCollapsed = false;
    } else {
      this.newApp.closeAll();
      this.isNewAppCollapsed = true;
    }
  }

  // Not being used for now.
  appsTabSelectedTabChange(changeEvent: MatTabChangeEvent) {
    // if(changeEvent.index == 1) {
    //   this.toggleNewAppAccordion('open');
    // }
  }

  /*----- Apps -----*/
  onSelectAppFolder(event, folder: AppFolder) {
    const appFolderIndex = this.selectedAppFolders.findIndex( sf => sf.id === folder.id);
    if(appFolderIndex == -1) {
      this.selectedAppFolders.push(folder);
    } else {
      this.selectedAppFolders.splice(appFolderIndex, 1);
    }
  }

  onOpenAppFolder(selectedFolder: AppFolder, index: number) {
    this.folderLoader = true;
    this.appsLoader = true;
    let folderTrails = this.folderTrails;
    let folderIndex = folderTrails.findIndex( index => index.id == selectedFolder.id);
    if(folderIndex == -1) {
      this.folderTrails.push(selectedFolder);
    }
    this.isFolderChildren = true;
    this.currentParentFolder = selectedFolder;
    this.getAppsInFolders();
  }

  getAppsInFolders() {
    this.subscriber = this.appFoldersSrv.getAppsInFolders(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.currentParentFolder.id
    ).subscribe( response => {
      if(response) {
        this.appFoldersChildren = response.message;
        this.appFoldersChildrenPaginate = response.pagination;
        let apps: any = this.appFoldersChildren.filter( app => app.type.name != 'folder');
        let folders: any = this.appFoldersChildren.filter( app => app.type.name == 'folder');
        this.apps = apps;
        this.appFolders = folders;
        this.folderLoader = false;
        this.appsLoader = false;
      }
    });
  }

  getAppsInFoldersNext() {
    this.appsLoader = true;
    this.subscriber = this.appFoldersSrv.getAppsInFoldersNext(this.appFoldersChildrenPaginate.next)
      .subscribe( response => {
      if(response) {
        let appFoldersChildren = this.appFoldersChildren;
        this.appFoldersChildren = appFoldersChildren.concat(response.message);
        this.appFoldersChildrenPaginate = response.pagination;
        let apps: any = this.appFoldersChildren.filter( app => app.type.name != 'folder');
        let folders: any = this.appFoldersChildren.filter( app => app.type.name == 'folder');
        this.apps = apps;
        this.appFolders = folders;
        this.appsLoader = false;
      }
    });
  }

  backToFolders() {
    this.folderTrails.length = 0;
    this.currentParentFolder = null;
    this.isFolderChildren = false;
    this.getAppFolders();
    this.getApps();
  }

  onTrailsClick(folder, index) {
    if(this.folderTrails && this.folderTrails.length != 0) {
      this.folderTrails.length = parseInt(index) + 1;
    } else {
      this.folderTrails.length = 0;
    }
    this.onOpenAppFolder(folder, index);
  }

  getAppsType() {
    this.appsLoader = true;
    this.subscriber = this.appsSrv.getAppTypes(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    ).subscribe(appsType => {
      if (appsType) {
        this.appTypes = appsType;
        this.storedAppTypes = appsType;
        this.groupAppTypesByCategories();
        this.appsLoader = false;
      }
    });
  }

  groupAppTypesByCategories() {
    this.appTypesByCategories = {};
    this.appTypes.forEach( (appType) => {
      // Get app types categories
      // const appTypeCategory = this.appTypesCategories.find( category => category == appType.category);
      // if(appTypeCategory == undefined) {
      //   this.appTypesCategories.push(appType.category);
      // }
      // Group app types by categories
      if(this.appTypesByCategories.hasOwnProperty(appType.category)) {
        this.appTypesByCategories[appType.category].push(appType);
      } else {
        this.appTypesByCategories[appType.category] = [];
        this.appTypesByCategories[appType.category].push(appType);
      }
    });
    this.storedAppTypesCategories = this.appTypesCategories;
    this.storedAppTypesByCategories = this.appTypesByCategories;
  }

  getAppFolders() {
    //this.folderLoader = true;
    this.subscriber = this.appFoldersSrv.getAppsFolders(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    ).subscribe( response => {
      if(response) {
        this.appFolders = response.message;
        this.appFoldersPaginate = response.pagination;
        this.storedAppFolders = this.appFolders;
        //this.folderLoader = false;
      }
    });
  }

  getAppFoldersNext() {
    //this.folderLoader = true;
    this.subscriber = this.appFoldersSrv.getAppsFoldersNext(this.appFoldersPaginate.next)
      .subscribe( response => {
        if(response) {
          // let appFolders = this.appFolders;
          // this.appFolders = appFolders.concat(response.message);
          this.appFolders.push(...response.message);
          this.appFoldersPaginate = response.pagination;
          this.storedAppFolders = this.appFolders;
          //this.folderLoader = false;
        }
      });
  }

  getApps() {
    this.subscriber = this.appsSrv.getApps(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    ).subscribe( response => {
      if(response) {
        this.apps = response.message;
        this.appsPaginate = response.pagination;
        this.storedApps = this.apps;

        this.apps.forEach( app => {
          this.appsByIds[app.id] = app;
        });

        //this.myApps.openAll();
        //this.isAppsCollapsed = false;

        this.getPlaylists();
        //this.getUserFavorites();
      }
    });
  }

  getAppsNext() {

    this.subscriber = this.appsSrv.getAppsNext(this.appsPaginate.next)
      .subscribe( response => {
        if(response) {
          //let apps = this.apps;
          //this.apps = apps.concat(response.message);
          this.apps.push(...response.message);
          this.appsPaginate = response.pagination;
          this.storedApps = this.apps;

          this.apps.forEach( app => {
            this.appsByIds[app.id] = app;
          });
        }
      });
  }

  onShowAppImage(app: Apps) {
    return `${this.requestEndpoint}${app.type.icon}`;
  }

  /*----- New App -----*/

  /*----- User Favorite Tabs -----*/
  // Old - Method
  // getPlaylistImage(playlistId: number, playlistSlides: Slide[]) {
  //   let activeSlide: Slide;
  //   let playlistImageUrl: string = '';
  //   let endpointV1 = `${this.env.endPoint}/api/v1/slides/`;
  //   // Note: slide preview in v3 endpoint not working yet.
  //   //let endpoint = `${this.env.endPoint}/api/v3/orgs/${this.currentWorkspace.account.id}/workspace/${this.currentWorkspace.id}/playlists/${this.playlistId}/slides/`;
  //   if (playlistSlides) {
  //     playlistSlides.every(slide => {
  //       if (this.utilSrv.checkSlideActivity(slide)) {
  //         activeSlide = slide;
  //         return false;
  //       }
  //       return true;
  //     })
  //     if (activeSlide) {
  //       playlistImageUrl = endpointV1 + activeSlide.id + '/preview/';
  //     } else {
  //       playlistImageUrl = '/assets/images/boldcast-large-logo.png';
  //     }
  //     return playlistImageUrl;
  //   }
  // }
  getPlaylistImage(playlistId: number) {
    let orgId = this.currentWorkspace.account.id;
    let workspaceId = this.currentWorkspace.id;
    return `${this.env.endPoint}/api/v3/orgs/${orgId}/workspaces/${workspaceId}/playlists/${playlistId}/thumbnail/`;
  }

  /**
   * get user favorites
   * @param null
   * @return `null`
   */
  getUserFavorites() {

    // Fetching favorite apps
    this.subscriber = this.favoritesSrv.getUserFavoritesV3(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      'app'
    )
    .subscribe( (favorites) => {
      if(favorites) {
        this.favoriteApps = favorites.slice();
        this.storedFavoriteApps = favorites.slice();

        this.favoriteApps.forEach( favorite => {
          this.favoriteAppsIndexes[favorite.resourceId] = true;
          const app = this.apps.find( app => app.id == favorite.resourceId);
          if(app != undefined) {
            this.favoriteAppsByIds[favorite.resourceId] = app;
          }
        });
      }
    });

    // Fetching favorite playlist
    this.subscriber = this.favoritesSrv.getUserFavoritesV3(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      'playlist'
    )
    .subscribe( (favorites) => {
      if(favorites) {
        this.isUserFavorite = false;
        this.favoritePlaylists = favorites.slice();
        this.storedFavoritePlaylists = favorites.slice();

        // Fetching playlist details
        this.favoritePlaylists.forEach( favorite => {
          const playlist = this.playlists.find( playlist => playlist.id == favorite.resourceId);
          if(playlist != undefined) {
            this.favoritePlaylistsByIds[favorite.resourceId] = playlist;
          }
          // Fetching favorite playlist slides
          this.getFavoritePlaylistSlides(favorite.resourceId);
        });

        // Checking if current playlist is a favorite playlist
        this.favoritePlaylists.every(favorite => {
          if (favorite.resourceId === this.playlistId) {
            this.isUserFavorite = true;
            return false;
          }
          return true;
        });

        this.storedFavoritePlaylistsByIds = this.favoritePlaylistsByIds;
      }
    });
  }

  getFavoritePlaylistSlides(playlistId: number) {
    this.subscriber = this.playlistsSrv.getPlaylistSlides(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      playlistId
    ).subscribe(slides => {
        if (slides) {
          this.favoritePlaylistsSlides[playlistId] = slides;
          this.storedFavoritePlaylistsSlides[playlistId] = slides;
        }
    });
  }

  /**
   * calls from template
   * when user type new tag and press on the some keys from `separatorKeysCodes`
   * add new tag into playlist tags
   * @param event with type `MatChipInputEvent`
   * @return `null`
   */
  onAddNewTag(event: MatChipInputEvent) {
    const input = event.input;
    const tagName = event.value;

    if ((tagName || '').trim()) {
      let tags = this.playlist.tags;
      tags.push(tagName)
    }

    this.onAddPlaylistTags();

    // Reset the input value
    if (input) {
      input.value = '';
    }
  }

  onAddPlaylistTags() {
    this.subscriber = this.playlistsSrv.addPlaylistTags(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.playlist.id,
      { tags: this.playlist.tags }
    ).subscribe( updatedPlaylist => {
      if(updatedPlaylist) {
        this.playlist.tags = updatedPlaylist.tags;
      }
    });
  }

  /**
   * calls from template
   * when user type new tag and press on the some keys from `separatorKeysCodes`
   * add new tag into playlist tags
   * @param event with type `MatChipInputEvent`
   * @return `null`
   */
  onRemoveTag(tagName: string) {
    if (!this.canUpdate){
      return;
    }
    let tags: string[] = this.playlist.tags;
    let tagIndex = tags.indexOf(tagName);
    if (tagIndex >= 0) {
      tags.splice(tagIndex, 1);
      this.playlist.tags = tags;
    }
    this.onAddPlaylistTags();
  }

  /**
   * calls from template
   * when user clicked on the favorite button
   * call `deleteWorkspaceFavoritePlaylist` when playlist already is favorite
   * call `createWorkspaceFavoritePlaylist` in case of playlist
   * is not workspace favorite
   * @param playlist is a playlist which should be manipulate
   * @return `null`
   */
  onToggleFavoritePlaylist() {
    if (this.storageSrv.selectedWorkspace) {
      if (this.isUserFavorite !== null) {
        this.isUserFavorite ?
          this.deleteUserFavoritePlaylist(this.playlist) :
          this.createUserFavoritePlaylist(this.playlist)
      }
    }
  }

  /**
   * send request to the server for a create workspace favorite
   * @param playlist is a playlist which should be make favorite
   * @return `null`
   */
  createUserFavoritePlaylist(playlist: Playlist) {
    let favoriteInfo: FavoriteCreateRequest = {
      resourceId: playlist.id,
      resourceType: 'playlist',
    }
    this.subscriber = this.favoritesSrv.createUserFavoriteV3(
        this.currentWorkspace.account.id,
        this.currentWorkspace.id,
        favoriteInfo
      ).subscribe(isCreated => {
        if (isCreated) {
          this.isUserFavorite = true;
        }
    })
  }

  /**
   * send request to the server for a delete user favorite
   * @param playlist is a playlist which should be delete from user favorites
   * @return `null`
   */
  deleteUserFavoritePlaylist(playlist: Playlist) {
    this.subscriber = this.sharedSrv.openDialog(
      {
        title: this.transDeleteFavorite,
        description: this.transDeleteFavoriteDesc,
        template: 0,
        cancel: 'no',
        confirm: 'Confirm'
      },
      true
    ).subscribe(response => {
      if (response.continue) {
        this.subscriber = this.favoritesSrv.deleteUserFavoritePlaylistV3(
          this.currentWorkspace.account.id,
          this.currentWorkspace.id,
          playlist.id
        ).subscribe(response => {
          if (response) {
            this.isUserFavorite = false;
          }
        })
      }
    });
  }

  /*------------------------------------------------------------
  * End Sidebar methods
  * ------------------------------------------------------------
  */

  /*------------------------------------------------------------
  * Maincontent methods
  * ------------------------------------------------------------
  */

  generatePlaylistForm() {
    this.playlistForm = this.fb.group({
      name: ['', [Validators.required, removeWhitespaceValidator]],
      description: ['', [Validators.required, removeWhitespaceValidator]]
    });
  }

  patchPlaylistForm(){
    this.playlistForm.get('name').patchValue(this.playlist.name);
    this.playlistForm.get('name').updateValueAndValidity();
    this.playlistForm.get('description').patchValue(this.playlist.description);
    this.playlistForm.get('description').updateValueAndValidity();
  }

  /**
   * listen playlistForm value changes
   * and update playlist info
   * @param null
   * @return `null`
   */
  listenPlaylistFormChanges() {
    this.subscriber = this.playlistForm.valueChanges
      .pipe(debounceTime(400))
      .subscribe( response => {
        let playlistInfo: PlaylistUpdateRequest = {
          name: response.name,
          description: response.description
        }
        if(!response.name) {
          delete playlistInfo.name;
        }
        if(!response.description) {
          delete playlistInfo.description;
        }
        if(response.name || response.description) {
          this.subscriber = this.playlistsSrv.updatePlaylist(
            this.currentWorkspace.account.id,
            this.currentWorkspace.id,
            this.playlist.id,
            playlistInfo,
          ).subscribe(updatedPlaylist => {
            if (updatedPlaylist && updatedPlaylist.id) {
              this.playlist = updatedPlaylist;
            }
          });
        }
      });
  }

  calcPlaylistTime(){
    let totalTime: number = 0;
    if (this.playlistSlides){
      this.playlistSlides.forEach((slide) => {
        if (this.utilSrv.checkSlideActivity(slide)) {
          totalTime = totalTime + slide.durationInSeconds;
        }
      });
    }
    return totalTime;
  }

  /**
   * send request to the server for
   * update current playlist info
   * @param null
   * @return `null`
   */
  updatePlaylistInfo() {
    this.subscriber = this.playlistsSrv.updatePlaylist(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.playlist.id,
      this.playlistForm.getRawValue()
    ).subscribe(updatedPlaylist => {
      if(updatedPlaylist) {
        this.playlist = updatedPlaylist;
      }
    })
  }

  getPlaylists() {
    this.subscriber = this.playlistsSrv.getPlaylists(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    )
    .subscribe(playlists => {
      if (playlists) {
        let allPlaylists: Playlist[] = playlists;
        this.storedPlaylists = this.updateSortingPlaylist(allPlaylists);
        this.playlists = this.updateSortingPlaylist(allPlaylists);

        this.getUserFavorites();

        // Get current playlist
        const playlist = this.playlists.find( pl => pl.id == this.playlistId);
        if(playlist != undefined) {
          this.playlist = playlist;
          this.patchPlaylistForm();
          this.getCurrentPlaylistSlides();
          this.listenPlaylistFormChanges();
          this.isCurrentPlaylist = true;
        }
      }
    });
  }

  getCurrentPlaylistSlides() {
    this.subscriber = this.playlistsSrv.getPlaylistSlides(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.playlistId
    ).subscribe(slides => {
        if (slides) {
          this.playlistSlides = slides;
          this.isCurrentPlaylist = true;
        }
    });
  }

  makePlaylistSlideAppsByIds(slide: Slide) {
    const app = this.apps.find( app => app.id == slide.app.id);
    if(app != undefined) {
      this.playlistSlideAppsByIds[slide.id] = app;
    }
  }

  /**
   * calls from template
   * when user drag and drop some items
   * reorder slides if user drag and drop slide item
   * othervise
   * - call `createSlideFromFiles` if user dragged item with type `AssetFile`
   * - call `createSlideFromSlide` if user dragged item with type `Slide`
   * - call `createSlideFromApps` if user dragged item with type `SlideTypeFull`
   * @param event with type `CdkDragDrop<Slide[]>`
   * @return `null`
   */
  onManipulateSlideItems(event: CdkDragDrop<Slide[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(
        this.playlistSlides,
        event.previousIndex,
        event.currentIndex
      );
      this.updateSlide(event.item.data, event.currentIndex);
    } else {
      let data = event.item.data;
      // Creating a slide from new App
      if(data && data.hasOwnProperty('resourceType')) {
        this.onCreateSlideFromFavoriteApps(data, event.currentIndex);
      // Creating slide from favorite playlist slides
      } else if(data && data.hasOwnProperty('app')) {
        this.onCreateSlideFromFavoritePlaylistApps(data, event.currentIndex);
      // Creating a slide from Apps
      } else {
        if(data.hasOwnProperty('type')) {
          this.onCreateSlideFromApps(data, event.currentIndex);
        } else {
          this.onCreateAppThenSlide(data, event.currentIndex);
        }
      }
    }
  }

  /**
   * reorder playlist's array from new to old date
   * @param null
   * @return `null`
   */
  updateSortingPlaylist(playlists: Playlist[]) {
    playlists.sort((firstPlaylist, secondPlaylist) => {
      return firstPlaylist.positionNumber - secondPlaylist.positionNumber;
    });
    return playlists;
  }

  /**
   * calls from template
   * open dialog for a change playlist options
   * after closed dialog send request to the server for a save all changes
   * @param null
   * @return `null`
   */
  onOpenPlaylistOptions() {
    this.subscriber = this.sharedSrv.openDialog<{ tags: string[] }>(
      {
        playlist: this.playlist
      },
      true,
      {},
      PaylistOptionsComponent
    )
    .subscribe(response => {
      if (response.continue) {
        this.playlist.tags = response.outputData.tags;
        this.onAddPlaylistTags();
      }
    });
  }

  /**
   * Old Method - no longer used.
   * calls from template
   * send request to the server for reorder slides
   * @param null
   * @return `null`
   */
  // reorderSlideList() {
  //   let reorderedList: Reorder[] = [];
  //   this.playlistSlides.forEach((slide, slideIndex) => {
  //     slide.positionNumber = slideIndex;
  //     reorderedList.push(
  //       {
  //         id: slide.id,
  //         positionNumber: slide.positionNumber
  //       }
  //     );
  //   });

  //   this.subscriber = this.slidesSrv.reorderSlides(
  //     { slides: reorderedList }
  //   )
  //   .subscribe(isReordered => {
  //     if (isReordered) {
  //     }
  //   })
  // }

  /**
   * calls from template
   * when user clicked on the slide edit option
   * open modal window whith dynamic input fields for a
   * edit slide data
   * @param slide with type `Slide` which should be copied
   * @return `null`
   */
  onEditSlide(slide: Slide, slideIndex: number) {
    this.subscriber = this.sharedSrv.openDialog(
      {
        slide: slide,
        currentPlaylistId: this.playlist.id,
      },
      true,
      { width: '40%' },
      SlideEditComponent
    )
    .subscribe(response => {
      if (response.continue) {
        let updatedSlide: Slide = response.outputData as Slide;
        this.playlistSlides.splice(slideIndex, 1, updatedSlide);
      }
    });
  }

  /**
   * calls from template
   * when user clicked on the slide copy option
   * send request to the server for copy and save the slide
   * @param slide with type `Slide` which should be copied
   * @return `null`
   */
  // onCopySlide(slide: Slide) {
  //   this.createSlideFromSlide(slide);
  // }

  /**
   * calls from template when user changed the slide duration
   * @param value is a time in format like as `00:00`
   * @param slide is a current slide
   * @param index is a slide index
   * @return `null`
   */
  onChangeSlideDuration(value: string, slide: Slide, index: number) {
    this.cancelDurationTime();
    this.currentDurationTime = setTimeout(() => {
      var duration = 0;
      if (value) {
        var timeItems = value.split(':');
        let minutes = +timeItems[0];
        if (minutes > 0) {
          duration = minutes * 60;
        }
        let seconds = +timeItems[1];
        if (seconds) {
          duration = duration + seconds;
        }
      }
      slide.durationInSeconds = duration;
      this.updateSlide(slide, index);
    }, 1500);
  }

  cancelDurationTime() {
    clearTimeout(this.currentDurationTime);
    this.currentDurationTime = undefined;
  }

  /**
   * calls from template
   * helper function for a block event triggering to up
   * @param event is a current event
   * @return `null`
   */
  onOpenSlidePreview(slide: Slide, previewContainer: HTMLDivElement) {
    previewContainer.classList.remove('d-none');
    previewContainer.innerHTML = `<iframe src="${this.utilSrv.env.endPoint}${this.playlist.previewUrl}${slide.id}/"
    class="preview-image" autoplay muted></iframe>`;
  }

  lockPlaylist(playlist: Playlist){
    let playlistId = playlist.id;
    let playlistInfo: PlaylistUpdateRequest = {
      lock: !playlist.isLocked
    }
    this.subscriber = this.playlistsSrv.updatePlaylist(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.playlistId,
      playlistInfo,
    ).subscribe(updatedPlaylist => {
      if (updatedPlaylist) {
        this.playlist = updatedPlaylist;
        for (var i = 0; i < this.storedPlaylists.length; i++){
          if (this.storedPlaylists[i].id == this.playlist.id){
            this.storedPlaylists[i] = updatedPlaylist;
            break;
          }
        }
      }
    });
  }

  showSlideErrors (slide: Slide) {
    this.sharedSrv.openDialog(
      {
        title: 'Slide Errors',
        slide: slide,
        currentWorkspace: this.currentWorkspace
      },
      true,
      null,
      SlideErrorsComponent
    ).subscribe(response => {
      // Do nothing
    })
  }

  assignToDevice(playlistId){
    this.sharedSrv.openDialog(
      null,
      true,
      {
        width: '45%'
      },
      AssignPlaylistToDeviceComponent
    ).subscribe(response => {
      if (response.continue) {
        let deviceId = response.outputData["deviceId"];
        this.devicesSrv.updateDevice(
          this.currentWorkspace.account.id,
          this.currentWorkspace.id,
          deviceId,
          { playlistId: playlistId }
        )
          .subscribe(updatedDevice => {
            if(updatedDevice) {
              // Do nothing
            }
          });
      }
    })
  }

  /**
   * calls from template
   * when user clicked on the preview button
   * open new tab with created url
   * @param null
   * @return `null`
   */
  onPreviewPlaylist() {
    window.open(
      `${this.requestEndpoint}${this.playlist.previewUrl}`,
      'RocketScreens Preview',
      'width=1280,height=720'
    );
  }

  // onCreateSlide(
  //   event: MouseEvent,
  //   app: Apps,
  //   element: HTMLDivElement
  // ) {
  onCreateSlide(app: Apps, appIndex: number) {
    if (app.type.requiresProfessional &&
      !this.accountFeatures['premium_casts']){
      return;
    }
    this.subscriber = this.sharedSrv.openDialog(
      {
        playlistId: this.playlist.id,
        app: app,
        appIndex: appIndex
      },
      true,
      null,
      CreateSlideComponent
    )
    .subscribe(response => {
      if (response.continue) {
        let createdSlide: any = response.outputData;
        //this.playlistSlides.push(createdSlide);
        this.playlistSlides.splice(appIndex, 0, createdSlide);
        this.makePlaylistSlideAppsByIds(createdSlide);
      }
    });
  }

  onCreateNewApp(
    event: MouseEvent,
    app: AppsTypes,
    element: HTMLDivElement
  ) {
    // console.log('Event', event);
    // console.log('Element', element);
    if (app.requiresProfessional &&
      !this.accountFeatures['premium_casts']){
      return;
    }

    this.onCreateAppThenSlide(app, 0);
  }

  onCreateAppThenSlide(
    app: AppsTypes,
    currentIndex?: number
  ) {

    this.subscriber = this.sharedSrv.openDialog(
      {
        isNew: true,
        app: null,
        appType: app,
        parentFolderId: null,
        allowSelectApp: false
      },
      true,
      { width: '51.15%' },
      SelectAppComponent
    )
    .subscribe(response => {
      if (response.continue) {
        let createdApp: any = response.outputData;

        // To do's - push newly created app to this.apps
        this.apps.push(createdApp);

        // Create a new slide with the newly created app details
        // this.onShortcutSlideCreation(createdApp, currentIndex);
        this.onCreateSlide(createdApp, currentIndex);
      }
    });
  }

  onShortcutSlideCreation(app: Apps, currentIndex?: number) {
    let slideInfo: SlideCreateRequestV3 = {
      appId: app.id,
      durationInSeconds: 15,
      positionNumber: 0
    };
    this.subscriber = this.slidesSrv.createSlide(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.playlistId,
      slideInfo
    )
      .subscribe(createdSlide => {
        if(createdSlide) {
          let slide: Slide = createdSlide;
          if (currentIndex >= 0) {
            this.playlistSlides.splice(currentIndex, 0, slide);
            //this.reorderSlideList();
          } else {
            this.playlistSlides.splice(0, 0, slide);
          }

          this.makePlaylistSlideAppsByIds(createdSlide);
        }
      });
  }

  onCreateSlideFromApps(app: Apps, currentIndex?: number) {
    if (app.type.requiresProfessional &&
      !this.accountFeatures['premium_casts']){
      return;
    }
    this.subscriber = this.sharedSrv.openDialog(
      {
        playlistId: this.playlist.id,
        app: app,
        appIndex: currentIndex
      },
      true,
      null,
      CreateSlideComponent
    )
    .subscribe(response => {
      if (response.continue) {
        let createdSlide: any = response.outputData;
        if (currentIndex >= 0) {
          this.playlistSlides.splice(currentIndex, 0, createdSlide);
          //this.reorderSlideList();
        } else {
          this.playlistSlides.splice(0, 0, createdSlide);
        }
        this.makePlaylistSlideAppsByIds(createdSlide);
      }
    });
  }

  onCreateSlideFromFavoriteApps(
    favorite: UserFavorite,
    currentIndex: number
  ) {
    let app = this.favoriteAppsByIds[favorite.resourceId];
    this.subscriber = this.sharedSrv.openDialog(
      {
        playlistId: this.playlist.id,
        app: app,
        appIndex: currentIndex
      },
      true,
      null,
      CreateSlideComponent
    )
    .subscribe(response => {
      if (response.continue) {
        let createdSlide: any = response.outputData;

        if (currentIndex >= 0) {
          this.playlistSlides.splice(currentIndex, 0, createdSlide);
          //this.reorderSlideList();
        } else {
          this.playlistSlides.splice(0, 0, createdSlide);
        }

        this.makePlaylistSlideAppsByIds(createdSlide);
      }
    });
  }

  onCreateSlideFromFavoritePlaylistApps(
    slide: Slide,
    currentIndex: number
  ) {
    let app = slide.app;
    this.subscriber = this.sharedSrv.openDialog(
      {
        playlistId: this.playlist.id,
        app: app,
        appIndex: currentIndex
      },
      true,
      null,
      CreateSlideComponent
    )
    .subscribe(response => {
      if (response.continue) {
        let createdSlide: any = response.outputData;

        if (currentIndex >= 0) {
          this.playlistSlides.splice(currentIndex, 0, createdSlide);
          //this.reorderSlideList();
        } else {
          this.playlistSlides.splice(0, 0, createdSlide);
        }

        this.makePlaylistSlideAppsByIds(createdSlide);
      }
    });
  }

  /**
   * send request to the server for a copy playlist slides into current playlist
   * @param slide is a slide which should be copied
   * @param currentIndex is a dragged item position (optional)
   * @return `null`
   */
  // createSlideFromFavoritePlaylist(
  //   favorite: UserFavorite,
  //   currentIndex: number = null
  // ) {
  //   let playlist = this.favoritePlaylistsByIds[favorite.resourceId];
  //   this.subscriber = this.playlistsSrv.copyPlaylistSlides(
  //     this.currentWorkspace.account.id,
  //     this.currentWorkspace.id,
  //     playlist.id,
  //     this.playlist.id,
  //     { positionNumber: currentIndex }
  //   )
  //   .subscribe(updatedPlaylist => {
  //     if(updatedPlaylist) {
  //       // To do's - Need to update playlists and current playlist
  //       // this.playlist = updatedPlaylist;
  //     }
  //   })
  // }

  /**
   * send request to the server for a copy slide
   * @param slide is a slide which should be copied
   * @param currentIndex is a dragged item position (optional)
   * @return `null`
   */
  onCopySlideFromSlide(slide: Slide, currentIndex?: number) {
    let copyInfo: SlideCopyRequestV3 = {
      playlistId: this.playlistId
    }
    this.subscriber = this.slidesSrv.copySlide(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.playlistId,
      slide.id,
      copyInfo
    )
    .subscribe(copiedSlide => {
      if (copiedSlide && copiedSlide.id >= 0) {
        if (currentIndex >= 0) {
          this.playlistSlides.splice(currentIndex, 0, copiedSlide);
          //this.reorderSlideList();
        } else {
          this.playlistSlides.push(copiedSlide);
        }
        this.makePlaylistSlideAppsByIds(copiedSlide);
      }
    });
  }

  /**
   * send request to the server for a update slide info
   * @param slide is a slide which should be updated
   * @param slideIndex is a index of slide from `currentPlaylist.slides`
   * @return `null`
   */
  updateSlide(slide: Slide, slideIndex: number) {
    let updateableInfo: SlideUpdateRequestV3 = {
      positionNumber: slideIndex,
      durationInSeconds: slide.durationInSeconds
    }
    this.subscriber = this.slidesSrv.updateSlide(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.playlistId,
      slide.id,
      updateableInfo
    ).subscribe(updatedSlide => {
      if(updatedSlide) {
        this.playlistSlides.splice(slideIndex, 1, updatedSlide);
        this.makePlaylistSlideAppsByIds(updatedSlide);
      }
    })
  }

  /**
   * calls from template
   * when user clicked on the slide delete option
   * open dialog for a confirmation before delete slide
   * send request to the server for delete slide
   * in case of confirmation
   * @param slide with type `Slide` which should be deleted
   * @param slideIndex is a position of slide from `playlistSlides`
   * @return `null`
   */
  onDeleteSlide(slide: Slide, slideIndex: number) {
    this.subscriber = this.sharedSrv.openDialog<null>(
      {
        title: this.transDeleteCast,
        description: this.transDeleteCastDesc,
        template: 0,
        cancel: this.cancelString,
        confirm: this.confirmString,
      },
      true
    ).subscribe(response => {
      if (response && response.continue) {
        this.subscriber = this.slidesSrv.deleteSlide(
          this.currentWorkspace.account.id,
          this.currentWorkspace.id,
          this.playlistId,
          slide.id
        ).subscribe(isDeleted => {
          if (isDeleted) {
            this.playlistSlides.splice(slideIndex, 1);
            delete this.playlistSlideAppsByIds[slide.id];
          }
        });
      }
    });
  }

  /**
   * calls from template
   * when user clicked on the slide schedule option
   * open modal window for  select enabled and disabled dates
   * @param slide with type `Slide` which should be copied
   * @return `null`
   */
  onScheduleSlide(slide: Slide, slideIndex: number) {
    this.subscriber = this.sharedSrv.openDialog<SlideUpdateRequest>(
      {
        slide: slide,
      },
      true,
      {
        width: '60%'
      },
      SlideScheduleComponent
    ).subscribe(response => {
      if (response && response.continue) {
        this.subscriber = this.slidesSrv.updateSlide(
          this.currentWorkspace.account.id,
          this.currentWorkspace.id,
          this.playlistId,
          slide.id,
          response.outputData
        ).subscribe(updatedSlide => {
          if(updatedSlide) {
            this.playlistSlides.splice(slideIndex, 1, updatedSlide);
            this.makePlaylistSlideAppsByIds(updatedSlide);
          }
        })
      }
    });
  }

  /**
   * calls from template
   * when user clicked on the my favorite button
   * call `deleteUserFavoriteSlide` when slide already is user favorite
   * call `createUserFavoriteSlide` in case of slide
   * is not user favorite
   * @param slide is a slide which should be manipulate
   * @return `null`
   */
  onToggleUserFavorite(slide: Slide) {
    if (this.favoriteAppsIndexes[slide.app.id]) {
      this.deleteUserFavoriteSlide(slide);
    } else {
      this.createUserFavoriteSlide(slide);
    }
  }

  /**
   * send request to the server for a create user favorite
   * @param slide is a slide which should be make favorite
   * @return `null`
   */
  createUserFavoriteSlide(slide: Slide) {
    let favoriteInfo: FavoriteCreateRequest = {
      resourceId: slide.app.id,
      resourceType: 'app'
    }
    this.subscriber = this.favoritesSrv.createUserFavoriteV3(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      favoriteInfo
    ).subscribe(favoriteApp => {
      if (favoriteApp) {
        this.favoriteApps.push(favoriteApp);
        this.storedFavoriteApps.push(favoriteApp);
        this.favoriteAppsIndexes[favoriteApp.resourceId] = true;
      }
    })
  }

  /**
   * send request to the server for delete user favorite
   * @param slide is a slide which should be make favorite
   * @return `null`
   */
  deleteUserFavoriteSlide(slide: Slide) {
    this.subscriber = this.sharedSrv.openDialog(
      {
        title: this.transRemoveFavorite,
        description: this.transRemoveFavoriteDesc,
        template: 0,
        cancel: this.cancelString,
        confirm: this.confirmString
      },
      true
    ).subscribe(response => {
      if (response && response.continue) {
        this.subscriber = this.favoritesSrv.deleteUserFavoriteSlideV3(
          this.currentWorkspace.account.id,
          this.currentWorkspace.id,
          slide.app.id
        ).subscribe(isDeleted => {
          if (isDeleted) {
            this.favoriteApps.every((favorite, indexOfFavorite) => {
              if (favorite.resourceId === slide.app.id) {
                this.favoriteApps.splice(indexOfFavorite, 1);
                delete this.favoriteAppsIndexes[favorite.resourceId];
                return false;
              }
              return true;
            })
          }
        });
      }
    });
  }

  /*------------------------------------------------------------
  * End Maincontent methods
  * ------------------------------------------------------------
  */

  /*------------------------------------------------------------
  * Permissions
  * ------------------------------------------------------------
  */
  canUpdate(){
    if (typeof this.playlist !== "undefined" && this.playlist.isLocked){
      return false;
    }
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.channels);
  }

  canRead(){
    return this.storageSrv.getWorkspaceReadPermission(Resource.channels);
  }

  canWrite() {
    return this.storageSrv.getWorkspaceWritePermission(Resource.channels);
  }

  canDelete() {
    if (typeof this.playlist !== "undefined" && this.playlist.isLocked){
      return false;
    }
    return this.storageSrv.getWorkspaceDeletePermission(Resource.channels);
  }

  canUpdateDevices(){
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.devices);
  }
}
