import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PlaylistsSectionComponent } from './playlists-section.component';
import { PlaylistsComponent } from './playlists/playlists.component';
import { PlaylistComponent } from './playlist/playlist.component';

const routes: Routes = [
  {
    path: '', component: PlaylistsSectionComponent, children: [
      {
        path: '',
        component: PlaylistsComponent
      },
      {
        path: 'new',
        component: PlaylistComponent
      },
      {
        path: 'edit/:playlistId',
        component: PlaylistComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PlaylistsRoutingModule { }
