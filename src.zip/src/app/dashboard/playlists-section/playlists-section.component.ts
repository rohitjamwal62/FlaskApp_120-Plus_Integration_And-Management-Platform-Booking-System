import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-playlists-section',
  templateUrl: './playlists-section.component.html',
  styleUrls: ['./playlists-section.component.scss']
})
export class PlaylistsSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
