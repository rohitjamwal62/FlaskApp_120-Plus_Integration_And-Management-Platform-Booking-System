import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PlaylistsRoutingModule } from './playlists-routing.module';
import { PlaylistsSectionComponent } from './playlists-section.component';
import { PlaylistsComponent } from './playlists/playlists.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { PlaylistComponent } from './playlist/playlist.component';


@NgModule({
  declarations: [
    PlaylistsSectionComponent,
    PlaylistsComponent,
    PlaylistComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    PlaylistsRoutingModule
  ]
})
export class PlaylistsModule { }
