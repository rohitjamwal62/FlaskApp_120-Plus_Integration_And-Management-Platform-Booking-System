import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { Router } from '@angular/router';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { PageState } from 'src/app/shared/enums/page-state.enum';
import { TemplateFlaggEvent } from 'src/app/shared/events/template-flagg.event';
import { TranslateService } from '@ngx-translate/core';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { debounceTime } from 'rxjs/operators';

import { SitebarItem } from 'src/app/shared/models/common-models/sitebar-item.model';
import { Slide } from 'src/app/shared/models/slide-models/slide.model';
import { Playlist } from 'src/app/shared/models/playlist-models/playlist.model';
import { PlaylistNewComponent } from 'src/app/shared/components/playlist-new/playlist-new.component';
import { PlaylistCreateRequest } from 'src/app/shared/models/requests-models/playlist-create.model';
import { Reorder } from 'src/app/shared/models/common-models/reorder.model';
import { FavoriteCreateRequest } from 'src/app/shared/models/requests-models/favorite-create.model';
import { UserFavorite } from 'src/app/shared/models/user-models/user-favorite.model';
import { PlaylistUpdateRequest } from 'src/app/shared/models/requests-models/playlist-update.model';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';

import { StorageService } from 'src/app/shared/services/storage.service';
import { UtilService } from 'src/app/shared/services/util.service';
import { PlaylistsService } from 'src/app/shared/services/playlists.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { FavoritesService } from 'src/app/shared/services/favorites.service';

import { PaylistOptionsComponent } from 'src/app/shared/components/paylist-options/paylist-options.component';

@Component({
  selector: 'app-playlists',
  templateUrl: './playlists.component.html',
  styleUrls: ['./playlists.component.scss']
})
export class PlaylistsComponent extends CleanOnDestroy implements OnInit {

  env = environment;
  endPoint = this.env.endPoint;

  scrollDisalbed: boolean = false;
  playlistItem: SitebarItem;
  storedPlaylists: Playlist[] = [];
  playlists: Playlist[];

  userFavorites: UserFavorite[] = [];
  userFavoriteIndexes: {
    [key: number]: boolean
  } = {};

  serviceEventListener = null;
  isPlaylists = false;
  isPlaylistsSearch = false;

  filterValue: string = '';
  currentLocale: any = '';

  searchControl = new FormControl();

  transChooseWorkspace: string = '';
  transDeleteTs: string = '';
  transDeleteDescTs: string = '';
  transUnsavedPlaylist: string = '';
  transRemoveFavorite: string = '';
  transRemoveFavoriteDesc: string = '';
  confirmString: string = '';
  cancelString: string = '';

  pageState = PageState.loading;

  /*--------------------------------------------------
  * V3 API integrations
  * --------------------------------------------------
  */
  currentWorkspace: Workspace;

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private playlistsSrv: PlaylistsService,
    private favoritesSrv: FavoritesService,
    private sharedSrv: SharedService,
    public storageSrv: StorageService,
    private router: Router
  ) {
    super();
  }

  ngOnInit() {

    this.playlistItem = this.utilSrv.getSitebarItem(this.utilSrv.objectNameFields.playlist+"s");
    this.currentLocale = this.utilSrv.locale;
    this.playlistItem = this.utilSrv.getSitebarItem('channels');

    this.tsTranslation();

    // Listening to API request errors
    this.serviceEventListener = this.sharedSrv.templateFlagg.subscribe({
      next: (event: TemplateFlaggEvent) => {
        this.isPlaylists = true;
      }
    });

    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe( workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;
          this.getUserFavorites();
          this.getPlaylists();
        }
      });
  }

  tsTranslation() {
    this.translate.get('PLAYLIST.CHOOSEWORKSPACE').subscribe((string) => {
      this.transChooseWorkspace = string;
    });
    this.translate.get('PLAYLIST.DELETETS').subscribe((string) => {
      this.transDeleteTs = string;
    });
    this.translate.get('PLAYLIST.DELETEDESCTS').subscribe((string) => {
      this.transDeleteDescTs = string;
    });
    this.translate.get('PLAYLIST.UNSAVEDPLAYLIST').subscribe((string) => {
      this.transUnsavedPlaylist = string;
    });
    this.translate.get('PLAYLIST.REMOVEFAVORITE').subscribe((string) => {
      this.transRemoveFavorite = string;
    });
    this.translate.get('PLAYLIST.REMOVEFAVORITEDESC').subscribe((string) => {
      this.transRemoveFavoriteDesc = string;
    });
    this.translate.get('CONFIRMBUTTON').subscribe((string) => {
      this.confirmString = string;
    });
    this.translate.get('CANCELBUTTON').subscribe((string) => {
      this.cancelString = string;
    });
  }

  /**
   * calls when changed selected workspace
   * subscribe to the playlists changes and get the new playlist
   * in case of changes
   * @param null
   * @return `null`
   */
  getPlaylists() {
    this.subscriber = this.playlistsSrv.getPlaylists(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    )
    .subscribe(playlists => {
      if (playlists) {
        this.playlists = playlists.slice();
        this.storedPlaylists = playlists.slice();
        this.playlists = this.updateSortingPlaylist(this.playlists);
        this.storedPlaylists = this.updateSortingPlaylist(this.storedPlaylists);

        // Show page skeleton
        this.pageState = PageState.withItems;
        if(playlists.length == 0) {
          if(this.canRead()) {
            this.pageState = PageState.noItems;
          } else {
            this.pageState = PageState.noReadPermission;
          }
        }
      }
    });
  }

  // /**
  //  * send request to the server for get workspace favorites
  //  * @param workspaceId is a workspace id which playlists should be received
  //  * @return `null`
  //  */
  // getWorkspaceFavorites(workspaceId: number) {
  //   this.favoritesSrv.getWorkspaceFavorites('playlist', workspaceId)
  //     .subscribe(workspaceFavorites => {
  //       this.workspaceFavorites = workspaceFavorites;
  //       this.workspaceFavorites.forEach(favorite => {
  //         this.workspaceFavoriteIndexes[favorite.resourceId] = true;
  //       });
  //     })
  // }

  /**
   * send request to the server for get user favorites
   * @param
   * @return `null`
   */
  getUserFavorites() {
    this.subscriber = this.favoritesSrv.getUserFavorites(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      'playlist'
    )
      .subscribe(userFavorites => {
        if(userFavorites) {
          this.userFavorites = userFavorites;
          this.userFavorites.forEach(favorite => {
            this.userFavoriteIndexes[favorite.resourceId] = true;
          });
        }
      })
  }

  /**
   * reorder playlist's array from new to old date
   * @param playlists with type `Playlist[]`
   * @return `playlist[]`
   */
  updateSortingPlaylist(playlists: Playlist[]) {
    playlists.sort((firstPlaylist, secondPlaylist) => {
      return firstPlaylist.positionNumber - secondPlaylist.positionNumber;
    });
    return playlists;
  }

  /**
   * calls from template
   * open dialog for a fiel playlist creation fields
   * @param null
   * @return `null`
   */
  // onCreatePlaylist() {
  //   if (
  //     this.storageSrv.selectedWorkspace
  //     && this.storageSrv.selectedWorkspace.id >= 0
  //   ) {
  //     this.subscriber = this.sharedSrv.openDialog<Playlist>(
  //       {
  //         workspaceId: this.storageSrv.selectedWorkspace.id,
  //         userFavorites: this.userFavorites
  //       },
  //       true,
  //       { width: '50%' },
  //       PlaylistNewComponent
  //     ).subscribe(response => {
  //       if (response.continue) {
  //         let playlist = response.outputData;
  //         this.playlists.unshift(playlist);
  //         this.storedPlaylists.unshift(playlist);
  //         this.playlists = this.updateSortingPlaylist(this.playlists);
  //         this.storedPlaylists = this.updateSortingPlaylist(this.storedPlaylists);
  //         this.storageSrv.playlists = this.playlists;
  //         this.pageState = PageState.withItems;
  //         this.onEditPlaylist(playlist.id);
  //       }
  //     });
  //   } else {
  //     this.sharedSrv.errorDialog(this.transChooseWorkspace);
  //   }
  // }
  onCreatePlaylist() {
    this.subscriber = this.sharedSrv.openDialog<Playlist>(
      {
        workspace: this.currentWorkspace,
        userFavorites: this.userFavorites,
        playlists: this.playlists
      },
      true,
      { width: '50%' },
      PlaylistNewComponent
    ).subscribe(response => {
      if (response.continue) {
        let playlist = response.outputData;
        this.playlists.unshift(playlist);
        this.storedPlaylists.unshift(playlist);
        this.playlists = this.updateSortingPlaylist(this.playlists);
        this.storedPlaylists = this.updateSortingPlaylist(this.storedPlaylists);
        this.pageState = PageState.withItems;
        this.onEditPlaylist(playlist.id);
      }
    });
  }

  /**
   * calls from template
   * helper function
   * ignore trigger event to up
   * @param null
   * @return `null`
   */
  onStopTriggeringEvent() {
    event.stopPropagation();
  }

  /**
   * calls from template
   * when user clicked on the edit button in playlist option
   * redirect user to the playlist edit page
   * @param playlistId is a playlist id which should be edited
   * @return `null`
   */
  onEditPlaylist(playlistId: number) {
    this.router.navigate(['/channels/edit', playlistId])
  }

  /**
   * calls from template
   * when user clicked on the copy button in playlist option
   * send request to the server for a copy playlist
   * @param playlist is a playlist which should pe copied, (type `playlist`)
   * @return `null`
   */
  onCopyPlaylist(playlist: Playlist) {
    this.subscriber = this.playlistsSrv.copyPlaylist(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      playlist.id
    ).subscribe(copiedPlaylist => {
      if (copiedPlaylist.id >= 0) {
        this.playlists.unshift(copiedPlaylist);
        this.storedPlaylists.unshift(copiedPlaylist);
        this.playlists = this.updateSortingPlaylist(this.playlists);
        this.storedPlaylists = this.updateSortingPlaylist(this.storedPlaylists);
      }
    })
  }

  /**
   * calls from template
   * when user clicked on the options button in playlist option
   * send request to the server for a change playlistTags
   * @param playlist is a playlist which options should be changed
   * @param playlistIndex is a playlist index
   * @return `null`
   */
  onOpenPlaylistOptions(playlist: Playlist, playlistIndex: number) {
    this.sharedSrv.openDialog<{ tags: string[] }>(
      {
        playlist: playlist
      },
      true,
      {},
      PaylistOptionsComponent
    ).subscribe(response => {
      if (response.continue) {
        let tags: string[] = response.outputData.tags;
        this.onAddPlaylistTags(playlist, playlistIndex, tags);
      }
    });

  }

  onAddPlaylistTags(playlist: Playlist, playlistIndex: number, tags) {
    let tagsInfo: { tags: string[] } = { tags: tags };
    this.subscriber = this.playlistsSrv.addPlaylistTags(
        this.currentWorkspace.account.id,
        this.currentWorkspace.id,
        playlist.id,
        tagsInfo
      ).subscribe( updatedPlaylist => {
        if(updatedPlaylist) {
          this.playlists[playlistIndex].tags = updatedPlaylist.tags;
        }
      });
  }

  /**
   * calls from template
   * when user clicked on the delete button in playlist option
   * send request to the server for a delete playlist
   * @param playlist is a playlist which should pe deleted, (type `Playlist`)
   * @return `null`
   */
  onDeletePlaylist(playlist: Playlist, playlistIndex: number) {
    this.sharedSrv.openDialog(
      {
        title: this.transDeleteTs,
        description: this.transDeleteDescTs,
        confirm: this.confirmString,
        cancel: this.cancelString,
        template: 0
      },
      true
    ).subscribe(response => {
      if (response.continue) {
        this.confirmPlaylistDeletion(playlist.id, playlistIndex);
      }
    });
  }

  confirmPlaylistDeletion(playlistId: number, playlistIndex: number) {
    this.subscriber = this.playlistsSrv.deletePlaylist(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      playlistId
    )
      .subscribe(isDeleted => {
        if (isDeleted) {
          this.playlists.splice(playlistIndex, 1);
          this.storedPlaylists = this.playlists;
          if (this.playlists.length == 0){
            this.pageState = PageState.noItems;
          }
        }
      });
  }

  /**
   * calls from template
   * helper for a optimizing *ngFor
   * @param index is a current element index with type `number`
   * @param item is a current element info with type `Playlist`
   * @return `number`
   */
  onTrackById(index: number, item: Playlist) {
    return item.id;
  }

  /**
   * calls from template
   * when user drad and drop playlist item
   * output event of material drag and drop functionality
   * send request to the server for a save new ordered list of playlists
   * @param event with type `CdkDragDrop<Playlist[]>`
   * @return `null`
   */
  onReorderPlaylists(event: CdkDragDrop<Playlist[]>) {
    moveItemInArray(this.playlists, event.previousIndex, event.currentIndex);
    let playlistReorderInfo: Reorder[] = [];
    this.playlists.forEach((playlist, index) => {
      playlist.positionNumber = index;
      playlistReorderInfo.push({
        id: playlist.id,
        positionNumber: playlist.positionNumber
      })
    });

    let playlist: Playlist = event.item.data;
    let playlistInfo: PlaylistUpdateRequest = {
      positionNumber: event.currentIndex
    }
    this.subscriber = this.playlistsSrv.updatePlaylist(
        this.currentWorkspace.account.id,
        this.currentWorkspace.id,
        playlist.id,
        playlistInfo,
      ).subscribe(updatedPlaylist => {
        if (updatedPlaylist) {
          // Do nothing
        }
      });
  }



  /**
   * calls from template
   * when user clicked on the my favorite button
   * call `deleteUserFavoritePlaylist` when playlist already is user favorite
   * call `createUserFavoritePlaylist` in case of playlist
   * is not user favorite
   * @param playlist is a playlist which should be manipulate
   * @return `null`
   */
  onToggleUserFavorite(playlist: Playlist) {
    if (this.userFavoriteIndexes[playlist.id]) {
      this.deleteUserFavorite(playlist);
    } else {
      this.createUserFavoritePlaylist(playlist);
    }
  }

  /**
   * send request to the server for a create user favorite
   * @param playlist is a playlist which should be make favorite
   * @return `null`
   */
  // createUserFavoritePlaylist(playlist: Playlist) {
  //   let favoriteInfo: FavoriteCreateRequest = {
  //     resourceId: playlist.id,
  //   }
  //   this.favoritesSrv.createFavoritePlaylist(
  //     favoriteInfo
  //   ).subscribe(isCreated => {
  //     if (isCreated) {
  //       this.userFavorites.push(
  //         {
  //           userId: this.storageSrv.currentUserInfo.id,
  //           resourceId: playlist.id,
  //           resourceType: 'playlist',
  //           resource: playlist
  //         }
  //       );
  //       this.userFavoriteIndexes[playlist.id] = true;
  //     }
  //   })
  // }

  createUserFavoritePlaylist(playlist: Playlist) {
    let favoriteInfo: FavoriteCreateRequest = {
      resourceId: playlist.id,
      resourceType: 'playlist',
    }
    this.subscriber = this.favoritesSrv.createUserFavoriteV3(
        this.currentWorkspace.account.id,
        this.currentWorkspace.id,
        favoriteInfo
      )
        .subscribe(isCreated => {
          if (isCreated) {
            this.userFavorites.push(
              {
                userId: this.storageSrv.currentUserInfo.id,
                resourceId: playlist.id,
                resourceType: 'playlist'
              }
            );
            this.userFavoriteIndexes[playlist.id] = true;
          }
      })
  }

  /**
   * send request to the server for delete user favorite
   * @param playlist is a playlist which should be make favorite
   * @return `null`
   */
  deleteUserFavorite(playlist: Playlist) {
    this.sharedSrv.openDialog(
      {
        title: this.transRemoveFavorite,
        description: this.transRemoveFavoriteDesc,
        template: 0,
        cancel: this.cancelString,
        confirm: this.confirmString
      },
      true
    ).subscribe(response => {
      if (response && response.continue) {
        this.confirmDeleteUserFavorite(playlist.id);
      }
    });
  }

  confirmDeleteUserFavorite(playlistId: number) {
    this.subscriber = this.favoritesSrv.deleteUserFavoriteSlideV3(
        this.currentWorkspace.account.id,
        this.currentWorkspace.id,
        playlistId
      )
        .subscribe(isDeleted => {
          if (isDeleted) {
            this.userFavorites.every((favorite, indexOfFavorite) => {
              if (favorite.resourceId === playlistId) {
                this.userFavorites.splice(indexOfFavorite, 1);
                delete this.userFavoriteIndexes[favorite.resourceId];
                return false;
              }
              return true;
            })
          }
        });
  }

  /**
   * calls from template
   * when user clicked on the preview button
   * open new tab with created url
   * @param playlist with type `Playlist` which should be show in preview mode
   * @return `null`
   */
  onPreviewPlaylist(playlist: Playlist) {
    window.open(
      `${this.utilSrv.env.endPoint}${playlist.previewUrl}`,
      'RocketScreens Preview',
      'width=1280,height=720'
    );
  }

  /**
   * calls from template
   * when user type some word into search input
   * filter playlists by user typed word
   * @param word with type string
   * @return `string`
   */
  onSearchByWord(word: string) {
    this.filterValue = word;
    this.searchControl.valueChanges
      .pipe(
        debounceTime(1000)
      )
      .subscribe(data => {
        if(data) {
          word = data.toLowerCase();
          this.playlists = this.storedPlaylists.filter(playlist => {
            let shouldTaken = false;
            let playlistName = playlist.name.toLowerCase();
            if (playlistName.indexOf(word) >= 0) {
              shouldTaken = true;
            }
            playlist.tags.every(tag => {
              if (tag.toLowerCase().indexOf(word) >= 0) {
                shouldTaken = true;
                return false;
              }
              return true;
            });
            return shouldTaken;
          });
          this.isPlaylistsSearch = true;
        } else {
          this.playlists = this.storedPlaylists;
          this.isPlaylistsSearch = false;
        }
      });
  }


  // lock the playlist
  lockPlaylist(playlist: Playlist, playlistIndex: number){
    let playlistId = playlist.id;
    let playlistInfo: PlaylistUpdateRequest = {
      lock: !playlist.isLocked
    }
    this.subscriber = this.playlistsSrv.updatePlaylist(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      playlistId,
      playlistInfo
    ).subscribe(updatedPlaylist => {
      if (updatedPlaylist) {
        this.playlists[playlistIndex] = updatedPlaylist;
        this.storedPlaylists = this.playlists;
      }
    });
  }

  getPlaylistImage(playlistId: number) {
    let orgId = this.currentWorkspace.account.id;
    let workspaceId = this.currentWorkspace.id;
    return `${this.env.endPoint}/api/v3/orgs/${orgId}/workspaces/${workspaceId}/playlists/${playlistId}/thumbnail/`;
  }

  // Method - not being used
  /**
   * calculate and return playlists duration time in seconds
   * @param playlist with type `Playlist`
   * @return `number`
   */
  // onCalculatePlaylistDuration(playlist: Playlist) {
  //   let totalTime = 0;
  //   if (playlist.slides) {
  //     playlist.slides.forEach(slide => {
  //       if (slide.isEnabled) {
  //         totalTime = totalTime + slide.durationInSeconds;
  //       }
  //     })
  //   }
  //   return totalTime;
  // }

  // Old method
  /**
 * create image for playlist item
 * take image from first active slide
 * or default image of playlsist
 *
 * @param playlist with type `Playlist`
 * @return `string`
 */
  // getPlaylistImage(playlist: Playlist) {
  //   let activeSlide: Slide;
  //   let playlistImageUrl: string = '';
  //   // if (playlist.slides) {
  //   //   playlist.slides.every(slide => {
  //   //     if (this.utilSrv.checkSlideActivity(slide)) {
  //   //       activeSlide = slide;
  //   //       return false;
  //   //     }
  //   //     return true;
  //   //   })
  //   // }

  //   if (activeSlide) {
  //     let endpoint = `${this.env.endPoint}/api/v1/slides/`;
  //     playlistImageUrl = endpoint + activeSlide.id + '/preview/';
  //   } else {
  //     playlistImageUrl = '/assets/images/boldcast-large-logo.png';
  //   }
  //   return playlistImageUrl;
  // }

  canUpdate(playlist){
    if (typeof playlist !== "undefined" && playlist.isLocked){
      return false;
    }
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.channels);
  }

  canRead(){
    return this.storageSrv.getWorkspaceReadPermission(Resource.channels);
  }

  canWrite() {
    return this.storageSrv.getWorkspaceWritePermission(Resource.channels);
  }

  canDelete(playlist) {
    if (typeof playlist !== "undefined" && playlist.isLocked){
      return false;
    }
    return this.storageSrv.getWorkspaceDeletePermission(Resource.channels);
  }

}
