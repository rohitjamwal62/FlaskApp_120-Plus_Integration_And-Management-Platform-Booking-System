import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ProfileSectionComponent } from './profile-section.component';
import { ProfileComponent } from './profile/profile.component';


const routes: Routes = [
    {
        path: '', component: ProfileSectionComponent, children: [
            {
                path: '',
                component: ProfileComponent
            },
            {
                path: ':tabName',
                component: ProfileComponent
            },


        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ProfileRoutingModule { }
