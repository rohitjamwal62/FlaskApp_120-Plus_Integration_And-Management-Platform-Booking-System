import { OnInit, Component } from '@angular/core';
import { take } from 'rxjs/operators';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';
import { phoneValidator } from 'src/app/shared/utils/phone-validator';

import { SitebarItem } from 'src/app/shared/models/common-models/sitebar-item.model';
import { UtilService } from 'src/app/shared/services/util.service';
import { UserPersonal } from 'src/app/shared/models/user-models/user-personal.model';
import { UsersService } from 'src/app/shared/services/users.service';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { UserUpdateRequest } from 'src/app/shared/models/requests-models/user-update.model';
import { StorageService } from 'src/app/shared/services/storage.service';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { ActivatedRoute } from '@angular/router';
import { SharedService } from 'src/app/shared/services/shared.service';
import { ChangeProfileImageComponent } from 'src/app/shared/components/change-profile-image/change-profile-image.component';

declare var OneSignal: any;
declare var window: any;

import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})

export class ProfileComponent implements OnInit {

  selectedIndex: number = 0;

  avatarChangeUrl: string = '';
  // sitebar item info
  profileItem: SitebarItem;
  // reactive form for profile
  profileForm: FormGroup;
  // current user info
  currentUserInfo: UserPersonal = {} as UserPersonal;

  // show defaultImage in case of user isn't have picture
  defaultImage: string = '';

  isPushNotificationEnabled: boolean = false;

  revokeText: string = 'Already Authenticated: Click to Revoke';
  signinMicrosoftText: string = 'Sign in with Microsoft';
  signinGoogleText: string = 'Sign in with Google';
  signinTwitterText: string = 'Sign in with Twitter';
  signinPowerBiText: string = 'Sign in with PowerBi';

  transProfileAvatar: string = '';
  transProfileAvatarDesc: string = '';
  transProfileAvatarDesc2: string = '';
  transChangePassword: string = '';
  transChangePasswordDesc: string = '';

  changePasswordUrl: string = '';

  constructor(
    private translate: TranslateService,
    private activRoute: ActivatedRoute,
    public utilSrv: UtilService,
    private storageSrv: StorageService,
    private fb: FormBuilder,
    private userSrv: UsersService,
    private sharedSrv: SharedService
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {

    this.changePasswordUrl = this.utilSrv.endPoint + '/password/change';
    this.profileItem = this.utilSrv.getSitebarItem('profile');
    this.avatarChangeUrl = this.utilSrv.env.changeAvatarUrl;
    this.defaultImage = this.utilSrv.appImages.profileDefaultImage;

    this.tsTranslation();
    this.generateProfileForm();
    this.getCurrentUserInfo();
    this.listenNotificationsEnableChange();

    let tabName = this.activRoute.snapshot.params['tabName']
    if (tabName) {
      switch (tabName) {
        case 'personal-information':
          this.selectedIndex = 0;
          break;
        case 'notifications':
          this.selectedIndex = 1;
          break;
      }
    }
  }

  tsTranslation() {
    this.translate.get('PROFILE.PROFILEAVATAR').subscribe((string) => {
      this.transProfileAvatar = string;
    });
    this.translate.get('PROFILE.PROFILEAVATARDESC').subscribe((string) => {
      this.transProfileAvatarDesc = string;
    });
    this.translate.get('PROFILE.PROFILEAVATARDESC2').subscribe((string) => {
      this.transProfileAvatarDesc2 = string;
    });
    this.translate.get('PROFILE.CHANGEPASSWORDTS').subscribe((string) => {
      this.transChangePassword = string;
    });
    this.translate.get('PROFILE.CHANGEPASSWORDDESCTS').subscribe((string) => {
      this.transChangePasswordDesc = string;
    });
  }

  /**
   * first run to determine if enabled or not
   *
   *
   * @param null
   *
   * @return `null`
   */
  listenNotificationsEnableChange() {
    OneSignal.push(() => {
      OneSignal.isPushNotificationsEnabled((isEnabled: boolean) => {
        window['areNotificationsEnabled'] = isEnabled;
        this.isPushNotificationEnabled = window['areNotificationsEnabled'];
      })
    });

    // boldcast listener for subscription changes
    OneSignal.push(() => {
      OneSignal.on("subscriptionChange", (isSubscribed: boolean) => {
        window['areNotificationsEnabled'] = isSubscribed;
        this.isPushNotificationEnabled = window['areNotificationsEnabled'];
      });
    });

  }

  /**
   * subscribe to the user info update and
   * store current user info
   * check user integrations
   *
   * @param null
   *
   * @return `null`
   */
  getCurrentUserInfo() {
    this.storageSrv.currentUserSubject.pipe(take(2))
      .subscribe(currentUserInfo => {
        if (currentUserInfo) {
          this.currentUserInfo = currentUserInfo;
          this.profileForm.patchValue(this.currentUserInfo);
        }
      });
  }

  /**
   * generate profileForm
   *
   * @param null
   *
   * @return `null`
   */
  generateProfileForm() {
    this.profileForm = this.fb.group({
      firstName: ['', ],
      lastName: ['',],
      // phoneNumber: ['', [Validators.pattern('[2-9]\\d{9}')]],
      phoneNumber: ['', [removeWhitespaceValidator, phoneValidator]],
    })
  }

  /**
   * allow typing only digits
   * @param event is a keydown event
   * @return `null`
   */
  onTypeOnlyNumbers(event: KeyboardEvent) {
    this.utilSrv.onTypeOnlyDigits(event);
  }

  addPhoneNumberPrefix() {
    let phoneNumber = this.profileForm.get('phoneNumber').value;
    if(phoneNumber.length > 2) {
      let first2 = phoneNumber.slice(0, 2);
      if(!phoneNumber.includes('+', 0)) {
        this.profileForm.get('phoneNumber').patchValue('+1'+phoneNumber);
      }
    }
  }

  /**
   * send request to the server for a update profile picture
   *
   * @param imageInput is a input element
   *
   * @return `null`
   */
  onChangeProfileImage(imageInput: HTMLInputElement) {
    // get choosed image
    let profileNewImage: File = imageInput.files[0];

    // check image extension
    let isValidExtension = this.utilSrv.checkImageExtension(profileNewImage);

    if (isValidExtension) {
      // uplaod in case validity
      let accountLogoForm = new FormData();
      accountLogoForm.append('file', profileNewImage);

      this.userSrv.updateProfileImage(accountLogoForm).subscribe( image => {
        if(image) {
          this.userSrv.getCurrentUserInfo().subscribe( userinfo => {
            if(userinfo) {
              this.currentUserInfo = userinfo;
            }
          });
        }
      });
    }
  }

  // changeProfileImage(){
  //   var followUpUrl = "https://en.gravatar.com/emails/";
  //   var message = this.transProfileAvatarDesc;

  //   if (this.currentUserInfo.picture.indexOf("gravatar") > -1){
  //     followUpUrl = "https://en.gravatar.com/emails/";
  //     message = this.transProfileAvatarDesc;
  //   } else if (this.currentUserInfo.picture.indexOf("google") > -1){
  //     followUpUrl = "https://myaccount.google.com/personal-info";
  //     message = this.transProfileAvatarDesc2;
  //   }

  //   this.sharedSrv.openDialog(
  //     {
  //       title: this.transProfileAvatar,
  //       description: message,
  //       confirm: 'Open',
  //       template: 1
  //     }, true
  //   ).subscribe(response => {
  //     if (response.continue){
  //       window.open(followUpUrl, "_blank");
  //     }
  //   });
  // }

  /*
  * trigger event for a open dialog wher user can choose file for upload
  */
  changeProfileImage(){
    this.sharedSrv.openDialog(
      {},
      true,
      null,
      ChangeProfileImageComponent
    ).subscribe(response => {
      if(response.continue == true) {
        this.userSrv.getCurrentUserInfo().subscribe( userinfo => {
          if(userinfo) {
            this.currentUserInfo = userinfo;
          }
        });
      }
    })
  }


  /**
   * trigger event for a open dialog wher user can choose file ofr a upload it
   *
   * @param input is a `HTMLInputElement` with type `file`
   *
   * @return `null`
   */
  onTrigerClick(input: HTMLInputElement) {

  }

  /**
   * calls from template
   * call `updateUserInfo` with neccessary info for update user info
   *
   * @param event is a output event of material slide toggle
   * with type `MatSlideToggleChange`
   *
   * @return `null`
   */
  onUpdateEmailNotification(event: MatSlideToggleChange) {
    this.updateUserInfo({ isEmailEnabled: event.checked })
  }

  /**
   * calls from template
   * call `updateUserInfo` with neccessary info for update user info
   *
   * @param event is a output event of material slide toggle
   * with type `MatSlideToggleChange`
   *
   * @return `null`
   */
  onUpdatePhoneNotification(event: MatSlideToggleChange) {
    this.updateUserInfo({ isPhoneEnabled: event.checked });
  }

  onUpdatePushNotifications() {
    window.setPushNotifications(!window.areNotificationsEnabled);
  }
  /**
   * send request to the server for update user info
   *
   * @param userInfo is a object with type `UserUpdateRequest`
   *
   * @return `null`
   */
  updateUserInfo(userInfo: UserUpdateRequest) {
    this.userSrv.updateUserInfo(userInfo).subscribe(updatedUser => {
      this.currentUserInfo = updatedUser;
      this.storageSrv.currentUserInfo = this.currentUserInfo;
    })
  }

  /**
   * generate profileForm
   *
   * @param null
   *
   * @return `null`
   */
  onUpdateProfile() {
    if (this.profileForm.valid) {
      this.userSrv.updateUserInfo(this.profileForm.getRawValue())
        .subscribe(updatedUser => {
          if(updatedUser) {
            this.currentUserInfo = updatedUser;
            this.storageSrv.currentUserInfo = this.currentUserInfo;
          }
        });
    }
  }


  /**
   * calls from template
   * when user change the selected tab
   *
   * replace the current url for a store user selected tab
   * and helper for mobile app
   *
   * @param event is a output event object of tab group `selectedTabChange` event
   *
   * @return `null`
   */
  onChangeTab(event: MatTabChangeEvent) {
    switch (event.index) {
      case 0:
        history.replaceState(location.href, '', `/profile/personal-information`);
        break;
      case 1:
        history.replaceState(location.href, '', `/profile/notifications`);
        break;
      case 2:
        history.replaceState(location.href, '', `/profile/integrations`);
        break;
    }
  }

  onChangeUserPassword() {
    // this.userSrv.changePaasword().subscribe(response => {
    //   if (response) {
    //     this.sharedSrv.openDialog(
    //       {
    //         title: this.transChangePassword,
    //         description: this.transChangePasswordDesc,
    //         confirm: 'Ok',
    //         template: 1
    //       }
    //     )
    //   }
    // })

    // password/change/
  }
}
