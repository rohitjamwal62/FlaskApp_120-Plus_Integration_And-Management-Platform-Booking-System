import { Component, OnInit } from '@angular/core';
import { SitebarItem } from 'src/app/shared/models/common-models/sitebar-item.model';
import { UtilService } from 'src/app/shared/services/util.service';
import { Recipient } from 'src/app/shared/models/recipient-models/recipient.model';
import { RecipientBrief } from 'src/app/shared/models/recipient-models/recipient-brief.model';
import { RecipientsService } from 'src/app/shared/services/recipients.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { Router } from '@angular/router';
//import { NotificationNewComponent } from 'src/app/shared/components/notification-new/notification-new.component';
//import { NotificationCreateRequest } from 'src/app/shared/models/notification-models/notification-create.model';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { Reorder } from 'src/app/shared/models/common-models/reorder.model';
import { FavoritesService } from 'src/app/shared/services/favorites.service';
import { FavoriteCreateRequest } from 'src/app/shared/models/requests-models/favorite-create.model';
import { UserFavorite } from 'src/app/shared/models/user-models/user-favorite.model';
//import { NotificationUpdateRequest } from 'src/app/shared/models/requests-models/notification-update.model';
import { StorageService } from 'src/app/shared/services/storage.service';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { RecipientGroup } from 'src/app/shared/models/recipient-models/recipient-group.model';
import { RecipientGroupUpdateRequest } from 'src/app/shared/models/requests-models/recipient-group-update.model';
import { RecipientGroupNewRequest } from 'src/app/shared/models/requests-models/recipient-group-new.model';
import { RecipientGroupEditComponent } from 'src/app/shared/components/recipient-group-edit/recipient-group-edit.component';
import { RecipientGroupHistoryComponent } from 'src/app/shared/components/recipient-group-history/recipient-group-history.component';
import { RecipientInvitation } from 'src/app/shared/models/recipient-models/recipient-invitation.model';
import { RecipientInvitesComponent } from 'src/app/shared/components/recipient-invites/recipient-invites.component';
import { RecipientEditComponent } from 'src/app/shared/components/recipient-edit/recipient-edit.component';
import { RecipientGroupRecipientsComponent } from 'src/app/shared/components/recipient-group-recipients/recipient-group-recipients.component';
import { TemplateFlaggEvent } from 'src/app/shared/events/template-flagg.event';
import { PageState } from 'src/app/shared/enums/page-state.enum';


import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-recipient-group',
  templateUrl: './recipient-group.component.html',
  styleUrls: ['./recipient-group.component.scss']
})
export class RecipientGroupComponent extends CleanOnDestroy implements OnInit {
  scrollDisalbed: boolean = false;
  // sitebar playlist item
  recipientItem: SitebarItem;

  recipientGroups: RecipientGroup[];

  filterValue: string = '';

  serviceEventListener = null;
  isRecipientGroups = false;
  isRecipientGroupsSearch = false;
  transDeleteRecipient: string = '';
  transDeleteRecipientDesc: string = '';
  transInviteAllRecipients: string = '';
  transInviteAllRecipientsDesc: string = '';
  transInviteRecipient: string = '';
  transInviteRecipientDesc: string = '';

  pageState = PageState.loading;

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private recipientsSrv: RecipientsService,
    private sharedSrv: SharedService,
    public storageSrv: StorageService,
    private router: Router
  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.recipientGroups = [];
    this.recipientItem = this.utilSrv.getSitebarItem("Recipients");
    
    this.tsTranslation();
    
    // Listening to API request errors
    this.serviceEventListener = this.sharedSrv.templateFlagg.subscribe({
      next: (event: TemplateFlaggEvent) => {
        this.isRecipientGroups = true;
      }
    });

    this.getRecipientGroups();
  }

  tsTranslation() {
    this.translate.get('RECIPIENTGROUP.DELETERECIPIENT').subscribe((string) => {
      this.transDeleteRecipient = string;
    });
    this.translate.get('RECIPIENTGROUP.DELETERECIPIENTDESC').subscribe((string) => {
      this.transDeleteRecipientDesc = string;
    });
    this.translate.get('RECIPIENTGROUP.INVITEALLRECIPIENTS').subscribe((string) => {
      this.transInviteAllRecipients = string;
    });
    this.translate.get('RECIPIENTGROUP.INVITEALLRECIPIENTSDESC').subscribe((string) => {
      this.transInviteAllRecipientsDesc = string;
    });
    this.translate.get('RECIPIENTGROUP.INVITERECIPIENT').subscribe((string) => {
      this.transInviteRecipient = string;
    });
    this.translate.get('RECIPIENTGROUP.INVITERECIPIENTDESC').subscribe((string) => {
      this.transInviteRecipientDesc = string;
    });
  }

  moveToRecipients(){
    this.router.navigate(['/recipients'])
  }

  getRecipientGroups(){
    this.storageSrv.recipientGroupsSubject.subscribe(recipientGroups => {
      if (recipientGroups){
        this.recipientGroups = recipientGroups;

        this.pageState = PageState.withItems;
        if (recipientGroups.length == 0){
          if (this.canRead()){
            this.pageState = PageState.noItems;
          } else {
            this.pageState = PageState.noReadPermission;
          }
        }

        // get the assigned playlist
        this.recipientGroups.forEach(recipientGroup => {
          if (this.storageSrv.playlists){
            this.storageSrv.playlists.forEach(playlist => {
              if (recipientGroup.playlist && recipientGroup.playlist.id == playlist.id){
                recipientGroup.fullPlaylist = playlist;
              }
            });
          }
        });

        // Template flagg
        this.isRecipientGroups = true;
      }
    });

  }

  onSearchByWord(word){
    if (word) {
      word = word.toLowerCase();
      this.recipientGroups = this.storageSrv.recipientGroups.filter(recipientGroup => {
        let shouldTaken = false;
        let groupName = recipientGroup.groupName.toLowerCase();
        if (groupName.indexOf(word) >= 0) {
          shouldTaken = true;
        }
        recipientGroup.tags.every(tag => {
          if (tag.toLowerCase().indexOf(word) >= 0) {
            shouldTaken = true;
            return false;
          }
          return true;
        });
        return shouldTaken;
      });

      this.isRecipientGroupsSearch = true;
    } else {
      this.recipientGroups = this.storageSrv.recipientGroups;
      this.isRecipientGroupsSearch = false;
    }
    this.filterValue = word;
  }


  shouldFilter(recipient){
    if (this.filterValue) {
        var word = this.filterValue.toLowerCase();
        let shouldTaken = false;
        let email = recipient.streamUser.email.toLowerCase();
        if (email.indexOf(word) >= 0) {
          shouldTaken = true;
        }

        if (recipient.streamUser.firstName && recipient.streamUser.firstName.toLowerCase().indexOf(word) >= 0) {
          shouldTaken = true;
        }

        if (recipient.streamUser.lastName && recipient.streamUser.lastName.toLowerCase().indexOf(word) >= 0) {
          shouldTaken = true;
        }

        return shouldTaken;
    } else {
      return true;
    }
  }

  onCreateGroup(){
      if (
      this.storageSrv.selectedWorkspace
      && this.storageSrv.selectedWorkspace.id >= 0
    ) {
      this.subscriber = this.sharedSrv
        .openDialog<RecipientGroup>(
          {
            workspaceId: this.storageSrv.selectedWorkspace.id,
            isNew: true
          },
          true,
          { width: '60%' },
          RecipientGroupEditComponent
        ).subscribe(response => {
          if (response.continue){
            let outputData = response.outputData;
            this.recipientGroups.unshift(outputData);
            this.storageSrv.recipientGroups = this.recipientGroups;
          }
        });
    } else {
      this.sharedSrv.errorDialog('Please choose your workspace before creating a new Recipient Group.');
    }
  }


  onDeleteRecipientGroup(recipientGroup, index){
    this.subscriber = this.sharedSrv.openDialog<null>(
      {
        title: this.transDeleteRecipient,
        description: this.transDeleteRecipientDesc,
        template: 0,
        cancel: 'no',
        confirm: 'confirm',
      },
      true
    ).subscribe(response => {
      if (response && response.continue) {
        this.recipientsSrv.deleteRecipientGroup(recipientGroup.id).subscribe(isDeleted => {
          if (isDeleted) {
            this.recipientGroups.splice(index, 1);
            this.storageSrv.recipientGroups = this.recipientGroups;
          }
        });
      }
    });
  }

  onViewHistory(recipientGroup){
    if (
      this.storageSrv.selectedWorkspace
      && this.storageSrv.selectedWorkspace.id >= 0
    ) {
      this.subscriber = this.sharedSrv
        .openDialog(
          {
            recipientGroup: recipientGroup
          },
          true,
          { width: '80%' },
          RecipientGroupHistoryComponent
        ).subscribe(response => {
        });
    } else {
      this.sharedSrv.errorDialog('Please choose your workspace before viewing Recipient Group Stream History.');
    }
  }


  onEditRecipientGroup(recipientGroup, index){
    if (
      this.storageSrv.selectedWorkspace
      && this.storageSrv.selectedWorkspace.id >= 0
    ) {
      this.subscriber = this.sharedSrv
        .openDialog<RecipientGroup>(
          {
            workspaceId: this.storageSrv.selectedWorkspace.id,
            isNew: false,
            recipientGroup: recipientGroup
          },
          true,
          { width: '60%' },
          RecipientGroupEditComponent
        ).subscribe(response => {
          if (response.continue){
            let updatedGroup = response.outputData;
            this.recipientGroups.splice(index, 1, updatedGroup);
            this.storageSrv.recipientGroups = this.recipientGroups;
          }
        });
    } else {
      this.sharedSrv.errorDialog('Please choose your workspace before creating a new Recipient Group.');
    }
  }


  lockRecipientGroup(recipientGroup, i){
    this.recipientsSrv.lockRecipientGroup(recipientGroup.id)
    .subscribe(response => {
        this.recipientGroups[i].isLocked = response.isLocked;
        this.storageSrv.recipientGroups = this.recipientGroups;
    });
  }

  onViewRecipients(recipientGroup: RecipientGroup){
    this.sharedSrv.openDialog<null>(
      {
        recipientGroup: recipientGroup
      },
      true,
      { width: '60%' },
      RecipientGroupRecipientsComponent
    )

  }


  canRead(){
    return this.storageSrv.getWorkspaceReadPermission(Resource.recipients);
  }

  canUpdate(){
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.recipients);
  }

  canWrite() {
    return this.storageSrv.getWorkspaceWritePermission(Resource.recipients);
  }

  canDelete() {
    return this.storageSrv.getWorkspaceDeletePermission(Resource.recipients);
  }

}
