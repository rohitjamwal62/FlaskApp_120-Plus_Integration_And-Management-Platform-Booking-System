import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RecipientsSectionComponent } from './recipients-section.component';
import { RecipientsComponent } from './recipients/recipients.component';
import { RecipientGroupComponent } from './recipient-group/recipient-group.component';

const routes: Routes = [
  {
    path: '', component: RecipientsSectionComponent, children: [
      {
        path: '',
        component: RecipientsComponent
      },
      {
        path: 'groups',
        component:RecipientGroupComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RecipientsRoutingModule { }
