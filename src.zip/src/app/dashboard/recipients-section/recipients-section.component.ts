import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recipients-section',
  templateUrl: './recipients-section.component.html',
  styleUrls: ['./recipients-section.component.scss']
})
export class RecipientsSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
