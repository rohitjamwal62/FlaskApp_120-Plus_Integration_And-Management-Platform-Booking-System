import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RecipientsRoutingModule } from './recipients-routing.module';
import { RecipientsSectionComponent } from './recipients-section.component';
import { RecipientsComponent } from './recipients/recipients.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { RecipientGroupComponent } from './recipient-group/recipient-group.component';


@NgModule({
  declarations: [
    RecipientsSectionComponent,
    RecipientsComponent,
    RecipientGroupComponent

  ],
  imports: [
    CommonModule,
    SharedModule,
    RecipientsRoutingModule
  ]
})
export class RecipientsModule { }
