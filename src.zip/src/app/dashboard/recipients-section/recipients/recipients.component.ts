import { Component, OnInit } from '@angular/core';
import { SitebarItemSub } from 'src/app/shared/models/common-models/sitebar-item-sub.model';
import { UtilService } from 'src/app/shared/services/util.service';
import { Recipient } from 'src/app/shared/models/recipient-models/recipient.model';
import { RecipientBrief } from 'src/app/shared/models/recipient-models/recipient-brief.model';
import { RecipientsService } from 'src/app/shared/services/recipients.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { Router } from '@angular/router';
//import { NotificationNewComponent } from 'src/app/shared/components/notification-new/notification-new.component';
//import { NotificationCreateRequest } from 'src/app/shared/models/notification-models/notification-create.model';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { Reorder } from 'src/app/shared/models/common-models/reorder.model';
import { FavoritesService } from 'src/app/shared/services/favorites.service';
import { FavoriteCreateRequest } from 'src/app/shared/models/requests-models/favorite-create.model';
import { UserFavorite } from 'src/app/shared/models/user-models/user-favorite.model';
//import { NotificationUpdateRequest } from 'src/app/shared/models/requests-models/notification-update.model';
import { StorageService } from 'src/app/shared/services/storage.service';
import { pipe } from 'rxjs';


import { Resource } from 'src/app/shared/enums/resource.enum';
import { PageState } from 'src/app/shared/enums/page-state.enum';

import { RecipientGroup } from 'src/app/shared/models/recipient-models/recipient-group.model';
import { RecipientGroupUpdateRequest } from 'src/app/shared/models/requests-models/recipient-group-update.model';
import { RecipientGroupNewRequest } from 'src/app/shared/models/requests-models/recipient-group-new.model';
import { RecipientGroupEditComponent } from 'src/app/shared/components/recipient-group-edit/recipient-group-edit.component';
import { RecipientGroupHistoryComponent } from 'src/app/shared/components/recipient-group-history/recipient-group-history.component';
import { RecipientInvitation } from 'src/app/shared/models/recipient-models/recipient-invitation.model';
import { RecipientInvitesComponent } from 'src/app/shared/components/recipient-invites/recipient-invites.component';
import { RecipientEditComponent } from 'src/app/shared/components/recipient-edit/recipient-edit.component';
import { TemplateFlaggEvent } from 'src/app/shared/events/template-flagg.event';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-recipients',
  templateUrl: './recipients.component.html',
  styleUrls: ['./recipients.component.scss']
})
export class RecipientsComponent extends CleanOnDestroy implements OnInit {
  scrollDisalbed: boolean = false;
  // sitebar playlist item
  recipientItem: SitebarItemSub;

  areGroupsShown: boolean = false;

  recipients: RecipientBrief[];
  recipientGroups: RecipientGroup[];
  recipientInvitations: RecipientInvitation[]

  filterValue: string = '';
  transChooseWorkspace: string = '';
  transChooseWorkspaceView: string = '';
  transDeleteRg: string = '';
  transDeleteRgDesc: string = '';
  deleteInvitationString: string = '';
  deleteString: string = '';
  deleteHeaderString: string = '';
  cancelString: string = '';
  resendInvitationHeaderString: string = '';
  resendInvitationString: string = '';
  confirmString: string = '';
  deleteRecipientString: string = '';
  deleteRecipientDescriptionString: string = '';

  serviceEventListener = null;
  isRecipients = false;
  isRecipientsSearch = false;

  pageState = PageState.loading;

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private recipientsSrv: RecipientsService,
    private sharedSrv: SharedService,
    public storageSrv: StorageService,
    private router: Router
  ) {
    super();

    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {

    let recipientItem = this.utilSrv.getSitebarItem('streams');
    this.recipientItem = recipientItem.submenu[0];

    // Listening to API request errors
    this.serviceEventListener = this.sharedSrv.templateFlagg.subscribe({
      next: (event: TemplateFlaggEvent) => {
        this.isRecipients = true;
      }
    });

    // Translations
    this.tsTranslations();

    // // listen to the selected workspace changing
    // this.subscriber = this.storageSrv.selectedWorkspaceSubject
    //   .subscribe(selectedWorkspace => {
    //     if (selectedWorkspace) {
    //       this.getWorkspaceFavorites(selectedWorkspace.id);
    //     }
    //   });

    //this.getRecipientInvitations();
    //this.getRecipients();
    this.getRecipientsAndInvitations();
  }

  tsTranslations() {
    this.translate.get('RECIPIENTS.CHOOSEWORKSPACE').subscribe((string) => {
      this.transChooseWorkspace = string;
    });
    this.translate.get('RECIPIENTS.CHOOSEWORKSPACEVIEW').subscribe((string) => {
      this.transChooseWorkspaceView = string;
    });
    this.translate.get('RECIPIENTS.DELETERG').subscribe((string) => {
      this.transDeleteRg = string;
    });
    this.translate.get('RECIPIENTS.DELETERGDESC').subscribe((string) => {
      this.transDeleteRgDesc = string;
    });
    this.translate.get("RECIPIENTS.DELETEINVITATION").subscribe((string) => {
      this.deleteInvitationString = string;
    });
    this.translate.get("RECIPIENTS.DELETE").subscribe((string) => {
      this.deleteString = string;
    });
    this.translate.get("RECIPIENTS.DELETEINVITATIONHEADER").subscribe((string) => {
      this.deleteHeaderString = string;
    });
    this.translate.get("RECIPIENTS.CANCEL").subscribe((string) => {
      this.cancelString = string;
    });
    this.translate.get("RECIPIENTS.RESENDINVITATIONHEADER").subscribe((string) => {
      this.resendInvitationHeaderString = string;
    });
    this.translate.get("RECIPIENTS.RESENDINVITATION").subscribe((string) => {
      this.resendInvitationString = string;
    });
    this.translate.get("RECIPIENTS.CONFIRM").subscribe((string) => {
      this.confirmString = string;
    });
    this.translate.get("RECIPIENTGROUP.DELETERECIPIENT").subscribe((string) => {
      this.deleteRecipientString = string;
    });
    this.translate.get("RECIPIENTGROUP.DELETERECIPIENTDESC").subscribe((string) => {
      this.deleteRecipientDescriptionString = string;
    });
  }

  getRecipientsAndInvitations(){
      this.storageSrv.recipientInvitationsSubject.subscribe(async(recipientInvitations) => {
        if (recipientInvitations){
          this.recipientInvitations = recipientInvitations;
        }

        // now get recipients
        this.storageSrv.recipientsSubject
        .subscribe(async(recipients) => {
          if (recipients){
            this.recipients = recipients;
            // Show page skeleton
            this.pageState = PageState.withItems;
            if(recipients.length == 0 && recipientInvitations.length == 0) {
              if(this.canRead()) {
                this.pageState = PageState.noItems;
              } else {
                this.pageState = PageState.noReadPermission;
              }
            }
          }

        });
      });

  }

  getRecipientInvitations(){
    this.storageSrv.recipientInvitationsSubject.subscribe(async(recipientInvitations) => {
      if (recipientInvitations){
        this.recipientInvitations = recipientInvitations;
      }
    });
  }

  getRefreshedInvitations(){
    this.recipientsSrv.getRecipientInvitations(this.storageSrv.selectedWorkspace.id)
      .subscribe(recipientInvitations => {
      if (recipientInvitations){
        this.recipientInvitations = recipientInvitations;
        this.storageSrv.recipientInvitations = recipientInvitations;
      }
    });
  }


  getRecipients(){
    this.storageSrv.recipientsSubject.subscribe(async(recipients) => {
        if (recipients){
          this.recipients = recipients;
          // Show page skeleton
          this.pageState = PageState.withItems;
          if(recipients.length == 0) {
            if(this.canRead()) {
              this.pageState = PageState.noItems;
            } else {
              this.pageState = PageState.noReadPermission;
            }
          }
        }

      });
  }

  onSearchByWord(word){
    if (word) {
      word = word.toLowerCase();
      this.recipients = this.storageSrv.recipients.filter(recipient => {
        let shouldTaken = false;
        let email = recipient.streamUser.email.toLowerCase();

        if (recipient.streamUser.firstName != null){
          let fName = recipient.streamUser.firstName.toLowerCase();
          if (fName.indexOf(word) >= 0) {
            shouldTaken = true;
          }
        }

        if (recipient.streamUser.lastName != null){
          let lName = recipient.streamUser.lastName.toLowerCase();
          if (lName.indexOf(word) >= 0) {
            shouldTaken = true;
          }
        }

        if (email.indexOf(word) >= 0) {
          shouldTaken = true;
        }

        return shouldTaken;
      });

      this.recipientInvitations = this.storageSrv.recipientInvitations.filter(recipientInvite => {
        let shouldTaken = false;
        let email = recipientInvite.email.toLowerCase();

        if (email.indexOf(word) >= 0) {
          shouldTaken = true;
        }

        return shouldTaken;
      });

      this.isRecipientsSearch = true;
    } else {
      this.recipients = this.storageSrv.recipients;
      this.recipientInvitations = this.storageSrv.recipientInvitations;
      this.isRecipientsSearch = false;
    }
    this.filterValue = word;
  }


  shouldFilter(recipient){
    if (this.filterValue) {
        var word = this.filterValue.toLowerCase();
        let shouldTaken = false;
        let email = recipient.streamUser.email.toLowerCase();
        if (email.indexOf(word) >= 0) {
          shouldTaken = true;
        }

        if (recipient.streamUser.firstName && recipient.streamUser.firstName.toLowerCase().indexOf(word) >= 0) {
          shouldTaken = true;
        }

        if (recipient.streamUser.lastName && recipient.streamUser.lastName.toLowerCase().indexOf(word) >= 0) {
          shouldTaken = true;
        }

        return shouldTaken;
    } else {
      return true;
    }
  }

  onInviteRecipients(){
   if (
      this.storageSrv.selectedWorkspace
      && this.storageSrv.selectedWorkspace.id >= 0
    ) {
      this.subscriber = this.sharedSrv
        .openDialog(
          {
            workspaceId: this.storageSrv.selectedWorkspace.id
          },
          true,
          { width: '60%' },
          RecipientInvitesComponent
        ).subscribe(response => {
          if (response.continue){
            this.getRefreshedInvitations();
            this.pageState = PageState.withItems;
          }
        });
    } else {
      this.sharedSrv.errorDialog('Please choose your workspace before inviting Recipients.');
    }
  }

  onDeleteRecipientGroup(recipientGroup, index){
    this.subscriber = this.sharedSrv.openDialog<null>(
      {
        title: this.transDeleteRg,
        description: this.transDeleteRgDesc,
        template: 0,
        cancel: 'no',
        confirm: 'confirm',
      },
      true
    ).subscribe(response => {
      if (response && response.continue) {
        this.recipientsSrv.deleteRecipientGroup(recipientGroup.id).subscribe(isDeleted => {
          if (isDeleted) {
            this.recipientGroups.splice(index, 1);
            this.storageSrv.recipientGroups = this.recipientGroups;

            if (this.recipientGroups.length == 0){
              this.pageState = PageState.noItems;
            }
          }
        });
      }
    });
  }

  onImportRecipients(){
    if (
      this.storageSrv.selectedWorkspace
      && this.storageSrv.selectedWorkspace.id >= 0
    ) {
      this.subscriber = this.sharedSrv
        .openDialog(
          {
            workspaceId: this.storageSrv.selectedWorkspace.id
          },
          true,
          { width: '60%' },
          RecipientInvitesComponent
        ).subscribe(response => {
          if (response.continue){
            this.getRefreshedInvitations();
          }
        });
    } else {
      this.sharedSrv.errorDialog('Please choose your workspace before inviting Recipients.');
    }
  }

  moveToGroups(){
    this.router.navigate(['/recipients/groups'])
  }

  onUpdateRecipient(recipient: Recipient, i: number){
    if (recipient){
      this.sharedSrv.openDialog<Recipient>(
        {
          recipient: recipient
        },
        true,
        { width: '45%' },
        RecipientEditComponent
      ).subscribe(response => {
        if (response.continue){
          this.storageSrv.recipients[i] = response.outputData;
        }
      });
    } else {
      this.sharedSrv.errorDialog(this.transChooseWorkspace);
    }
  }

  onCreateGroup(){
      if (
      this.storageSrv.selectedWorkspace
      && this.storageSrv.selectedWorkspace.id >= 0
    ) {
      this.subscriber = this.sharedSrv
        .openDialog<RecipientGroupNewRequest>(
          {
            workspaceId: this.storageSrv.selectedWorkspace.id,
            isNew: true
          },
          true,
          { width: '60%' },
          RecipientGroupEditComponent
        ).subscribe(response => {
          if (response.continue){
            this.recipientsSrv.createRecipientGroup(response.outputData)
              .subscribe(newGroup => {
                this.recipientGroups.unshift(newGroup);
                this.storageSrv.recipientGroups = this.recipientGroups;
                this.pageState = PageState.withItems;
              });
          }
        });
    } else {
      this.sharedSrv.errorDialog(this.transChooseWorkspace);
    }
  }

  onSendDownloadLinks(recipient: Recipient, i: number) {
    this.recipientsSrv.sendDownloadLinks(recipient.id)
      .subscribe(response => {

      });
  }

  onDeleteRecipient(recipient: Recipient, i: number){
    if (recipient){
      this.sharedSrv.openDialog({
        title: this.deleteRecipientString,
        description: this.deleteRecipientDescriptionString,
        confirm: this.confirmString,
        cancel: this.cancelString,
        template: 0
      }, true, { width: '45%' }
      ).subscribe(response => {
        if (response.continue){
          this.recipientsSrv.deleteRecipient(recipient.id)
          .subscribe(response => {
            if (response){
              this.recipients.splice(i, 1);
              if (this.recipients.length == 0 && this.recipientInvitations.length == 0){
                this.pageState = PageState.noItems;
              }
            }
          });
        }
      });
    }
  }

  onResendInvitation(invitation: RecipientInvitation){
    if (invitation){
      this.recipientsSrv.resendRecipientInvite(invitation.id)
      .subscribe(response => {
        this.sharedSrv.openDialog({
          title: this.resendInvitationHeaderString,
          description: this.resendInvitationString,
          confirm: this.confirmString,
          cancel: this.cancelString,
          template: 0
        }, true, {
          width: '45%',
        })
      });
    }
  }

  onDeleteInvitation(invitation: RecipientInvitation, i){
    this.sharedSrv.openDialog({
          title: this.deleteHeaderString,
          description: this.deleteInvitationString,
          confirm: this.deleteString,
          cancel: this.cancelString,
          template: 0
        }, true, {
          width: '45%',
        }).subscribe(response => {
          if (response.continue){
            this.recipientsSrv.deleteRecipientInvitation(invitation.id)
            .subscribe(response => {
              this.recipientInvitations.splice(i, 1);
              //this.storageSrv.recipientInvitations.splice(i, 1);
              if (this.recipients.length == 0 && this.recipientInvitations.length == 0){
                this.pageState = PageState.noItems;
              }
            });
          }
        });
  }

  onViewHistory(recipientGroup){
    if (
      this.storageSrv.selectedWorkspace
      && this.storageSrv.selectedWorkspace.id >= 0
    ) {
      this.subscriber = this.sharedSrv
        .openDialog(
          {
            recipientGroup: recipientGroup
          },
          true,
          { width: '80%' },
          RecipientGroupHistoryComponent
        ).subscribe(response => {

        });
    } else {
      this.sharedSrv.errorDialog(this.transChooseWorkspaceView);
    }
  }


  isActiveRecipient(recipient){
    var inactiveAge = 7 * 24 * 60 * 60 * 1000;
    var currentTime = new Date().getTime();

    if ((currentTime - recipient.lastCheckinTimestamp) > inactiveAge){
      return false;
    } else {
      return true;
    }

  }


  canRead(){
    return this.storageSrv.getWorkspaceReadPermission(Resource.recipients);
  }

  canUpdate(){
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.recipients);
  }

  canWrite() {
    return this.storageSrv.getWorkspaceWritePermission(Resource.recipients);
  }

  canDelete() {
    return this.storageSrv.getWorkspaceDeletePermission(Resource.recipients);
  }

}
