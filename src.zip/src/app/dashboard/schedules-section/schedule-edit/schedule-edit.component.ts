import { Component, OnInit } from '@angular/core';
import { ScheduleEvent } from 'src/app/shared/models/event-scheduler-models/schedule-event';
import { DateAdapter, MAT_DATE_LOCALE, MAT_DATE_FORMATS } from '@angular/material/core';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { Moment } from 'moment';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { TranslateService } from '@ngx-translate/core';

import { SharedService } from 'src/app/shared/services/shared.service';
import { UtilService } from 'src/app/shared/services/util.service';
import { ReportsService } from 'src/app/shared/services/reports.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { SchedulesService } from 'src/app/shared/services/schedules.service';

import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { Schedule } from 'src/app/shared/models/schedule-models/schedule.model';
import { Playlist } from 'src/app/shared/models/playlist-models/playlist.model';
import { PlaylistV1 } from 'src/app/shared/models/playlist-models/playlist-v1.model';
import { ScheduledPlaylist } from 'src/app/shared/models/schedule-models/scheduled-playlist.model';
import { ScheduleWeekDay } from 'src/app/shared/models/event-scheduler-models/schedule-weekday.model';
import { ScheduledPlaylistCreateRequest } from 'src/app/shared/models/requests-models/scheduled-playlist-create.model';
import { Location } from 'src/app/shared/models/common-models/location.model';

import { ScheduleEventEditComponent } from 'src/app/shared/components/schedule-event-edit/schedule-event-edit.component';
import { AssignToDeviceComponent } from 'src/app/shared/components/assign-to-device/assign-to-device.component';

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};


@Component({
  selector: 'app-schedule-edit',
  templateUrl: './schedule-edit.component.html',
  styleUrls: ['./schedule-edit.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ]
})

export class ScheduleEditComponent extends CleanOnDestroy implements OnInit {

  selectedWorkspace: Workspace;

  // input proerty of schedule calendar
  weekDays: ScheduleWeekDay[] = [];

  // hour duration in miliseconds
  hourInMiliseconds: number = 60 * 60 * 1000;
  currentMonday = new Date(this.sharedSrv.getThisMonday());

  currentWeekEnd = new Date(
    new Date(this.currentMonday).getFullYear(),
    new Date(this.currentMonday).getMonth(),
    new Date(this.currentMonday).getDate() + 6
  );

  minDate = new Date();

  startDate = null;
  endDate = null;

  events: ScheduleEvent[] = [];

  scheduleForm: FormGroup;

  isScheduleNew: boolean = true;
  // don't send request in case of should wait until request response
  canSendRequest: boolean = true;
  currentSchedule: Schedule;
  currentScheduleIndex: number;

  assignedDevices: { id: number }[] = [];

  shouldUpdateAssignedDevices: { id: number }[] = null;

  updateScheduleTimer = null;

  currentLocale: any = '';

  transDeleteEvent: string = '';
  defaultNewScheduleName: string = '';

  constructor(
    public utilSrv: UtilService,
    private translate: TranslateService,
    private sharedSrv: SharedService,
    private storageSrv: StorageService,
    private scheduleSrv: SchedulesService,
    private reportsSrv: ReportsService,
    private router: Router,
    private fb: FormBuilder,
    private activRoute: ActivatedRoute
  ) {
    super();

    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {

    let scheduleId = this.activRoute.snapshot.params['scheduleId'];
    let deviceId = this.activRoute.snapshot.queryParams['deviceId'];
    let date = new Date();
    this.minDate.setDate(date.getDate() + 1);
    this.currentLocale = this.utilSrv.locale;

    this.tsTranslation();
    this.generateScheduleForm();

    // if (scheduleId >= 0) {
    //   this.getScheduleById(scheduleId);
    // }

    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe(workspace => {
        if (workspace) {
          this.selectedWorkspace = workspace;
          if (scheduleId >= 0) {
            this.getScheduleById(scheduleId);
          }
        }
      });

  }

  tsTranslation() {
    this.translate.get('SCHEDULEEDIT.DELETEEVENT').subscribe((string) => {
      this.transDeleteEvent = string;
    });
    this.translate.get('SCHEDULES.DEFAULTSCHEDULENAME').subscribe((string) => {
      this.defaultNewScheduleName = string;
    });
  }

  /**
   * generate schedule form
   *
   * @param null
   *
   * @return `null`
   */
  generateScheduleForm() {
    var startTime = null;
    if (this.startDate != null){
      startTime = this.startDate.getTime();
    }

    var endTime = null;
    if (this.endDate != null){
      endTime = this.endDate.getTime();
    }

    this.scheduleForm = this.fb.group({
      scheduleName: this.defaultNewScheduleName,
      startDate: startTime,
      endDate: endTime
    })
  }

  /**
   * get schedule by schedule id
   *
   * @param scheduleId is aschedule Id which should be received
   *
   * @return `null`
   */
  getScheduleById(scheduleId: number) {
    this.subscriber = this.storageSrv.schedulesSubject.subscribe(schedules => {
      if (schedules) {
        schedules.every((schedule, index) => {
          if (schedule.id === +scheduleId) {
            this.currentSchedule = schedule;
            this.currentScheduleIndex = index;
            this.isScheduleNew = false;
            this.scheduleForm.patchValue(this.currentSchedule);
            if (this.currentSchedule.startDate) {
              this.startDate = new Date(this.currentSchedule.startDate);
            } else {
              this.startDate = null;
            }
            if (this.currentSchedule.endDate) {
              this.endDate = new Date(this.currentSchedule.endDate);
            } else {
              this.endDate = null;
            }

            this.assignedDevices = this.currentSchedule.assignedDevices;
            if (this.currentSchedule.scheduledPlaylists.length > 0) {
              this.transformToTheEvents(this.currentSchedule.scheduledPlaylists);
            }

            return false;
          }
          return true;
        });
        if (!this.currentSchedule) {
          this.router.navigate(['../']);
        }
      }
    })
  }

  onSchedulePlaylist() {
    this.openScheduleEventEditDialog(null, true);
  }

  transformToTheEvents(scheduledPlaylists: ScheduledPlaylist[]) {
    let playlistsById: { [key: number]: PlaylistV1 } = {};
    let events: ScheduleEvent[] = [];

    // subscribe to the playlists
    this.subscriber = this.storageSrv.playlistsSubject
      .subscribe(playlists => {
        if (playlists) {

          // sort playlists by ids
          playlists.forEach(playlist => {
            playlistsById[playlist.id] = playlist;
          });

          scheduledPlaylists.forEach(scheduledPlaylist => {
            let color: string = '';
            let playlistName: string = '';
            let playlist = playlistsById[scheduledPlaylist.playlist.id];

            if (playlist) {
              color = playlist.color;
              playlistName = playlist.playlistName;
            }

            let event = new ScheduleEvent({
              playlistId: scheduledPlaylist.playlist.id,
              playlistName: playlistName,
              startDate: this.currentSchedule.startDate,
              endDate: this.currentSchedule.endDate,
              startSeconds: scheduledPlaylist.startSeconds,
              endSeconds: scheduledPlaylist.endSeconds,
              onMonday: scheduledPlaylist.onMonday,
              onTuesday: scheduledPlaylist.onTuesday,
              onWednesday: scheduledPlaylist.onWednesday,
              onThursday: scheduledPlaylist.onThursday,
              onFriday: scheduledPlaylist.onFriday,
              onSaturday: scheduledPlaylist.onSaturday,
              onSunday: scheduledPlaylist.onSunday,
              id: scheduledPlaylist.id,
              color: color
            });

            events.push(event);
          });

          this.events = events;
        }
      });

  }

  transFormToDate(weekday: number, seconds: number) {
    let hours = Math.floor(seconds / 3600);
    let minutes = Math.floor((seconds - (hours * 3600)) / 60);
    return new Date(
      this.currentMonday.getFullYear(),
      this.currentMonday.getMonth(),
      this.currentMonday.getDate() + weekday,
      hours,
      minutes,
      0
    );
  }

  /**
   * calls from template
   * output event of event-scheduler
   *
   * @param event with type `ScheduleEvent`
   *
   * @return `null`
   */
  onEndDrawEvent(event: ScheduleEvent) {
    this.openScheduleEventEditDialog(event, false);
  }

  /**
   * open dialog for current event
   *
   * @param null
   *
   * @return `number`
   * monday date in miliseconds
   */
  openScheduleEventEditDialog(
    event: ScheduleEvent,
    isNew: boolean,
    existedEventData?: {
      eventIndex: number,
      eventPreviousState: ScheduleEvent
    }
  ) {

    this.subscriber = this.sharedSrv.openDialog<any>(
      {
        scheduleData: event,
        isNew: isNew,
      },
      true,
      { width: '40%' },
      ScheduleEventEditComponent
    ).subscribe(response => {
      if (response.continue) {

        let data = response.outputData;

        if (existedEventData) {
          this.events.splice(existedEventData.eventIndex, 1);
        }

        let scheduleEvent = new ScheduleEvent({
          startDate: this.currentSchedule.startDate,
          endDate: this.currentSchedule.endDate,
          startSeconds: data.startSeconds,
          endSeconds: data.endSeconds,
          onMonday: data.onMonday,
          onTuesday: data.onTuesday,
          onWednesday: data.onWednesday,
          onThursday: data.onThursday,
          onFriday: data.onFriday,
          onSaturday: data.onSaturday,
          onSunday: data.onSunday,
          playlistName: data.playlistName,
          playlistId: data.playlistId,
          color: data.color
        });

        this.addEventToTheList(scheduleEvent);
        this.onSaveSchedule();
      } else {
        if (existedEventData) {
          this.events[existedEventData.eventIndex] = existedEventData.eventPreviousState;
          this.events = this.events.slice();
        }
      }
    });
  }

  /**
   * calls from template
   * output event of event-scheduler
   *
   * @param event with type `ScheduleEvent`
   * @return `null`
   */
  onUpdateEvent(event: {
    eventPreviousState: ScheduleEvent,
    eventIndex: number,
    event: ScheduleEvent
  }) {
    this.openScheduleEventEditDialog(event.event, false, event);
  }

  /**
   * calls from template
   * helper function for disable dates on the calendar which is less than endDate
   *
   * @param moment with type `Moment`
   * @return `null`
   */
  startDateFilter = (moment: Moment) => {
    if (this.endDate) {
      return moment.toDate().getTime() < this.endDate.getTime();
    }
    return true;
  }

  /**
   * calls from template
   * helper function for disable dates on the calendar
   * which is more than startDate
   *
   * @param moment with type `Moment`
   * @return `null`
   */
  endDateFilter = (moment: Moment) => {
    if (this.startDate) {
      return moment.toDate().getTime() > this.startDate.getTime();
    }
    return true;
  }

  /**
   * calls from template
   * when user clicked on the play24/7 button
   *
   * select all week as one schedule event
   * and open dialog for choose playlistId
   *
   * @param null
   * @return `null`
   */
  onScheduleWeekly() {
    this.startDate = null;
    this.endDate = null;
    this.scheduleForm.get('startDate').patchValue(this.startDate);
    this.scheduleForm.get('endDate').patchValue(this.endDate);
    //this.openScheduleEventEditDialog(event, true);
    this.updateSchedule();

  }

  /**
   * calls from template
   * set selected date to the property depends on property
   *
   * @param event is a output event Object of mat datepicker
   * @param property is a helper argument for a
   * detect which property should be change
   *
   * @return `null`
   */
  onChangeDate(
    event: MatDatepickerInputEvent<Moment>,
    property: 'start' | 'end'
  ) {
    let selectedDate: number = null;
    if (event.value) {
      try {
        let date = event.value.toDate();
        selectedDate = date.getTime();
      } catch (e) { }
    }

    if (property === 'start') {
      this.startDate = selectedDate ? new Date(selectedDate) : null;
      this.scheduleForm.get('startDate').patchValue(selectedDate);
    } else {
      this.endDate = selectedDate ? new Date(selectedDate) : null;
      this.scheduleForm.get('endDate').patchValue(selectedDate);
    }
    this.onSaveSchedule();
  }

  /**
   * check all cases overlaping before put event into list
   *
   * @param scheduleEvent is current event which should be put into evelts list
   * @return `null`
   */
  addEventToTheList(scheduleEvent: ScheduleEvent) {
    let newEventsList = [];
    let shouldAddPlaylist = true;
    let isPlaylistExists = false;

    for (let i = 0; i < this.events.length; i++) {

      let event = this.events[i];

      if (event && scheduleEvent && event.playlistId === scheduleEvent.playlistId) {
        scheduleEvent.color = event.color;
        isPlaylistExists = true;
      }
    }

    if (!isPlaylistExists) {
      scheduleEvent = new ScheduleEvent(scheduleEvent);
    }

    if (shouldAddPlaylist) {
      this.events.push(scheduleEvent);
      this.events = this.events.concat(newEventsList);
    }

    this.events = this.events.slice();

  }

  /**
   * calls from template output event of event-scheduler
   * event triggers when the user want to delete created event
   * delete event in case of user confirmation
   * @param event is object of output event
   * @return `null`
   */
  onShouldDeleteEvent(event: { event: ScheduleEvent, eventIndex: number }) {
    this.sharedSrv.openDialog({
      title: this.transDeleteEvent,
      description:
        `You are about to delete ${event.event.playlistName}. Do you want to confirm?`,
      template: 0,
      cancel: 'no',
      confirm: 'Confirm'
    }, true).subscribe(response => {
      if (response.continue) {
        this.events.splice(event.eventIndex, 1);
        this.events = this.events.slice();
        this.onSaveSchedule();
      }
    })
  }

  /**
   * calls from template output event of event-scheduler
   * event triggers when the user want to change created event
   * open dialog for a change event data
   * @param event is object of output event
   * @return `null`
   */
  onShouldChangeEvent(event: { event: ScheduleEvent, eventIndex: number }) {
    this.openScheduleEventEditDialog(event.event, false, {
      eventIndex: event.eventIndex,
      eventPreviousState: event.event
    })
  }

  /**
   * calls from template
   * redirect user to the schedule page
   * @param null
   * @return `null`
   */
  onGoToTheSchedule() {
    this.router.navigate(['/schedules']);
  }

  /**
   * calls from template
   * when user want to assign schedule to the device
   * @param null
   * @return `null`
   */
  onAssignSchedule() {
    this.sharedSrv.openDialog<{
      scheduleId: number,
      assignedDevices: { id: number }[]
    }>(
      {
        shouldSelectSchedule: false,
        schedule: this.scheduleForm.getRawValue(),
        assignedDevices: this.assignedDevices
      },
      true,
      null,
      AssignToDeviceComponent
    ).subscribe(response => {
      if (response.continue) {
        this.shouldUpdateAssignedDevices = response.outputData.assignedDevices.slice();
        this.assignedDevices = response.outputData.assignedDevices;
        this.onSaveSchedule();
      }
    });

  }

  /**
   * calls from template
   * when user want to save schedule changes
   * @param null
   * @return `null`
   */
  onSaveSchedule() {
    if (this.scheduleForm.valid && this.canSendRequest) {
      this.canSendRequest = false;
      let workspace = this.storageSrv.selectedWorkspace;
      if (workspace && workspace.id > 0 && this.isScheduleNew) {
        this.addSchedule(workspace.id);
      } else {
        this.updateSchedule();
        this.createScheduledPlaylists(this.currentSchedule.id);
      }
    }
  }

  /**
   * create new schedule with user filled info
   * @param workspaceId is a current selected workspace id
   * @return `null`
   */
  addSchedule(workspaceId: number) {

    let scheduleInfo = this.scheduleForm.getRawValue();
    if (!scheduleInfo.scheduleName) {
      scheduleInfo.scheduleName = this.defaultNewScheduleName;
    }
    scheduleInfo.workspaceId = workspaceId;
    this.scheduleSrv.createWorkspaceSchedule(scheduleInfo)
      .subscribe(schedule => {
        if (schedule && schedule.id) {
          this.currentScheduleIndex = 0;
          this.currentSchedule = schedule;
          this.isScheduleNew = false;

          this.storageSrv.schedules.unshift(schedule);

          this.createScheduledPlaylists(schedule.id);
          this.assignScheduleInCaseOfNeccessary();
        }
        this.canSendRequest = true;
      });
  }

  /*
  * Updating schedule
  */
  onChangeScheduleName() {
    let scheduleInfo = this.scheduleForm.getRawValue();
    if (this.updateScheduleTimer) {
      clearInterval(this.updateScheduleTimer);
      this.updateScheduleTimer = null;
    }
    this.updateScheduleTimer = setTimeout(() => {
      this.currentSchedule.scheduleName = scheduleInfo.scheduleName ? scheduleInfo.scheduleName : this.defaultNewScheduleName;
      this.scheduleSrv.updateSchedule(this.currentSchedule, this.currentSchedule.id).subscribe(response => {

      });
    }, 300);

  }

  onEnterForm (event) {
    event.preventDefault();
    this.onSaveSchedule();
  }

  /**
   * update schedule with user filled info
   *
   * @param workspaceId is a current selected workspace id
   *
   * @return `null`
   */
  updateSchedule() {
    let scheduleInfo = this.scheduleForm.getRawValue();
    if (!scheduleInfo.scheduleName) {
      scheduleInfo.scheduleName = this.defaultNewScheduleName;
    }
    this.scheduleSrv.updateSchedule(scheduleInfo, this.currentSchedule.id)
      .subscribe(schedule => {
        if (schedule) {
          this.transformToTheEvents(schedule.scheduledPlaylists);
          this.currentSchedule = schedule;
          this.storageSrv.schedules[this.currentScheduleIndex] = this.currentSchedule;
          this.assignScheduleInCaseOfNeccessary();
        }
        this.canSendRequest = true;
      })
  }

  /**
   * send request to the server
   * for update assigned schedule
   * in case of neccessary (if user updates the assigned info)
   *
   * @param null
   *
   * @return `null`
   */
  assignScheduleInCaseOfNeccessary() {
    if (this.shouldUpdateAssignedDevices) {
      this.scheduleSrv.assignScheduleToTheDevice(
        { devices: this.assignedDevices },
        this.currentSchedule.id
      ).subscribe(assignedDevices => {
        if (assignedDevices) {
          this.assignedDevices = assignedDevices;
          let deviceLocations: Location[] = [];
          this.assignedDevices.forEach(device => {
            deviceLocations.push({
              id: device.id,
              location: ''
            });
          });
          this.storageSrv.schedules[this.currentScheduleIndex].assignedDevices = deviceLocations;
          this.shouldUpdateAssignedDevices = null;
          //Migrating to v3
          //this.storageSrv.getDevices(this.storageSrv.selectedWorkspace.id);
        }
      });
    }
  }

  /**
   * create / update schedule scheduled playlists
   *
   * @param scheduleId is a schedule id which playlists should be updated
   *
   * @return `null`
   */
  createScheduledPlaylists(scheduleId: number) {
    let scheduledPlaylists = this.transformScheduledPlaylistsForRequest();
    this.scheduleSrv.createScheduledPlaylists({ playlists: scheduledPlaylists }, scheduleId)
      .subscribe(scheduledPlaylists => {
        if (scheduledPlaylists) {
          this.transformToTheEvents(scheduledPlaylists);
          this.storageSrv.schedules[this.currentScheduleIndex].scheduledPlaylists = scheduledPlaylists;
          this.storageSrv.getTimelineReport(this.selectedWorkspace.id);
        }
      });
  }



  /**
   * transform and to prepare created events for request
   * create scheduled playlists
   *
   * @param null
   *
   * @return `ScheduledPlaylistCreateRequest[]`
   */
  transformScheduledPlaylistsForRequest(): ScheduledPlaylistCreateRequest[] {
    let transformedScheduledPlaylists: ScheduledPlaylistCreateRequest[] = [];
    this.events.forEach(event => {
      transformedScheduledPlaylists.push({
        playlistId: event.playlistId,
        startSeconds: event.startSeconds,
        endSeconds: event.endSeconds,
        onMonday: event.onMonday,
        onTuesday: event.onTuesday,
        onWednesday: event.onWednesday,
        onThursday: event.onThursday,
        onFriday: event.onFriday,
        onSaturday: event.onSaturday,
        onSunday: event.onSunday
      });
    });
    return transformedScheduledPlaylists;
  }


  /**
   * get seconds from date hours and minutes
   *
   * @param value is a date in miliseconds
   *
   * @return `number`
   */
  transformHoursAndMinutesToSeconds(value: number) {
    let date = new Date(value);
    return (date.getHours() * 60 * 60) + (date.getMinutes() * 60);
  }

  canUpdate(){
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.schedules);
  }

  canRead(){
    return this.storageSrv.getWorkspaceReadPermission(Resource.schedules);
  }

  canWrite() {
    return this.storageSrv.getWorkspaceWritePermission(Resource.schedules);
  }

  canDelete() {
    return this.storageSrv.getWorkspaceDeletePermission(Resource.schedules);
  }

}
