import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SchedulesSectionComponent } from './schedules-section.component';
import { SchedulesComponent } from './schedules/schedules.component';
import { ScheduleEditComponent } from './schedule-edit/schedule-edit.component';

const routes: Routes = [
    {
        path: '', component: SchedulesSectionComponent, children: [
            {
                path: '',
                component: SchedulesComponent
            },
            {
                path: 'new',
                component: ScheduleEditComponent
            },
            {
                path: 'edit/:scheduleId',
                component: ScheduleEditComponent
            },

        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class SchedulesSectionRoutingModule { }
