import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-schedules-section',
  templateUrl: './schedules-section.component.html',
  styleUrls: ['./schedules-section.component.scss']
})
export class SchedulesSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
