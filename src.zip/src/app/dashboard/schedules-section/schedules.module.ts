import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SchedulesSectionRoutingModule } from './schedules-section-routing.module';

import { SchedulesSectionComponent } from './schedules-section.component';
import { SchedulesComponent } from './schedules/schedules.component';
import { ScheduleEditComponent } from './schedule-edit/schedule-edit.component';
import { SharedModule } from 'src/app/shared/shared.module';

@NgModule({
  declarations: [
    SchedulesSectionComponent,
    SchedulesComponent,
    ScheduleEditComponent
  ],
  imports: [
    CommonModule,
    SchedulesSectionRoutingModule,
    SharedModule
  ]
})
export class SchedulesModule { }
