import { Component, OnInit, Inject } from '@angular/core';
import { SitebarItem } from 'src/app/shared/models/common-models/sitebar-item.model';
import { Router } from '@angular/router';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { Moment } from 'moment';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { TranslateService } from '@ngx-translate/core';

import { Resource } from 'src/app/shared/enums/resource.enum';
import { PageState } from 'src/app/shared/enums/page-state.enum';
import { TemplateFlaggEvent } from 'src/app/shared/events/template-flagg.event';

import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { Schedule } from 'src/app/shared/models/schedule-models/schedule.model';
import { Device } from 'src/app/shared/models/device-models/device.model';
import { Reorder } from 'src/app/shared/models/common-models/reorder.model';
import { Playlist } from 'src/app/shared/models/playlist-models/playlist.model';
import { PlaylistV1 } from 'src/app/shared/models/playlist-models/playlist-v1.model';
import { TimelineOptions } from 'src/app/shared/models/timeline-models/timeline-options.model';
import { TimelineEvent } from 'src/app/shared/models/timeline-models/timeline-event';
import { ScheduleEvent } from 'src/app/shared/models/event-scheduler-models/schedule-event';

import { DeviceV3 } from 'src/app/shared/models/device-models/device-v3.model';
import { Pagination } from 'src/app/shared/models/common-models/pagination.model';

import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { SchedulesService } from 'src/app/shared/services/schedules.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { ReportsService } from 'src/app/shared/services/reports.service';
import { DevicesService } from 'src/app/shared/services/devices.service';

import { AssignToDeviceComponent } from 'src/app/shared/components/assign-to-device/assign-to-device.component';
import { ScheduleNewComponent } from 'src/app/shared/components/schedule-new/schedule-new.component';
import { ScheduleCreateUpdateRequest } from 'src/app/shared/models/requests-models/schedule-create-update.model';
import { NewSchedulesComponent } from 'src/app/shared/components/new-schedules/new-schedules.component';

@Component({
  selector: 'app-schedules',
  templateUrl: './schedules.component.html',
  styleUrls: ['./schedules.component.scss']
})
export class SchedulesComponent extends CleanOnDestroy implements OnInit {

  currentLocale: any = '';
  selectedWorkspace: Workspace;
  currentWorkspace: Workspace;

  timelineOptions: TimelineOptions = {
    directionsName: '',
    dayFormat1: 'EEEE',
    dayFormat2: 'MMM dd',
    directionDescription: '',
    showPlayers: true
  }
  scheduleItem: SitebarItem;

  defaultScheduleImage: string = '';
  schedules: Schedule[];
  startDate = new Date(this.sharedSrv.getThisMonday());
  hourInMiliseconds: number = 60 * 60 * 1000;

  endDate = new Date(
    new Date(this.startDate).getFullYear(),
    new Date(this.startDate).getMonth(),
    new Date(this.startDate).getDate() + 6
  );

  // timelineItems: TimelineEvent[] = [];
  timelineItems: any[] = [];

  scheduleByIds: { [key: number]: Schedule };
  devices: DeviceV3[];
  devicesPaginate: Pagination = { count: 0, limit: 0, next: '', offset: 0 };
  storedSchedules: Schedule[];
  devicesByIds: { [key: number]: DeviceV3 };
  filterValue: string = '';

  serviceEventListener = null;
  isSchedules = false;
  isSchedulesSearch = false;
  transDeleteSchedule: string = '';
  transDeleteScheduleDesc: string = '';
  confirmString: string = '';
  cancelString: string = '';
  playerString: string = '';

  playlistsByIds: {
      [key: number]: PlaylistV1
    } = {}

  pageState = PageState.loading;

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private schedulesSrv: SchedulesService,
    private storageSrv: StorageService,
    private router: Router,
    private reportsSrv: ReportsService,
    private sharedSrv: SharedService,
    private devicesSrv: DevicesService
  ) {
    super();

    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {

    // Listening to API request errors
    this.serviceEventListener = this.sharedSrv.templateFlagg.subscribe({
      next: (event: TemplateFlaggEvent) => {
        this.isSchedules = true;
      }
    });
    this.currentLocale = this.utilSrv.locale;
    this.timelineOptions.directionsName = "";
    this.timelineOptions.directionDescription = "";
    this.scheduleItem = this.utilSrv.getSitebarItem('schedules');
    this.defaultScheduleImage = this.utilSrv.appImages.websiteLargeLogo;

    this.tsTranslation();

    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe(workspace => {
        if (workspace) {
          this.selectedWorkspace = workspace;
          this.currentWorkspace = workspace;
          this.getTimelineReport();
          this.getSchedules();
        }
      });

  }

  tsTranslation() {
    this.translate.get('SCHEDULES.DELETESCHEDULE').subscribe((string) => {
      this.transDeleteSchedule = string;
    });
    this.translate.get('SCHEDULES.DELETESCHEDULEDESC').subscribe((string) => {
      this.transDeleteScheduleDesc = string;
    });
    this.translate.get('CONFIRMBUTTON').subscribe((string) => {
      this.confirmString = string;
    });
    this.translate.get('CANCELBUTTON').subscribe((string) => {
      this.cancelString = string;
    });

    this.translate.get("DEFAULTTERMS.PLAYER").subscribe((string) => {
      this.playerString = string;
    });
  }

  checkPageState() {
    if(this.schedules.length == 0) {
      if(this.canRead()) {
        this.pageState = PageState.noItems;
      } else {
        this.pageState = PageState.noReadPermission;
      }
    }
  }

  getSchedules() {
    this.subscriber = this.storageSrv.schedulesSubject.subscribe(async(schedules) => {
      if (schedules) {

        this.storedSchedules = schedules.slice();
        this.schedules = schedules.slice();
        this.sortByPositionNumber();
        this.scheduleByIds = {};
        this.schedules.forEach(schedule => {
          this.scheduleByIds[schedule.id] = schedule;
        });
        this.sortAssignedSchedulesByDevices();

        // Show page skeleton
        this.pageState = PageState.withItems;
        this.checkPageState();

      }
    });
  }

  getTimelineReport() {
    this.subscriber = this.storageSrv.timelineReportSubject.subscribe( timelineReport => {
      if(timelineReport) {
        this.timelineOptions.directionDescription = `Players`;
        this.timelineItems = timelineReport;
      }
    });
  }

  /**
   * calls from template
   * helper function for disable dates which is not monday
   *
   * @param moment with type `Moment`
   *
   * @return `null`
   */
  startDateFilter = (moment: Moment) => {
    if(moment != null) {
      return moment.toDate().getDay() === 1;
    }
  }

  /**
   * calls from template
   * filter schedules by schedule name
   *
   * @param name is a user typed name
   *
   * @return `null`
   */
  onSearchByScheduleName(name: string) {
    name = name.toLowerCase();
    this.filterValue = name;
    this.isSchedules = true;
    this.schedules = this.storedSchedules.filter(schedule => {
      let scheduleName = schedule.scheduleName.toLowerCase();
      return scheduleName.indexOf(name) >= 0;
    });
    if(name) {
      this.isSchedulesSearch = true;
    } else {
      this.isSchedulesSearch = false;
    }
  }

  /**
   * calls from template
   *
   * change timeline dates
   *
   * @param event is a output object with type `MatDatepickerInputEvent<Moment>`
   *
   * @return `null`
   */
  onChangeDate(event: MatDatepickerInputEvent<Moment>) {
    this.startDate = event.value.toDate();
    this.endDate = new Date(
      this.startDate.getFullYear(),
      this.startDate.getMonth(),
      this.startDate.getDate() + 6,
      0, 0, 0
    );
    this.sortAssignedSchedulesByDevices();
  }

  /**
   * sort schedules by scheudle positionNumbers
   *
   * @param null
   *
   * @return `null`
   */
  sortByPositionNumber() {
    this.schedules.sort((schedule1, schedule2) => {
      return schedule1.positionNumber - schedule2.positionNumber;
    });
  }

  /**
   * separate  devices which have assigned schedules from list
   * and get assigned schedules for every devices
   * @param null
   * @return `null`
   */
  async sortAssignedSchedulesByDevices() {
    // this.subscriber = this.storageSrv.devicesSubject.subscribe(devices => {
    //   if (devices) {
    //     this.devices = this.storageSrv.devices;
    //     let playlistSubject = this.storageSrv.playlistsSubject
    //       .subscribe(playlists => {
    //         if (playlists) {
    //           let playlistsByIds = {};
    //           playlists.forEach(playlist => {
    //             this.playlistsByIds[playlist.id] = playlist;
    //           });
    //           //this.prepareTimelineItems();
    //         }
    //         // if (playlistSubject) {
    //         //   playlistSubject.unsubscribe()
    //         // }
    //       });
    //   }
    // })
    this.subscriber = this.devicesSrv.getDevices(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    )
      .subscribe( response => {
        if(response) {
          this.devices = response.message;
          this.devicesPaginate = response.pagination;

          let playlistSubject = this.storageSrv.playlistsSubject
          .subscribe(playlists => {
            if (playlists) {
              let playlistsByIds = {};
              playlists.forEach(playlist => {
                this.playlistsByIds[playlist.id] = playlist;
              });
            }
          });
        }
      });
  }

  /**
   * preparing data for generate TimelineItems
   * @param null
   * @return `null`
   */
  // prepareTimelineItems() {
  //   // organize schedules into ids to make easy to access/find
  //   let scheduleByIds: {
  //     [key: number]: Schedule
  //   } = {}


  //   this.storageSrv.schedules.forEach(schedule => {
  //     scheduleByIds[schedule.id] = schedule;
  //   });

  //   this.scheduleByIds = scheduleByIds;

  //   // map for scheduled events
  //   let scheduledEvents = {};
  //   let assignedDevices = [];

  //   this.devices.forEach(device => {
  //     let assignedDevice = {
  //       device: device,
  //       events: []
  //     }

  //     // populate schedule events
  //     device.assignedSchedules.forEach(schedule => {
  //       if (!scheduledEvents.hasOwnProperty(schedule.id)){
  //         let foundSchedule = this.scheduleByIds[schedule.id];
  //         var events = [];
  //         if (foundSchedule) {
  //           events = this.generateTimelineEvents(foundSchedule, device.id, this.startDate, this.endDate);
  //         }
  //         scheduledEvents[schedule.id] = events;
  //       }
  //       assignedDevice["events"] = assignedDevice["events"].concat(scheduledEvents[schedule.id]);
  //     });

  //     // add schedule events for each device
  //     assignedDevices.push(assignedDevice);
  //   });

  //   this.timelineOptions.directionDescription = `${this.playerString}`;
  //   this.timelineItems = assignedDevices;
  // }

  // generateTimelineEvents(schedule, deviceId, startDate, endDate){
  //   var rowHeight = 300;
  //   var minEventHeight = 30;
  //   var maxSeconds = 24 * 60 * 60;

  //   var events: TimelineEvent[] = [];

  //   // if null, return no events
  //   if (!schedule){
  //     return events;
  //   }

  //   // check if schedule is within start date and end date, if not return no events
  //   var canPlay = true;
  //   if (schedule.startDate != null && schedule.startDate < startDate){
  //     canPlay = false;
  //   }
  //   if (schedule.endDate != null && schedule.endDate > endDate){
  //     canPlay = false;
  //   }

  //   if (!canPlay){
  //     return events;
  //   }

  //   // make events for each scheduled playlist
  //   schedule.scheduledPlaylists.forEach(scheduledPlaylist => {
  //     var left = 0;
  //     var color = this.playlistsByIds[scheduledPlaylist.playlist.id]["color"];
  //     var name = this.playlistsByIds[scheduledPlaylist.playlist.id]["playlistName"];
  //     var route = "/schedules/edit/"+schedule.id;

  //     // calculate top and bottom
  //     var top = (scheduledPlaylist.startSeconds / maxSeconds) * rowHeight;
  //     var height = ((scheduledPlaylist.endSeconds / maxSeconds) * rowHeight) - top;
  //     if (height < minEventHeight){
  //       height = minEventHeight;
  //     }

  //     // calculate left positions based on which days are enabled
  //     if (scheduledPlaylist.onMonday){
  //       left = 0;
  //       events.push({left:left,top:top, height:height, color: color, name:name, route: route})
  //     }

  //     if (scheduledPlaylist.onTuesday){
  //       left = 1;
  //       events.push({left:left,top:top, height:height, color: color, name:name, route: route})
  //     }

  //     if (scheduledPlaylist.onWednesday){
  //       left = 2;
  //       events.push({left:left,top:top, height:height, color: color, name:name, route: route})
  //     }

  //     if (scheduledPlaylist.onThursday){
  //       left = 3;
  //       events.push({left:left,top:top, height:height, color: color, name:name, route: route})
  //     }

  //     if (scheduledPlaylist.onFriday){
  //       left = 4;
  //       events.push({left:left,top:top, height:height, color: color, name:name, route: route})
  //     }

  //     if (scheduledPlaylist.onSaturday){
  //       left = 5;
  //       events.push({left:left,top:top, height:height, color: color, name:name, route: route})
  //     }

  //     if (scheduledPlaylist.onSunday){
  //       left = 6;
  //       events.push({left:left,top:top, height:height, color: color, name:name, route: route})
  //     }

  //   });
  //   return events;
  // }

  /**
   * calls from template
   * when user want to create schedule
   *
   * navigate user to the /schedules/new
   *
   * @param null
   *
   * @return `null`
   */
  onCreateSchedule() {
    this.sharedSrv.openDialog<Schedule>(
      { workspaceId: this.storageSrv.selectedWorkspace.id },
      true,
      null,
      NewSchedulesComponent
    ).subscribe(response => {
      if (response.outputData) {
        let schedule: Schedule = response.outputData;
        this.schedules.push(schedule);
        this.storageSrv.schedules.push(schedule);
        this.storageSrv.getTimelineReport(this.selectedWorkspace.id);
        this.router.navigate(['/schedules/edit', schedule.id]);
      }
    });
  }


  /**
   * calls from template
   * when user want to assign schedule to the device
   *
   * @param null
   *
   * @return `null`
   */
  onAssignSchedule() {
    if (this.schedules && this.schedules.length > 0) {
      this.sharedSrv.openDialog<{
        scheduleId: number,
        assignedDevices: { id: number }[]
      }>(
        {
          shouldSelectSchedule: true,
          schedule: null,
        },
        true,
        null,
        AssignToDeviceComponent
      ).subscribe(response => {
        if (response.continue) {

          let data = response.outputData;
          if (data.scheduleId >= 0) {

            this.assignDevices(
              data.assignedDevices,
              data.scheduleId
            )
          }
          this.storageSrv.getTimelineReport(this.selectedWorkspace.id);
        }
      });
    }

  }

  /**
   * calls from template
   * when user want to assign device to the schedule
   *
   * @param schedule is a schedule which should assign to the devices
   *
   * @return `null`
   */
  onEditScheduleAssignedDevices(schedule: Schedule) {
    if (schedule) {
      this.sharedSrv.openDialog<{
        scheduleId: number,
        assignedDevices: { id: number }[]
      }>(
        {
          shouldSelectSchedule: false,
          schedule: schedule,
          assignedDevices: schedule.assignedDevices
        },
        true,
        null,
        AssignToDeviceComponent
      ).subscribe(response => {
        if (response.continue) {
          let data = response.outputData;
          this.assignDevices(
            data.assignedDevices,
            schedule.id
          )
          this.storageSrv.getTimelineReport(this.selectedWorkspace.id);
        }
      });
    }
  }

  /**
   * send request to the server for update schedule assigned devices
   *
   * @param assignedDevices is a object of assigned devices
   * @param scheduleId is a schedule Id which should be update
   *
   * @return `null`
   */
  assignDevices(assignedDevices: { id: number }[], scheduleId: number) {
    this.schedulesSrv.assignScheduleToTheDevice(
      { devices: assignedDevices },
      scheduleId
    ).subscribe(assignedDevices => {
      if (assignedDevices) {
        this.schedules.every(schedule => {
          if (schedule.id === scheduleId) {
            schedule.assignedDevices = assignedDevices;
            return false;
          }
          return true;
        });

        this.storageSrv.schedules.every(schedule => {
          if (schedule.id === scheduleId) {
            schedule.assignedDevices = assignedDevices;
            return false;
          }
          return true;
        });
        //Migrating to v3
        //this.storageSrv.getDevices(this.storageSrv.selectedWorkspace.id);
        this.storageSrv.getTimelineReport(this.selectedWorkspace.id);
      }
    });
  }

  /**
   * calls from template for each scheudle item
   * helper function for ngFor optimization
   *
   *
   * @param index is a index of each item
   * @param item is a each item
   *
   * @return `string`
   */
  onTrackById(index: number, item: { id: number }) {
    return item.id;
  }


  /**
   * calls from template
   * when user drag and drop slide Item
   *
   * send request to the server for a save new reordered list
   *
   * @param event is a angular materia drop output event
   *
   * @return `string`
   */
  onReorderSchedules(event: CdkDragDrop<Schedule[]>) {
    moveItemInArray(this.schedules, event.previousIndex, event.currentIndex);
    let schedulesReorderInfo: Reorder[] = [];
    this.schedules.forEach((schedule, index) => {
      schedule.positionNumber = index;
      schedulesReorderInfo.push({
        id: schedule.id,
        positionNumber: schedule.positionNumber
      })
    });
    this.schedulesSrv.reorderSchedules({
      schedules: schedulesReorderInfo
    }).subscribe(response => {
      if (response) {

      }
    })
  }

  /**
   * calls from template
   * for every scheudle item
   *
   * return image for current schedule
   * if schedule have any playlists return
   * first image of enabled slide of first playlist
   *
   * @param schedule is a schedule Item for which should find image
   *
   * @return `string`
   */
  onGetScheduleImage(schedule: Schedule) {
    let image = '';
    if (this.playlistsByIds) {
      schedule.scheduledPlaylists.every(scheduledPlaylist => {
        let playlist = this.playlistsByIds[scheduledPlaylist.playlist.id];
        if (playlist) {
          playlist.slides.every(slide => {
            if (this.utilSrv.checkSlideActivity(slide)) {
              image =
                `${this.utilSrv.env.endPoint}/api/v1/slides/${slide.id}/preview/`;
              return false;
            }
            return true;
          });
          if (image) {
            return false;
          }
        }
        return true;
      });
    }
    image = image ? image : this.defaultScheduleImage;
    return image;
  }

  /**
   * calls from template
   * when user want to edit schedule
   *
   * redirect user to the /schedule/edit/{`scheduleId`}
   *
   * @param scheduleId is a schedule id which user wnat edit
   *
   * @return `null`
   */
  onEditSchedule(scheduleId: number) {
    this.router.navigate(['/schedules/edit', scheduleId]);
  }

  /**
   * calls from template
   * when user want to delete scheudle
   *
   * after confirmation
   * send request to the server for a delete schedule
   *
   * @param schedule is a schedule whic h should be deleted
   * @param scheduleIndex is a schedule index from `schedules`
   *
   * @return `null`
   */
  onDeleteSchedule(schedule: Schedule, scheduleIndex: number) {
    this.sharedSrv.openDialog({
      title: this.transDeleteSchedule,
      description: this.transDeleteScheduleDesc,
      template: 0,
      cancel: this.cancelString,
      confirm: this.confirmString
    },
      true).subscribe(response => {
        if (response.continue) {
          this.schedulesSrv.deleteScheduleById(schedule.id)
            .subscribe(response => {
              if (response) {
                this.schedules.splice(scheduleIndex, 1);

                // have to find correct index of schedule to delete
                for (var i = 0; i < this.storedSchedules.length; i++){
                  if (this.storedSchedules[i].id == schedule.id){
                    this.storedSchedules.splice(i, 1);
                    break;
                  }
                }
                for (var i = 0; i < this.storageSrv.schedules.length; i++){
                  if (this.storageSrv.schedules[i].id == schedule.id){
                    this.storageSrv.schedules.splice(i, 1);
                    break;
                  }
                }

                if (this.storedSchedules.length == 0){
                  this.pageState = PageState.noItems;
                }

                this.storageSrv.getTimelineReport(this.selectedWorkspace.id);
              }
            })
        }
      });
  }

  canUpdate(){
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.schedules);
  }

  canRead(){
    return this.storageSrv.getWorkspaceReadPermission(Resource.schedules);
  }

  canWrite() {
    return this.storageSrv.getWorkspaceWritePermission(Resource.schedules);
  }

  canDelete() {
    return this.storageSrv.getWorkspaceDeletePermission(Resource.schedules);
  }



}
