import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-support-section',
  templateUrl: './support-section.component.html',
  styleUrls: ['./support-section.component.scss']
})
export class SupportSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
