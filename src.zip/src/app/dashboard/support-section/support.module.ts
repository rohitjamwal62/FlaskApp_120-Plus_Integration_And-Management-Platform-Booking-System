import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SupportSectionRoutingModule } from './support-section-routing.module';
import { SupportSectionComponent } from './support-section.component';
import { SupportComponent } from './support/support.component';
import { MaterialModule } from 'src/app/shared/material/material.module';
import { SharedModule } from 'src/app/shared/shared.module';

@NgModule({
  declarations: [
    SupportSectionComponent,
    SupportComponent
  ],
  imports: [
    CommonModule,
    MaterialModule,
    SupportSectionRoutingModule,
    SharedModule
  ]
})
export class SupportModule { }
