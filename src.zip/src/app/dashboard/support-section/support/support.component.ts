import { Component, OnInit, Renderer2, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { UserRequestsService } from 'src/app/shared/services/user-requests.service';
import { SupportService } from 'src/app/shared/services/support.service';

import { SitebarItem } from 'src/app/shared/models/common-models/sitebar-item.model';
import { UserRequest } from 'src/app/shared/models/user-models/user-request.model';
import { UserRequestCreateRequest } from 'src/app/shared/models/requests-models/user-request-create.model';

import { RequestNewComponent } from 'src/app/shared/components/request-new/request-new.component';

@Component({
  selector: 'app-support',
  templateUrl: './support.component.html',
  styleUrls: ['./support.component.scss']
})
export class SupportComponent extends CleanOnDestroy implements OnInit, AfterViewInit {

  supportItem: SitebarItem;
  userRequests: UserRequest[] = [];
  supportForm: FormGroup;

  @ViewChild('supportContainer', { static: true }) supportContainer: ElementRef;

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private sharedSrv: SharedService,
    private requestsSrv: UserRequestsService,
    private renderer: Renderer2,
    public storageSrv: StorageService,
    private fb: FormBuilder,
    private supportSrv: SupportService
  ) {
    super();

    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.supportItem = this.utilSrv.getSitebarItem('support');
    this.generateSupportForm();
  }

  ngAfterViewInit() {
    // set form html into template
    // it works only in this way
    // Not being used anymore.
    // let script1 = this.renderer.createElement('script');
    // script1.text = 'hbspt.forms.create({portalId: "135305", formId: "a5c5aded-d62f-4d1b-91e6-04796c7a00c6"});';
    // this.renderer.appendChild(
    //   this.supportContainer.nativeElement,
    //   script1
    // );
  }

  generateSupportForm() {
    this.supportForm = this.fb.group({
      subject: ['', [Validators.required, removeWhitespaceValidator]],
      content: ['', [Validators.required, removeWhitespaceValidator]]
    });
  }

  onSend() {
    if (this.supportForm.valid) {
      let formData = this.supportForm.getRawValue();
      this.supportSrv.createTicket(formData).subscribe(supportId => {
        if(supportId) {
          this.sharedSrv.openDialog({
              title: 'Success',
              description: `Thank you for contacting Support. Your Support ID is ${supportId}. Please keep this number for your records.`,
              template: 1,
              confirm: 'ok'
          }, true);
          this.supportForm.reset();
        }
      }, (err) => {
        this.sharedSrv.openDialog({
          title: 'Error',
          description: `Unable to submit your support request. Please contact support directly at support@rocketscreens.com`,
          template: 1,
          confirm: 'ok'
        }, true);
        //this.supportForm.reset();
      });
    }
  }
}
