import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  ChangeDetectorRef,
  Input,
  OnDestroy,
  Output,
  EventEmitter,
  OnChanges
} from '@angular/core';
import { Subscription } from 'src/app/shared/models/common-models/subscription.model';
import { StripeChangeEvent } from 'src/app/shared/models/common-models/stripe-change-event.model';
import { MatSelectChange } from '@angular/material/select';
import { SubscriptionsService } from 'src/app/shared/services/subscriptions.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Country } from 'src/app/shared/models/common-models/country.model';
import { LocalRequestsService } from 'src/app/shared/services/local-requests.service';
import { BillingInfo } from 'src/app/shared/models/common-models/billing-info.model';
import { SharedService } from 'src/app/shared/services/shared.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { WorkspacesService } from 'src/app/shared/services/workspaces.service';
import { BillingRequest } from 'src/app/shared/models/requests-models/billing-create-update.model';
import { Account } from 'src/app/shared/models/account-models/account.model';
import { DefaultDialogInputData } from 'src/app/shared/models/common-models/default-dialog-input-data.model';
import { BillEstimate } from 'src/app/shared/models/account-models/bill-estimate.model';
import { BillHistory } from 'src/app/shared/models/account-models/bill-history.model';
import { AccountUpdateFailedEvent } from 'src/app/shared/events/account-update-failed.event';
import { MatPaginatorModule } from '@angular/material/paginator';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { WorkspaceUpdateRequest } from 'src/app/shared/models/requests-models/workspace-update.model';
import { UtilService } from 'src/app/shared/services/util.service';
import { TranslateService } from '@ngx-translate/core';

// Utils
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

@Component({
  selector: 'details-tab',
  templateUrl: './details-tab.component.html',
  styleUrls: ['./details-tab.component.scss']
})
export class DetailsTabComponent implements OnInit, OnChanges {

  workspaceForm: FormGroup;
  @Input() workspace: Workspace;

  currentLocale: any = '';

  constructor(
    private translate: TranslateService,
    private cd: ChangeDetectorRef,
    private fb: FormBuilder,
    private subscriptionsSrv: SubscriptionsService,
    private sharedSrv: SharedService,
    private workspacesSrv: WorkspacesService,
    private storageSrv: StorageService,
    private localRequestsSrv: LocalRequestsService,
    public utilSrv: UtilService
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.currentLocale = this.utilSrv.locale;
    this.generateWorkspaceForm();
  }

  ngOnChanges() {
    if (this.workspace && this.workspaceForm){
      this.workspaceForm.patchValue(this.workspace);
    }
  }

    /**
   * generate `workspaceForm`
   *
   * @param null
   *
   * @return `null`
   */
  generateWorkspaceForm() {
    this.workspaceForm = this.fb.group({
      workspaceName: ['', [Validators.required, removeWhitespaceValidator]]
    })

    if (this.workspace){
      this.workspaceForm.patchValue(this.workspace);
    }
  }


  /**
   * update workspace info in case of validity
   *
   * @param null
   *
   * @return `null`
   */
  onUpdateWorkspaceInfo() {
    if (this.workspaceForm.valid) {
      let workspaceUpdatableInfo = this.workspaceForm.getRawValue() as WorkspaceUpdateRequest;

      this.workspacesSrv.updateWorkspaceById(workspaceUpdatableInfo,this.workspace.id).subscribe(updatedWorkspace => {

        this.workspace = updatedWorkspace;
        let accountWorkspaces = this.storageSrv.workspacesByAccountsId[this.workspace.account.id];

        accountWorkspaces.every((workspace, index) => {
          if (workspace.id === this.workspace.id) {
            accountWorkspaces[index] = this.workspace;
            return false;
          }
          return true;
        });

        this.storageSrv.selectedWorkspace.workspaceName = workspaceUpdatableInfo.workspaceName;

        this.confirmUpdateDialog();
      })
    }
  }

  confirmUpdateDialog() {
    this.sharedSrv.openDialog({
      title: 'Confirm',
      description: 'Workspace updated successfully!',
      template: 1,
      confirm: 'ok'
    }, true).subscribe( response => {
      
    });
  }

}
