import { Component, OnInit, ViewChild, ElementRef, ChangeDetectorRef, Input, OnDestroy, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { UtilService } from 'src/app/shared/services/util.service';
import { Subscription } from 'src/app/shared/models/common-models/subscription.model';
import { StripeChangeEvent } from 'src/app/shared/models/common-models/stripe-change-event.model';
import { MatSelectChange } from '@angular/material/select';
import { SubscriptionsService } from 'src/app/shared/services/subscriptions.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Country } from 'src/app/shared/models/common-models/country.model';
import { LocalRequestsService } from 'src/app/shared/services/local-requests.service';
import { BillingInfo } from 'src/app/shared/models/common-models/billing-info.model';
import { SharedService } from 'src/app/shared/services/shared.service';
import { AccountsService } from 'src/app/shared/services/accounts.service';
import { BillingRequest } from 'src/app/shared/models/requests-models/billing-create-update.model';
import { Account } from 'src/app/shared/models/account-models/account.model';
import { DefaultDialogInputData } from 'src/app/shared/models/common-models/default-dialog-input-data.model';
import { BillEstimate } from 'src/app/shared/models/account-models/bill-estimate.model';
import { BillHistory } from 'src/app/shared/models/account-models/bill-history.model';
import { AccountUpdateFailedEvent } from 'src/app/shared/events/account-update-failed.event';
import { MatPaginatorModule } from '@angular/material/paginator';
import { WorkspaceGroup } from 'src/app/shared/models/workspace-models/workspace-group.model';
import { WorkspacesService } from 'src/app/shared/services/workspaces.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { WorkspaceGroupNewComponent } from 'src/app/shared/components/workspace-groups/workspace-group-new/workspace-group-new.component';
import { TranslateService } from '@ngx-translate/core';

// Utils
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

@Component({
  selector: 'groups-tab',
  templateUrl: './groups-tab.component.html',
  styleUrls: ['./groups-tab.component.scss']
})
export class GroupsTabComponent implements OnChanges, OnInit {

  @Input() workspaceGroups: WorkspaceGroup[] = [];
  @Input() workspace: Workspace;
  @Output() workspaceGroupsChange: EventEmitter<any> = new EventEmitter();

  selectedWorkspace: Workspace;
  selectedWorkspaceGroup: WorkspaceGroup;
  workspaceGroupForm: FormGroup;

  currentLocale: any = '';
  transConfirmation: string = '';
  transConfirmationDesc: string = '';
  transDeleteWorkspaceGroup: string = '';
  transDeleteWorkspaceGroupDesc: string = '';
  confirmString: string = '';
  cancelString: string = '';

  workspaces: Workspace[] = [];

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private cd: ChangeDetectorRef,
    private fb: FormBuilder,
    private subscriptionsSrv: SubscriptionsService,
    private sharedSrv: SharedService,
    private accountSrv: AccountsService,
    private localRequestsSrv: LocalRequestsService,
    private storageSrv: StorageService,
    private workspacesSrv: WorkspacesService
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.currentLocale = this.utilSrv.locale;
    this.tsTranslation();
    this.generateWorkspaceGroupForm();
  }

  ngOnChanges(changes: SimpleChanges) {
    if(changes.workspace) {
      this.workspaceChange();
    }
  }

  tsTranslation() {
    this.translate.get('WORKSPACEEDIT.CONFIRMATION').subscribe((string) => {
      this.transConfirmation = string;
    });
    this.translate.get('WORKSPACEEDIT.CONFIRMATIONDESC').subscribe((string) => {
      this.transConfirmationDesc = string;
    });
    this.translate.get('WORKSPACEEDIT.DELETEWORKSPACEGROUP').subscribe((string) => {
      this.transDeleteWorkspaceGroup = string;
    });
    this.translate.get('WORKSPACEEDIT.DELETEWORKSPACEGROUPDESC').subscribe((string) => {
      this.transDeleteWorkspaceGroupDesc = string;
    });
    this.translate.get('CONFIRMBUTTON').subscribe((string) => {
      this.confirmString = string;
    });
    this.translate.get('CANCELBUTTON').subscribe((string) => {
      this.cancelString = string;
    });
  }

  workspaceChange() {
    if(Object.keys(this.workspace).length) {
      this.workspaces = this.storageSrv.workspacesByAccountsId[this.workspace.account.id];
    }
  }

  selectWorkspaceGroup(workspaceGroupId){
    if (workspaceGroupId == null){
      this.selectedWorkspaceGroup = null;
      return;
    }

    for (let group of this.workspaceGroups){
      if (workspaceGroupId == group.id){
        this.selectedWorkspaceGroup = group;
        break;
      }
    }

    this.generateWorkspaceGroupForm();
  }

  generateWorkspaceGroupForm(){
    if (this.selectedWorkspaceGroup){
      this.workspaceGroupForm = this.fb.group({
        groupName: [this.selectedWorkspaceGroup.groupName, [Validators.required, removeWhitespaceValidator]],
      })

      for (let permission of this.selectedWorkspaceGroup.permissions){
        this.workspaceGroupForm.addControl(permission.id+'create', this.fb.control(permission.create));
        this.workspaceGroupForm.addControl(permission.id+'read', this.fb.control(permission.read));
        this.workspaceGroupForm.addControl(permission.id+'update', this.fb.control(permission.update));
        this.workspaceGroupForm.addControl(permission.id+'delete', this.fb.control(permission.delete));
      }

      this.updateFormFields();
    }
  }

  updateFormFields() {

  }

  onUpdateWorkspaceGroup(){
    if (this.workspaceGroupForm.valid){
      var rawData = this.workspaceGroupForm.getRawValue();
      var workspaceRequest = {permissions: [], workspaceGroupName:rawData.groupName};

      // need to format request into correct organization because of weird form format
      Object.keys(rawData).forEach(key => {
        if (key === "groupName"){
          return;
        }
        var originalKey = key;

        // try to parse id out, and then rest of it
        if (key.indexOf("create") > -1){
          var permId = +key.replace("create", "");
          workspaceRequest.permissions.push({"id":permId, "create":rawData[originalKey]});
        } else if (key.indexOf("read") > -1){
          var permId = +key.replace("read", "");
          workspaceRequest.permissions.push({"id":permId, "read":rawData[originalKey]});
        } else if (key.indexOf("update") > -1){
          var permId = +key.replace("update", "");
          workspaceRequest.permissions.push({"id":permId, "update":rawData[originalKey]});
        } else if (key.indexOf("delete") > -1){
          var permId = +key.replace("delete", "");
          workspaceRequest.permissions.push({"id":permId, "delete":rawData[originalKey]});
        }
      });


      this.workspacesSrv.updateWorkspaceGroup(this.selectedWorkspaceGroup.workspace.id, this.selectedWorkspaceGroup.id, workspaceRequest)
        .subscribe(updatedGroup => {
          this.selectedWorkspaceGroup = updatedGroup;

          // Emit updated group back to workspace edit
          let objIndex = this.workspaceGroups.findIndex((obj => obj.id == this.selectedWorkspaceGroup.id));
          this.workspaceGroups[objIndex] = updatedGroup;
          this.workspaceGroupsChange.emit(this.workspaceGroups);

          // Update the storage data
          this.updateStorageWorkspaceData();

          // open success window
          let data: DefaultDialogInputData = {
            title: this.transConfirmation,
            description: this.transConfirmationDesc,
            template: 0,
            confirm: 'Ok'
          }
          this.sharedSrv.openDialog<null>(data, true, {width: "45%"})
        });
    }
  }

  updateStorageWorkspaceData() {
    // Update the storage data
    let _workspaces = this.workspaces;
    let _workspaceIndex = _workspaces.findIndex((obj=> obj.id == this.workspace.id));
    this.workspaces[_workspaceIndex].groups = this.workspaceGroups;
    this.storageSrv.workspacesByAccountsId[this.workspace.account.id] = this.workspaces;
  }

  onCreateNewGroup(){
    this.sharedSrv.openDialog<null>({workspaceId:this.workspace.id}, true, null, WorkspaceGroupNewComponent)
    .subscribe(async response => {
      if (response.continue){
        this.workspacesSrv.createWorkspaceGroup(this.workspace.id, response.outputData)
        .subscribe(response => {
          this.workspaceGroups.push(response);
          this.workspaceGroupsChange.emit(this.workspaceGroups);

          // Update the storage data
          this.updateStorageWorkspaceData();

        });
      }
    });
  }


  // delete a workspace group
  onDeleteWorkspaceGroup(workspaceGroupId){
    let data: DefaultDialogInputData = {
      title: this.transDeleteWorkspaceGroup,
      description: this.transDeleteWorkspaceGroupDesc,
      template: 0,
      confirm: this.confirmString,
      cancel: this.cancelString
    }
    this.sharedSrv.openDialog<null>(data, true, {width: "45%"})
    .subscribe(response => {
      if (response.continue){
        this.workspacesSrv.deleteWorkspaceGroup(this.workspace.id, workspaceGroupId)
        .subscribe(response => {
          if (response) {
            // remove workspace group from list of workspace groups
            let workspaceGrpIndex = this.workspaceGroups.findIndex(workspaceGr => {
              return workspaceGroupId == workspaceGr.id;
            });

            if (workspaceGrpIndex >= 0){
              this.workspaceGroups.splice(workspaceGrpIndex, 1);

              // Update the storage data
              this.updateStorageWorkspaceData();
            }

          };
        });
      }
    });
  }

}
