import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  ChangeDetectorRef,
  Input,
  OnDestroy,
  Output,
  EventEmitter,
  OnChanges
} from '@angular/core';
import { Subscription } from 'src/app/shared/models/common-models/subscription.model';
import { StripeChangeEvent } from 'src/app/shared/models/common-models/stripe-change-event.model';
import { MatSelectChange } from '@angular/material/select';
import { SubscriptionsService } from 'src/app/shared/services/subscriptions.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Country } from 'src/app/shared/models/common-models/country.model';
import { LocalRequestsService } from 'src/app/shared/services/local-requests.service';
import { BillingInfo } from 'src/app/shared/models/common-models/billing-info.model';
import { SharedService } from 'src/app/shared/services/shared.service';
import { AccountsService } from 'src/app/shared/services/accounts.service';
import { BillingRequest } from 'src/app/shared/models/requests-models/billing-create-update.model';
import { Account } from 'src/app/shared/models/account-models/account.model';
import { DefaultDialogInputData } from 'src/app/shared/models/common-models/default-dialog-input-data.model';
import { BillEstimate } from 'src/app/shared/models/account-models/bill-estimate.model';
import { BillHistory } from 'src/app/shared/models/account-models/bill-history.model';
import { AccountUpdateFailedEvent } from 'src/app/shared/events/account-update-failed.event';
import { MatPaginatorModule } from '@angular/material/paginator';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { WorkspacesService } from 'src/app/shared/services/workspaces.service';
import { WorkspaceGroup } from 'src/app/shared/models/workspace-models/workspace-group.model';
import { UserBasic } from 'src/app/shared/models/user-models/user-basic.model';
import { WorkspaceMembersComponent } from 'src/app/shared/components/workspace-members/workspace-members.component';

import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'members-tab',
  templateUrl: './members-tab.component.html',
  styleUrls: ['./members-tab.component.scss']
})
export class MembersTabComponent implements OnInit, OnChanges {

  @Input() workspace: Workspace;
  @Input() workspaceId: number;
  @Input() accountId: number;

  @Input() accountMembers: UserBasic[];
  @Input() workspaceMembersByIds: {
    [key: number]: UserBasic
  };
    // stored workspace member
  @Input() workspaceMembers: UserBasic[] = [];
  // stored workspace groups
  @Input() workspaceGroups: WorkspaceGroup[] = [];
  subscriber;

  transNoAccountMembers: string = '';
  transNoAccountMembersDesc: string = '';
  transDeleteWorkspace: string = '';
  transDeleteWorkspaceDesc: string = '';
  transUserRoleChange: string = '';
  transUserRoleChangeDesc: string = '';
  confirmString: string = '';
  cancelString: string = '';

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private cd: ChangeDetectorRef,
    private fb: FormBuilder,
    private subscriptionsSrv: SubscriptionsService,
    private sharedSrv: SharedService,
    private accountSrv: AccountsService,
    private localRequestsSrv: LocalRequestsService,
    private storageSrv: StorageService,
    private workspacesSrv: WorkspacesService
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {

    this.translate.get('WORKSPACEEDIT.NOACCOUNTMEMBERS').subscribe((string) => {
      this.transNoAccountMembers = string;
    });
    this.translate.get('WORKSPACEEDIT.NOACCOUNTMEMBERSDESC').subscribe((string) => {
      this.transNoAccountMembersDesc = string;
    });
    this.translate.get('WORKSPACEEDIT.REMOVEUSER').subscribe((string) => {
      this.transDeleteWorkspace = string;
    });
    this.translate.get('WORKSPACEEDIT.DELETEWORKSPACEDESC').subscribe((string) => {
      this.transDeleteWorkspaceDesc = string;
    });
    this.translate.get('WORKSPACEEDIT.USERROLECHANGE').subscribe((string) => {
      this.transUserRoleChange = string;
    });
    this.translate.get('WORKSPACEEDIT.USERROLECHANGEDESC').subscribe((string) => {
      this.transUserRoleChangeDesc = string;
    });
    this.translate.get('CONFIRMBUTTON').subscribe((string) => {
      this.confirmString = string;
    });
    this.translate.get('CANCELBUTTON').subscribe((string) => {
      this.cancelString = string;
    });

  }


  ngOnChanges() {
  }


    /**
   * calls from template
   * navigate user to the account edit page
   *
   * @param null
   *
   * @return `null`
   */
  onAddNewMember() {
    if (this.accountMembers) {
      if (this.accountMembers.length > 0) {
        this.sharedSrv.openDialog<{ id: number }[]>(
          {
            members: this.accountMembers,
            workspaceGroups: this.workspaceGroups
          },
          true,
          null,
          WorkspaceMembersComponent
        ).subscribe(response => {
          if (response.continue) {
            this.workspacesSrv.addNewMemberToTheWorkspace(+this.workspaceId,response.outputData
            ).subscribe(members => {
              if (response) {

                // find the user we want
                var user = null;
                for (var i = 0; i < this.accountMembers.length; i++){
                  if (this.accountMembers[i].id == response.outputData["userId"]){
                    user = this.accountMembers[i];
                  }
                }

                // add into workspace group
                for (var i = 0; i < this.workspaceGroups.length; i++){
                  if (this.workspaceGroups[i].id == response.outputData["groupId"]){
                    this.workspaceGroups[i].members.push(user);
                  }
                }

                this.workspaceMembers.push(user);
                this.workspaceMembersByIds[response.outputData["userId"]] = user;
              }
            })
          }
        })
      } else {
        this.sharedSrv.openDialog({
          title: this.transNoAccountMembers,
          description: this.transNoAccountMembersDesc,
          confirm: 'Ok',
          template: 1
        });
      }
    }
  }


  /**
   * calls from template
   *
   * when user clicked on the delete button of member options
   * first open dialog for a confirmation
   * after delete user in case of confirm
   *
   * @param memberId is a member id wich should be deleted (type `number`)
   *
   * @return `null`
   */
  onDeleteMemberFromWorkspace(memberId: number, workspaceGroup: WorkspaceGroup) {
    this.subscriber = this.sharedSrv.openDialog({
      title: this.transDeleteWorkspace,
      description: this.transDeleteWorkspaceDesc,
      confirm: this.confirmString,
      cancel: this.cancelString,
      template: 0
    }, true, {
      width: '45%',
    }).subscribe(response => {
      if (response.continue) {
        this.workspacesSrv.deleteMemberFromWorkspace(
          memberId,
          this.workspace.id
        ).subscribe(response => {
          if (response) {
            delete this.workspaceMembersByIds[memberId];
            this.workspaceMembers = this.workspaceMembers.filter((member) => {
              return member.id !== memberId;
            });

            workspaceGroup.members.every((eachMember, memberIndex) => {
              if (eachMember.id === memberId) {
                workspaceGroup.members.splice(memberIndex, 1);
                return false;
              }
              return true;
            });
          }
        });
      }
    });
  }

    /**
   * calls from template
   *
   * hide the delete member button on current user item
   *
   * @param memberId is a checked member id (type `number`)
   *
   * @return `boolean`
   */
  onCheckCurrentUser(memberId: number) {
    if (memberId >= 0) {
      let currentUser = this.storageSrv.currentUserInfo;
      // check member id with current user Id
      // return false when member id equal to the current user Id
      return currentUser && currentUser.id === memberId;
    }
  }

    /**
   * calls from template
   *
   * when user clicked on the some role button of member options
   * first open dialog for a confirmation
   * after change member role in case of confirm
   *
   * @param memberId is a member id wich role should be changed (type `number`)
   * @param role type `number`
   *
   * @return `null`
   */
  onChangeUserRole(member: UserBasic, roleObject: WorkspaceGroup, userRole: WorkspaceGroup) {
    if (+userRole.id !== +roleObject.id) {
      this.subscriber = this.sharedSrv.openDialog(
        {
          title: this.transUserRoleChange,
          description: this.transUserRoleChangeDesc,
          template: 0,
          confirm: 'Confirm',
          cancel: 'no'
        },
        true,
        {
          width: '45%'
        }).subscribe(response => {
          if (response.continue) {
            this.workspacesSrv.updateWorkspaceMember({
              workspaceGroupId: +roleObject.id,
            },
              member.id,
              this.workspace.id
            ).subscribe(response => {
              if (response) {
                // move user id to correct group
                // remove from userRole
                for (var i = 0; i < userRole.members.length; i++){
                  if (userRole.members[i].id == member.id){
                    userRole.members.splice(i, 1);
                  }
                }

                //add to rolObject
                roleObject.members.push(member);

              };
            })
          }
        });
    }
  }

  /**
   * calls from template
   * helper for a optimizing *ngFor
   *
   * @param index is a current element index with type `number`
   * @param item is a current element info with type `UserBasic | WorkspaceGroup`
   *
   * @return `number`
   */
  onTrackById(index: number, item: UserBasic | WorkspaceGroup) {
    return item.id;
  }



}
