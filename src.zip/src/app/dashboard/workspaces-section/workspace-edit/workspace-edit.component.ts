import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { ActivatedRoute, Router } from '@angular/router';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { TranslateService } from '@ngx-translate/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { SitebarItem } from 'src/app/shared/models/common-models/sitebar-item.model';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { UserBasic } from 'src/app/shared/models/user-models/user-basic.model';
import { WorkspaceGroup } from 'src/app/shared/models/workspace-models/workspace-group.model';
import { Account } from 'src/app/shared/models/account-models/account.model';
import { WorkspaceUpdateRequest } from 'src/app/shared/models/requests-models/workspace-update.model';

import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { AccountsService } from 'src/app/shared/services/accounts.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { WorkspacesService } from 'src/app/shared/services/workspaces.service';

import { WorkspaceMembersComponent } from 'src/app/shared/components/workspace-members/workspace-members.component';

@Component({
  selector: 'app-workspace-edit',
  templateUrl: './workspace-edit.component.html',
  styleUrls: ['./workspace-edit.component.scss']
})
export class WorkspaceEditComponent extends CleanOnDestroy implements OnInit {

  protected baseUrl = environment.endPoint;

  selectedIndex: number = null;
  // sitebar item info
  workspaceItem: SitebarItem;
  // storet user typed new workspace name before update it
  typedWorkspaceName: string = '';
  // current workspace info
  account: Account = {} as Account;
  // current workspace info
  workspace: Workspace = {} as Workspace;
  // workspace account image
  workspaceEndPoint: string = '';
  workspaceLogoEndpoint: string = '';
  // stored workspace id from url
  workspaceId: number;
  // stored workspace member
  workspaceMembers: UserBasic[] = [];
  // stored workspace groups
  workspaceGroups: WorkspaceGroup[] = [];
  // transformed array with key `member.id` and value `UserBasic` (member info)
  workspaceMembersByIds: {
    [key: number]: UserBasic
  }

  accountMembers: UserBasic[];
  
  activeLink:number = 0;

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private sharedSrv: SharedService,
    private storageSrv: StorageService,
    private workspacesSrv: WorkspacesService,
    private activeRoute: ActivatedRoute,
    private accountSrv: AccountsService,
    private fb: FormBuilder,
    private router: Router
  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.workspaceItem = this.utilSrv.getSitebarItem('workspaces');
    this.workspaceEndPoint = `${this.utilSrv.env.endPoint}/api/v1/workspaces/`;
    //this.workspaceEndPointV3 = `${this.utilSrv.env.endPoint}/api/v3/`;

    this.subscriber = this.activeRoute.params.subscribe(params => {
      this.workspaceId = +params['workspaceId'];
      if (this.workspaceId >= 0) {
        this.getWorkspaceById();
        this.getWorkspaceGroups();
        this.getWorkspaceMembers();
      }

      if (params['tabName']) {
        switch (params['tabName']) {
          case 'details':
            this.selectedIndex = 0;
            break;
          case 'members':
            this.selectedIndex = 1;
            break;
          case 'groups':
            this.selectedIndex = 2;
            break;
        }
      }
    });
  }


  /**
   * get account members
   *
   * @param accountId is a workspace account id
   *
   * @return `null`
   */
  getAccountMembers(accountId: number) {
    this.accountSrv.getAccountUsers(accountId).subscribe(accountMembers => {
      this.accountMembers = accountMembers;
    });
  }


  /**
   * get workspace by `workspaceId`
   *
   * @param null
   *
   * @return `null`
   */
  getWorkspaceById() {
    this.workspacesSrv.getWorkspaceById(this.workspaceId)
      .subscribe(workspace => {
        if (workspace) {
          this.workspace = workspace;
          this.getAccountByAccountId(this.workspace.account.id);
          this.typedWorkspaceName = this.workspace.workspaceName;
          this.workspaceLogoEndpoint = this.utilSrv.env.endPoint + '/api/v1/workspaces/';
          this.workspaceLogoEndpoint = `${this.workspaceLogoEndpoint}${this.workspace.id}/logo/`;
          this.getAccountMembers(this.workspace.account.id)
        } else {
          this.router.navigate(['/home']);
        }

      });
  }

  /**
   * get workspace members by `workspaceId`
   *
   * @param null
   *
   * @return `null`
   */
  getWorkspaceMembers() {
    // reset workspace members before get new list of workspace members
    this.workspaceMembers = [];
    this.workspaceMembersByIds = {};
    this.workspacesSrv.getWorkspaceMembersByWorkspaceId(this.workspaceId)
      .subscribe(workspaceMembers => {
        this.workspaceMembers = workspaceMembers;
        this.workspaceMembers.forEach(workspaceMember => {
          this.workspaceMembersByIds[workspaceMember.id] = workspaceMember;
        });

      });
  }

  /**
   * get account by `accountId`
   *
   * @param null
   *
   * @return `null`
   */
  getAccountByAccountId(accountId: number) {
    this.accountSrv.getAccoutById(accountId).subscribe(account => {
      this.account = account;
    });
  }

  /**
   * get workspace groups by `workspaceId`
   *
   * @param null
   *
   * @return `null`
   */
  getWorkspaceGroups() {
    // reset workspace members before get new list of workspace members
    this.workspaceGroups = [];
    this.workspacesSrv.ListWorkspaceGroups(this.workspaceId)
      .subscribe(workspaceGroups => {
        this.workspaceGroups = workspaceGroups;
      })
  }



  /**
   * calls from template
   * navigate user to the account edit page
   *
   * @param null
   *
   * @return `null`
   */
  onNavigateUserToTheAccountPage() {
    this.router.navigate(['/accounts', this.account.id]);
  }

    /**
   * calls from template
   * when user change the selected tab
   * replace the current url for a store user selected tab
   * and helper for mobile app
   * @param event is a output event object of tab group `selectedTabChange` event
   * @return `null`
   */
  onChangeTab(event: MatTabChangeEvent) {
    switch (event.index) {
      case 0:
        history.replaceState(location.href, '', `${this.baseUrl}/workspaces/${this.workspaceId}/details`);
        break;
      case 1:
        history.replaceState(location.href, '', `${this.baseUrl}/workspaces/${this.workspaceId}/members`);
        break;
      case 2:
        history.replaceState(location.href, '', `${this.baseUrl}/workspaces/${this.workspaceId}/groups`);
        break;
    }
  }

  /**
   * calls from template
   * when user choose a new account logo
   *
   * @param workspaceImageInput with type `HTMLInputElement`
   *
   * @return `null`
   */
  onChangeWorkspaceImage(workspaceImageInput: HTMLInputElement) {
    // get choosed image
    let workspaceNewImage: File = workspaceImageInput.files[0];

    // check image extension
    let isValidExtension = this.utilSrv.checkImageExtension(workspaceNewImage);

    if (isValidExtension) {
      // uplaod in case validity
      let workspaceLogoForm = new FormData();
      workspaceLogoForm.append('file', workspaceNewImage);
      this.workspacesSrv.changeWorkspaceLogo(workspaceLogoForm, this.workspaceId)
        .subscribe(response => {
          if (response) {
            this.changeWorkspaceLogo();
          }
        })
    }
  }

    /**
   * change account logo path
   *
   * @param null
   *
   * @return `null`
   */
  changeWorkspaceLogo() {
    this.workspaceLogoEndpoint = '';
    // settimeout need for a update existing image
    setTimeout(() => {
      this.workspaceLogoEndpoint = `${this.workspaceEndPoint}${this.workspaceId}/logo/`;
      // this.workspaceLogoEndpoint = `${this.workspaceEndPointV3}orgs/${this.workspace.account}/workspaces/${this.workspaceId}/logo/`;
    })
  }


}
