import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WorkspacesSectionComponent } from './workspaces-section.component';
import { WorkspaceEditComponent } from './workspace-edit/workspace-edit.component';

const routes: Routes = [
  {
    path: '', component: WorkspacesSectionComponent, children: [
      {
        path: ':workspaceId',
        component: WorkspaceEditComponent
      },
      {
        path: ':workspaceId/:tabName',
        component: WorkspaceEditComponent
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class WorkspacesRoutingModule { }
