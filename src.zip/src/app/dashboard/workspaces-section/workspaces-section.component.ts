import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-workspaces-section',
  templateUrl: './workspaces-section.component.html',
  styleUrls: ['./workspaces-section.component.scss']
})
export class WorkspacesSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
