import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from 'src/app/shared/shared.module';
import { WorkspacesRoutingModule } from './workspaces-routing.module';

import { WorkspacesSectionComponent } from './workspaces-section.component';
import { WorkspaceEditComponent } from './workspace-edit/workspace-edit.component';
import { DetailsTabComponent } from './workspace-edit/details-tab/details-tab.component';
import { GroupsTabComponent } from './workspace-edit/groups-tab/groups-tab.component';
import { MembersTabComponent } from './workspace-edit/members-tab/members-tab.component';
import { MatTableModule } from '@angular/material/table';


@NgModule({
  declarations: [
    WorkspacesSectionComponent,
    WorkspaceEditComponent,
    DetailsTabComponent,
    GroupsTabComponent,
    MembersTabComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    WorkspacesRoutingModule,
    MatTableModule
  ]
})
export class WorkspacesModule { }
