import { ErrorHandler, Injectable } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
 
@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
 
    constructor(
        private logger: NGXLogger,
    ) { }
 
    handleError(error: Error) {
        const err = {
            message: error.message ? error.message : error.toString(),
            stack: error.stack ? error.stack : ''
        };
 
        // Optionally send it to your back-end API
        this.logger.error(err);
    }
}