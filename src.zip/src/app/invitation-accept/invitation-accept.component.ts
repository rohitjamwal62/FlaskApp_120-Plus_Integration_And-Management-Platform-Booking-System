import { Component, OnInit } from '@angular/core';
import { InvitationsService } from '../shared/services/invitations.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-invitation-accept',
  templateUrl: './invitation-accept.component.html',
  styleUrls: ['./invitation-accept.component.scss']
})
export class InvitationAcceptComponent implements OnInit {

  constructor(
    private invitationsSrv: InvitationsService,
    private activeRoute: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit() {
    if (this.activeRoute.snapshot.params['invitationKey']) {
      let verifikationKey = this.activeRoute.snapshot.params['invitationKey'];
      this.invitationsSrv.verifyInvitation(verifikationKey)
        .subscribe(isVerified => {
          if (isVerified) {
            this.router.navigate(['']);
            // TODO some logic here
          }
        },
          error => {
          })
    }
  }

}
