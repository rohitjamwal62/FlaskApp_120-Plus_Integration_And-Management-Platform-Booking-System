import { Component, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';

// TODO: Add Angular decorator.
@Component({
  template: ''
})

export abstract class CleanOnDestroy implements OnDestroy {

    // private array of subscribers 
    // store the subscribers into the subscribers property 
    // for a destroy when destroys the component
    private subscribers: Subscription = new Subscription();

    /**
     * setter take subscription and set into 
     * `CleanOnDestroy.subscribers` for a unsubscribe 
     * when destroys a component
     * 
     * @param subscriber with type `Subscription`
     *
     * @return `null`
     */
    set subscriber(subscriber: Subscription) {
        this.subscribers.add(subscriber);
    }

    // unsubscribe all 
    ngOnDestroy(): void {
        this.subscribers.unsubscribe();
    }

}