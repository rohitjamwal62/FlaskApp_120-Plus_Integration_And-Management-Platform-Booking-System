import { Component, OnInit, Inject, ViewChild, AfterViewInit } from '@angular/core';
import { UtilService } from 'src/app/shared/services/util.service';
import { AccountInvitationFull } from '../../models/account-models/account-invitation-full.model';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSelectChange, MatSelect } from '@angular/material/select';
import { InvitationsService } from '../../services/invitations.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'user-account-invitations',
  templateUrl: './account-invitations.component.html',
  styleUrls: ['./account-invitations.component.scss']
})
export class AccountInvitationsComponent implements OnInit, AfterViewInit {

  accountInvitations: AccountInvitationFull[] = [];

  selectedInvitationIds: number[] = [];
  invitationsService: InvitationsService;

  invitationsByIds: {
    [key: number]: AccountInvitationFull
  } = {};

  @ViewChild('multiSelect', { static: true }) multiSelect: MatSelect;

  constructor(
    public utilSrv: UtilService,
    private translate: TranslateService,
    public dialogRef: MatDialogRef<AccountInvitationsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      accountInvitations: AccountInvitationFull[]
    },
    invitationsService: InvitationsService
  ) {
    this.invitationsService = invitationsService;
  }

  ngOnInit() {
    if (this.data){
      this.accountInvitations = this.data.accountInvitations;
      this.accountInvitations.forEach(invite => {
          this.invitationsByIds[invite.id] = invite;
        });
    }
  }

  ngAfterViewInit() {
  }

  /**
   * calls from template
   * helper for a optimizing *ngFor
   *
   * @param index is a current element index with type `number`
   * @param item is a current element info
   *        with type `{id: number}`
   *
   * @return `number`
   */
  onTrackById(index: number, item: { id: number }) {
    return item.id;
  }

  onChooseInvitation(event: MatSelectChange) {
    this.selectedInvitationIds = event.value;
  }

  onRemoveInvitation(index: number, select: MatSelect) {
    this.selectedInvitationIds.splice(index, 1);
    select.writeValue(this.selectedInvitationIds);
  }


  /**
   * close dialog without changes
   *
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * close dialog with selected members Info
   *
   * @param null
   *
   * @return `null`
   */
  onContinue() {

    let invitations = []
    this.selectedInvitationIds.forEach(inviteId => {
      invitations.push({
        id: inviteId
      })
    })

    // send invitations here
    this.invitationsService.acceptInvitations({"invitations":invitations})
    .subscribe(response => {
      this.dialogRef.close({ continue: true, outputData: null});
    });

  }
}
