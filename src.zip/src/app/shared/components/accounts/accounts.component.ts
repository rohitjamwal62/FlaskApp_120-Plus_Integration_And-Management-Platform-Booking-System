import { Component, OnInit, Inject, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { UtilService } from '../../services/util.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AccountsService } from '../../services/accounts.service';
import { StorageService } from '../../services/storage.service';
import { WorkspacesService } from '../../services/workspaces.service';
import { Workspace } from '../../models/workspace-models/workspace.model';

import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-accounts',
  templateUrl: './accounts.component.html',
  styleUrls: ['./accounts.component.scss']
})
export class AccountsComponent implements OnInit, AfterViewInit {

	accountLogoEndpoint: string = '';

  selectedWorkspace: Workspace;

  // referance of storageSrv.workspacesByAccountsId
  workspacesByAccountsId: {
    [key: number]: Workspace[]
  }

  currentLocale: any = '';

  constructor(
    public utilSrv: UtilService,
    private translate: TranslateService,
    private router: Router,
  	public storageSrv: StorageService,
  	private accountSrv: AccountsService,
    private workspacesSrv: WorkspacesService,
  	public dialogRef: MatDialogRef<AccountsComponent>,
  	@Inject(MAT_DIALOG_DATA) public data: any
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.currentLocale = this.utilSrv.locale;
  	this.accountLogoEndpoint = `${this.utilSrv.env.endPoint}/api/v1/accounts/`;
    this.selectedWorkspace = this.storageSrv.selectedWorkspace;
  }

  ngAfterViewInit() {

  }

  changeSelectedWorkspace(workspace: Workspace) {
    this.storageSrv.selectedWorkspace = workspace;
    this.selectedWorkspace = workspace;
    this.checkAdmin(workspace.account.id);
    this.moveSelectedWorkspaceToTop(workspace);
    this.onClose();
    this.router.navigate(['/']);
  }

  checkAdmin(accountId: number) {
    if (this.storageSrv.getAdminAccount(accountId) == null){
      this.accountSrv.getAccountGroups(accountId).subscribe(accountGroups => {
        accountGroups.forEach(accountGroup => {
          if (accountGroup.groupName === 'Admin') {
            accountGroup.users.some(user => {
              if (user.id === this.storageSrv.currentUserInfo.id) {
                this.storageSrv.setAdminAccounts(accountId, true);
                return true;
              } else {
                this.storageSrv.setAdminAccounts(accountId, false);
                return false;
              }
            });
          }
        });
      });
    }
  }

  moveSelectedWorkspaceToTop(workspace: Workspace){
    // find selected workspace/account and put them at the top of the currentUserAccounts
    if (this.storageSrv.currentUserAccounts){
      for (var i = 0; i < this.storageSrv.currentUserAccounts.length; i++){
        if (workspace.account.id == this.storageSrv.currentUserAccounts[i].id){
          var item = this.storageSrv.currentUserAccounts[i];
          this.storageSrv.currentUserAccounts.splice(i,1);
          this.storageSrv.currentUserAccounts.unshift(item);
          break;
        }
      }
    }
  }

  /**
   * calls from template
   * ignote event triggering to up
   *
   * @param event is a `MouseEvent`
   *
   * @return null
   */
  onStopPropagate(event: MouseEvent) {
    event.stopPropagation();
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * close dialog without changes
   *
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  onClose() {
    this.dialogRef.close({ continue: true, outputData: null });
  }

}
