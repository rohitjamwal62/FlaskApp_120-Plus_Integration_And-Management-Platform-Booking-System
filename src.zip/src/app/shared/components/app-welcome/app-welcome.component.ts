import { Component, OnInit, Inject, ViewChild, AfterViewInit } from '@angular/core';
//import { SlickModule } from 'ngx-slick';
import { TranslateService } from '@ngx-translate/core';

import { environment } from 'src/environments/environment';

import { CookieService } from 'ngx-cookie-service';
import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { AppWelcomeService } from 'src/app/shared/services/app-welcome.service'
import { UsersService } from 'src/app/shared/services/users.service';
import { IntegrationsService } from 'src/app/shared/services/integrations.service';

import { IntegrationTypes } from 'src/app/shared/models/integration-models/integration-types.model';

import { HelpIntegratingPlatformsComponent } from 'src/app/shared/components/help-integrating-platforms/help-integrating-platforms.component';

declare var EnjoyHint: any;

@Component({
  selector: 'app-welcome',
  templateUrl: './app-welcome.component.html',
  styleUrls: ['./app-welcome.component.scss']
})
export class AppWelcomeComponent implements OnInit {

  slides = [
    {img: "/assets/images/welcome.svg", title: '', content: '' },
    {img: "/assets/images/playlist.svg", title: '', content: ""},
    {img: "/assets/images/device.svg", title: '', content: ""},
    {img: "/assets/images/schedule.svg", title: '', content: ""},
    {img: "/assets/images/content.svg", title: '', content: ""},
    {img: "/assets/images/workspace.svg", title: '', content: ""},
    {img: "/assets/images/tutorial.svg", title: '', content: "", finalAction: ""},
  ];
  slideConfig = {"slidesToShow": 1, "slidesToScroll": 1, "arrows":true, "dots":true, "infinite":false, nextArrow:'#introNext', prevArrow:'#introPrev'};

  introTutorialSteps = [
    {selector:'#devices', event:'click', description:"", showSkip:false},
    {selector:'#newVirtualDevice', event:'click', description:"", showSkip:false},
    {'next #deviceNameField':"", showSkip:false},
    {'next #deviceChannelField':"", margin:50, showSkip:false},
    {selector:'#claimDevice', event:'click', description:"", showSkip:false},
    {selector: '.device-group-header', event:'click', description:"", showSkip:false, timeout: 1000},
    {selector: '.device-options', event:'click', description:"", showSkip:false, timeout:200},
    {selector: '.virtual-device-preview', event:'click', description:"", showSkip:false, timeout:200},
    {selector: '#channels', event: 'click', description:"", showSkip: false},
    {selector: '.playlist-image', event:'click', description:"", showSkip: false},
    {'next .slides-list':"", showSkip: false},
    {selector:'.slide-category-News', event:'click', description:"", showSkip: false, scrollAnimationSpeed:1000},
    {selector:'.slide-type-CNN', event:'click', description:"", showSkip: false},
    {'next .slide-form':"", showSkip: false, timeout: 200},
    {selector: '.create-button', event:'click', description:"", showSkip: false},
    {'next .slides-list':'', nextButton: {text: ""}, showSkip: false, timeout:200}
  ];

  introTutorialStepsTablet = [
    {selector:'#mobileHeader', event:'click', description:"", showSkip: false},
    {selector:'#devices', event:'click', description:"", showSkip:false},
    {selector:'#newVirtualDevice', event:'click', description:"", showSkip:false },
    {'next #deviceNameField':"", showSkip:false},
    {'next #deviceChannelField':"", margin:50, showSkip:false},
    {selector:'#claimDevice', event:'click', description:"", showSkip:false},
    {selector: '.device-group-header', event:'click', description:"", showSkip:false, timeout: 1000},
    {selector: '.device-options', event:'click', description:"", showSkip:false, timeout:200},
    {selector: '.virtual-device-preview', event:'click', description:"", showSkip:false, timeout:200},
    {selector: '#mobileHeader', event: 'click', description:"", showSkip: false},
    {selector: '#channels', event: 'click', description:"", showSkip: false},
    {selector: '.playlist-image', event:'click', description:"", showSkip: false},
    {'next .slides-list':"", showSkip: false},
    {selector: '.add-slide-button', event: 'click', description: "", showSkip: false, timeout: 300},
    {selector:'.slide-category-News', event:'click', description:"", showSkip: false, scrollAnimationSpeed:1000, timeout: 300},
    {selector:'.slide-type-CNN', event:'click', description:"", showSkip: false},
    {'next .slide-form':"", showSkip: false, timeout: 200},
    {selector: '.create-button', event:'click', description:"", showSkip: false},
    {selector: '#mobile-close-content', event: 'click', description: "", showSkip: false},
    {'next .slides-list':'', nextButton: {text: ""}, showSkip: false, timeout:200}
  ];

  introTutorialStepsMobile = [
    {selector:'#mobileHeader', event:'click', description:"", showSkip: false},
    {selector:'#devices', event:'click', description:"", showSkip:false},
    {selector:'#newVirtualDevice', event:'click', description:"", showSkip:false },
    {'next #deviceNameField':"", showSkip:false},
    {'next #deviceChannelField':"", margin:50, showSkip:false},
    {selector:'#claimDevice', event:'click', description:"", showSkip:false},
    {selector: '.device-group-header', event:'click', description:"", showSkip:false, timeout: 1000},
    {selector: '.device-options-mobile', event:'click', description:"", showSkip:false, timeout:200},
    {selector: '.virtual-device-preview', event:'click', description:"", showSkip:false, timeout:200},
    {selector: '#mobileHeader', event: 'click', description:"", showSkip: false},
    {selector: '#channels', event: 'click', description:"'.", showSkip: false},
    {selector: '.playlist-image', event:'click', description:"", showSkip: false},
    {'next .slides-list':"", showSkip: false},
    {selector: '.add-slide-button-mobile', event: 'click', description: "", showSkip: false, timeout: 300},
    {selector:'.slide-category-News', event:'click', description:"", showSkip: false, scrollAnimationSpeed:1000, timeout: 300},
    {selector:'.slide-type-CNN', event:'click', description:"", showSkip: false},
    {'next .slide-form':"", showSkip: false, timeout: 200},
    {selector: '.create-button', event:'click', description:"", showSkip: false},
    {selector: '#mobile-close-content', event: 'click', description: "", showSkip: false, timeout: 500},
    {'next .slide-item-inner':'', nextButton: {text: ""}, showSkip: false, timeout:200}
  ];

  //cookieService: CookieService;
  //storageService: StorageService;
  //appWelcomeService: AppWelcomeService;
  //usersService: UsersService;
  //sharedService: SharedService;

  protected baseUrl = environment.endPoint;
  integrationTypes: IntegrationTypes[];
  showTutorial = false;
  showHelp = false;
  helpUrl: string = "https://knowledge.rocketscreens.com/en/knowledge";

  currentLocale: any = '';

  constructor(
    private cookieSrv: CookieService,
    public storageSrv: StorageService,
    public utilSrv: UtilService,
    private usersSrv: UsersService,
    public sharedSrv: SharedService,
    private appWelcomeSrv: AppWelcomeService,
    private integrationsSrv: IntegrationsService,
    private translate: TranslateService
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {

    this.currentLocale = this.utilSrv.locale;
    this.tsTranslation();
    this.getShowTutorial();
    this.getIntegrationTypes();
    //this.appWelcomeService.setComponent(this);
  }

  tsTranslation() {
    // Slides Translations in .ts file
    this.translate.get('WELCOMETS.WELCOME').subscribe((welcome) => {
      this.slides[0].content = welcome;
    });
    this.translate.get('WELCOMETS.PLAYLIST').subscribe((playlist) => {
      this.slides[1].title = "";
      this.slides[1].content = playlist;
    });
    this.translate.get('WELCOMETS.DEVICE').subscribe((device) => {
      this.slides[2].title = "";
      this.slides[2].content = device;
    });
    this.translate.get('WELCOMETS.SCHEDULE').subscribe((schedule) => {
      this.slides[3].title = "";
      this.slides[3].content = schedule;
    });
    this.translate.get('WELCOMETS.CONTENT').subscribe((content) => {
      this.slides[4].title = "";
      this.slides[4].content = content;
    });
    this.translate.get('WELCOMETS.WORKSPACE').subscribe((workspace) => {
      this.slides[5].title = "";
      this.slides[5].content = workspace;
    });
    this.translate.get('WELCOMETS.TUTORIAL').subscribe((tutorial) => {
      this.slides[6].content = tutorial;
    });
    this.translate.get('WELCOMETS.FINALACTION').subscribe((fa) => {
      this.slides[6].finalAction = fa;
    });

    // Intro Tutorial Steps Translations
    this.translate.get('INTROTUTORIALSTEPS.DEVICES').subscribe((devices) => {
      this.introTutorialSteps[0].description = devices;
    });
    this.translate.get('INTROTUTORIALSTEPS.NEWVIRTUALDEVICE').subscribe((newVirtualDevice) => {
      this.introTutorialSteps[1].description = newVirtualDevice;
    });
    this.translate.get('INTROTUTORIALSTEPS.DEVICENAMEFIELD').subscribe((deviceNameField) => {
      this.introTutorialSteps[2]['next #deviceNameField'] = deviceNameField;
    });
    this.translate.get('INTROTUTORIALSTEPS.DEVICECHANNELFIELD').subscribe((deviceChannelField) => {
      this.introTutorialSteps[3]['next #deviceChannelField'] = deviceChannelField;
    });
    this.translate.get('INTROTUTORIALSTEPS.CLAIMDEVICE').subscribe((claimDevice) => {
      this.introTutorialSteps[4].description = claimDevice;
    });
    this.translate.get('INTROTUTORIALSTEPS.DEVICEGROUPHEADER').subscribe((deviceGroupHeader) => {
      this.introTutorialSteps[5].description = deviceGroupHeader;
    });
    this.translate.get('INTROTUTORIALSTEPS.DEVICEOPTIONS').subscribe((deviceOptions) => {
      this.introTutorialSteps[6].description = deviceOptions;
    });
    this.translate.get('INTROTUTORIALSTEPS.VIRTUALDEVICEPREVIEW').subscribe((virtualDevicePrev) => {
      this.introTutorialSteps[7].description = virtualDevicePrev;
    });
    this.translate.get('INTROTUTORIALSTEPS.CHANNELS').subscribe((channels) => {
      this.introTutorialSteps[8].description = channels;
    });
    this.translate.get('INTROTUTORIALSTEPS.PLAYLISTIMAGE').subscribe((playlistImage) => {
      this.introTutorialSteps[9].description = playlistImage;
    });
    this.translate.get('INTROTUTORIALSTEPS.SLIDESLIST').subscribe((slidesList) => {
      this.introTutorialSteps[10]['next .slides-list'] = slidesList;
    });
    this.translate.get('INTROTUTORIALSTEPS.SLIDECATEGORYNEWS').subscribe((slideCategoryNews) => {
      this.introTutorialSteps[11].description = slideCategoryNews;
    });
    this.translate.get('INTROTUTORIALSTEPS.SLIDETYPECNN').subscribe((slideTypeCnn) => {
      this.introTutorialSteps[12].description = slideTypeCnn;
    });
    this.translate.get('INTROTUTORIALSTEPS.SLIDEFORM').subscribe((slideForm) => {
      this.introTutorialSteps[13].description = slideForm;
    });
    this.translate.get('INTROTUTORIALSTEPS.CREATEBUTTON').subscribe((createButton) => {
      this.introTutorialSteps[14].description = createButton;
    });
    this.translate.get('INTROTUTORIALSTEPS.SLIDESLIST2').subscribe((slidesList) => {
      this.introTutorialSteps[15]['next .slides-list'] = slidesList;
    });
    this.translate.get('INTROTUTORIALSTEPS.NEXTBUTTON').subscribe((nextButton) => {
      this.introTutorialSteps[15].nextButton.text = nextButton;
    });

    // Intro Tutorial Steps Translations - Tablet
    this.translate.get('INTROTUTORIALSTEPSTABLET.MOBILEHEADER').subscribe((mobileHeader) => {
      this.introTutorialStepsTablet[0].description = mobileHeader;
    });
    this.translate.get('INTROTUTORIALSTEPSTABLET.DEVICES').subscribe((devices) => {
      this.introTutorialStepsTablet[1].description = devices;
    });
    this.translate.get('INTROTUTORIALSTEPSTABLET.NEWVIRTUALDEVICE').subscribe((newVirtualDevice) => {
      this.introTutorialStepsTablet[2].description = newVirtualDevice;
    });
    this.translate.get('INTROTUTORIALSTEPSTABLET.DEVICENAMEFIELD').subscribe((deviceNameField) => {
      this.introTutorialStepsTablet[3]['next #deviceNameField'] = deviceNameField;
    });
    this.translate.get('INTROTUTORIALSTEPSTABLET.DEVICECHANNELFIELD').subscribe((deviceChannelField) => {
      this.introTutorialStepsTablet[4]['next #deviceChannelField'] = deviceChannelField;
    });
    this.translate.get('INTROTUTORIALSTEPSTABLET.CLAIMDEVICE').subscribe((claimDevice) => {
      this.introTutorialStepsTablet[5].description = claimDevice;
    });
    this.translate.get('INTROTUTORIALSTEPSTABLET.DEVICEGROUPHEADER').subscribe((deviceGroupHeader) => {
      this.introTutorialStepsTablet[6].description = deviceGroupHeader;
    });
    this.translate.get('INTROTUTORIALSTEPSTABLET.DEVICEOPTIONS').subscribe((deviceOptions) => {
      this.introTutorialStepsTablet[7].description = deviceOptions;
    });
    this.translate.get('INTROTUTORIALSTEPSTABLET.VIRTUALDEVICEPREVIEW').subscribe((virtualDevicePrev) => {
      this.introTutorialStepsTablet[8].description = virtualDevicePrev;
    });
    this.translate.get('INTROTUTORIALSTEPSTABLET.MOBILEHEADER2').subscribe((mobileHeader) => {
      this.introTutorialStepsTablet[9].description = mobileHeader;
    });
    this.translate.get('INTROTUTORIALSTEPSTABLET.CHANNELS').subscribe((channels) => {
      this.introTutorialStepsTablet[10].description = channels;
    });
    this.translate.get('INTROTUTORIALSTEPSTABLET.PLAYLISTIMAGE').subscribe((playlistImage) => {
      this.introTutorialStepsTablet[11].description = playlistImage;
    });
    this.translate.get('INTROTUTORIALSTEPSTABLET.SLIDESLIST').subscribe((slidesList) => {
      this.introTutorialStepsTablet[12]['next .slides-list'] = slidesList;
    });
    this.translate.get('INTROTUTORIALSTEPSTABLET.ADDSLIDEBUTTON').subscribe((addSlideButton) => {
      this.introTutorialStepsTablet[13].description = addSlideButton;
    });
    this.translate.get('INTROTUTORIALSTEPSTABLET.SLIDECATEGORYNEWS').subscribe((slideCategoryNews) => {
      this.introTutorialStepsTablet[14].description = slideCategoryNews;
    });
    this.translate.get('INTROTUTORIALSTEPSTABLET.SLIDETYPECNN').subscribe((slideTypeCnn) => {
      this.introTutorialStepsTablet[15].description = slideTypeCnn;
    });
    this.translate.get('INTROTUTORIALSTEPSTABLET.SLIDEFORM').subscribe((slideForm) => {
      this.introTutorialStepsTablet[16].description = slideForm;
    });
    this.translate.get('INTROTUTORIALSTEPSTABLET.CREATEBUTTON').subscribe((createButton) => {
      this.introTutorialStepsTablet[17].description = createButton;
    });
    this.translate.get('INTROTUTORIALSTEPSTABLET.MOBILECLOSECONTENT').subscribe((mobileCloseContent) => {
      this.introTutorialStepsTablet[18].description = mobileCloseContent;
    });
    this.translate.get('INTROTUTORIALSTEPSTABLET.SLIDESLIST2').subscribe((slidesList) => {
      this.introTutorialStepsTablet[19]['next .slides-list'] = slidesList;
    });
    this.translate.get('INTROTUTORIALSTEPSTABLET.NEXTBUTTON').subscribe((nextButton) => {
      this.introTutorialStepsTablet[19].nextButton.text = nextButton;
    });

    // Intro Tutorial Steps Translations - Mobile
    this.translate.get('INTROTUTORIALSTEPSMOBILE.MOBILEHEADER').subscribe((mobileHeader) => {
      this.introTutorialStepsMobile[0].description = mobileHeader;
    });
    this.translate.get('INTROTUTORIALSTEPSMOBILE.DEVICES').subscribe((devices) => {
      this.introTutorialStepsMobile[1].description = devices;
    });
    this.translate.get('INTROTUTORIALSTEPSMOBILE.NEWVIRTUALDEVICE').subscribe((newVirtualDevice) => {
      this.introTutorialStepsMobile[2].description = newVirtualDevice;
    });
    this.translate.get('INTROTUTORIALSTEPSMOBILE.DEVICENAMEFIELD').subscribe((deviceNameField) => {
      this.introTutorialStepsMobile[3]['next #deviceNameField'] = deviceNameField;
    });
    this.translate.get('INTROTUTORIALSTEPSMOBILE.DEVICECHANNELFIELD').subscribe((deviceChannelField) => {
      this.introTutorialStepsMobile[4]['next #deviceChannelField'] = deviceChannelField;
    });
    this.translate.get('INTROTUTORIALSTEPSMOBILE.CLAIMDEVICE').subscribe((claimDevice) => {
      this.introTutorialStepsMobile[5].description = claimDevice;
    });
    this.translate.get('INTROTUTORIALSTEPSMOBILE.DEVICEGROUPHEADER').subscribe((deviceGroupHeader) => {
      this.introTutorialStepsMobile[6].description = deviceGroupHeader;
    });
    this.translate.get('INTROTUTORIALSTEPSMOBILE.DEVICEOPTIONS').subscribe((deviceOptions) => {
      this.introTutorialStepsMobile[7].description = deviceOptions;
    });
    this.translate.get('INTROTUTORIALSTEPSMOBILE.VIRTUALDEVICEPREVIEW').subscribe((virtualDevicePrev) => {
      this.introTutorialStepsMobile[8].description = virtualDevicePrev;
    });
    this.translate.get('INTROTUTORIALSTEPSMOBILE.MOBILEHEADER2').subscribe((mobileHeader) => {
      this.introTutorialStepsMobile[9].description = mobileHeader;
    });
    this.translate.get('INTROTUTORIALSTEPSMOBILE.CHANNELS').subscribe((channels) => {
      this.introTutorialStepsMobile[10].description = channels;
    });
    this.translate.get('INTROTUTORIALSTEPSMOBILE.PLAYLISTIMAGE').subscribe((playlistImage) => {
      this.introTutorialStepsMobile[11].description = playlistImage;
    });
    this.translate.get('INTROTUTORIALSTEPSMOBILE.SLIDESLIST').subscribe((slidesList) => {
      this.introTutorialStepsMobile[12]['next .slides-list'] = slidesList;
    });
    this.translate.get('INTROTUTORIALSTEPSMOBILE.ADDSLIDEBUTTON').subscribe((addSlideButton) => {
      this.introTutorialStepsMobile[13].description = addSlideButton;
    });
    this.translate.get('INTROTUTORIALSTEPSMOBILE.SLIDECATEGORYNEWS').subscribe((slideCategoryNews) => {
      this.introTutorialStepsMobile[14].description = slideCategoryNews;
    });
    this.translate.get('INTROTUTORIALSTEPSMOBILE.SLIDETYPECNN').subscribe((slideTypeCnn) => {
      this.introTutorialStepsMobile[15].description = slideTypeCnn;
    });
    this.translate.get('INTROTUTORIALSTEPSMOBILE.SLIDEFORM').subscribe((slideForm) => {
      this.introTutorialStepsMobile[16].description = slideForm;
    });
    this.translate.get('INTROTUTORIALSTEPSMOBILE.CREATEBUTTON').subscribe((createButton) => {
      this.introTutorialStepsMobile[17].description = createButton;
    });
    this.translate.get('INTROTUTORIALSTEPSMOBILE.MOBILECLOSECONTENT').subscribe((mobileCloseContent) => {
      this.introTutorialStepsMobile[18].description = mobileCloseContent;
    });
    this.translate.get('INTROTUTORIALSTEPSMOBILE.SLIDEITEMINNER').subscribe((slideItemInner) => {
      this.introTutorialStepsMobile[19]['next .slide-item-inner'] = slideItemInner;
    });
    this.translate.get('INTROTUTORIALSTEPSMOBILE.NEXTBUTTON').subscribe((nextButton) => {
      this.introTutorialStepsMobile[19].nextButton.text = nextButton;
    });
  }

  startIfAvailable(){

  }

  getIntegrationTypes() {
    this.integrationsSrv.getIntegrationTypes()
      .subscribe( integrationTypes => {
        if(integrationTypes) {
          this.integrationTypes = integrationTypes;
        }
      });
  }

  getShowTutorial() {
    this.storageSrv.currentUserSubject.subscribe(currentUser => {
      if (currentUser != null){
        this.showTutorial = currentUser.showTutorial;
      }
    });
  }

  openHelpIntegrationPlatforms() {
    this.sharedSrv.openDialog(
      {
        integrationTypes: this.integrationTypes
      },
      true,
      null,
      HelpIntegratingPlatformsComponent
    ).subscribe(response => {
      if (response.outputData) {
        // Do nothing
        this.onShowHelp(response.outputData as string);
      }
    });
  }

  close(){
    this.imReady();
    this.showTutorial = false;
  }

  imReady(){
    var userInfo = this.storageSrv.currentUserInfo;
    userInfo.showTutorial = false;
    this.usersSrv.updateUserInfo({showTutorial:false})
      .subscribe(response => {
        this.storageSrv.currentUserInfo = response;
      });
  }

  startIntroTutorial(){
    var enjoyhint_instance = null;
    enjoyhint_instance = new EnjoyHint({});
    if (document.body.offsetWidth <= 575){
      enjoyhint_instance.setScript(this.introTutorialStepsMobile);
    } else if (document.body.offsetWidth <= 768) {
      enjoyhint_instance.setScript(this.introTutorialStepsTablet);
    } else {
      enjoyhint_instance.setScript(this.introTutorialSteps);
    }
    enjoyhint_instance.runScript()
  }

  onShowHelp(url: string){
    this.showHelp = true;
    this.helpUrl = url;
    this.close();
  }

  openExternalPage(){
    window.open(this.helpUrl, "_blank");
  }


}
