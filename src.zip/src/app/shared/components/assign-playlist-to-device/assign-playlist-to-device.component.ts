import { Component, OnInit, Inject, AfterViewChecked, ViewChild, AfterViewInit } from '@angular/core';
import { CleanOnDestroy } from '../../classes/clean-destroy';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ENTER, TAB } from '@angular/cdk/keycodes';
import { MatSelectChange, MatSelect } from '@angular/material/select';
import { TranslateService } from '@ngx-translate/core';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { Device } from '../../models/device-models/device.model';
import { Schedule } from '../../models/schedule-models/schedule.model';

import { DeviceV3 } from 'src/app/shared/models/device-models/device-v3.model';
import { Pagination } from 'src/app/shared/models/common-models/pagination.model';

import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from '../../services/storage.service';
import { DevicesService } from 'src/app/shared/services/devices.service';

@Component({
  selector: 'app-assign-playlist-to-device',
  templateUrl: './assign-playlist-to-device.component.html',
  styleUrls: ['./assign-playlist-to-device.component.scss']
})
export class AssignPlaylistToDeviceComponent extends CleanOnDestroy implements OnInit {

  currentWorkspace: Workspace;
  currentLocale: any = '';
  addOnBlur = true;
  separatorKeysCodes: number[] = [ENTER, TAB];

  // workspace devices list
  devices: DeviceV3[] = [];
  devicesPaginate: Pagination = { count: 0, limit: 0, next: '', offset: 0 };

  assignDeviceForm: FormGroup;

  // sort devices by ids
  devicesByIds: { [key: number]: DeviceV3 } = {};

  @ViewChild('multiSelect') multiSelect: MatSelect;

  constructor(
    public utilSrv: UtilService,
    private translate: TranslateService,
    public dialogRef: MatDialogRef<AssignPlaylistToDeviceComponent>,
    private storageSrv: StorageService,
    private devicesSrv: DevicesService,
    private fb: FormBuilder
  ) {
    super();

    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.currentLocale = this.utilSrv.locale;
    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe(workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;
          this.getDevices();
          this.generateAssignDeviceForm();
        }
      });
  }



  /**
   * get devices from storage service
   * @param null
   * @return null
   */
  generateAssignDeviceForm() {
    this.assignDeviceForm = this.fb.group({
      deviceId: [null, [Validators.required]]
    })
  }

  /**
   * get devices from storage service
   * @param null
   * @return null
   */
  getDevices() {
    // this.storageSrv.devicesSubject.subscribe(devices => {
    //   if (devices) {
    //     this.devices = devices;
    //     this.devicesByIds = {};
    //     this.devices.forEach(device => {
    //       this.devicesByIds[device.id] = device;
    //     });
    //   }
    // });
    this.subscriber = this.devicesSrv.getDevices(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    )
      .subscribe( response => {
        if(response) {
          this.devices = response.message;
          this.devicesPaginate = response.pagination;
          this.devicesByIds = {};
          this.devices.forEach(device => {
            this.devicesByIds[device.id] = device;
          });
        }
      });
  }


  /**
   * calls from template
   * helper function for ngFor optimization
   *
   * @param index is a current index of item
   * @param item is a current item
   *
   * @return `number`
   */
  onTrackById(index: number, item: { id: number }) {
    return item.id;
  }

  /**
   * close dialog and continue
   * @param null
   * @return `null`
   */
  onContinue() {
    this.dialogRef.close({
      continue: true,
      outputData: {
        deviceId: this.assignDeviceForm.get('deviceId').value,
      }
    });
  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

}
