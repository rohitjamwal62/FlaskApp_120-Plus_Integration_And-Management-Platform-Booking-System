import { Component, OnInit, Inject, ViewChild, AfterViewInit } from '@angular/core';
import { UtilService } from 'src/app/shared/services/util.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CleanOnDestroy } from '../../classes/clean-destroy';
import { MatSelectChange, MatSelect } from '@angular/material/select';
import { TranslateService } from '@ngx-translate/core';

import { Device } from '../../models/device-models/device.model';
import { DeviceV3 } from '../../models/device-models/device-v3.model';
import { Schedule } from '../../models/schedule-models/schedule.model';
import { ScheduleV3 } from '../../models/schedule-models/schedule-v3.model';

import { StorageService } from '../../services/storage.service';

@Component({
  selector: 'app-assign-schedule',
  templateUrl: './assign-schedule.component.html',
  styleUrls: ['./assign-schedule.component.scss']
})
export class AssignScheduleComponent extends CleanOnDestroy implements OnInit, AfterViewInit {

  currentLocale: any = '';
  schedules: Schedule[] = [];
  schedulesByIds: { [key: number]: Schedule };
  selectedScheduleIds: number[] = [];
  @ViewChild('multiSelect', { static: true }) multiSelect: MatSelect;

  constructor(
    public utilSrv: UtilService,
    private translate: TranslateService,
    private storageSrv: StorageService,
    public dialogRef: MatDialogRef<AssignScheduleComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      device: DeviceV3,
      deviceSchedules: ScheduleV3[]
    }
  ) { 
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.currentLocale = this.utilSrv.locale;
    this.getSchedules();
  }

  ngAfterViewInit() {
    if (this.data) {
      this.selectedScheduleIds = [];
      let selectedScheduleIds = [];
      // this.data.assignedSchedules.forEach(schedule => {
      //   selectedScheduleIds.push(schedule.id);
      // });
      if(this.data.deviceSchedules && this.data.deviceSchedules.length > 0) {
        this.data.deviceSchedules.forEach(schedule => {
          selectedScheduleIds.push(schedule.id);
        });
      }
      
      if (this.multiSelect && selectedScheduleIds.length > 0) {
        setTimeout(() => {
          this.selectedScheduleIds = selectedScheduleIds;
          this.multiSelect.writeValue(this.selectedScheduleIds);
        }, 1000)
      }
    }
  }
  /**
 * get schedules from StorageService
 * @param null
 * @return null
 */
  getSchedules() {
    this.subscriber = this.storageSrv.schedulesSubject.subscribe(schedules => {
      if (schedules) {
        this.schedules = schedules;
        this.schedulesByIds = {}
        this.schedules.forEach(schedules => {
          this.schedulesByIds[schedules.id] = schedules;
        });
      }
    })
  }

  /**
   * close dialog without changes
   * 
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * close dialog and continue
   * @param null
   * @return `null`
   */
  onContinue() {
    let scheduleIds: number[] = [];
    this.selectedScheduleIds.forEach(id => {
      //scheduleIds.push({ id: id, location: '' });
      scheduleIds.push(id);
    })
    this.dialogRef.close({
      continue: true, 
      outputData: {
        device: this.data,
        schedules: scheduleIds
      }
    });
  }

  /**
   * calls from template
   * helper function for ngFor optimization
   * @param index is a current index of item
   * @param item is a current item
   * @return `number`
   */
  onTrackById(index: number, item: { id: number }) {
    return item.id;
  }


  /**
   * calls from template
   * replace new assigned devices list with old one
   * @param event is a output event object of `MatSelectChange`
   * @return `null`
   */
  onAssignSchedule(event: MatSelectChange) {
    this.selectedScheduleIds = event.value as number[];
  }

  /**
   * calls from template
   * when user clicked on the chip remove button 
   * remove assigned schedule and update mat select selected options
   * @param event is a output event object of `MatSelectChange`
   * @return `null`
   */
  onRemoveAssignedSchedule(deviceIndex: number, multiSelect: MatSelect) {
    this.selectedScheduleIds.splice(deviceIndex, 1);
    multiSelect.writeValue(this.selectedScheduleIds);
  }


}
