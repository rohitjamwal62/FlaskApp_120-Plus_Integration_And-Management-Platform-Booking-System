import { Component, OnInit, Inject, AfterViewChecked, ViewChild, AfterViewInit } from '@angular/core';
import { CleanOnDestroy } from '../../classes/clean-destroy';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ENTER, TAB } from '@angular/cdk/keycodes';
import { MatSelectChange, MatSelect } from '@angular/material/select';
import { TranslateService } from '@ngx-translate/core';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { Schedule } from '../../models/schedule-models/schedule.model';
import { Device } from '../../models/device-models/device.model';

import { DeviceV3 } from 'src/app/shared/models/device-models/device-v3.model';
import { Pagination } from 'src/app/shared/models/common-models/pagination.model';

import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from '../../services/storage.service';
import { DevicesService } from 'src/app/shared/services/devices.service';

@Component({
  selector: 'app-assign-to-device',
  templateUrl: './assign-to-device.component.html',
  styleUrls: ['./assign-to-device.component.scss']
})
export class AssignToDeviceComponent extends CleanOnDestroy implements OnInit {

  currentWorkspace: Workspace;
  currentLocale: any = '';
  addOnBlur = true;
  separatorKeysCodes: number[] = [ENTER, TAB];

  // workspace devices list
  devices: DeviceV3[] = [];
  devicesPaginate: Pagination = { count: 0, limit: 0, next: '', offset: 0 };

  assignDeviceForm: FormGroup;
  // schedules list
  schedules: Schedule[] = [];

  // stored assigned devices
  selectedDeviceIds: number[] = [];

  // sort devices by ids
  devicesByIds: { [key: number]: DeviceV3 } = {};

  @ViewChild('multiSelect', { static: true }) multiSelect: MatSelect;

  newSchedule: string = '';

  constructor(
    public utilSrv: UtilService,
    private translate: TranslateService,
    private storageSrv: StorageService,
    private devicesSrv: DevicesService,
    public dialogRef: MatDialogRef<AssignToDeviceComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      schedule: Schedule,
      shouldSelectSchedule: boolean,
      assignedDevices: { id: number }[]
    },
    private fb: FormBuilder
  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {

    this.currentLocale = this.utilSrv.locale;
    this.translate.get('ASSIGNDEVICE.NEWSCHEDULE').subscribe((string) => {
      this.newSchedule = string;
    });

    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe(workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;
          this.getDevices();
          this.generateAssignDeviceForm();
          if (this.data) {
            if (!this.data.shouldSelectSchedule) {
              let scheduleName = this.data.schedule.scheduleName;
              scheduleName = scheduleName ? scheduleName : this.newSchedule;
              this.assignDeviceForm.get('scheduleId').patchValue(scheduleName);
              this.assignDeviceForm.get('scheduleId').disable();
            } else {
              this.schedules = this.storageSrv.schedules;
            }
          } else {
            this.onCloseWithoutChanges();
          }
        }
      });
  }



  /**
   * get devices from storage service
   * @param null
   * @return null
   */
  generateAssignDeviceForm() {
    this.assignDeviceForm = this.fb.group({
      scheduleId: [null, [Validators.required]]
    })
  }

  /**
   * get devices from storage service
   * @param null
   * @return null
   */
  getDevices() {
    // this.storageSrv.devicesSubject.subscribe(devices => {
    //   if (devices) {
    //     this.devices = devices;
    //     this.devicesByIds = {};
    //     this.devices.forEach(device => {
    //       this.devicesByIds[device.id] = device;
    //     });
    //     if (this.data.assignedDevices) {
    //       this.getAssignedDevices(this.data.assignedDevices);
    //     }
    //   }
    // });
    this.subscriber = this.devicesSrv.getDevices(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    )
      .subscribe( response => {
        if(response) {
          this.devices = response.message;
          this.devicesPaginate = response.pagination;
          this.devicesByIds = {};
          this.devices.forEach(device => {
            this.devicesByIds[device.id] = device;
          });
          if (this.data.assignedDevices) {
            this.getAssignedDevices(this.data.assignedDevices);
          }
        }
      });
  }

  /**
   * get assigned devices for current schedule
   * @param event is a object of `selectionChange` event
   * @return `null`
   */
  getAssignedDevices(assignedDevices: { id: number }[]) {
    if (assignedDevices) {
      this.selectedDeviceIds = [];
      assignedDevices.forEach(device => {
        this.selectedDeviceIds.push(device.id);
      });
      if (this.multiSelect) {
        setTimeout(() => {
          this.multiSelect.writeValue(this.selectedDeviceIds);
        }, 1000);
      }
    }
  }

  /**
   * calls from template
   * output event of schedule select box
   * get assigned devices for current schedule by id `event.value`
   * and update `deviceSelectRef` for select assigned devices
   *
   * @param event is a object of `selectionChange` event
   * @param deviceSelectRef is a mat select reference of devices
   *
   * @return `null`
   */
  onChangeSchedule(event: MatSelectChange, deviceSelectRef: MatSelect) {
    let scheduleId = event.value;
    this.schedules.every(schedule => {
      if (schedule.id === scheduleId) {
        this.getAssignedDevices(schedule.assignedDevices);
        deviceSelectRef.writeValue(this.selectedDeviceIds);
        return false;
      }
      return true;
    })
  }

  /**
   * calls from template
   * output event of mat select (selectionChange)
   * @param event is a object of `selectionChange` event
   * @return `null`
   */
  onAssignDeivce(event: MatSelectChange) {
    this.selectedDeviceIds = event.value as number[];
  }

  /**
   * calls from template
   * remove assigned device with index `deviceIndex`
   * and update selected items opf element `multiSelect`
   *
   * @param deviceIndex is a index of assigned deivce which should be deleted
   * @param multiSelect is a element referance of material select
   *
   * @return `null`
   */
  onRemoveAssignedDevice(deviceIndex: number, multiSelect: MatSelect) {
    this.selectedDeviceIds.splice(deviceIndex, 1);
    multiSelect.writeValue(this.selectedDeviceIds);
  }

  /**
   * calls from template
   * helper function for ngFor optimization
   *
   * @param index is a current index of item
   * @param item is a current item
   *
   * @return `number`
   */
  onTrackById(index: number, item: { id: number }) {
    return item.id;
  }

  /**
   * close dialog and continue
   * @param null
   * @return `null`
   */
  onContinue() {
    let devices: { id: number }[] = [];
    this.selectedDeviceIds.forEach(deviceId => {
      devices.push({ id: deviceId });
    })
    this.selectedDeviceIds
    this.dialogRef.close({
      continue: true,
      outputData: {
        scheduleId: this.assignDeviceForm.get('scheduleId').value,
        assignedDevices: devices
      }
    });
  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

}
