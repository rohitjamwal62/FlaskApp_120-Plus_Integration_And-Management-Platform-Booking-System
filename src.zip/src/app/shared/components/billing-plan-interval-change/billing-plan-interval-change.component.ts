import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UtilService } from 'src/app/shared/services/util.service';
import { Subscription } from 'src/app/shared/models/common-models/subscription.model';
import { ArraySortPipe } from 'src/app/shared/pipes/sorted.pipe';
import { TranslateService } from '@ngx-translate/core';

// Utils
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

@Component({
  selector: 'app-billing-plan-interval-change',
  templateUrl: './billing-plan-interval-change.component.html',
  styleUrls: ['./billing-plan-interval-change.component.scss']
})
export class BillingPlanIntervalChangeComponent implements OnInit {

  convertForm: FormGroup
  currentSubscriptionOptions: Subscription[] = [];

  constructor(
    public utilSrv: UtilService,
    private translate: TranslateService,
    public dialogRef: MatDialogRef<BillingPlanIntervalChangeComponent>,
    private fb: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data: { 
      subscriptions: Subscription[], 
      interval: string, 
      tier: string, 
      mode: string
    }
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    if (this.data && this.data.mode === "tier"){
      // create tier list
      this.generateForm();
      this.getSubscriptionsByTier(this.data.tier, this.data.interval);

    } else {
      // create interval list
      this.generateForm();
      this.getSubscriptionsByInterval(this.data.interval, this.data.tier);
    }
  }

  /**
   * generate `createFolderForm`
   * @param parentId is a parent folder id with type `number`
   * @return `null`
   */

  generateForm() {
    this.convertForm = this.fb.group({
      subscriptionId: ['', [Validators.required]],
    })
  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * close dialog and create folder
   * @param null
   * @return `null`
   */
  onSubmitForm() {
    if (this.convertForm.valid) {
      this.dialogRef.close({
        continue: true,
        outputData: this.convertForm.getRawValue()
      })
    }
  }

  getSubscriptionsByInterval(interval: string, tier: string){
    this.currentSubscriptionOptions = [];
    for (var i = 0; i < this.data.subscriptions.length; i++){
      if (this.data.subscriptions[i].interval !== interval && this.data.subscriptions[i].tier === tier){
        this.currentSubscriptionOptions.push(this.data.subscriptions[i]);
      }
    }
  }

  getSubscriptionsByTier(tier: string, interval: string){
    this.currentSubscriptionOptions = [];
    for (var i = 0; i < this.data.subscriptions.length; i++){
      if (this.data.subscriptions[i].tier !== tier && this.data.subscriptions[i].interval === interval){
        this.currentSubscriptionOptions.push(this.data.subscriptions[i]);
      }
    }
  }

  dollarFormat(num){
    return "$"+ num.toFixed(2);
  }

}
