import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { BoldcastFilestackComponent } from './boldcast-filestack.component';

describe('BoldcastFilestackComponent', () => {
  let component: BoldcastFilestackComponent;
  let fixture: ComponentFixture<BoldcastFilestackComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ BoldcastFilestackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BoldcastFilestackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
