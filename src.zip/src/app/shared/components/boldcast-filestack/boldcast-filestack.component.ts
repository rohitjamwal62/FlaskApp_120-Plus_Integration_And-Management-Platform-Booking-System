import { Component, OnInit, Inject } from '@angular/core';
import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { IntegrationsService } from 'src/app/shared/services/integrations.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';

import { OAuthResourceOption } from '../../models/common-models/oauth-resource-option.model';

@Component({
  selector: 'app-boldcast-filestack',
  templateUrl: './boldcast-filestack.component.html',
  styleUrls: ['./boldcast-filestack.component.scss']
})
export class BoldcastFilestackComponent implements OnInit {

	workspaceId: number = 0;

	boldcastFolders: OAuthResourceOption[] = [];
  boldcastFolderTrails: OAuthResourceOption[] = [];
  selectedFolder: OAuthResourceOption;

  constructor(
  	private translate: TranslateService,
    public utilSrv: UtilService,
    private storageSrv: StorageService,
    private sharedSrv: SharedService,
    private integrationsSrv: IntegrationsService,
    public dialogRef: MatDialogRef<BoldcastFilestackComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
    	workspaceId: number;
      folders: OAuthResourceOption[];
    }
  ) { }

  ngOnInit() {
  	if(this.data) {
  		this.boldcastFolders = this.data.folders;
  		this.workspaceId = this.data.workspaceId;
      this.sortFolders();
  	}
  }

  onSelectFolder(folder) {
    this.selectedFolder = folder;
  }
  onSelectChildFolder(folder) {
    let filteredFolder = this.boldcastFolderTrails.filter( f => f.id == folder.id);
    if(filteredFolder.length == 0) {
      this.boldcastFolderTrails.push(folder);
    }
    this.integrationsSrv.getBoldcastChildFolders(this.workspaceId,folder.id).subscribe( assets => {
      if(assets) {
        this.boldcastFolders = assets;
        this.sortFolders();
      }
    });
  }
  onCurrentFolderClick() {
    this.boldcastFolderTrails = [];
    this.integrationsSrv.getBoldcastFolders(this.workspaceId).subscribe( folders => {
      if(folders) {
        this.boldcastFolders = folders;
        this.sortFolders();
      }
    });
  }
  onBoldcastFolderTrailsClick(folderId, trailIndex) {
    this.boldcastFolderTrails.length = trailIndex + 1;
    this.integrationsSrv.getBoldcastChildFolders(this.workspaceId, folderId).subscribe( assets => {
      if(assets) {
        this.boldcastFolders = assets;
        this.sortFolders();
      }
    });
  }

  sortFolders() {
    this.boldcastFolders.sort((a, b) => a.name.localeCompare(b.name));
  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  onContinue() {
    if (this.selectedFolder) {
      this.dialogRef.close({ continue: true, outputData: this.selectedFolder });
    }
  }

}
