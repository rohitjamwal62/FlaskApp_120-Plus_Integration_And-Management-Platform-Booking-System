import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { UtilService } from 'src/app/shared/services/util.service';
import { UsersService } from 'src/app/shared/services/users.service';

@Component({
  selector: 'app-change-profile-image',
  templateUrl: './change-profile-image.component.html',
  styleUrls: ['./change-profile-image.component.scss']
})
export class ChangeProfileImageComponent implements OnInit {

	imageUploadForm = new FormData();

  constructor(
  	public utilSrv: UtilService,
  	private userSrv: UsersService,
  	public dialogRef: MatDialogRef<ChangeProfileImageComponent>,
  	@Inject(MAT_DIALOG_DATA) public data: {
  		systemMessages: []
  	}
  ) { }

  ngOnInit() {
  }

  onChangeProfileImage(imageInput: HTMLInputElement) {
    // get choosed image
    let profileNewImage: File = imageInput.files[0];

    // check image extension
    let isValidExtension = this.utilSrv.checkProfileImageExtension(profileNewImage);

    if (isValidExtension) {
      this.imageUploadForm.append('file', profileNewImage);
    }
  }

  onUploadImage() {
  	this.userSrv.updateProfileImage(this.imageUploadForm).subscribe( image => {
  		this.dialogRef.close({ continue: true, outputData: null });
  	});
  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

}
