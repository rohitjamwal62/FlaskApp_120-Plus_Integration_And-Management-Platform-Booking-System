import { Component, OnInit, Inject } from '@angular/core';
import { CleanOnDestroy } from '../../classes/clean-destroy';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { TranslateService } from '@ngx-translate/core';
import { ChangeDetectorRef } from '@angular/core';
import * as filestack from 'filestack-js';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

import { Workspace } from '../../models/workspace-models/workspace.model';
import { SitebarItem } from '../../models/common-models/sitebar-item.model';
import { AssetFolder } from '../../models/asset-models/asset-folder.model';
import { AssetFile } from '../../models/asset-models/asset-file.model';
import { AccountFavorite } from '../../models/account-models/account-favorite.model';
import { UserFavorite } from '../../models/user-models/user-favorite.model';
import { WorkspaceFavorite } from '../../models/workspace-models/workspace-favorite.model';
import { FilesStoreRequest } from 'src/app/shared/models/requests-models/files-store.model';

import { Pagination } from 'src/app/shared/models/common-models/pagination.model';
import { AssetFileV3 } from 'src/app/shared/models/asset-models/asset-file-v3.model';
import { AssetFolderV3 } from 'src/app/shared/models/asset-models/asset-folder-v3.model';
import { FilesStoreV3Request } from 'src/app/shared/models/requests-models/files-store-v3.model';

import { UtilService } from '../../services/util.service';
import { ContentService } from '../../services/content.service';
import { StorageService } from '../../services/storage.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { AssetFilesService } from 'src/app/shared/services/asset-files.service';
import { AssetFoldersService } from 'src/app/shared/services/asset-folders.service';
import { AssetsMetadataService } from 'src/app/shared/services/assets-metadata.service';

@Component({
  selector: 'app-choose-file',
  templateUrl: './choose-file.component.html',
  styleUrls: ['./choose-file.component.scss']
})
export class ChooseFileComponent extends CleanOnDestroy implements OnInit {
  // user selected workspace
  currentWorkspace: Workspace;

  // available space
  availableSpace: number;

  // sitebar content item
  sitebarContentItem: SitebarItem;
  uploadPicker: any;

  //storedAssetFiles: AssetFileV3[] = [];
  //currentParentFolder: AssetFolderV3;
  //currentFolderFiles: AssetFileV3[] = [];
  //currentFolderId: number;

  folderImage: string = '';
  selectedFile: AssetFileV3;
  assetFolders: AssetFolderV3[];
  assetFiles: AssetFileV3[];
  assetFolderFiles: AssetFolderV3[] | AssetFileV3[];
  defaultParentFolderId: number;
  selectedChildFolder: AssetFolderV3;
  assetPaginate: Pagination;
  assetChildPaginate: Pagination;

  // Breadcrumbs
  folderTrails: AssetFolderV3[] = [];
  tempFiles: any[] = [];

  // accountFavorites: AccountFavorite[] = [];
  // userFavorites: UserFavorite[] = [];
  // workspaceFavorites: WorkspaceFavorite[] = [];

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private storageSrv: StorageService,
    private sharedSrv: SharedService,
    private contentSrv: ContentService,
    private assetFilesSrv: AssetFilesService,
    private assetFolderSrv: AssetFoldersService,
    private assetMetadataSrv: AssetsMetadataService,
    private cdr: ChangeDetectorRef,
    public dialogRef: MatDialogRef<ChooseFileComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      allowedFileTypes: string[],
      selectedFile: string
    },
  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    // get content sitebar item
    this.sitebarContentItem = this.utilSrv.getSitebarItem('content');
    this.folderImage = this.utilSrv.appImages.folder;

    this.storageSrv.selectedWorkspaceSubject
      .subscribe(workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;
          this.initializeFilestack(this.currentWorkspace);
          //this.getWorskspaceFolders();
          //this.getWorkspaceFiles();
          this.getWorkspaceFoldersAndFiles();
          //console.log('allowedFileTypes', this.data);
        }
      });
  }

  /*----- Breadcrumbs -----*/
  backToContent() {
    this.folderTrails.length = 0;
    this.selectedChildFolder = null;
    this.getWorkspaceFoldersAndFiles();
  }
  onTrailsClick(folder, index) {
    // if(this.folderTrails && this.folderTrails.length != 0) {
    //   this.folderTrails.length = parseInt(index) + 1;
    // } else {
    //   this.folderTrails.length = 0;
    // }
    // this.assetFolders.every(f => {
    //   if (f.id == +folder.id) {
    //     this.currentParentFolder = f;
    //     return false;
    //   }
    //   return true;
    // });
    if(this.folderTrails && this.folderTrails.length != 0) {
      this.folderTrails.length = parseInt(index) + 1;
    } else {
      this.folderTrails.length = 0;
    }
    this.selectedChildFolder = folder;
    this.getChildrenFilesFolders();
  }

  getWorkspaceFoldersAndFiles(){
    this.assetFolderSrv.getFolders(
      this.currentWorkspace.account.id, 
      this.currentWorkspace.id
    )
      .subscribe( response => {
        if(response.message) {
          let assets: any = response.message;
          if(assets.length > 0 && assets[0].hasOwnProperty('parentFolder')) {
            this.defaultParentFolderId = assets[0]?.parentFolder;
          }
          this.assetFolders = [];
          this.assetFiles = [];
          this.assetFolderFiles = assets;
          this.assetPaginate = response.pagination;
          assets.forEach( asset => {
            if(asset.type == 'boldcast/folder') {
              this.assetFolders.push(asset);
            } else {
              this.assetFiles.push(asset);
            }
          });
        }
      });
  }

  getFoldersAndFilesNext() {
    this.assetFolderSrv.getFoldersNext(
      this.assetPaginate.next
    )
      .subscribe( response => {
        if(response.message) {
          let assets: any = response.message;
          this.assetPaginate = response.pagination;
          this.assetFolderFiles.push(...assets);
          assets.forEach( asset => {
            if(asset.type == 'boldcast/folder') {
              this.assetFolders.push(asset);
            } else {
              this.assetFiles.push(asset);
            }
          });
        }
      });
  }

  getChildrenFilesFolders() {
    this.assetFolderSrv.retrieveChildrenFilesFolders(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.selectedChildFolder.id
    )
      .subscribe( response => {
        if(response.message) {
          let assets: any = response.message;
          this.assetFolders = [];
          this.assetFiles = [];
          this.assetFolderFiles = assets;
          this.assetChildPaginate = response.pagination;
          assets.forEach( asset => {
            if(asset.type == 'boldcast/folder') {
              this.assetFolders.push(asset);
            } else {
              this.assetFiles.push(asset);
            }
          });
        }
      });
  }

  getFoldersChildNext() {
    this.assetFolderSrv.retrieveChildrenFilesFoldersNext(
      this.assetChildPaginate.next
    )
      .subscribe( response => {
        if(response.message) {
          let assets: any = response.message;
          this.assetChildPaginate = response.pagination;
          this.assetFolderFiles.push(...assets);
          assets.forEach( asset => {
            if(asset.type == 'boldcast/folder') {
              this.assetFolders.push(asset);
            } else {
              this.assetFiles.push(asset);
            }
          });
        }
      });
  }


  /**
   * calls when changed selected workspace
   * get workspace storage info with type `AssetSizeInfo`
   * which contains used space and total space infos
   * @param null
   * @return `null`
   */
  // getWorskspaceFolders() {
  //   this.contentSrv.getFolders(this.currentWorkspace.id)
  //     .subscribe(assetFolders => {
  //       this.assetFolders = assetFolders;
  //       this.openSelectedFolder();
  //     });
  // }

  /**
   * calls when changed selected workspace
   * get workspace storage info with type `AssetSizeInfo`
   * which contains used space and total space infos
   * @param null
   * @return `null`
   */
  // getWorkspaceFiles() {
  //   this.contentSrv.getAllFiles(this.currentWorkspace.id)
  //     .subscribe(assetFiles => {
  //       this.storedAssetFiles = assetFiles;
  //       this.assetFiles = assetFiles;
  //     });
  // }

  checkAllowedFileTypes(file) {
    //let extension = file.assetExtension.split('/')[1];
    let extension = file.type.split('/')[1];
    if(this.data.allowedFileTypes.indexOf(extension) >= 0) {
      return true;
    }
    return false;
  }


  /**
   * calls when receive `assetsFolder` Info
   * find and set as selected folder workspace parent folder
   * @param null
   * @return `null`
   */
  // openSelectedFolder() {
  //   this.assetFolders.every(folder => {
  //     if (folder && !folder.parentFolder) {
  //       this.currentParentFolder = folder;
  //       return false;
  //     }
  //     return true;
  //   })
  // }

  /**
   * calls from template
   * store user selected file
   * @param file with type `AssetFile`
   * @return `null`
   */
  onSelectFile(file: AssetFileV3) {
    this.selectedFile = file;
  }

  /**
   * calls from template
   * helper for a optimizing *ngFor
   * @param index is a current element index with type `number`
   * @param item is a current element info with type `Workspace`
   * @return `number`
   */
  onTrackById(index: number, item: AssetFileV3 | AssetFolderV3) {
    return item.id;
  }

  /**
   * calls from template
   * store user opened folder
   * for a show those files which `parentFolder.id === currentParentFolder.id`
   *
   * @param folderId with type `number` which should be opened
   * @return `null`
   */
  onOpenFolder(folder, folderId: number) {
    // let folderTrails = this.folderTrails;
    // let folderIndex = folderTrails.findIndex( index => index.id == folderId);
    // if(folderIndex == -1) {
    //   this.folderTrails.push(folder);
    // }
    // this.assetFolders.every(folder => {
    //   if (folder.id == +folderId) {
    //     this.currentParentFolder = folder;
    //     return false;
    //   }
    //   return true;
    // })
    let folderTrails = this.folderTrails;
    let folderIndex = folderTrails.findIndex( index => index.id == folder.id);
    if(folderIndex == -1) {
      this.folderTrails.push(folder);
    }
    this.selectedChildFolder = folder;
    this.getChildrenFilesFolders();
  }

  /**
   * calls from template
   * check file type and return corresponding image url
   * @param file with type `AssetFile`
   * @return `null`
   */
  // onShowFileImage(file: AssetFileV3) {
  //   let imageEndpoint = `${this.utilSrv.env.endPoint}/api/v1/assets/files/`;
  //   let fileImage: string = '';
  //   if (file.assetExtension.indexOf('image') >= 0) {
  //     fileImage = imageEndpoint + file.id + '/download/'
  //   } else {
  //     fileImage = this.utilSrv.fileIcons[file.assetExtension];
  //   }
  //   return fileImage;
  // }
  onShowFileImage(file: AssetFileV3) {
    let orgId = this.currentWorkspace.account.id;
    let workspaceId = this.currentWorkspace.id;
    let imageEndpoint = `${this.utilSrv.env.endPoint}/api/v3/orgs/${orgId}/workspaces/${workspaceId}/assets/files/`;
    let fileImage: string = '';
    if (file.type == 'image/jpg' ||
      file.type == 'image/jpeg' ||
      file.type == 'image/png' ||
      file.type == 'image/gif' ) {
      fileImage = imageEndpoint + file.id + '/thumbnail/';
    } else {
      fileImage = this.utilSrv.fileIcons[file.type];
    }
    return fileImage;
  }

  /**
   * calls when changed selected workspace
   * get workspace storage info with type `AssetSizeInfo`
   * which contains used space and total space infos
   * @param null
   * @return `null`
   */
  getWorkspaceStorageSpace() {
    // this.contentSrv.getAssetsSize(this.currentWorkspace.id)
    //   .subscribe(assetsSize => {
    //     let availableSpace = assetsSize.total - assetsSize.used;
    //     this.availableSpace = (availableSpace / 1024 / 1024 / 1024);
    //   });
    this.assetMetadataSrv.getSizeOfAssets(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    )
      .subscribe( assetsSize => {
        let availableSpace = assetsSize.total - assetsSize.used;
        this.availableSpace = (availableSpace / 1024 / 1024 / 1024);
      })
  }

  /**
   * calls when changed selected workspace
   * get workspace signature initialize filestack and set options
   * @param workspaceId is a workspace id which signature should be retrive
   * @return `null`
   */
  initializeFilestack(workspace: Workspace) {
    // this.contentSrv.getWorkspaceSignature(workspace.id).subscribe(security => {
    //   this.uploadPicker = filestack.init('AyICa710SKHijIQhQZ2UQz', { "security": security });
    // });
    this.assetMetadataSrv.getUploadPolicySignature(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    )
      .subscribe( security => {
        this.uploadPicker = filestack.init('AyICa710SKHijIQhQZ2UQz', { "security": security });
      })
  }

  /**
   * calls from template
   * when user clicked on the `Upload` button
   *
   * open dialog for a choose some files,
   * copy and past or drang and drop files
   *
   * after closed dialog upload chosed files
   * in case of user clicked on the upload button
   *
   * @param null
   * @return `null`
   */
  onUploadFile() {
    // if (this.uploadPicker && this.currentParentFolder) {
    //   if (this.storageSrv.currentAccount && this.currentWorkspace) {
    //     let uploadPicker = this.uploadPicker.picker(
    //       this.utilSrv.fileStackOptionsInit(
    //         this.currentWorkspace,
    //         this.storageSrv.currentAccount,
    //         this.currentParentFolder.id,
    //         this.uploadFiles.bind(this),
    //         this.sharedSrv.errorDialog
    //       )
    //     );
    //     uploadPicker.open();
    //   }
    // }
    let parentFolderId = (this.selectedChildFolder) ? this.selectedChildFolder.id : this.defaultParentFolderId;
    if (this.uploadPicker && this.defaultParentFolderId) {
      if (this.storageSrv.currentAccount && this.currentWorkspace) {
        let uploadPicker = this.uploadPicker.picker(
          this.utilSrv.fileStackOptionsInitV3(
            this.currentWorkspace,
            this.storageSrv.currentAccount,
            parentFolderId,
            this.uploadFilesV3.bind(this),
            this.sharedSrv.errorDialog
          )
        );
        uploadPicker.open();
      }
    }
  }

  uploadFilesV3(uploadFileForm: FilesStoreV3Request) {

    for (let f in uploadFileForm['files']) {
      this.tempFiles.push(uploadFileForm['files'][f]);
    }

    this.assetFilesSrv.addAssetsToWorkspace(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      uploadFileForm
    )
      .subscribe(uploadedFiles => {
        if(uploadedFiles) {
          if(this.selectedChildFolder) {
            this.getChildrenFilesFolders();
          } else {
            this.getWorkspaceFoldersAndFiles();
          }
          this.cdr.detectChanges();
          this.tempFiles = [];
          this.getWorkspaceStorageSpace();
        }
      })
  }

  /**
   * `utilSrv.fileStackOptionsInit` callback function
   * calls from filestackApi `options.onUploadDone`
   * upload user select files and update `assetFiles` property
   * @param uplodFileForm is array of files which already uploaded on the
   * storage and should be store files info in the server
   * (type `FilesStoreRequest`)
   * @return `null`
   */
  // uploadFiles(uploadFileForm: FilesStoreV3Request) {
  //   for (let f in uploadFileForm['assets']) {
  //     this.tempFiles.push(uploadFileForm['assets'][f]);
  //   }
  //   this.assetFilesSrv.addAssetsToWorkspace(
  //     this.currentWorkspace.account.id,
  //     this.currentWorkspace.id,
  //     uploadFileForm
  //   )
  //     .subscribe(uploadedFiles => {
  //       if(uploadedFiles) {
  //         uploadedFiles.forEach(file => {
  //           var found = false;
  //           for (var i = 0; i < this.assetFiles.length; i++){
  //             if (this.assetFiles[i].id == file.id){
  //               found = true;
  //               break;
  //             }
  //           }
  //           if (!found){
  //             this.storedAssetFiles.push(file);
  //           }
  //           this.cdr.detectChanges();
  //         });
  //         this.tempFiles = [];
  //         this.getWorkspaceStorageSpace();
  //       }
  //     })
  // }


  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  onContinue() {
    if (this.selectedFile && this.selectedFile.id >= 0) {
      this.dialogRef.close({ continue: true, outputData: this.selectedFile });
    }
  }

  canUpload() {
    return this.uploadPicker != null && this.storageSrv.getWorkspaceWritePermission(Resource.content);
  }

}
