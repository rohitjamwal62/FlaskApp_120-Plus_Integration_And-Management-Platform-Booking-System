import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';

import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { AssetFolder } from '../../models/asset-models/asset-folder.model';
import { AssetFile } from '../../models/asset-models/asset-file.model';
import { AssetsPatchRequest } from '../../models/requests-models/assets-patch.model';
import { AssetFolderV3 } from 'src/app/shared/models/asset-models/asset-folder-v3.model';
import { AssetFoldersUpdateRequest } from 'src/app/shared/models/requests-models/asset-folders-update.model';
import { AssetFileV3 } from 'src/app/shared/models/asset-models/asset-file-v3.model';
import { AssetFileUpdateRequest } from 'src/app/shared/models/requests-models/asset-file-update.model';
import { Pagination } from 'src/app/shared/models/common-models/pagination.model';

import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { ContentService } from 'src/app/shared/services/content.service';
import { AssetFoldersService } from 'src/app/shared/services/asset-folders.service';
import { AssetFilesService } from 'src/app/shared/services/asset-files.service';

@Component({
  selector: 'app-choose-folders',
  templateUrl: './choose-folders.component.html',
  styleUrls: ['./choose-folders.component.scss']
})
export class ChooseFoldersComponent implements OnInit {

  currentWorkspace: Workspace;
  parentFolderId: number;
  defaultParentFolder: AssetFolderV3;
  assetFolders: AssetFolderV3[];
  assetFoldersPaginate: Pagination;
  selectedChildFolder: boolean = false;

  // folder default image
  folderImage: string = '';

  selectedFolder: AssetFolderV3 = null;
  foldersToMove: AssetFolderV3[] = [];
  filesToMove: AssetFileV3[] = [];

  folderUpdateRequest: { folders: AssetFoldersUpdateRequest[] } = {
    folders: []
  };
  fileUpdateRequest: { files: AssetFileUpdateRequest[] } = {
    files: []
  };

  itemType: {
    folder: boolean,
    file: boolean
  } = { folder: false, file: false };

  // Breadcrumbs
  folderTrails: AssetFolderV3[] = [];

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private storageSrv: StorageService,
    private contentSrv: ContentService,
    private assetFolderSrv: AssetFoldersService,
    private assetFilesSrv: AssetFilesService,
    public dialogRef: MatDialogRef<ChooseFoldersComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      folderSelection: AssetFolderV3[],
      fileSelection: AssetFileV3[],
      parentFolderId: number
    },
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    if (this.data) {
      this.foldersToMove = this.data.folderSelection;
      this.filesToMove = this.data.fileSelection;
      this.parentFolderId = this.data.parentFolderId;
      this.itemType.folder = (this.foldersToMove && this.foldersToMove.length > 0) ? true : false;
      this.itemType.file = (this.filesToMove && this.filesToMove.length > 0) ? true : false;

      this.storageSrv.selectedWorkspaceSubject
        .subscribe(async(workspace) => {
          if (workspace) {
            this.currentWorkspace = workspace;
            this.getDefaultParentFolder(this.parentFolderId);
            this.getChildrenFilesFolders(this.parentFolderId);
          }
        });
    }

    this.folderImage = this.utilSrv.appImages.folder;
  }

  backToContent() {
    this.folderTrails.length = 0;
    this.selectedChildFolder = false;
    this.selectedFolder = null;
    this.getChildrenFilesFolders(this.parentFolderId);
  }

  onTrailsClick(folder, index) {
    if(this.folderTrails && this.folderTrails.length != 0) {
      this.folderTrails.length = parseInt(index) + 1;
    } else {
      this.folderTrails.length = 0;
    }
    this.selectedChildFolder = true;
    this.selectedFolder = folder;
    this.getChildrenFilesFolders(folder.id);
  }

  getDefaultParentFolder(folderId: number) {
    this.assetFolderSrv.getAssetFolder(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      folderId
    )
      .subscribe( folder => {
        if(folder) {
          this.defaultParentFolder = folder;
        }
      });
  }

  getChildrenFilesFolders(folderId: number) {
    this.assetFolderSrv.retrieveChildrenFilesFolders(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      folderId
    )
      .subscribe( response => {
        if(response.message) {
          let assets: any = response.message;
          this.assetFoldersPaginate = response.pagination;
          this.assetFolders = assets;
          this.assetFolders.sort( (a, b) => a.name.localeCompare(b.name));
          this.removeFolderSelectionsFromList();
        }
      });
  }

  getFoldersChildNext() {
    this.assetFolderSrv.retrieveChildrenFilesFoldersNext(
      this.assetFoldersPaginate.next
    )
      .subscribe( response => {
        if(response.message) {
          let assets: any = response.message;
          this.assetFoldersPaginate = response.pagination;
          this.assetFolders.push(...assets);
          this.assetFolders.sort( (a, b) => a.name.localeCompare(b.name));
          this.removeFolderSelectionsFromList();
        }
      });
  }

  removeFolderSelectionsFromList() {
    this.foldersToMove.forEach(  folder => {
      let index = this.assetFolders.findIndex( (assetFolder, index) => folder.id === assetFolder.id);
      if(index != -1) {
        this.assetFolders.splice(index, 1);
      }
    });
  }

  updateSelectedFolderParentFolderId() {
    this.folderUpdateRequest['folders'] = this.data.folderSelection.map( folder => {
      return { id: folder.id, folderId: this.selectedFolder.id, folderName: folder.name };
    })
  }

  updateSelectedFilesParentFolderId() {
    this.fileUpdateRequest['files'] = this.data.fileSelection.map( file => {
      return { id: file.id, folderId: this.selectedFolder.id };
    })
  }

  /**
   * calls from template
   * helper for a optimizing *ngFor
   * @param index is a current element index with type `number`
   * @param item is a current element info with type `Workspace`
   * @return `number`
   */
  onTrackById(index: number, item: { id: number }) {
    return item.id;
  }

  /**
   * calls from template
   * when user clicked on the folder for a select it
   * @param folder is a user selected folder
   * @return `null`
   */
  onSelectFolder(folder: AssetFolderV3) {
    if(this.selectedFolder && this.selectedFolder.id == folder.id) {
      this.selectedFolder = null;
    } else {
      this.selectedFolder = folder;
      this.updateSelectedFolderParentFolderId();
      this.updateSelectedFilesParentFolderId();
    }
  }

  /**
   * calls from template
   * store user opened folder
   * for a show those files which `parentFolder.id === currentParentFolder.id`
   * @param folderId with type `number` which should be opened
   * @return `null`
   */
  onOpenFolder(event: MouseEvent, folder: AssetFolderV3) {
    event.stopPropagation();
    let folderTrails = this.folderTrails;
    let folderIndex = folderTrails.findIndex( index => index.id == folder.id);
    if(folderIndex == -1) {
      this.folderTrails.push(folder);
    }
    this.selectedChildFolder = true;
    this.selectedFolder = folder;
    this.getChildrenFilesFolders(folder.id);
  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  onShowFileImage(file: AssetFileV3) {
    let orgId = this.currentWorkspace.account.id;
    let workspaceId = this.currentWorkspace.id;
    let imageEndpoint = `${this.utilSrv.env.endPoint}/api/v3/orgs/${orgId}/workspaces/${workspaceId}/assets/files/`;
    let fileImage: string = '';
    if (file.type == 'image/jpg' ||
      file.type == 'image/jpeg' ||
      file.type == 'image/png' ||
      file.type == 'image/gif' ) {
      fileImage = imageEndpoint + file.id + '/download/';
    } else {
      fileImage = this.utilSrv.fileIcons[file.type];
    }
    return fileImage;
  }

  /**
   * close with selected folder
   * @param null
   * @return `null`
   */
  onContinue() {
    if (this.selectedFolder) {
      if(this.itemType.folder && this.itemType.file) {
        this.updateFolders();
        this.updateFiles();
      } else {
        if(this.itemType.folder) {
          this.updateFolders();
        }
        if(this.itemType.file) {
          this.updateFiles();
        }
      }
    }
  }

  updateFolders() {
    this.assetFolderSrv.updateFolders(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.folderUpdateRequest
    ).subscribe(updatedFolders => {
      if (updatedFolders) {
        this.dialogRef.close({ continue: true, outputData: null });
      }
    });
  }

  updateFiles() {
    this.assetFilesSrv.updateFiles(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.fileUpdateRequest
    ).subscribe(updatedFiles => {
      if (updatedFiles) {
        this.dialogRef.close({ continue: true, outputData: null });
      }
    });
  }

}
