import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateAppFolderComponent } from './create-app-folder.component';

describe('CreateAppFolderComponent', () => {
  let component: CreateAppFolderComponent;
  let fixture: ComponentFixture<CreateAppFolderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateAppFolderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateAppFolderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
