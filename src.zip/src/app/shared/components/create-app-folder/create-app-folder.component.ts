import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { UtilService } from 'src/app/shared/services/util.service';

// Utils
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

@Component({
  selector: 'app-create-app-folder',
  templateUrl: './create-app-folder.component.html',
  styleUrls: ['./create-app-folder.component.scss']
})
export class CreateAppFolderComponent implements OnInit {

  createFolderForm: FormGroup;
  
  constructor(
    public utilSrv: UtilService,
    private translate: TranslateService,
    public dialogRef: MatDialogRef<CreateAppFolderComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { parentId: number },
    private fb: FormBuilder
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.generateCreateFolderForm(this.data.parentId);
  }

  /**
   * generate `createFolderForm`
   * 
   * @param parentId is a parent folder id with type `number`
   *
   * @return `null`
   */
  generateCreateFolderForm(parentId: number) {
    this.createFolderForm = this.fb.group({
      folderId: parentId,
      name: ['', [Validators.required, removeWhitespaceValidator]]
    })
  }

  /**
   * close dialog without changes
   * 
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * close dialog and create folder
   * 
   * @param null
   *
   * @return `null`
   */
  onCreateFolder() {
    if (this.createFolderForm.valid) {
      this.dialogRef.close({
        continue: true,
        outputData: this.createFolderForm.getRawValue()
      })
    }
  }

}
