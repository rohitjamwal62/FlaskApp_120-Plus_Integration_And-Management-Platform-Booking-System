import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';

// Services
import { UtilService } from 'src/app/shared/services/util.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { AccountsService } from 'src/app/shared/services/accounts.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { DeviceGroupsService } from 'src/app/shared/services/device-groups.service';

// Models
import { AccountFeatures } from 'src/app/shared/models/account-models/account-features.model';
import { Pagination } from 'src/app/shared/models/common-models/pagination.model';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { Device } from 'src/app/shared/models/device-models/device.model';
import { DeviceGroup } from 'src/app/shared/models/device-models/device-group.model';

import { DeviceV3 } from 'src/app/shared/models/device-models/device-v3.model';
import { DeviceGroupV3 } from 'src/app/shared/models/device-models/device-group-v3.model';

// Components
import { PhysicalPlayerComponent } from 'src/app/shared/components/create-player/physical-player/physical-player.component';
import { VirtualPlayerComponent } from 'src/app/shared/components/create-player/virtual-player/virtual-player.component';
import { EmbeddedPlayerComponent } from 'src/app/shared/components/create-player/embedded-player/embedded-player.component';
import { WebtvPlayerComponent } from 'src/app/shared/components/create-player/webtv-player/webtv-player.component';

import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-create-player',
  templateUrl: './create-player.component.html',
  styleUrls: ['./create-player.component.scss']
})
export class CreatePlayerComponent extends CleanOnDestroy implements OnInit {

  currentWorkspace: Workspace;
  accountFeatures: AccountFeatures;

	imgPath: string = '/assets/images/';

  // store the device groups into property
  deviceGroups: DeviceGroupV3[] = [];
  deviceGroupsPaginate: Pagination = { count: 0, limit: 0, next: '', offset: 0 };

  // store the sorted devices data by device group id
  sortedDevicesByGroup: {
    [key: number]: DeviceV3[]
  } = {};

  currentLocale: any = '';
  physicalPlayer: string = '';
  virtualPlayer: string = '';
  embeddedPlayer: string = '';

  constructor(
    public utilSrv: UtilService,
    private translate: TranslateService,
  	public sharedSrv: SharedService,
    public accountsSrv: AccountsService,
    public storageSrv: StorageService,
    private devicesGroupSrv: DeviceGroupsService,
  	public dialogRef: MatDialogRef<CreatePlayerComponent>,
  	@Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.currentLocale = this.utilSrv.locale;
    this.tsTranslation();
    this.subscriber = this.storageSrv.accountFeaturesSubject.subscribe( accountFeatures => {
      if (accountFeatures) {
        this.accountFeatures = accountFeatures;
      }
    });
    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe( workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;
        }
      });
  }

  tsTranslation() {
    this.translate.get('CREATEPLAYER.PHYSICALPLAYER').subscribe((string) => {
      this.physicalPlayer = string;
    });
    this.translate.get('CREATEPLAYER.VIRTUALPLAYER').subscribe((string) => {
      this.virtualPlayer = string;
    });
    this.translate.get('CREATEPLAYER.EMBEDDEDPLAYER').subscribe((string) => {
      this.embeddedPlayer = string;
    });
  }

  createPhysicalPlayer() {
  	this.sharedSrv.openDialog<DeviceV3>({
      title: this.physicalPlayer,
    	},
    	true,
    	null,
    	PhysicalPlayerComponent
    )
      .subscribe(response => {
    	  if (response.continue){
          this.dialogRef.close({ continue: true, outputData: response.outputData });
        }
    	});
  }

  createVirtualPlayer() {
  	this.sharedSrv.openDialog<DeviceV3>({
      title: this.virtualPlayer,
    	},
    	true,
    	null,
    	VirtualPlayerComponent
    )
      .subscribe(response => {
    	  if (response.continue){
          this.dialogRef.close({ continue: true, outputData: response.outputData });
        }
    	});
  }

  createWebtvPlayer() {
    this.sharedSrv.openDialog<DeviceV3>({
      title: "Create WebTV Player",
    	},
    	true,
    	null,
    	WebtvPlayerComponent
    )
      .subscribe(response => {
    	  if (response.continue){
          this.dialogRef.close({ continue: true, outputData: response.outputData });
        }
    	});
  }

  createEmbeddedPlayer() {
    if (this.accountFeatures['web_player']){
      this.sharedSrv.openDialog<DeviceV3>({
        title: this.embeddedPlayer,
        },
        true,
        null,
        EmbeddedPlayerComponent
      )
        .subscribe(response => {
          if (response.continue){
            this.dialogRef.close({ continue: true, outputData: response.outputData });
          }
        });
    	}
  }

  /**
   * Add new device into deviceGroup
   * @param deviceInfo with type `Device`  (updated device info)
   * @return `null`
   */
  async integrateDeviceIntoList(deviceInfo: DeviceV3) {
    if(deviceInfo != null) {
      if (deviceInfo.deviceGroup) {
        if (!this.sortedDevicesByGroup[deviceInfo.deviceGroup]) {
          this.devicesGroupSrv.getDeviceGroups(
            this.currentWorkspace.account.id,
            this.currentWorkspace.id
          )
            .subscribe( response => {
              if(response) {
                this.sortedDevicesByGroup[deviceInfo.deviceGroup] = [];
                this.deviceGroups = response.message;
                this.deviceGroupsPaginate = response.pagination;
              }
            })
        }
        this.sortedDevicesByGroup[deviceInfo.deviceGroup].push(deviceInfo);
      }
    }
  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

}
