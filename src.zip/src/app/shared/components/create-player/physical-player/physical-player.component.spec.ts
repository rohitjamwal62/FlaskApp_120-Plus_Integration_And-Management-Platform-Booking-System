import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { PhysicalPlayerComponent } from './physical-player.component';

describe('PhysicalPlayerComponent', () => {
  let component: PhysicalPlayerComponent;
  let fixture: ComponentFixture<PhysicalPlayerComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ PhysicalPlayerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhysicalPlayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
