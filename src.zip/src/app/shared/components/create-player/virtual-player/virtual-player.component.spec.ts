import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { VirtualPlayerComponent } from './virtual-player.component';

describe('VirtualPlayerComponent', () => {
  let component: VirtualPlayerComponent;
  let fixture: ComponentFixture<VirtualPlayerComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ VirtualPlayerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VirtualPlayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
