import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';

import { Pagination } from 'src/app/shared/models/common-models/pagination.model';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { Playlist } from 'src/app/shared/models/playlist-models/playlist.model';
import { Device } from 'src/app/shared/models/device-models/device.model';
import { DeviceGroup } from 'src/app/shared/models/device-models/device-group.model';
import { RegisterDeviceRequest } from 'src/app/shared/models/common-models/register-device-request.model';
import { Schedule } from 'src/app/shared/models/schedule-models/schedule.model';

import { DeviceV3 } from 'src/app/shared/models/device-models/device-v3.model';
import { DeviceGroupV3 } from 'src/app/shared/models/device-models/device-group-v3.model';

import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { PlaylistsService } from 'src/app/shared/services/playlists.service';
import { DeviceGroupsService } from 'src/app/shared/services/device-groups.service';
import { DevicesService } from 'src/app/shared/services/devices.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { SchedulesService } from 'src/app/shared/services/schedules.service';
import { DeviceGroupEditComponent } from 'src/app/shared/components/device-group-edit/device-group-edit.component';
import { TranslateService } from '@ngx-translate/core';

// Utils
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

@Component({
  selector: 'app-virtual-player',
  templateUrl: './virtual-player.component.html',
  styleUrls: ['./virtual-player.component.scss']
})
export class VirtualPlayerComponent extends CleanOnDestroy implements OnInit {

  currentWorkspace: Workspace;
  // store the default image on this property for a display this one
  // before choosed image
  defaultDeviceImage: string = '';

  // store user choosed image as base 64 for a show image localy
  uploadedImageBase64: string = '';

  registerDeviceForm: FormGroup;
  deviceGroups: DeviceGroupV3[] = [];
  deviceGroupsPaginate: Pagination = { count: 0, limit: 0, next: '', offset: 0 };
  playlists: Playlist[] = [];

  //Note: Hidden for now. Player api endpoint is migrating to v3.
  //schedules: Schedule[] = [];

  // allowed images format
  allowedImageExtensions: string[] = [];
  canNotSendRequest = false;
  currentLocale: any = '';

  constructor(
    private translate: TranslateService,
    public dialogRef: MatDialogRef<VirtualPlayerComponent>,
    private storageSrv: StorageService,
    private fb: FormBuilder,
    public utilSrv: UtilService,
    private deviceGroupsSrv: DeviceGroupsService,
    private devicesSrv: DevicesService,
    private sharedSrv: SharedService,
    private schedulesSrv: SchedulesService,
    private playlistsSrv: PlaylistsService,
    @Inject(MAT_DIALOG_DATA) public data: DeviceGroup[]
  ) { 
    super(); 
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    
    this.currentLocale = this.utilSrv.locale;
    this.defaultDeviceImage = this.utilSrv.appImages.defaultImage;
    this.allowedImageExtensions = this.utilSrv.allowedImageExtensions;

    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe( workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;
          this.createRegisterDeviceForm();
          this.getPlaylists();
          //Note: Hidden for now. Player api endpoint is migrating to v3.
          //this.getSchedules();
          this.getDeviceGroups();
        }
      });
  }

  /**
   * create registerDeviceForm
   * @param null
   * @return `null`
   */
  createRegisterDeviceForm() {
    // this.registerDeviceForm = this.fb.group({
    //   deviceName: ['', [Validators.required, removeWhitespaceValidator]],
    //   code: ['', [Validators.required, removeWhitespaceValidator]],
    //   groupId: -1,
    //   playlistId: null,
    //   deviceImage: null,
    //   typeId: 2,
    //   schedules: []
    // })
    this.registerDeviceForm = this.fb.group({
      name: ['', [Validators.required, removeWhitespaceValidator]],
      code: ['', [Validators.required, removeWhitespaceValidator]],
      typeId: 2,
      groupId: -1,
      playlistId: null,
      schedules: [],
      deviceImage: null
    })
  }

  /**
   * get deviceGroups from storage service or server
   * @param null
   * @return `null`
   */
  getDeviceGroups() {
    this.subscriber = this.deviceGroupsSrv.getDeviceGroups(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    )
      .subscribe( response => {
        if(response) {
          this.deviceGroups = response.message;
          this.deviceGroupsPaginate = response.pagination;
        }
      })
  }

  /**
   * get playlists from storage service
   * @param null
   * @return `null`
   */
  getPlaylists() {
    this.subscriber = this.playlistsSrv.getPlaylists(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    )
      .subscribe(playlists => {
        if (playlists) {
          this.playlists = playlists;
        }
      })
  }

  /**
   * get schedules from storage service
   * @param null
   * @return `null`
   */
  // getSchedules() {
  //   this.storageSrv.schedulesSubject.subscribe(schedules => {
  //     if (schedules) {
  //       this.schedules = schedules;
  //     }
  //   })
  // }

  /**
   * calls from template
   * when user choose image
   * check image type and store file into form
   * for a upload into server after closed dialog
   * and store image file as base64 into `uploadedImageBase64`
   * for a display before upload
   * @param input is HTMLInputElement
   * @return `null`
   */
  onSelectDeviceImage(input: HTMLInputElement) {
    const slpitedImageName = input.files[0].name.split('.');
    const fileExtension = slpitedImageName[slpitedImageName.length - 1].toLowerCase();
    const isExistsOnAllowedExtensions = this.allowedImageExtensions.indexOf(fileExtension);
    if (isExistsOnAllowedExtensions >= 0) {
      this.registerDeviceForm.get('deviceImage').patchValue(input.files[0]);
      this.transformImageToBase64();
    }
  }

  /**
   * store the image as base64 into `uploadedImageBase64` property
   * @param null
   * @return `null`
   */
  transformImageToBase64() {
    let reader = new FileReader();
    reader.onload = (event): void => {
      // called once readAsDataURL is completed
      this.uploadedImageBase64 = event.target['result'] as string;
      reader.onload = null
    }
    reader.readAsDataURL(this.registerDeviceForm.get('deviceImage').value);
  }

  /**
   * calls from template
   * delete selected image from form and reset `uploadedImageBase64` value
   * @param null
   * @return `null`
   */
  onDeleteSelectedImage() {
    this.registerDeviceForm.get('deviceImage').patchValue(null);
    this.uploadedImageBase64 = '';
  }

  /**
   * calls from template
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * calls from template
   * close dialog with register device data
   * @param null
   * @return `null`
   */
  async onRegisterDevice() {
    if (this.registerDeviceForm.valid) {
      this.canNotSendRequest = true;
      let data = this.registerDeviceForm.getRawValue();
      if (data.groupId === -1) {
        data.groupId = null;
      }
      // data.workspaceId = this.currentWorkspace.id;
      // Note: Hidden for now while migrating to v3.
      // let rawSchedules = this.registerDeviceForm.get('schedules').value;
      // let schedules = [];
      // if (rawSchedules){
      //   for(var i = 0; i < rawSchedules.length; i++) {
      //     schedules.push({ id: rawSchedules[i] });
      //   }
      // }
      // data.schedules = schedules;
      this.devicesSrv.claimDevice(
        this.currentWorkspace.account.id,
        this.currentWorkspace.id,
        data
      )
        .subscribe( device => {
          if(device) {
            this.updateDeviceInfoInCaseOfNecessity(device);
          } else {
            this.canNotSendRequest = false;
          }
        }, err => {
          this.canNotSendRequest = false;
        });
    }
  }


  /**
   * update device image and selected playlist Id in case of neccessary
   * @param createdDevice with type `Device` which is a new added device data
   * @param registerDeviceInfo with type `RegisterDeviceRequest` which user selected and typed
   * @return `null`
   */
  async updateDeviceInfoInCaseOfNecessity(
    createdDevice: DeviceV3
  ) {
    let deviceForm = this.registerDeviceForm.getRawValue();
    if (deviceForm.deviceImage) {
      let imageForm = new FormData();
      imageForm.append('file', deviceForm.deviceImage);
      this.devicesSrv.setDeviceImage(
        this.currentWorkspace.account.id,
        this.currentWorkspace.id,
        createdDevice.id,
        imageForm
      )
        .subscribe(response => {
          if(response) {
            this.dialogRef.close({ continue: true, outputData: createdDevice });
          }
        });
    } else {
      this.dialogRef.close({ continue: true, outputData: createdDevice });
    }
  }

}
