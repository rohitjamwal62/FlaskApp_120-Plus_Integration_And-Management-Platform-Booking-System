import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { WebtvPlayerComponent } from './webtv-player.component';

describe('WebtvPlayerComponent', () => {
  let component: webtvPlayerComponent;
  let fixture: ComponentFixture<webtvPlayerComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ WebtvPlayerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WebtvPlayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
