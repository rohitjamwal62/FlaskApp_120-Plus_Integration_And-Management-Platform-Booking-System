import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { FormBuilder, FormGroup, FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { SlidesService } from 'src/app/shared/services/slides.service';

import { Apps } from 'src/app/shared/models/apps-models/apps.model';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { Slide } from 'src/app/shared/models/slide-models/slide.model';
import { SlideCreateRequestV3 } from 'src/app/shared/models/requests-models/slide-create-v3.model';
import { SelectAppComponent } from 'src/app/shared/components/select-app/select-app.component';
import { SharedService } from 'src/app/shared/services/shared.service';

@Component({
  selector: 'app-create-slide',
  templateUrl: './create-slide.component.html',
  styleUrls: ['./create-slide.component.scss']
})
export class CreateSlideComponent extends CleanOnDestroy implements OnInit {

	appForm: FormGroup;
	currentWorkspace: Workspace;
	app: Apps;
	playlistId: number;
	defaultDuration: number = 30;

  constructor(
  	private storageSrv: StorageService,
  	private slidesSrv: SlidesService,
  	private fb: FormBuilder,
    public utilSrv: UtilService,
    private sharedSrv: SharedService,
  	public dialogRef: MatDialogRef<CreateSlideComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
    	playlistId: number;
      app: Apps;
      appIndex: number;
    }
  ) {
  	super();
  }

  ngOnInit(): void {

    if(this.data) {
      this.playlistId = this.data.playlistId;
      this.app = this.data.app;
      this.generateAppForm();
    }

  	this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe(workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;
          this.appForm.get('name').patchValue(this.app.name);
          this.appForm.get('name').disable();
          //this.appForm.get('durationInSeconds').patchValue(30);
          let durationInSeconds: string = this.transformSecTo24hrFormat(30);
          this.appForm.get('durationInSeconds').patchValue(durationInSeconds);
        }
      });
  }

  generateAppForm() {
    this.appForm = this.fb.group({
      name: ['App Name', [Validators.required, removeWhitespaceValidator]],
      durationInSeconds: ['']
    });
  }

  transformSecTo24hrFormat(sec: number) {
    let hours = (sec < 3600) ? 0 : Math.floor(sec / 3600);
    let minutes = (sec < 60) ? 0 : Math.floor((sec - (hours * 3600)) / 60);
    let seconds = Math.floor(sec - ((hours * 3600) + (minutes * 60)));
    return this.addZero(hours)+':'+this.addZero(minutes)+':'+this.addZero(seconds);
  }

  addZero(number: number) {
    return number > 9 ? number + '' : '0' + number;
  }

  timeStrToSeconds(time: string) {
    let timeArr: string[] = time.split(':');
    let hr = Number(timeArr[0]) * 3600;
    let min = Number(timeArr[1]) * 60;
    let sec = Number(timeArr[2]);
    return (hr+min+sec);
  }

  onSave() {
  	let formData = this.appForm.getRawValue();
  	let slideInfo: SlideCreateRequestV3 = {
  		appId: this.app.id,
  		positionNumber: this.data.appIndex,
  		durationInSeconds: this.timeStrToSeconds(formData.durationInSeconds)
  	};
  	this.slidesSrv.createSlide(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.playlistId,
      slideInfo
    )
    .subscribe(createdSlide => {
      if(createdSlide) {
      	let slide: Slide = createdSlide;
      	this.dialogRef.close({ continue: true, outputData: slide });
      }
    });
  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  onShowAppImage(app: Apps) {
    let slideImageUrl: string = '';
    let endpoint = `${this.utilSrv.env.endPoint}/api/v3/orgs/${this.currentWorkspace.account.id}/workspaces/${this.currentWorkspace.id}/apps/`;
    slideImageUrl = endpoint + app.id + '/thumbnail/';
    slideImageUrl += "?t="+(app.modifiedTimestamp);
    return slideImageUrl;
  }

  onEditApp() {
    this.subscriber = this.sharedSrv.openDialog(
      {
        isNew: false,
        app: this.app,
        allowSelectApp: false
      },
      true,
      { width: '50%' },
      SelectAppComponent
    )
    .subscribe(response => {
      // Do nothing
    });
  }

}
