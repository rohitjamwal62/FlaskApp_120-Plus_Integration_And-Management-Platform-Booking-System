import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';
import { CleanOnDestroy } from '../../classes/clean-destroy';
import { MatChipInputEvent } from '@angular/material/chips';
import { ENTER, TAB } from '@angular/cdk/keycodes';
import { Observable } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';

import { AccountFeatures } from 'src/app/shared/models/account-models/account-features.model';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { Timezone } from '../../models/common-models/timezone.model';
import { Device } from '../../models/device-models/device.model';
import { DeviceV3 } from '../../models/device-models/device-v3.model';

import { UtilService } from '../../services/util.service';
import { LocalRequestsService } from '../../services/local-requests.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { DevicesService } from 'src/app/shared/services/devices.service';

import { DevicePasswordComponent } from 'src/app/shared/components/device-password/device-password.component';

@Component({
  selector: 'app-device-edit',
  templateUrl: './device-edit.component.html',
  styleUrls: ['./device-edit.component.scss']
})
export class DeviceEditComponent extends CleanOnDestroy implements OnInit {

  currentWorkspace: Workspace;
  accountFeatures: AccountFeatures;

  separatorKeysCodes: number[] = [ENTER, TAB];
  deviceImageEndpoint = ''

  // store the default image on this property for a display this one
  // before choosed image

  // allowed images extensions
  allowedImageExtensions: string[] = [];
  editDeviceForm: FormGroup;

  // store user choosed image as base 64 for a show image localy
  uploadedImageBase64: string | ArrayBuffer = '';
  deviceImageUrl: string = '';

  horizontal = {
    image: '',
    value: 1
  }

  verticalBottomLeft = {
    image: '',
    value: 2
  }

  verticalBottomRight = {
    image: '',
    value: 3
  }

  device: DeviceV3 = null;

  // TODO Change type and value
  timezoneList: Timezone[] = [];

  storedTimezoneLists: Timezone[] = [];

  deviceImageFile: File
  // update device when property value is true
  shouldUpdateDeviceData: boolean = false;
  filteredOptions: Observable<Timezone[]>;

  currentLocale: any = '';

  constructor(
    private translate: TranslateService,
    private fb: FormBuilder,
    public utilSrv: UtilService,
    private localRequests: LocalRequestsService,
    public storageSrv: StorageService,
    private sharedSrv: SharedService,
    private devicesSrv: DevicesService,
    public dialogRef: MatDialogRef<DeviceEditComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DeviceV3,
  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }


  ngOnInit() {

    this.currentLocale = this.utilSrv.locale;

    // get horizontal and vertical images
    this.horizontal.image = this.utilSrv.appImages.horizontalImage;
    this.verticalBottomLeft.image = this.utilSrv.appImages.verticalImageBottomLeft;
    this.verticalBottomRight.image = this.utilSrv.appImages.verticalImageBottomRight;
    // get allowed images extensions
    this.allowedImageExtensions = this.utilSrv.allowedImageExtensions;
    this.deviceImageEndpoint = `${this.utilSrv.env.endPoint}/api/v1/devices/`;

    // generate form
    this.generateEditDeviceForm();
    this.getTimezones();

    this.subscriber = this.storageSrv.accountFeaturesSubject.subscribe( accountFeatures => {
      if (accountFeatures) {
        this.accountFeatures = accountFeatures;
      }
    });

    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe(workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;
          this.deviceImageEndpoint = `${this.utilSrv.env.endPoint}/api/v3/orgs/${this.currentWorkspace.account.id}/workspaces/${this.currentWorkspace.id}/devices/`;
          if (this.data) {
            this.device = this.data;
            this.editDeviceForm.patchValue(this.data);
            this.editDeviceForm.get('deviceOrientationId').patchValue(this.data.deviceOrientation.id);
            this.editDeviceForm.get('sources').patchValue(this.device.sources);
          }
        }
      });

    this.subscribeToTheValueChanges();

  }

  /**
   * get timezones from json
   * @param null
   * @return `null`
   */
  getTimezones() {
    this.localRequests.getTimezones().subscribe(timezoneList => {
      if (timezoneList) {
        this.timezoneList = timezoneList;
        this.timezoneList.sort((timezone1, timezone2) => {
          return timezone1["Europe/Andorra"] > timezone2["Europe/Andorra"] ? 1 : -1;
        });
        this.timezoneList.unshift({
          '1': 0,
          'AD': 'helper',
          "Europe/Andorra": 'Determine Automatically'
        });
        this.storedTimezoneLists = [...this.timezoneList];
      }
    });
  }

  /**
   * generate edit device form
   * @param null
   * @return `null`
   */
  generateEditDeviceForm() {
    this.editDeviceForm = this.fb.group({
      name: '',
      deviceImage: null,
      sources: [],
      timezoneKey: '',
      notificationsEnabled: false,
      showControls: false,
      deviceOrientationId: null,
    })
  }

  filterByName(value: string) {

    const filterValue = value.toLowerCase();
    this.timezoneList = this.storedTimezoneLists
      .filter(
        timezone => timezone["Europe/Andorra"].toLowerCase().includes(filterValue)
      );
  }

  /**
   * calls from template
   * change `editDeviceForm.deviceOrientationId` to 0
   * (0 is vertical orientation)
   * @param null
   * @return `null`
   */
  onChangeOrientationToVerticalBottomLeft() {
    this.editDeviceForm.get('deviceOrientationId').patchValue(
      this.verticalBottomLeft.value
    );
  }

  onChangeOrientationToVerticalBottomRight() {
    this.editDeviceForm.get('deviceOrientationId').patchValue(
      this.verticalBottomRight.value
    );
  }

  /**
   * calls from template
   * change `editDeviceForm.deviceOrientationId` to 1
   * (1 is horizontal orientation)
   * @param null
   *
   * @return `null`
   */
  onChangeOrientationToHorizontal() {
    this.editDeviceForm.get('deviceOrientationId').patchValue(
      this.horizontal.value
    );
  }

  /**
   * calls from template
   * when user choose image
   * check image type and store file into form
   * for a upload into server after closed dialog
   * and store image file as base64 into `uploadedImageBase64`
   * for a display before upload
   * @param input is HTMLInputElement
   * @return `null`
   */
  onSelectDeviceImage(input: HTMLInputElement) {
    let deviceImage: File = input.files[0];
    let isValidExtension = this.utilSrv.checkImageExtension(deviceImage);
    // set image into form  when extension is allowed
    if (isValidExtension) {
      this.editDeviceForm.get('deviceImage').patchValue(deviceImage);
      this.transformImageToBase64();
    }
  }

  /**
   * subscribe to the `editDeviceForm.valueChanges`
   * @param null
   * @return `null`
   */
  subscribeToTheValueChanges() {
    this.subscriber = this.editDeviceForm.valueChanges.subscribe(response => {
      // change the property value to true
      // for a update device info when closed the dialog
      this.shouldUpdateDeviceData = true;
    })
  }

  /**
   * store the image as base64 into `uploadedImageBase64` property
   * @param null
   * @return `null`
   */
  transformImageToBase64() {
    let reader = new FileReader();
    reader.onload = (event): void => { // called once readAsDataURL is completed
      this.uploadedImageBase64 = event.target['result'];
      reader.onload = null
    }
    reader.readAsDataURL(this.editDeviceForm.get('deviceImage').value);
  }

  /**
   * calls from template
   * delete selected image from form and reset `uploadedImageBase64` value
   * @param null
   * @return `null`
   */
  onDeleteSelectedImage() {
    this.editDeviceForm.get('deviceImage').patchValue(null);
    this.uploadedImageBase64 = '';
  }

  /**
   * calls from template
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * calls from template
   * when user clicked on the save button
   * close dialog with changed device data
   * @param null
   * @return `null`
   */
  onEditDevice() {
    if (this.editDeviceForm.valid) {
      let deviceForm = this.editDeviceForm.getRawValue();
      if(deviceForm.deviceImage) {
        let imageForm = new FormData();
        imageForm.append('file', deviceForm.deviceImage);
        delete deviceForm.deviceImage;
        this.updateDeviceImage(imageForm);
      }
      this.updateDevice(deviceForm);
    }
  }

  updateDeviceImage(imageForm) {
    this.devicesSrv.setDeviceImage(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.device.id,
      imageForm
    )
      .subscribe(response => {
        if(response) {
          // Do nothing
        }
      });
  }

  updateDevice(deviceForm) {
    this.devicesSrv.updateDevice(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.device.id,
      deviceForm
    )
      .subscribe(updatedDevice => {
        if(updatedDevice) {
          this.dialogRef.close({
            continue: true,
            outputData: updatedDevice,
          });
        }
      });
  }

  onSetDevicePassword() {
    this.subscriber = this.sharedSrv.openDialog(
      this.device.id,
      true,
      null,
      DevicePasswordComponent
    ).subscribe(response => {
      if (response.continue) {
        this.dialogRef.close({ continue: false, outputData: null });
      }
    })
  }

    /**
  * calls from template
  * when user type new tag and press on the some keys from `separatorKeysCodes`
  * add new tag into playlist tags
  * @param event with type `MatChipInputEvent`
  * @return `null`
  */
  onAddNewSource(event: MatChipInputEvent) {

    const input = event.input;
    const sourceName = event.value;

    if ((sourceName || '').trim()) {
      let sources = this.editDeviceForm.get('sources').value;
      sources.push(sourceName)
      this.editDeviceForm.get('sources').patchValue(sources);
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }
  }

  onBlurAddNewSource(event) {
    const sourceName = event.target.value;
    if ((sourceName || '').trim()) {
      let sources = this.editDeviceForm.get('sources').value;
      sources.push(sourceName)
      this.editDeviceForm.get('sources').patchValue(sources);
    }
    event.target.value = '';
  }

   /**
   * calls from template
   * when user type new tag and press on the some keys from `separatorKeysCodes`
   * add new tag into playlist tags
   * @param event with type `MatChipInputEvent`
   * @return `null`
   */
  onRemoveSource(sourceName: string) {
    let sources: string[] = this.editDeviceForm.get('sources').value;
    let sourceIndex = sources.indexOf(sourceName);
    if (sourceIndex >= 0) {
      sources.splice(sourceIndex, 1);
      this.editDeviceForm.get('sources').patchValue(sources);
    }
  }

}
