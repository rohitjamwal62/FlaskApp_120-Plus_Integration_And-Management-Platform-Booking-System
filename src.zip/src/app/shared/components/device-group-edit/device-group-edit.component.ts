import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormControl, Validators, FormBuilder, FormGroup } from '@angular/forms';
import { CleanOnDestroy } from '../../classes/clean-destroy';
import { TranslateService } from '@ngx-translate/core';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { DeviceGroup } from '../../models/device-models/device-group.model';
import { DialogOutputData } from '../../models/common-models/dialog-output-data.model';

import { DeviceGroupV3 } from 'src/app/shared/models/device-models/device-group-v3.model';

import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { DeviceGroupsService } from 'src/app/shared/services/device-groups.service';

@Component({
  selector: 'app-device-group-edit',
  templateUrl: './device-group-edit.component.html',
  styleUrls: ['./device-group-edit.component.scss']
})
export class DeviceGroupEditComponent extends CleanOnDestroy implements OnInit {

  currentWorkspace: Workspace;
  deviceGroupForm: FormGroup;
  shouldUpdateDeviceGroupInfo: boolean = false;
  currentLocale:any = '';
  
  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private storageSrv: StorageService,
    private deviceGroupsSrv: DeviceGroupsService,
    public dialogRef: MatDialogRef<DeviceGroupEditComponent>,
    private fb: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data?: DeviceGroupV3,

  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.currentLocale = this.utilSrv.locale;
    this.generatedeviceGroupForm();
    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe(workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;
          if (this.data) {
            this.deviceGroupForm.patchValue(this.data);
            this.subscriber = this.deviceGroupForm.valueChanges.subscribe(response => {
              this.shouldUpdateDeviceGroupInfo = true;
            })
          } else {
            this.shouldUpdateDeviceGroupInfo = true;
          }
        }
      });
  }

  /**
   * generate `deviceGroupForm`
   * @param null
   * @return `null`
   */
  generatedeviceGroupForm() {
    this.deviceGroupForm = this.fb.group({
      name: ['', [Validators.required, removeWhitespaceValidator]]
    })
  }

  /**
   * close dialog with returning output data
   * @param null
   * @return `null`
   */
  onSubmitDeviceGroup() {
    let formData = this.deviceGroupForm.getRawValue();
    if (this.deviceGroupForm.valid) {

      // this.deviceGroupsSrv.updateDeviceGroupInfo({ 
      //   groupName: formData.groupName,
      //   statusId: 0 
      // }, this.data.id).subscribe( deviceGroup => {
      //   if(deviceGroup) {
      //     this.dialogRef.close({ continue: true, outputData: deviceGroup });
      //   }
      // });

      this.deviceGroupsSrv.updateDeviceGroup(
        this.currentWorkspace.account.id,
        this.currentWorkspace.id,
        this.data.id,
        { 
          name: formData.name,
          statusId: 0 
        }
      )
        .subscribe(deviceGroup => {
          if(deviceGroup) {
            this.dialogRef.close({ continue: true, outputData: deviceGroup });
          }
        });
    }
  }

  /**
   * close dialog without changes 
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

}
