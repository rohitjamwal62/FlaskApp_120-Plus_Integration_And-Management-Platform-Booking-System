import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { DeviceGroupNewComponent } from './device-group-new.component';

describe('DeviceGroupNewComponent', () => {
  let component: DeviceGroupNewComponent;
  let fixture: ComponentFixture<DeviceGroupNewComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ DeviceGroupNewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviceGroupNewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
