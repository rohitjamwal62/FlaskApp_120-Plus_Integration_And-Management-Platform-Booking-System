import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormControl, Validators, FormBuilder, FormGroup } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';
import { CleanOnDestroy } from '../../classes/clean-destroy';

import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { DeviceGroup } from '../../models/device-models/device-group.model';
import { DialogOutputData } from '../../models/common-models/dialog-output-data.model';

import { DeviceGroupV3 } from 'src/app/shared/models/device-models/device-group-v3.model';

import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { DeviceGroupsService } from 'src/app/shared/services/device-groups.service';


@Component({
  selector: 'app-device-group-new',
  templateUrl: './device-group-new.component.html',
  styleUrls: ['./device-group-new.component.scss']
})
export class DeviceGroupNewComponent extends CleanOnDestroy implements OnInit {

  currentWorkspace: Workspace;
  deviceGroupForm: FormGroup;
  currentLocale:any = '';
  
  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private storageSrv: StorageService,
    private deviceGroupsSrv: DeviceGroupsService,
    public dialogRef: MatDialogRef<DeviceGroupNewComponent>,
    private fb: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data?: DeviceGroupV3,

  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.currentLocale = this.utilSrv.locale;
    this.generatedeviceGroupForm();
    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe(workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;
        }
      });
  }

  /**
   * generate `deviceGroupForm`
   * @param null
   * @return `null`
   */
  generatedeviceGroupForm() {
    this.deviceGroupForm = this.fb.group({
      groupName: ['', [Validators.required, removeWhitespaceValidator]]
    })
  }

  /**
   * close dialog with returning output data
   * @param null
   * @return `null`
   */
  onSubmitDeviceGroup() {
    let formData = this.deviceGroupForm.getRawValue();
    if (this.deviceGroupForm.valid) {

      // Update instead of creating a new device group
      // this.deviceGroupsSrv.createDeviceGroup({
      //   groupName: formData.groupName,
      //   workspaceId: this.storageSrv.selectedWorkspace.id
      // }).subscribe(deviceGroup => {
      // 	if(deviceGroup) {
      // 		this.storageSrv.deviceGroups.unshift(deviceGroup);
	     //    this.storageSrv.deviceGroupsSubject.next(this.storageSrv.deviceGroups);
	     //    this.dialogRef.close({ continue: true, outputData: deviceGroup });
      // 	}
      // });
      this.deviceGroupsSrv.createDeviceGroup(
        this.currentWorkspace.account.id,
        this.currentWorkspace.id,
        { name: formData.groupName }
      )
        .subscribe(deviceGroup => {
          if(deviceGroup) {
            this.dialogRef.close({ continue: true, outputData: deviceGroup });
          }
        });
    }
  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

}
