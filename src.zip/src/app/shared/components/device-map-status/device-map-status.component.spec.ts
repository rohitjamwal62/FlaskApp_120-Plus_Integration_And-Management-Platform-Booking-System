import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { DeviceMapStatusComponent } from './device-map-status.component';

describe('DeviceMapStatusComponent', () => {
  let component: DeviceMapStatusComponent;
  let fixture: ComponentFixture<DeviceMapStatusComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ DeviceMapStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviceMapStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
