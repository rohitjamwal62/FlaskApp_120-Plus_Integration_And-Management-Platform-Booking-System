import { Component, ElementRef, AfterViewInit, Input, OnChanges } from '@angular/core';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { Router } from '@angular/router';

import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { WorkspaceReportsDisconnectedDevice } from 'src/app/shared/models/workspace-models/workspace-reports-disconnected-device.model';
import { Device } from 'src/app/shared/models/device-models/device.model';
import { DeviceV3 } from 'src/app/shared/models/device-models/device-v3.model';

import { StorageService } from 'src/app/shared/services/storage.service';
import { ReportsService } from 'src/app/shared/services/reports.service';
import { DevicesService } from 'src/app/shared/services/devices.service';
import { WorkspacesService } from 'src/app/shared/services/workspaces.service';

import * as moment from 'moment';
import * as L from 'leaflet';

@Component({
  selector: 'app-device-map-status',
  templateUrl: './device-map-status.component.html',
  styleUrls: ['./device-map-status.component.scss']
})
export class DeviceMapStatusComponent extends CleanOnDestroy implements AfterViewInit, OnChanges {

	private map;
	private markers = L.layerGroup();

  @Input() selectedWorkspace: Workspace;

  loader: boolean = false;
	//selectedWorkspace: Workspace;
	devices: WorkspaceReportsDisconnectedDevice[];
  toolTip: any = '';

  greenMarker: string = 'assets/images/green-marker.png';
  yellowMarker: string = 'assets/images/yellow-marker.png';
  redMarker: string = 'assets/images/red-marker.png';

  constructor(
    public router: Router,
  	private storageSrv: StorageService,
  	private reportSrv: ReportsService,
    private devicesSrv: DevicesService,
    private workspaceSrv: WorkspacesService,
    private elementRef: ElementRef
  ) {
    super();
  }

  ngAfterViewInit() {
  	this.initMap();
  	//this.subscribeToCurrentWorkspace();
  }

  ngOnChanges() {
    this.subscribeToCurrentWorkspace();
  }

  initMap() {
    const options = {
      enableHighAccuracy: true,
      timeout: 5000,
      maximumAge: 0
    };

    navigator.geolocation.getCurrentPosition(
      pos => {
        this.renderMap(pos.coords.latitude, pos.coords.longitude);
      },
      err => {
        this.renderMap(38, -96);
      },
      options
    );
  }

  subscribeToCurrentWorkspace() {
    if(this.selectedWorkspace) {
      //this.getDeviceIpLatLng();
      this.initMap();
    }
  }

  renderMap(lat: number, lng: number) {
    const tiles = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      minZoom: 3,
      maxZoom: 19,
      attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    });
    const superThis = this;
    try {
      if (this.map == null){
        this.map = L.map('map', {
          center: [ lat, lng ],
          zoom: 4
        });
      }
      tiles.addTo(this.map);
      setTimeout(function(){
        superThis.map.invalidateSize();
        if(superThis.selectedWorkspace) {
          superThis.getDeviceIpLatLng();
        }
      }, 100);
    } catch(err){
      throw "Error rendering map: "+err.message;
    }
  }

  // getDeviceIpLatLng() {
  //   this.loader = true;
  //   //this.map.invalidateSize();
  //   this.devices = [];
  // 	this.subscriber = this.devicesSrv.getDeviceStatuses(
  //     this.selectedWorkspace.account.id,
  //     this.selectedWorkspace.id
  //   ).subscribe( devices => {
  //     this.loader = false;
  //     if(devices) {
		// 		this.devices = devices;
		// 		this.plotMapMarkers();
		// 	}
		// });
  // }

  getDeviceIpLatLng() {
    this.devices = [];
    if (this.selectedWorkspace){
      this.loader = true;
      this.subscriber = this.workspaceSrv.getDisconnectedDevices(
        this.selectedWorkspace.account.id,
        this.selectedWorkspace.id
      )
        .subscribe( devices => {
          this.loader = false;
          if(devices) {
            this.devices = devices;
            this.plotMapMarkers();
          }
        });
    } else {
      this.loader = false;
    }
  }

  plotMapMarkers() {
      this.toolTip = '';

      this.markers.clearLayers();

      if(this.devices.length > 0) {

        // Create a new array
        let latLngArr = this.devices.map((d) => {
          return { lat: d.latlng[0], lng: d.latlng[1], device: d }
        });

        // Group devices by coordinates
        let newLatLngArr = latLngArr.reduce( (a, b) => {
          var i = a.findIndex( x => x.lat === b.lat && x.lng === b.lng);
          var devices = [];
          devices.push(b.device);
          return i === -1 ? a.push({ lat: b.lat, lng: b.lng, devices: devices }) : a[i].devices.push(b.device), a;
        }, []);

        for(const d of newLatLngArr) {
          let _icon: string = '/assets/images/icon-marker.png';
          let toolTipText:string = '';

          // Loop devices
          for (const t of d.devices) {

            let lastSeenDate: string = '';

            // Determining marker color.
            if(t.isDisconnected) {
              _icon = this.redMarker;
            } else if(t.deviceStatus.id == 2 && _icon !== this.redMarker) {
              _icon = this.yellowMarker;
            } else if (t.deviceStatus.id == 1 && _icon !== this.redMarker && _icon !== this.yellowMarker){
              _icon = this.greenMarker;
            }

            lastSeenDate = moment(t.lastCheckinTimestamp).format('MM/DD/YYYY hh:mm A');

            if(t.isDisconnected) {
              toolTipText = `<div class="inner-row"><img src="${this.redMarker}" class="col-img"/><div class="col-content"><h5>${t.deviceName}</h5> <p>Last seen ${lastSeenDate}</p></div></div>`;
            } else if(t.deviceStatus.id == 2) {
              toolTipText = `<div class="inner-row">`;
                toolTipText += `<img src="${this.yellowMarker}" class="col-img"/>`;
                toolTipText += `<div class="col-content">`;
                  toolTipText += `<h5>${t.deviceName}</h5>`;
                  toolTipText += `<p>Stopped at ${lastSeenDate}</p>`;
                toolTipText += `</div>`;
              toolTipText += `</div>`;
            } else {
              toolTipText = `<div class="inner-row">`;
                toolTipText += `<img src="${this.greenMarker}" class="col-img"/>`;
                toolTipText += `<div class="col-content"><h5>${t.deviceName}</h5>`;
                toolTipText += `</div>`;
              toolTipText += `</div>`;
            }

            this.toolTip += `<a class="status-link pointer" data-status-id="${t.id}">${toolTipText}</a>`;
          }

          if(d.lat != undefined && d.lng != undefined) {

            let customIcon = L.icon({
              iconUrl: _icon,
              iconSize: [32, 32]
            });

            const toolTipHtml = `<div class="leaflet-popup-content-inner" data-simplebar>${this.toolTip}</div>`;
            const marker = L.marker([d.lat, d.lng, { riseOnHover: true }], { icon: customIcon }).bindPopup(toolTipHtml);

            let self = this;
            marker.on('popupopen', function() {
              var statusLink = self.elementRef.nativeElement.querySelectorAll(".status-link");
              for(const sl of statusLink) {
                sl.addEventListener('click', (e) => {
                  var statusId = e.currentTarget.getAttribute("data-status-id");
                  self.router.navigate([`/devices/${statusId}`]);
                });
              }
            });

            try {
              this.markers.addLayer(marker);
            } catch(err){
              throw "Error adding marker to markers layer: "+err.message;
            }

            toolTipText = '';
            this.toolTip = '';
          }

          try {
            this.map.addLayer(this.markers);
          } catch(err){
            throw "Error adding markers to map: "+err.message;
          }
        }

        this.map.invalidateSize();

      }
    }
}
