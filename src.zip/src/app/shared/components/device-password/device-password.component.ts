import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';
import { CleanOnDestroy } from '../../classes/clean-destroy';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';

import { StorageService } from 'src/app/shared/services/storage.service';
import { DevicesService } from 'src/app/shared/services/devices.service';

@Component({
  selector: 'app-device-password',
  templateUrl: './device-password.component.html',
  styleUrls: ['./device-password.component.scss']
})
export class DevicePasswordComponent extends CleanOnDestroy implements OnInit {

  currentWorkspace: Workspace;
  devicePasswordForm: FormGroup;
  deviceId: number;

  constructor(
    private storageSrv: StorageService,
    private fb: FormBuilder,
    private devicesSrv: DevicesService,
    public dialogRef: MatDialogRef<DevicePasswordComponent>,
    @Inject(MAT_DIALOG_DATA) public data: number,
  ) {
    super();
  }

  ngOnInit(): void {
    this.generateForm();
    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe(workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;
          if(this.data) {
            this.deviceId = this.data;
          }
        }
      });
  }

  generateForm() {
    this.devicePasswordForm = this.fb.group({
      password: ""
    })
  }

  onSave() {
    if (this.devicePasswordForm.valid) {
      let formData = this.devicePasswordForm.getRawValue();
      this.devicesSrv.updateDevice(
        this.currentWorkspace.account.id,
        this.currentWorkspace.id,
        this.deviceId,
        formData
      )
        .subscribe(updatedDevice => {
          if(updatedDevice) {
            this.dialogRef.close({
              continue: true,
              outputData: null,
            });
          }
        });
    }
  }

  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

}
