import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CleanOnDestroy } from '../../../classes/clean-destroy';
import { TranslateService } from '@ngx-translate/core';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

import { Pagination } from 'src/app/shared/models/common-models/pagination.model';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { Playlist } from '../../../models/playlist-models/playlist.model';
import { RegisterDeviceRequest } from '../../../models/common-models/register-device-request.model';
//import { DeviceGroup } from '../../../models/device-models/device-group.model';
//import { PlaylistV1 } from '../../../models/playlist-models/playlist-v1.model';
//import { Device } from '../../../models/device-models/device.model';

import { DeviceV3 } from 'src/app/shared/models/device-models/device-v3.model';
import { DeviceCreateV3Request } from 'src/app/shared/models/requests-models/device-create-v3.model';
import { DeviceUpdateV3Request } from 'src/app/shared/models/requests-models/device-update-v3.model';
import { DeviceGroupV3 } from 'src/app/shared/models/device-models/device-group-v3.model';

import { UtilService } from '../../../services/util.service';
import { StorageService } from '../../../services/storage.service';
import { DeviceGroupsService } from '../../../services/device-groups.service';
import { DevicesService } from '../../../services/devices.service';
import { SharedService } from '../../../services/shared.service';
import { PlaylistsService } from 'src/app/shared/services/playlists.service';

import { DeviceGroupEditComponent } from '../../../components/device-group-edit/device-group-edit.component';

@Component({
  selector: 'app-virtual-device-register',
  templateUrl: './virtual-device-register.component.html',
  styleUrls: ['./virtual-device-register.component.scss']
})
export class VirtualDeviceRegisterComponent extends CleanOnDestroy implements OnInit {

  currentWorkspace: Workspace;

  // store the default image on this property for a display this one
  // before choosed image
  defaultDeviceImage: string = '';

  // store user choosed image as base 64 for a show image localy
  uploadedImageBase64: string = '';
  registerDeviceForm: FormGroup;
  deviceGroups: DeviceGroupV3[] = [];
  deviceGroupsPaginate: Pagination = { count: 0, limit: 0, next: '', offset: 0 };
  playlists: Playlist[] = [];

  // allowed images format
  allowedImageExtensions: string[] = [];
  canNotSendRequest = false;
  currentLocale: any = '';

  constructor(
    private translate: TranslateService,
    public dialogRef: MatDialogRef<VirtualDeviceRegisterComponent>,
    private storageSrv: StorageService,
    private fb: FormBuilder,
    public utilSrv: UtilService,
    private deviceGroupsSrv: DeviceGroupsService,
    private devicesSrv: DevicesService,
    private sharedSrv: SharedService,
    private playlistsSrv: PlaylistsService,
    @Inject(MAT_DIALOG_DATA) public data: DeviceGroupV3[]
  ) { 
    super();
    translate.setDefaultLang(this.utilSrv.locale); 
  }

  ngOnInit() {
    this.currentLocale = this.utilSrv.locale;
    this.defaultDeviceImage = this.utilSrv.appImages.defaultImage;
    this.allowedImageExtensions = this.utilSrv.allowedImageExtensions;
    this.createRegisterDeviceForm();
    
    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe(workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;
          this.getPlaylists();
          this.getDeviceGroups();
        }
      });

  }

  /**
   * create registerDeviceForm
   * @param null
   * @return `null`
   */
  createRegisterDeviceForm() {
    this.registerDeviceForm = this.fb.group({
      deviceName: ['', [Validators.required, removeWhitespaceValidator]],
      typeId: null,
      groupId: -1,
      playlistId: null,
      deviceImage: null
    })
  }

  /**
   * get deviceGroups from storage service or server
   * @param null
   * @return `null`
   */
  getDeviceGroups() {
    // if (this.storageSrv.deviceGroups) {
    //   this.deviceGroups = this.storageSrv.deviceGroups;
    // } else {
    //   if (this.storageSrv.selectedWorkspace) {
    //     this.deviceGroupsSrv.getDeviceGroups(
    //       this.storageSrv.selectedWorkspace.id
    //     ).subscribe(deviceGroups => {
    //       this.storageSrv.deviceGroups = deviceGroups;
    //       this.deviceGroups = this.storageSrv.deviceGroups;
    //     })
    //   } else {
    //     this.onCloseWithoutChanges();
    //   }
    // }
    this.subscriber = this.deviceGroupsSrv.getDeviceGroups(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    )
      .subscribe( response => {
        if(response) {
          this.deviceGroups = response.message;
          this.deviceGroupsPaginate = response.pagination;
        }
      })
  }

  /**
   * get playlists from storage service
   * @param null
   * @return `null`
   */
  // getPlaylists() {
  //   this.subscriber = this.storageSrv.playlistsSubject.subscribe(playlists => {
  //     if (playlists) {
  //       this.playlists = playlists;
  //     }
  //   })
  // }
  getPlaylists() {
    this.subscriber = this.playlistsSrv.getPlaylists(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    ).subscribe(playlists => {
      if (playlists) {
        this.playlists = playlists;
      }
    })
  }

  /**
   * calls from template
   * when user choose image
   * check image type and store file into form
   * for a upload into server after closed dialog
   * and store image file as base64 into `uploadedImageBase64`
   * for a display before upload
   * @param input is HTMLInputElement
   * @return `null`
   */
  onSelectDeviceImage(input: HTMLInputElement) {

    const slpitedImageName = input.files[0].name.split('.');
    const fileExtension = slpitedImageName[slpitedImageName.length - 1].toLowerCase();
    const isExistsOnAllowedExtensions = this.allowedImageExtensions.indexOf(fileExtension);

    if (isExistsOnAllowedExtensions >= 0) {
      this.registerDeviceForm.get('deviceImage').patchValue(input.files[0]);
      this.transformImageToBase64();
    }
  }

  /**
   * store the image as base64 into `uploadedImageBase64` property
   * @param null
   * @return `null`
   */
  transformImageToBase64() {
    let reader = new FileReader();
    reader.onload = (event): void => {
      // called once readAsDataURL is completed
      this.uploadedImageBase64 = event.target['result'] as string;
      reader.onload = null
    }
    reader.readAsDataURL(this.registerDeviceForm.get('deviceImage').value);
  }

  /**
   * calls from template
   * delete selected image from form and reset `uploadedImageBase64` value
   * @param null
   * @return `null`
   */
  onDeleteSelectedImage() {
    this.registerDeviceForm.get('deviceImage').patchValue(null);
    this.uploadedImageBase64 = '';
  }

  /**
   * calls from template
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * calls from template
   * close dialog with register device data
   * @param null
   * @return `null`
   */
  async onRegisterDevice() {
    if (this.registerDeviceForm.valid) {
      this.canNotSendRequest = true;
      let formData: DeviceCreateV3Request = this.registerDeviceForm.getRawValue();
      if (formData.groupId === -1) {
        formData.groupId = null;
      }
      // data.workspaceId = this.storageSrv.selectedWorkspace.id;
      // try {
      //   let createdDevice = await this.devicesSrv.createVirtualDevice(data).toPromise();
      //   if (createdDevice) {
      //     this.updateDeviceInfoInCaseOfNecessity(createdDevice, data);
      //   }
      // } catch (error) {
      //   this.canNotSendRequest = false;
      // }
      this.subscriber = this.devicesSrv.claimDevice(
        this.currentWorkspace.account.id,
        this.currentWorkspace.id,
        formData
      )
        .subscribe(createdDevice => {
          if(createdDevice) {
            this.updateDeviceInfoInCaseOfNecessity(createdDevice, formData);
          }
        }, err => {
          this.canNotSendRequest = false;
        });
    }
  }


  /**
   * update device image and selected playlist Id in case of neccessary
   *
   * @param createdDevice with type `Device` which is a new added device data
   * @param registerDeviceInfo with type `RegisterDeviceRequest` which user selected and typed
   * @return `null`
   */
  async  updateDeviceInfoInCaseOfNecessity(
    createdDevice: DeviceV3, 
    registerDeviceInfo: DeviceCreateV3Request
  ) {

    if (registerDeviceInfo.deviceImage) {
      let imageForm = new FormData();
      imageForm.append('file', registerDeviceInfo.deviceImage);
      //await this.devicesSrv.uploadDeviceImage(imageForm, createdDevice.id).toPromise();
      this.updateDeviceImage(imageForm, createdDevice);
    }

    if (registerDeviceInfo.playlistId) {
      let deviceForm:DeviceUpdateV3Request = { playlistId: registerDeviceInfo.playlistId };
      this.subscriber = this.devicesSrv.updateDevice(
        this.currentWorkspace.account.id,
        this.currentWorkspace.id,
        createdDevice.id,
        deviceForm
      )
        .subscribe(updatedDevice => {
          if(updatedDevice) {
            this.dialogRef.close({
              continue: true,
              outputData: createdDevice
            });
          }
        });

      // createdDevice = await this.devicesSrv.updateDeviceInfo({
      //   playlistId: registerDeviceInfo.playlistId
      // }, createdDevice.id).toPromise();
    }

    // this.dialogRef.close({
    //   continue: true,
    //   outputData: createdDevice
    // });

  }

  updateDeviceImage(imageForm, device: DeviceV3) {
    this.devicesSrv.setDeviceImage(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      device.id,
      imageForm
    )
      .subscribe(response => {
        if(response) {
          // Do nothing
        }
      });
  }


  /**
   * open dialog for a type new device group name
   * after dialog colsed send request to the server
   * for a create new device group
   * @param null
   * @return `null`
   */
  onCreateGroup() {
    this.subscriber = this.sharedSrv.openDialog<{ groupName: string }>(
      null,
      true,
      null,
      DeviceGroupEditComponent
    ).subscribe(response => {
      if (response.continue) {
        // this.deviceGroupsSrv.createDeviceGroup({
        //   groupName: response.outputData.groupName,
        //   workspaceId: this.storageSrv.selectedWorkspace.id
        // }).subscribe(createdDeviceInfo => {
        //   //this.deviceGroups.unshift(createdDeviceInfo);
        //   //this.sortedDevicesByGroup[createdDeviceInfo.id] = [];
        //   //this.storageSrv.deviceGroups.unshift(createdDeviceInfo);
        //   this.registerDeviceForm.get("groupId").patchValue(createdDeviceInfo.id);
        //   this.storageSrv.deviceGroupsSubject.next(this.storageSrv.deviceGroups);
        // })
        this.deviceGroupsSrv.createDeviceGroup(
          this.currentWorkspace.account.id,
          this.currentWorkspace.id,
          { name: response.outputData.groupName }
        )
          .subscribe(deviceGroup => {
            if(deviceGroup) {
              this.registerDeviceForm.get("groupId").patchValue(deviceGroup.id);
            }
          });
      }
    });
  }


}
