import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DefaultDialogInputData } from '../../models/common-models/default-dialog-input-data.model';

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss']
})
export class DialogComponent {

  constructor(
    public dialogRef: MatDialogRef<DialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DefaultDialogInputData,
  ) { }


  /**
   * close dialog and continue
   * 
   * @param null
   *
   * @return `null`
   */
  onContinue() {
    this.dialogRef.close({ continue: true, outputData: null });
  }

  /**
   * close dialog without changes
   * 
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

}
