import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditAppFolderComponent } from './edit-app-folder.component';

describe('EditAppFolderComponent', () => {
  let component: EditAppFolderComponent;
  let fixture: ComponentFixture<EditAppFolderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditAppFolderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditAppFolderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
