import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { UtilService } from 'src/app/shared/services/util.service';

import { AppFolder } from 'src/app/shared/models/app-folders/app-folder.model';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

@Component({
  selector: 'app-edit-app-folder',
  templateUrl: './edit-app-folder.component.html',
  styleUrls: ['./edit-app-folder.component.scss']
})
export class EditAppFolderComponent implements OnInit {

  updateFolderForm: FormGroup;
  
  constructor(
    public utilSrv: UtilService,
    private translate: TranslateService,
    public dialogRef: MatDialogRef<EditAppFolderComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
    	folder: AppFolder; 
    	parentId: number 
    },
    private fb: FormBuilder
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.generateUpdateFolderForm(this.data.parentId);
  }

  /**
   * generate `updateFolderForm`
   * 
   * @param parentId is a parent folder id with type `number`
   *
   * @return `null`
   */
  generateUpdateFolderForm(parentId: number) {
    this.updateFolderForm = this.fb.group({
      folderId: parentId,
      name: [this.data.folder.name, [Validators.required, removeWhitespaceValidator]]
    })
  }

  /**
   * close dialog without changes
   * 
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * close dialog and create folder
   * 
   * @param null
   *
   * @return `null`
   */
  onCreateFolder() {
    if (this.updateFolderForm.valid) {
      this.dialogRef.close({
        continue: true,
        outputData: this.updateFolderForm.getRawValue()
      })
    }
  }

}
