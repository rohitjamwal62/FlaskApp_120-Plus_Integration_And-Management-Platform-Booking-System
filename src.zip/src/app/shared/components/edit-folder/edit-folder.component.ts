import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { AssetFolderV3 } from 'src/app/shared/models/asset-models/asset-folder-v3.model';
import { AssetFolderUpdateRequest } from 'src/app/shared/models/requests-models/asset-folder-update.model';

import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { ContentService } from 'src/app/shared/services/content.service';
import { AssetFoldersService } from 'src/app/shared/services/asset-folders.service';

@Component({
  selector: 'app-edit-folder',
  templateUrl: './edit-folder.component.html',
  styleUrls: ['./edit-folder.component.scss']
})
export class EditFolderComponent implements OnInit {

  currentWorkspace: Workspace;
	folderForm: FormGroup;
	folder: AssetFolderV3;

  constructor(
  	private translate: TranslateService,
    public utilSrv: UtilService,
    private storageSrv: StorageService,
    private sharedSrv: SharedService,
    private assetFolderSrv: AssetFoldersService,
    public dialogRef: MatDialogRef<EditFolderComponent>,
    private fb: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data: {
      folder: AssetFolderV3;
    }
  ) {
  	translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
  	if(this.data) {
  		this.folder = this.data.folder;
  		this.generateFolderForm();
      this.storageSrv.selectedWorkspaceSubject
        .subscribe(async(workspace) => {
          if (workspace) {
            this.currentWorkspace = workspace;
          }
        });
  	}
  }

  // generateFolderForm() {
  //   this.folderForm = this.fb.group({
  //     name: [this.folder.name, [Validators.required, removeWhitespaceValidator]],
  //     folderId: this.folder.id
  //   });
  // }
  generateFolderForm() {
    this.folderForm = this.fb.group({
      name: [this.folder.name, [Validators.required, removeWhitespaceValidator]]
    });
  }

  onUpdate() {
  	let folderForm = this.folderForm.getRawValue();
  	this.assetFolderSrv.updateAssetFolder(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      this.folder.id,
      folderForm as AssetFolderUpdateRequest
    ).subscribe(folder => {
  		if(folder) {
  			this.dialogRef.close({ continue: true, outputData: folder });
  		}
  	});
  }

  /**
   * close dialog without changes 
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

}
