import { Component, Input, Output, EventEmitter, ViewChild, ElementRef, OnChanges, SimpleChanges, OnInit } from '@angular/core';
import { ScheduleOptionsForWeek } from '../../models/event-scheduler-models/schedule.options';
import { ScheduleEvent } from '../../models/event-scheduler-models/schedule-event';
import { UUID } from 'angular2-uuid';
import { ScheduleWeekDay } from '../../models/event-scheduler-models/schedule-weekday.model';
import { UtilService } from 'src/app/shared/services/util.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-event-scheduler',
  templateUrl: './event-scheduler.component.html',
  styleUrls: ['./event-scheduler.component.scss'],
})
export class EventSchedulerComponent implements OnChanges, OnInit {


  // view can be dayly weekly and monthly
  view: 'day' | 'week' | 'month' = 'week';
  hourInMiliseconds = 60 * 60 * 1000;
  // default day format
  dayFormat: string = 'dd/MM/yyyy';
  hours: number[] = [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22];

  @Input() hoursStart: number = 0;
  @Input() hoursEnd: number = 24;
  @Input() showCurrentTimeByLine: boolean = false;
  @Input() disableDrawing: boolean = false;
  @Input() realTime: boolean = false;
  @Input() makecurrentDateBolder: boolean = false;
  @Input() shouldSortByPerious: boolean = false;

  @Input() scheduleOtions: ScheduleOptionsForWeek = {
    view: "week",
    dayName: "name",
    dayFormat: this.dayFormat,
    directionsName: 'Hours/Week'
  }

  // input start date by default the current date
  @Input() startDate = this.getThisMonday();

  // input end date
  @Input() endDate = this.resetDate(
    new Date(
      new Date(this.startDate).getFullYear(),
      new Date(this.startDate).getMonth(),
      new Date(this.startDate).getDate() + 6
    )
  ).getTime();

  // input events which should be show on the scheduler calendar
  @Input() events: ScheduleEvent[] = [];

  // property have value only when user draw on the scheduler calendar
  currentCreatedEvent: ScheduleEvent;

  // helper property used on themplate
  @Input() weekDays: ScheduleWeekDay[] = [];
  // shows should generate weekdays or not by default is true
  @Input() shouldGenerateWeekDays: boolean = true;
  // can only change event when property value is true
  // property value is true when user press the left button of mouse
  // or touch and hold the screen
  canChangeEvent: boolean = false;

  isExistingEvent: boolean = false;

  helperTimerForEventInfo = null;
  @ViewChild('schedule') scheduleCalendar: ElementRef;

  eventKeyChangedDirection: 'startDate' | 'endDate' = 'endDate';
  // changed event index
  // have a value when user start draw existing event
  changedEventIndex: number = null;
  // store the event state bofore change it
  eventPreviousState: ScheduleEvent = null;

  shouldLoad: boolean = false;

  positionOfCurrentTime: number = 0;
  timerForCurrentTime = null;
  timeInterval: number = 0; //  in miliseconds
  currentDate: Date = new Date();

  storedCreatedEvent: ScheduleEvent;

  newEvent: string = '';
  // OUTPUT EVENTS START /////////////////////////////////////////////////////////////////////////

  // event emits when user start drawing
  @Output() eventDrawStart: EventEmitter<ScheduleEvent> = new EventEmitter();
  // event emits when user drawing and also update the ScheduleEvent
  @Output() eventDrawUpdate: EventEmitter<ScheduleEvent> = new EventEmitter();
  // event emits when user end drawing and also finish update the new ScheduleEvent
  @Output() eventDrawEnd: EventEmitter<ScheduleEvent> = new EventEmitter();
  // event emits when user start drawing the existing event
  @Output() eventStartChange: EventEmitter<ScheduleEvent> = new EventEmitter();
  // event emits when user drawing and also update the  existing ScheduleEvent
  @Output() eventChange: EventEmitter<ScheduleEvent> = new EventEmitter();
  // event emits when user end drawing and also finish update the existing ScheduleEvent
  @Output() eventEndChange: EventEmitter<{
    eventIndex: number,
    event: ScheduleEvent,
    eventPreviousState: ScheduleEvent
  }> = new EventEmitter();

  // event emits when user enter the cursor over the element
  @Output() eventEnter: EventEmitter<ScheduleEvent> = new EventEmitter();
  // event emits when user leave the cursor from the element
  @Output() eventLeave: EventEmitter<ScheduleEvent> = new EventEmitter();
  // event emits when user remove the event from calendar
  @Output() removeEvent: EventEmitter<ScheduleEvent> = new EventEmitter();
  // event emits when user drawing existing event and also update the current ScheduleEvent
  @Output() eventShouldChange: EventEmitter<{
    eventIndex: number,
    event: ScheduleEvent
  }> = new EventEmitter();
  // event emits when user want to delete the existing event from calendar
  @Output() eventShouldDelete: EventEmitter<{
    eventIndex: number,
    event: ScheduleEvent
  }> = new EventEmitter();

  // OUTPUT EVENTS END/////////////////////////////////////////////////////////////////////////

  constructor(
    public utilSrv: UtilService,
    private translate: TranslateService,
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {

    this.tsTranslation();
    this.generateWeekDays();
  }

  tsTranslation() {
    this.translate.get('EVENTSCHEDULER.NEWEVENT').subscribe((string) => {
      this.newEvent = string;
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.shouldGenerateWeekDays) {
      if (
        changes.startDate && this.endDate || changes.endDate && this.startDate
      ) {
        this.startDate = this.resetDate(new Date(this.startDate)).getTime();
        this.endDate = this.resetDate(new Date(this.endDate)).getTime();
        this.generateWeekDays();
      }
    }

    if (changes.events) {
      setTimeout(() => {
        this.events.forEach(event => {
          this.paintEvent(event);
        })
      }, 1000);
    }

    if (changes.showCurrentTimeByLine) {
      if (this.showCurrentTimeByLine) {
        this.playCurrentTimeTimer();
      } else {
        this.destroyShowingTime();
      }
    }
  }


  /**
   * generate week days at start to end
   * and  make disable days in case
   *
   * @param start is a date in miliseconds (by default is `startDate`)
   * @param end is a date in miliseconds (by default is `endDate`)
   *
   * @return `null`
   */
  generateWeekDays(start: number = this.startDate, end: number = this.endDate) {
    this.weekDays = [];
    let id = 1;
    // day in miliseconds
    let day = 24 * 60 * 60 * 1000;
    for (let i = start; i <= end; i = i + day) {
      this.weekDays.push({
        id: id,
        date: i,
        shortName: 'EEE',
        name: 'EEEE',
        name2: this.scheduleOtions.dayFormat2,
        shouldShowName2: this.scheduleOtions.dayFormat2 ? true : false,
        disabled: false
      });
    }
  }

  /**
   * calls from template
   * check and return boolean value for a make today bolder
   *
   * @param dateInNumber is a date in miliseconds
   *
   * @return `boolean`
   */
  shouldMakeDateBolder(dateInNumber: number) {
    return dateInNumber === new Date(
      this.currentDate.getFullYear(),
      this.currentDate.getMonth(),
      this.currentDate.getDate(),
      0, 0, 0
    ).getTime();
  }

  /**
   * get current monday
   *
   * @param null
   *
   * @return `number`
   * monday date in miliseconds
   */
  getThisMonday() {
    let date = new Date();

    let today = date.getDate();
    let dayOfWeek = this.getWeekDay(date);
    return new Date(
      date.getFullYear(),
      date.getMonth(),
      today - dayOfWeek,
      0, 0, 0
    ).getTime();
  }

  /**
   * helper function for ngfor optimization
   *
   * @param index is a current element index
   * @param item is current item which have id property
   *
   * @return `number`
   */
  onTrackById(index: number, item: { id: number }) {
    return item.id;
  }

  /**
   * helper function for ngfor optimization
   *
   * @param index is a current element index
   * @param item is current item
   *
   * @return `number`
   */
  onTrackByValue(index: number, item: number) {
    return item;
  }

  /**
   * calls from template
   * when user start to draw event
   *
   * generate new event with start and end dates
   * and trigger `eventDrawStart` output event
   *
   * @param event is a `MouseEvent`
   * @param weekDayElement is a current weekDayEvent html element
   * @param weekDay is a current weekDay object
   *
   * @return `null`
   */
  onStartCreateEvent(
    event: MouseEvent,
    weekDayElement: HTMLDivElement,
    weekDay: ScheduleWeekDay) {

    if (weekDay.disabled || this.disableDrawing) {
      return;
    }

    // set canChangeEvent value to true
    this.canChangeEvent = true;
    // generate created date

    this.removeOpenedPopupsFromCalendar();

    let createdDate = this.calculateDateOfEvent(event, weekDayElement);

    let days = {
      onMonday: false,
      onTuesday: false,
      onWednesday: false,
      onThursday: false,
      onFriday: false,
      onSaturday: false,
      onSunday: false
    };

    if (createdDate) {
      let currentDay = new Date(createdDate).getDay();
      switch(currentDay) {
        case 0:
          days.onSunday = true;
          break;
        case 1:
          days.onMonday = true;
          break;
        case 2:
          days.onTuesday = true;
          break;
        case 3:
          days.onWednesday = true;
          break;
        case 4:
          days.onThursday = true;
          break;
        case 5:
          days.onFriday = true;
          break;
        case 6:
          days.onSaturday = true;
      }

      // generate new event
      this.currentCreatedEvent = new ScheduleEvent({
        startDate: createdDate.getTime(),
        endDate: createdDate.getTime(),
        onMonday: days.onMonday,
        onTuesday: days.onTuesday,
        onWednesday: days.onWednesday,
        onThursday: days.onThursday,
        onFriday: days.onFriday,
        onSaturday: days.onSaturday,
        onSunday: days.onSunday,
        playlistName: this.newEvent,
        id: 'new-event'
      });

      this.paintEvent(this.currentCreatedEvent, false);

      this.eventDrawStart.emit(this.currentCreatedEvent);
    }

  }

  /**
   * calls from template
   * when user finish the drawing in schedule calendar
   *
   * set calculated date into generated/or existing event end/or start date
   * and trigger output event depends event is new or not
   * in case of new eventDrawEnd
   * otherwise eventEndChange
   *
   * @param event is a `MouseEvent`
   * @param weekDayElement is a current weekDayEvent html element
   * @param weekDay is a current weekDay object
   *
   * @return `null`
   */
  onEndCreateEvent(
    event: MouseEvent,
    weekDayElement: HTMLDivElement,
    weekDay: ScheduleWeekDay
  ) {

    // If this.currentCreatedEvent is null
    if(!this.currentCreatedEvent) {
      return;
    }

    let calcDate = this.calculateDateOfEvent(event, weekDayElement);
    let startDate = new Date(this.currentCreatedEvent.startDate);
    let _endDate = new Date(this.currentCreatedEvent.endDate);
    let endDate = calcDate.getDay();

    if (!this.canChangeEvent
      || weekDay && weekDay.disabled
      || this.disableDrawing
    ) {
      return;
    }

    if (this.currentCreatedEvent.endDate < this.currentCreatedEvent.startDate) {
      let storedStart = this.currentCreatedEvent.startDate;
      if(_endDate.getDay() != 0) {
        this.currentCreatedEvent.startDate = this.currentCreatedEvent.endDate;
        this.currentCreatedEvent.endDate = storedStart;
      } else {
        this.currentCreatedEvent.endDate = storedStart;
      }
    }

    const eventDuration = Math.abs(this.currentCreatedEvent.startDate - this.currentCreatedEvent.endDate);
    const eventParam = 5 * 60 * 1000;

    // If start day is sunday, end day should also be sunday.
    if(startDate.getDay() == 0 && endDate != 0) {
      let resetCalcDateTime = calcDate.setHours(0);
      this.currentCreatedEvent.startDate = resetCalcDateTime;
    }

    if (eventDuration > eventParam) {
      if (!this.isExistingEvent) {
        this.currentCreatedEvent.id = UUID.UUID();
        this.eventDrawEnd.emit(this.currentCreatedEvent);
        this.removePaintedEvent(this.currentCreatedEvent);
      } else {
        if (
          this.currentCreatedEvent.startDate === this.storedCreatedEvent.startDate
          && this.currentCreatedEvent.endDate === this.storedCreatedEvent.endDate
        ) {
          // do nothing
        } else {
          this.eventEndChange.emit({
            eventIndex: this.changedEventIndex,
            event: this.currentCreatedEvent,
            eventPreviousState: Object.assign({}, this.eventPreviousState)
          });
        }
      }

    } else {
      this.removePaintedEvent(this.currentCreatedEvent);
    }

    this.currentCreatedEvent = null;
    this.canChangeEvent = false;
    this.isExistingEvent = false;
    this.eventKeyChangedDirection = 'endDate';
    this.changedEventIndex = null;
    this.eventPreviousState = null;
  }

  /**
   * calls from template
   * calculate and return event height in percent
   *
   * @param event is a `MouseEvent`
   * @param weekDay Date is a day in miliseconds
   *
   * @return `null`
   */
  onCalculateEventHeight(weekdayDate: number, event: ScheduleEvent) {
    let height: number | string = 100;
    let weekDay = this.getWeekDay(weekdayDate);
    let currentWeekDay = this.getWeekDay(new Date());
    if (weekDay > currentWeekDay) {
      height = 0;
    } else if (weekDay === currentWeekDay) {
      let start = event.startDate > weekdayDate ? event.startDate : weekdayDate;
      let end = event.endDate < weekdayDate ?
        event.endDate
        : weekdayDate + (24 * this.hourInMiliseconds);
      let now = new Date().getTime();
      if (start > new Date().getTime()) {
        height = 0;
      } else if (event.endDate > new Date().getTime()) {
        height = (((now - start) % (24 * this.hourInMiliseconds) * 100 / (end - start)));
        height = height.toFixed(2);
      }
    }
    return height;
  }

  /**
   * calls from template
   * every time when user drawing in schedule calendar
   *
   * set calculated date into generated/or existing event end/or start date
   * and trigger output event depends event is new or not
   * in case of new eventChange
   * otherwise eventDrawUpdate
   *
   * @param event is a `MouseEvent`
   * @param weekDayElement is a current weekDayEvent html element
   *
   * @return `null`
   */
  onCreateEvent(event: MouseEvent, weekDayElement: HTMLDivElement, weekDay: ScheduleWeekDay) {
    if (!this.canChangeEvent || weekDay.disabled || this.disableDrawing) {
      return;
    }

    let createdDate: Date | number = this.calculateDateOfEvent(event, weekDayElement);
    if (createdDate) {
      let eventElements = Array.from(
        this.scheduleCalendar.nativeElement.querySelectorAll(
          `.schedule-event-active`
        )
      ) as HTMLDivElement[];
      eventElements.forEach(eventItem => {
        eventItem.classList.remove('schedule-event-active');
      });
      createdDate = createdDate.getTime();
      this.currentCreatedEvent[this.eventKeyChangedDirection] = createdDate;
      this.paintEvent(this.currentCreatedEvent, false);
      if (this.isExistingEvent) {
        this.eventChange.emit(this.currentCreatedEvent);
      } else {
        this.eventDrawUpdate.emit(this.currentCreatedEvent);
      }
    }
  }

  /**
   * calculate and return Date from current event position
   *
   * @param event is a `MouseEvent`
   * @param weekDayElement is a current weekDayEvent html element
   *
   * @return `Date`
   */
  calculateDateOfEvent(event: MouseEvent, weekDayElement: HTMLDivElement) {
    let weekDayDate = new Date(+weekDayElement.getAttribute('weekday'));
    let dayInHundredPercent = weekDayElement.clientHeight;
    let selectedTime = event.clientY - (weekDayElement.getBoundingClientRect().top);
    let selectedTimeAsPercent = selectedTime * 100 / dayInHundredPercent;
    let hourswithMinutesAsPercent = this.hoursStart + selectedTimeAsPercent * (this.hoursEnd - this.hoursStart) / 100;
    let hours = Math.floor(hourswithMinutesAsPercent);
    let minutes = this.getHoursAndMinutesFromPercent(hourswithMinutesAsPercent);
    return this.transformToDate(weekDayDate, hours, minutes);
  }

  /**
   * calculate and return minutes from percent
   *
   * @param percent with type `number`
   *
   * @return `number`
   */
  getHoursAndMinutesFromPercent(percent: number) {
    let minutesInPercent = (percent % 1) * 100;
    return Math.floor(minutesInPercent * 60 / 100);
  }

  /**
   * calculate and return date from coming arguments
   *
   * @param weekDay with type `Date`
   * @param hours with type `number`
   * @param minutes with type `number`
   *
   * @return `number`
   */
  transformToDate(weekDay: Date, hours: number, minutes: number) {
    if (weekDay instanceof Date) {
      return new Date(
        weekDay.getFullYear(),
        weekDay.getMonth(),
        weekDay.getDate(),
        hours,
        minutes
      );
    }
    return null;
  }

  /**
   * reset and return start and end of loop
   *
   * @param start is a start date in numbers
   * @param end is a end date in numbers
   *
   * @return `{ loopStart: number, loopEnd: number }`
   */
  calculateStartAndEndLoop(start: number, end: number) {

    let loopEnd: number;
    let loopStart: number;

    let startDate = new Date(start);
    let endDate = new Date(end);

    if (startDate) {
      loopStart = this.resetDate(startDate).getTime();
    }

    if (endDate) {
      loopEnd = this.resetDate(endDate).getTime();
    }
    if (loopStart > loopEnd) {
      let helper = loopStart;
      loopStart = loopEnd;
      loopEnd = helper;
    }
    return { loopStart, loopEnd };
  }

  /**
   * paint event on scheduling calendar depends start and end date
   *
   * @param scheduleEvent is a event which should be paint
   * @param isCreated shows event is created or not
   *
   * @return `null`
   */
  paintEvent(scheduleEvent: ScheduleEvent, isCreated: boolean = true) {
    let calendar = this.scheduleCalendar.nativeElement as HTMLDivElement;
    for(let i = 0; i <= 6; i++) {
      let top = 0;
      let bottom = 0;
      let startHour = 0;
      let endHour = 0;

      if(scheduleEvent.startSeconds == undefined && scheduleEvent.endSeconds == undefined) {
        let startDate = new Date(scheduleEvent.startDate);
        let endDate = new Date(scheduleEvent.endDate);
        startHour = startDate.getHours();
        endHour = endDate.getHours();
        top = 100 / 24 * startHour;
        bottom = 100 - (100 / 24 * endHour);
      } else {
        startHour = scheduleEvent.startSeconds / 60 / 60;
        endHour = scheduleEvent.endSeconds / 60 / 60;
        top = 100 / 24 * startHour;
        bottom = 100 - (100 / 24 * endHour);
      }

      let weekDay = calendar.querySelector(`.weekday-${i}`) as HTMLDivElement;
      if (weekDay) {
        let eventElement = weekDay.querySelector(
          `.schedule-event-${scheduleEvent.id}-weekday-${i}`
        ) as HTMLDivElement;
        // store every element
        if (eventElement) {
          eventElement.style.top = `${top}%`;
          eventElement.style.bottom = `${bottom}%`;
          switch(i) {
            case 0:
              if(!scheduleEvent.onMonday) {
                eventElement.style.display = `none`;
              }
              break;
            case 1:
              if(!scheduleEvent.onTuesday) {
                eventElement.style.display = `none`;
              }
              break;
            case 2:
              if(!scheduleEvent.onWednesday) {
                eventElement.style.display = `none`;
              }
              break;
            case 3:
              if(!scheduleEvent.onThursday) {
                eventElement.style.display = `none`;
              }
              break;
            case 4:
              if(!scheduleEvent.onFriday) {
                eventElement.style.display = `none`;
              }
              break;
            case 5:
              if(!scheduleEvent.onSaturday) {
                eventElement.style.display = `none`;
              }
              break;
            case 6:
              if(!scheduleEvent.onSunday) {
                eventElement.style.display = `none`;
              }
          }
        }

        let newEventElement = weekDay.querySelector(
          `.new-event-weekday-${i}`
        ) as HTMLDivElement;
        if (newEventElement) {
          newEventElement.style.top = `${top}%`;
          newEventElement.style.bottom = `${bottom}%`;
        }
      }
    }
  }

  /**
   * detect event mergings and calculate evend container width and left
   *
   * @param weekDay is a events container
   *
   * @return `null`
   */
  sortEventsByPeriods(weekDay: HTMLDivElement) {
    let eventElementPhases = Array.from(
      weekDay.querySelectorAll('.schedule-event-border')
    ) as HTMLDivElement[];
    eventElementPhases.sort((a, b) => {
      return a.offsetTop - b.offsetTop
    })
    let mergedEventsList: {
      start: number,
      end: number,
      elements: HTMLDivElement[],
      elementsForView: HTMLDivElement[][]
    }[] = [
        {
          start: eventElementPhases[0].offsetTop,
          end: eventElementPhases[0].offsetTop + eventElementPhases[0].offsetHeight,
          elements: [eventElementPhases[0]],
          elementsForView: []
        }
      ];
    // debugger;
    for (let i = 1; i < eventElementPhases.length; i++) {

      let element = eventElementPhases[i];
      let elementTop = element.offsetTop;
      let elementBottom = element.offsetTop + element.offsetHeight;
      let isAdded = false;

      for (let j = 0; j < mergedEventsList.length; j++) {

        let mergedEvents = mergedEventsList[j];
        if (elementTop > mergedEvents.start && elementTop < mergedEvents.end) {
          mergedEvents.elements.push(element);
          if (elementBottom > mergedEvents.end) {
            mergedEvents.end = elementBottom;
          }
          isAdded = true;
          break;
        }

        if (elementBottom > mergedEvents.start && elementBottom < mergedEvents.end) {
          mergedEvents.elements.push(element);
          if (elementTop < mergedEvents.start) {
            mergedEvents.start = elementTop;
          }
          isAdded = true;
          break;
        }

        if (elementTop < mergedEvents.start && elementBottom > mergedEvents.end) {
          mergedEvents.elements.push(element);
          mergedEvents.end = elementBottom;
          mergedEvents.start = elementTop;
          isAdded = true;
          break;
        }
      }

      if (!isAdded) {
        mergedEventsList.push({
          start: elementTop,
          end: elementBottom,
          elements: [element],
          elementsForView: []
        });
      }

    }
    this.sortEventsByPlaces(mergedEventsList);
  }

  /**
   * sort events by places and paint in view
   *
   * @param mergedEventsList is a array of objects with
   * - `start`: `number` start of period in pixels
   * - `end`: `number` end of period in pixels
   * - `elements`: `HTMLDivElement[]` all period event containers list
   * - `elementsForView`: `HTMLDivElement[][]` array of elements
   *    which is sorted by places and should be painted
   *
   * @return `null`
   */
  sortEventsByPlaces(mergedEventsList: {
    start: number,
    end: number,
    elements: HTMLDivElement[],
    elementsForView: HTMLDivElement[][]
  }[]
  ) {
    mergedEventsList.forEach((mergedEvents) => {
      let width = 100 / mergedEvents.elements.length;
      mergedEvents.elements.sort((elem1, elem2) => {
        return elem1.offsetTop - elem2.offsetTop;
      });

      for (let i = 0; i < mergedEvents.elements.length; i++) {
        let eachElement = mergedEvents.elements[i];
        mergedEvents.elementsForView.push([eachElement]);
        let currentIndex = mergedEvents.elementsForView.length - 1;
        // debugger;

        let maxHeight = mergedEvents.end;
        for (let j = i + 1; j < mergedEvents.elements.length; j++) {
          if (eachElement.offsetTop + eachElement.offsetHeight < mergedEvents.elements[j].offsetTop
            && mergedEvents.elements[j].offsetTop + mergedEvents.elements[j].offsetHeight <= maxHeight) {

            mergedEvents.elementsForView[currentIndex].push(mergedEvents.elements[j]);
            eachElement = mergedEvents.elements[j];
            mergedEvents.elements.splice(j, 1);
            j = j - 1;

          }
        }
      }
    });

    mergedEventsList.forEach(mergedElement => {
      let width = 100 / mergedElement.elementsForView.length;
      mergedElement.elementsForView.forEach((elements, index) => {
        elements.forEach((element) => {
          element.style.width = width + '%';
          element.style.left = index * width + '%';
        });
      });
    });

  }

  /**
   * remove painted event from scheduling calendar
   *
   * @param scheduleEvent is a event which should be remove
   *
   * @return `null`
   */
  removePaintedEvent(scheduleEvent: ScheduleEvent) {

    let calendar = this.scheduleCalendar.nativeElement as HTMLDivElement;
    let scheduleEvents: HTMLDivElement[] = Array.from(
      calendar.querySelectorAll(`.schedule-event-${scheduleEvent.id}`)
    );
    scheduleEvents.forEach(eventElement => {
      eventElement.style.top = '0';
      eventElement.style.bottom = '100%';
      eventElement.classList.remove('schedule-event-border');
      eventElement.classList.remove('start');
      eventElement.classList.remove('end');
    });
  }

  /**
   * reset and return `Date`
   *
   * @param date is a `Date` which should be transformted
   *
   * @return `Date`
   */
  resetDate(date: Date) {
    return new Date(
      date.getFullYear(),
      date.getMonth(),
      date.getDate(), 0, 0, 0, 0
    );
  }

  /**
   * calls from template
   * when user enter the cursor over the element
   *
   * add class to the event for a somehow highligted
   *
   * @param scheduleEvent which event should be higlighted
   * @param shouldEmitEvent property shows status of event emission
   *
   * @return `null`
   */
  onMakeEventActive(
    scheduleEvent: ScheduleEvent,
    shouldEmitEvent: boolean = true
  ) {
    if (this.canChangeEvent || this.disableDrawing) {
      return;
    }
    if (this.scheduleCalendar) {
      let calendar = this.scheduleCalendar.nativeElement as HTMLDivElement;
      let eventElements = Array.from(
        calendar.querySelectorAll(
          `.schedule-event-border.schedule-event-${scheduleEvent.id}`
        )
      ) as HTMLDivElement[];
      eventElements.forEach(eventItem => {
        eventItem.classList.add('schedule-event-active');
      });
    }

    if (shouldEmitEvent) {
      this.eventEnter.emit(scheduleEvent);
    }
  }

  /**
   * calls from template
   * when user leave the cursor from the element
   *
   * remove active class from the event
   *
   * @param scheduleEvent from which class should be removed
   * @param shouldEmitEvent property shows status of event emission
   *
   * @return `null`
   */
  onMakeEventInactive(
    scheduleEvent: ScheduleEvent,
    shouldEmitEvent: boolean = true
  ) {
    if (this.canChangeEvent || this.disableDrawing) {
      return;
    }
    if (this.scheduleCalendar) {
      let calendar = this.scheduleCalendar.nativeElement as HTMLDivElement;
      let eventElements = Array.from(
        calendar.querySelectorAll(
          `.schedule-event-border.schedule-event-${scheduleEvent.id}`
        )
      ) as HTMLDivElement[];
      eventElements.forEach(eventItem => {
        eventItem.classList.remove('schedule-event-active');
      })
    }

    if (shouldEmitEvent) {
      this.eventLeave.emit(scheduleEvent);
    }
  }



  /**
   * calls from template
   * for a check is event multiday
   *
   * @param event is a curent event
   *
   * @return `boolean`
   */
  isEventMultiday(event: ScheduleEvent) {
    let start = this.resetDate(new Date(event.startDate));
    let end = this.resetDate(new Date(event.endDate));
    return start.getTime() === end.getTime();
  }


  /**
   * trigger output event for a event change
   *
   * @param scheduleEvent is a event which should be changed
   * @param eventContainer is a event container
   *
   * @return `null`
   */
  onEditScheduleEvent(
    scheduleEvent: ScheduleEvent,
    eventContainer: HTMLDivElement,
    eventIndex: number
  ) {
    event.stopPropagation();
    event.preventDefault();
    this.eventShouldChange.emit({
      event: scheduleEvent,
      eventIndex: eventIndex
    });
    this.onCloseEventOptions(eventContainer);

  }

  /**
   * trigger output event for a delete event
   *
   * @param scheduleEvent is a event which should be deleted
   * @param eventContainer is a event container
   *
   * @return `null`
   */
  onShouldDeleteEvent(
    scheduleEvent: ScheduleEvent,
    eventContainer: HTMLDivElement,
    eventIndex: number
  ) {
    event.stopPropagation();
    event.preventDefault();
    this.eventShouldDelete.emit({
      eventIndex: eventIndex,
      event: scheduleEvent
    });
    this.onCloseEventOptions(eventContainer);
  }

  /**
   * close opened event info dialog
   *
   * @param eventContainer is a event container
   *
   * @return `null`
   */
  onCloseEventOptions(eventContainer: HTMLDivElement) {
    event.stopPropagation();
    event.preventDefault();
    if (this.disableDrawing) {
      return;
    }
    let popup = eventContainer.querySelector(
      `.event-info-popup`
    ) as HTMLDivElement;
    if (popup) {
      popup.style.bottom = 'none';
      popup.style.top = 'none';
      popup.style.left = 0 + 'px';
      popup.style.display = 'none';
      popup.style.opacity = 0 + '';
      popup.classList.remove('event-info-opened')
    }
  }

  /**
   * stop triggering event
   *
   * @param event is a event with type `MouseEvent`
   *
   * @return `null`
   */
  onStopPropagation(event: MouseEvent) {
    event.stopPropagation();
  }

  /**
   * calls from template
   * ignore event triggering
   *
   * @param event is a event with type `MouseEvent`
   *
   * @return `null`
   */
  onPreventDefault(event: MouseEvent) {
    event.preventDefault()
  }

  /**
   * open dialog with event info and options
   *
   * @param eventContainer is a event container
   * @param scheduleEvent is a current event which info should be showed
   *
   * @return `null`
   */
  onOpenEventOptions(
    eventContainer: HTMLDivElement,
    scheduleEvent: ScheduleEvent
  ) {
    if (this.disableDrawing) {
      return;
    }
    if (event.type === 'click') {
      event.stopPropagation();
      event.preventDefault();
    }

    this.removeOpenedPopupsFromCalendar();
    this.detectPlaceForEventPopup(eventContainer, 'start');
  }

  /**
   * depends screen sizes detect and open dialog with event info
   *
   * @param eventElement is a event html element
   * @param eventDirection shows direction wher should open popup
   *
   * @return `null`
   */
  detectPlaceForEventPopup(
    eventElement: HTMLDivElement,
    eventDirection: 'start' | 'end'
  ) {
    let popup =
      eventElement.querySelector('.event-info-popup') as HTMLDivElement;
    let weekDayElement = eventElement.parentElement as HTMLDivElement;
    let left: number = 0;
    popup.style.opacity = 0 + '';
    popup.style.display = 'block';
    if (eventDirection === 'start') {
      left = (popup.offsetWidth + 10) * -1;
      let elementOffsetLeft = eventElement.offsetLeft;
      if (weekDayElement.offsetLeft + elementOffsetLeft + left < 0) {
        left = (eventElement.offsetWidth + 10); // make value negative
      }

      popup.style.bottom = 'none';
      popup.style.top = 0 + 'px';
    } else {
      left = eventElement.offsetWidth + 10;
      let elementOffsetLeftAndWidth =
        eventElement.offsetLeft + eventElement.offsetWidth;
      if (
        weekDayElement.offsetLeft + elementOffsetLeftAndWidth + popup.offsetWidth
        > document.body.offsetWidth
      ) {
        left = (popup.offsetWidth + 10) * -1 // make value negative
      }
      popup.style.top = 'none';
      popup.style.bottom = 0 + 'px';
    }
    popup.style.left = left + 'px';
    popup.style.opacity = 1 + '';
    popup.classList.add('event-info-opened');
  }

  /**
   * close all opened event popups
   *
   * @param null
   *
   * @return `null`
   */
  removeOpenedPopupsFromCalendar() {
    if (this.disableDrawing) {
      return;
    }
    let calendar = this.scheduleCalendar.nativeElement as HTMLDivElement;
    let popups = Array.from(calendar.querySelectorAll(
      `.event-info-popup.event-info-opened`
    )) as HTMLDivElement[];
    popups.forEach(popup => {
      popup.style.bottom = 'none';
      popup.style.top = 'none';
      popup.style.left = 0 + 'px';
      popup.style.display = 'none';
      popup.style.opacity = 0 + '';
      popup.classList.remove('event-info-opened')
    });
  }


  /**
   * play interval for a change current time in template every minute
   *
   * @param null
   *
   * @return `null`
   */
  playCurrentTimeTimer() {
    this.timeInterval = (60 - new Date().getSeconds()) * 1000;
    this.calculatePositionOfCurrentTime();
    this.timerForCurrentTime = setInterval(() => {
      this.currentDate = new Date();
      this.calculatePositionOfCurrentTime();
      this.timeInterval = 60 * 1000;
    }, this.timeInterval)
  }

  /**
   * calculate position of current time
   *
   * @param null
   *
   * @return `null`
   */
  calculatePositionOfCurrentTime() {
    let currentTime = new Date();
    let hours = currentTime.getHours();
    let minutes = currentTime.getMinutes();
    let currentTimeInMiliseconds =
      (hours * this.hourInMiliseconds) + (minutes * 60 * 1000);
    let hoursInHundredPercent =
      (this.hoursEnd - this.hoursStart) * this.hourInMiliseconds;
    this.positionOfCurrentTime =
      currentTimeInMiliseconds * 100 / hoursInHundredPercent;
  }

  /**
   * destroy timer
   *
   * @param null
   *
   * @return `null`
   */
  destroyShowingTime() {
    clearInterval(this.timerForCurrentTime);
  }

  /**
   * before existing event manipulation detect direction and prepare to change it
   *
   * @param scheduleEvent is a curent event which should be change
   * @param changeDirection shows from wher should change event form start or end
   *
   * @return `null`
   */
  onStartChangeExistingEvent(
    scheduleEvent: ScheduleEvent,
    changeDirection: 'startDate' | 'endDate' = 'endDate',
    eventIndex: number
  ) {

    event.preventDefault();
    event.stopPropagation();
    if (this.disableDrawing) {
      return;
    }
    this.canChangeEvent = true;
    this.currentCreatedEvent = scheduleEvent;
    this.storedCreatedEvent = Object.assign({}, this.currentCreatedEvent);
    this.removeOpenedPopupsFromCalendar();
    this.eventStartChange.emit(scheduleEvent);
    this.isExistingEvent = true;
    this.eventKeyChangedDirection = changeDirection;
    this.changedEventIndex = eventIndex;
    this.eventPreviousState = Object.assign({}, scheduleEvent);

  }

  getWeekDay(date: Date | number) {
    if (!(date instanceof Date)) {
      date = new Date(date);
    }
    return date.getDay() - 1 < 0 ? 6 : date.getDay() - 1;
  }

  secondsToHoursMinutes(seconds: number) {
    let minutes = '';
    let hours = Math.floor(seconds / 60 / 60);
    let min = Math.floor(seconds / 60 ) - (hours * 60);
    if(min < 10) {
      minutes = `0${min}`;
    } else {
      minutes = min.toString();
    }
    if(hours == 12) {
      return hours+':'+minutes+' PM';
    } else if(hours > 12) {
      return (hours - 12)+':'+minutes+' PM';
    } else {
      return hours+':'+minutes+' AM';
    }
  }
}
