import { Component, OnInit, Inject } from '@angular/core';
import { IntegrationsService } from 'src/app/shared/services/integrations.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';
import { OAuthResourceOption } from 'src/app/shared/models/common-models/oauth-resource-option.model';

@Component({
  selector: 'app-filestack',
  templateUrl: './filestack.component.html',
  styleUrls: ['./filestack.component.scss']
})
export class FilestackComponent implements OnInit {

	driveFolders: OAuthResourceOption[] = [];
  folderTrails: OAuthResourceOption[] = [];
  selectedFolder: OAuthResourceOption;
  selectedFile: OAuthResourceOption;
  loader: boolean = false;

  constructor(
  	private translate: TranslateService,
    private integrationsSrv: IntegrationsService,
    public dialogRef: MatDialogRef<FilestackComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      fromUrl: string;
      fieldKey: string;
    }
  ) { }

  ngOnInit() {
  	if(this.data) {
  		this.getFolders();
  	}
  }

  getFolders() {
    this.loader = true;
  	this.integrationsSrv.getFromUrlRequest(this.data.fromUrl).subscribe( folders => {
      if(folders) {
        this.driveFolders = folders;
        this.sortFolders();
        this.loader = false;
      }
    },
    err => {
      this.loader = false;
    });
  }

  onSelectFile(file) {
  	this.selectedFile = file;
  }

  onSelectFolder(folder) {
    this.selectedFolder = folder;
  }

  onSelectChildFolder(folder) {
    let filteredFolder = this.folderTrails.filter( f => f.id == folder.id);
    if(filteredFolder.length == 0) {
      this.folderTrails.push(folder);
    }
    let apiUrl = '';
    if (this.data.fromUrl.indexOf("?") > -1){
      apiUrl = `${this.data.fromUrl}&folderId=${folder.id}`;
    } else {
      apiUrl = `${this.data.fromUrl}/?folderId=${folder.id}`;
    }
    this.integrationsSrv.getFromUrlRequest(apiUrl).subscribe( folders => {
      if(folders) {
      	this.driveFolders = folders;
        this.sortFolders();
      }
    });
  }

  onCurrentDriveClick() {
    this.folderTrails = [];
    this.integrationsSrv.getFromUrlRequest(this.data.fromUrl).subscribe( folders => {
      if(folders) {
        this.driveFolders = folders;
        this.sortFolders();
      }
    });
  }

  onFolderTrailsClick(folderId, trailIndex) {
    this.folderTrails.length = trailIndex + 1;
    let apiUrl = '';
    if (this.data.fromUrl.indexOf("?") > -1){
      apiUrl = `${this.data.fromUrl}&folderId=${folderId}`;
    } else {
      apiUrl = `${this.data.fromUrl}/?folderId=${folderId}`;
    }
    this.integrationsSrv.getFromUrlRequest(apiUrl).subscribe( folders => {
      if(folders) {
      	this.driveFolders = folders;
        this.sortFolders();
      }
    });
  }

  sortFolders() {
    this.driveFolders.sort((a, b) => a.name.localeCompare(b.name));
  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  onContinue() {
    if (this.selectedFolder) {
      this.dialogRef.close({ continue: true, outputData: this.selectedFolder });
    }
  }

}
