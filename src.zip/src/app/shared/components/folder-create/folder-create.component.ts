import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { AssetFolderCreateRequest } from 'src/app/shared/models/requests-models/asset-folder-create.model';

import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { AssetFoldersService } from 'src/app/shared/services/asset-folders.service';

@Component({
  selector: 'app-folder-create',
  templateUrl: './folder-create.component.html',
  styleUrls: ['./folder-create.component.scss']
})
export class FolderCreateComponent implements OnInit {

  currentWorkspace: Workspace;
  createFolderForm: FormGroup;
  
  constructor(
    public utilSrv: UtilService,
    private storageSrv: StorageService,
    private assetFolderSrv: AssetFoldersService,
    private translate: TranslateService,
    public dialogRef: MatDialogRef<FolderCreateComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { parentId: number },
    private fb: FormBuilder
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.generateCreateFolderForm(this.data.parentId);
    this.storageSrv.selectedWorkspaceSubject
      .subscribe(workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;
        }
      })
  }

  /**
   * generate `createFolderForm`
   * @param parentId is a parent folder id with type `number`
   * @return `null`
   */
  generateCreateFolderForm(parentId: number) {
    this.createFolderForm = this.fb.group({
      name: ['', [Validators.required, removeWhitespaceValidator]],
      folderId: parentId
    })
  }

  /**
   * close dialog without changes 
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * close dialog and create folder 
   * @param null
   * @return `null`
   */
  onCreateFolder() {
    if (this.createFolderForm.valid) {
      let formData:AssetFolderCreateRequest = this.createFolderForm.getRawValue();
      this.assetFolderSrv.addFolder(
        this.currentWorkspace.account.id,
        this.currentWorkspace.id,
        formData
      )
        .subscribe(createdFolder => {
          if(createdFolder) {
            this.dialogRef.close({
              continue: true,
              outputData: createdFolder
            })
          }
        })
    }
  }

}
