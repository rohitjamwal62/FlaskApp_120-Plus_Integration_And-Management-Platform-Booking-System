import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { GoogleDocsSheetsSlideFilestackComponent } from './google-docs-sheets-slide-filestack.component';

describe('GoogleDocsSheetsSlideFilestackComponent', () => {
  let component: GoogleDocsSheetsSlideFilestackComponent;
  let fixture: ComponentFixture<GoogleDocsSheetsSlideFilestackComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ GoogleDocsSheetsSlideFilestackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GoogleDocsSheetsSlideFilestackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
