import { Component, OnInit, Inject } from '@angular/core';
import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { IntegrationsService } from 'src/app/shared/services/integrations.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';

import { GoogleDrive } from 'src/app/shared/models/common-models/google-drive.model';
import { GoogleDriveFolder } from 'src/app/shared/models/integration-models/google-drive-folder.model';

@Component({
  selector: 'app-google-docs-filestack',
  templateUrl: './google-docs-filestack.component.html',
  styleUrls: ['./google-docs-filestack.component.scss']
})
export class GoogleDocsFilestackComponent implements OnInit {

  connectionId: number = 0;
  driveId: string = '';

	currentGoogleDrive: GoogleDrive;
	googleDriveFolders: GoogleDriveFolder[] = [];
  driveFolderTrails: GoogleDriveFolder[] = [];
  selectedFile: GoogleDriveFolder;

  constructor(
  	private translate: TranslateService,
    public utilSrv: UtilService,
    private storageSrv: StorageService,
    private sharedSrv: SharedService,
    private integrationsSrv: IntegrationsService,
    public dialogRef: MatDialogRef<GoogleDocsFilestackComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
    	connectionId: number;
    	drive: GoogleDrive;
    	driveId: string;
      googleDriveFolders: GoogleDriveFolder[];
    }
  ) { }

  ngOnInit() {
  	if(this.data) {
  		this.connectionId = this.data.connectionId;
  		this.driveId = this.data.driveId;
  		this.googleDriveFolders = this.data.googleDriveFolders;
  		this.currentGoogleDrive = this.data.drive;
      this.sortFolders();
  	}
  }
  
  onTrailsClick(folderId, trailIndex) {
    this.driveFolderTrails.length = trailIndex + 1;
    this.integrationsSrv.getGoogleDriveDocs(this.connectionId, this.driveId, folderId).subscribe( assets => {
      if(assets) {
        this.googleDriveFolders = assets;
        this.sortFolders();
      }
    });
  }

  onCurrentDriveClick() {
    this.driveFolderTrails = [];
    this.integrationsSrv.getGoogleDriveFolders(this.connectionId, this.driveId).subscribe( folders => {
      if(folders) {
        this.googleDriveFolders = folders;
        this.sortFolders();
      }
    });
  }

  onSearchDriveDocs(folder) {
    let filteredFolder = this.driveFolderTrails.filter( f => f.id == folder.id);
    if(filteredFolder.length == 0) {
      this.driveFolderTrails.push(folder);
    }
    this.integrationsSrv.getGoogleDriveDocs(this.connectionId, this.driveId, folder.id).subscribe( assets => {
      if(assets) {
        this.googleDriveFolders = assets;
        this.sortFolders();
      }
    });
  }

  onSelectFile(docs) {
    this.selectedFile = docs;
  }

  sortFolders() {
    this.googleDriveFolders.sort((a, b) => a.name.localeCompare(b.name));
  }

  /**
   * close dialog without changes 
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  onContinue() {
    if (this.selectedFile) {
      this.dialogRef.close({ continue: true, outputData: this.selectedFile });
    }
  }

}
