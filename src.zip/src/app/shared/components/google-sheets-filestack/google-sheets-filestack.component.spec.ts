import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { GoogleSheetsFilestackComponent } from './google-sheets-filestack.component';

describe('GoogleSheetsFilestackComponent', () => {
  let component: GoogleSheetsFilestackComponent;
  let fixture: ComponentFixture<GoogleSheetsFilestackComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ GoogleSheetsFilestackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GoogleSheetsFilestackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
