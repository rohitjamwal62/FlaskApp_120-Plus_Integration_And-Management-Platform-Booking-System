import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { GoogleSlideFilestackComponent } from './google-slide-filestack.component';

describe('GoogleSlideFilestackComponent', () => {
  let component: GoogleSlideFilestackComponent;
  let fixture: ComponentFixture<GoogleSlideFilestackComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ GoogleSlideFilestackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GoogleSlideFilestackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
