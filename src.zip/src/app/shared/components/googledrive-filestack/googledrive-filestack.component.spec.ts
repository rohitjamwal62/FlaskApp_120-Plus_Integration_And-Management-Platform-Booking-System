import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { GoogledriveFilestackComponent } from './googledrive-filestack.component';

describe('GoogledriveFilestackComponent', () => {
  let component: GoogledriveFilestackComponent;
  let fixture: ComponentFixture<GoogledriveFilestackComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ GoogledriveFilestackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GoogledriveFilestackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
