import { Component, OnInit, Inject } from '@angular/core';
import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { IntegrationsService } from 'src/app/shared/services/integrations.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';

import { GoogleDrive } from 'src/app/shared/models/common-models/google-drive.model';
import { GoogleDriveFolder } from 'src/app/shared/models/integration-models/google-drive-folder.model';

@Component({
  selector: 'app-googledrive-filestack',
  templateUrl: './googledrive-filestack.component.html',
  styleUrls: ['./googledrive-filestack.component.scss']
})
export class GoogledriveFilestackComponent implements OnInit {

	connectionId: number = 0;
  driveId: string = '';

	currentGoogleDrive: GoogleDrive;
	googleDriveFolders: GoogleDriveFolder[] = [];
  driveFolderTrails: GoogleDriveFolder[] = [];
  selectedFolder: GoogleDriveFolder;

  constructor(
  	private translate: TranslateService,
    public utilSrv: UtilService,
    private storageSrv: StorageService,
    private sharedSrv: SharedService,
    private integrationsSrv: IntegrationsService,
    public dialogRef: MatDialogRef<GoogledriveFilestackComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
    	connectionId: number;
    	drive: GoogleDrive;
    	driveId: string;
      googleDriveFolders: GoogleDriveFolder[];
    }
  ) { }

  ngOnInit() {
  	if(this.data) {
  		this.googleDriveFolders = this.data.googleDriveFolders;
  		this.connectionId = this.data.connectionId;
  		this.driveId = this.data.driveId;
  		this.currentGoogleDrive = this.data.drive;
      this.sortFolders();
  	}
  }

  onSelectGoogleDriveFolder(folder) {
    this.selectedFolder = folder;
  }
  onSelectGoogleDriveChildFolder(folder) {
    let filteredFolder = this.driveFolderTrails.filter( f => f.id == folder.id);
    if(filteredFolder.length == 0) {
      this.driveFolderTrails.push(folder);
    }
    this.integrationsSrv.getGoogleDriveChildFolders(this.connectionId, this.driveId, folder.id).subscribe( assets => {
      if(assets) {
        this.googleDriveFolders = assets;
        this.sortFolders();
      }
    });
  }
  onCurrentGoogleDriveClick() {
    this.driveFolderTrails = [];
    this.integrationsSrv.getGoogleDriveFolders(this.connectionId, this.driveId).subscribe( folders => {
      if(folders) {
        this.googleDriveFolders = folders;
        this.sortFolders();
      }
    });
  }
  onDriveFolderTrailsClick(folderId, trailIndex) {
    this.driveFolderTrails.length = trailIndex + 1;
    this.integrationsSrv.getGoogleDriveChildFolders(this.connectionId, this.driveId, folderId).subscribe( assets => {
      if(assets) {
        this.googleDriveFolders = assets;
        this.sortFolders();
      }
    });
  }

  sortFolders() {
    this.googleDriveFolders.sort((a, b) => a.name.localeCompare(b.name));
  }

  /**
   * close dialog without changes 
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  onContinue() {
    if (this.selectedFolder) {
      this.dialogRef.close({ continue: true, outputData: this.selectedFolder });
    }
  }

}
