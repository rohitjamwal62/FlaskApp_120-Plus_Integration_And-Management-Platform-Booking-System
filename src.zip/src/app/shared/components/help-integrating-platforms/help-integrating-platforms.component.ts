import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { take } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';

import { UtilService } from 'src/app/shared/services/util.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { IntegrationsService } from 'src/app/shared/services/integrations.service';
import { IntegrationsOptService } from 'src/app/shared/services/integrations-opt.service';

import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { IntegrationTypes } from 'src/app/shared/models/integration-models/integration-types.model';

@Component({
  selector: 'app-help-integrating-platforms',
  templateUrl: './help-integrating-platforms.component.html',
  styleUrls: ['./help-integrating-platforms.component.scss']
})
export class HelpIntegratingPlatformsComponent implements OnInit {

  integrationTypes: IntegrationTypes[];
  currentLocale: any = '';

  constructor(
    public utilSrv: UtilService,
    private translate: TranslateService,
    public dialogRef: MatDialogRef<HelpIntegratingPlatformsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      integrationTypes: IntegrationTypes[];
    },
    public storageSrv: StorageService,
    private sharedSrv: SharedService

  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.currentLocale = this.utilSrv.locale;
    if(this.data) {
      let integrationTypes = this.data.integrationTypes;
      if(integrationTypes) {
        this.integrationTypes = integrationTypes.filter( integration => {
          if(integration.hasOwnProperty('help') && integration.help !== null) {
            return integration;
          }
        });
      }
    }
  }

  onOpenHelp(integration) {
    this.dialogRef.close({continue: true, outputData: integration.help});
  }

  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

}
