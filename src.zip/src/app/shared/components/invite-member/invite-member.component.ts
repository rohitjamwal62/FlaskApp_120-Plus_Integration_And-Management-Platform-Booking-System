import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { WorkspaceV3 } from 'src/app/shared/models/workspace-models/workspace-v3.model';
import { WorkspaceRole } from 'src/app/shared/models/workspace-models/workspace-role.model';

import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { WorkspacesService } from 'src/app/shared/services/workspaces.service';
import { InvitationsService } from 'src/app/shared/services/invitations.service';

@Component({
  selector: 'app-invite-member',
  templateUrl: './invite-member.component.html',
  styleUrls: ['./invite-member.component.scss']
})
export class InviteMemberComponent implements OnInit {

  inviteMemberForm: FormGroup;
  workspaces: WorkspaceV3[];
  workspaceRolesById: { [key:number]: WorkspaceRole[] } = {};
  selectedWorkspaceRoles = [];
  currentLocale: any = '';

  highlightedWorkspace: Array<boolean> = [];

  constructor(
    public utilSrv: UtilService,
    public storageSrv: StorageService,
    private translate: TranslateService,
    private workspaceSrv: WorkspacesService,
    private invitationsSrv: InvitationsService,
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<InviteMemberComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      accountId: number
    }
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {

    this.currentLocale = this.utilSrv.locale;
    this.generateInviteMemberForm();

    if (this.data) {
      this.inviteMemberForm.patchValue(this.data);
      this.getAccountsWorkspaces();
    }
  }

  getAccountsWorkspaces() {
    //let workspaces = this.storageSrv.workspacesByAccountsId[this.data.accountId];
    this.workspaceSrv.getWorkspaces(this.data.accountId)
      .subscribe( workspaces => {
        if(workspaces) {
          this.workspaces = workspaces;
          this.workspaces.forEach(workspace => {
            this.getWorkspaceRoles(workspace.id);
          });
        }
      });
  }

  getWorkspaceRoles(workspaceId: number) {
    this.workspaceSrv.getWorkspaceRoles(
      this.data.accountId,
      workspaceId
    )
      .subscribe( workspaceRoles => {
        if(workspaceRoles) {
          this.workspaceRolesById[workspaceId] = workspaceRoles;
        }
      })
  }


  /**
   * generate `inviteMemberForm`
   * @param null
   * @return `null`
   */
  generateInviteMemberForm() {
    this.inviteMemberForm = this.fb.group({
      workspaceGroupIds: null,
      email: ['', [Validators.required, Validators.email, removeWhitespaceValidator]]
    });
  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * close dialog with new invotation info output data
   * @param null
   * @return `null`
   */
  onInviteMember() {
    if (this.inviteMemberForm.valid) {
      let data = this.inviteMemberForm.getRawValue();

      // transform workspace groups into ids
      var ids = [];
      this.selectedWorkspaceRoles.forEach(role => {
        ids.push(role.id);
      });
      data["workspaceGroupIds"] = ids;

      this.invitationsSrv.createInvitation(
        this.data.accountId,
        data
      )
        .subscribe(invitation => {
          if (invitation) {
            this.dialogRef.close({
              continue: true,
              outputData: invitation
            });
          }
        })
    }
  }

  addWorkspaceRole(workspaceRole, id) {
    // if already in, ignore it
    let found = false;
    let selectedWorkspaceRoles = this.selectedWorkspaceRoles;

    if(this.selectedWorkspaceRoles.length > 0) {
      selectedWorkspaceRoles.forEach((role, i) => {
        if (role.id == workspaceRole.id){
          found = true;
          return;
        }
        // same parent workspace so cant be added
        if (role.workspace == workspaceRole.workspace){
          this.selectedWorkspaceRoles.splice(i, 1);
        }
      });

      if(found) {
        this.removeWorkspaceRole(workspaceRole);
      } else {
        this.selectedWorkspaceRoles.push(workspaceRole);
      }

    } else {
      this.selectedWorkspaceRoles.push(workspaceRole);
    }

  }

  isSelectedWorkspaceRole(workspaceRoleId) {
    let selectedWorkspaceRoles = this.selectedWorkspaceRoles;
    let findWorkspaceRole = selectedWorkspaceRoles.find( wr => wr.id == workspaceRoleId);
    return findWorkspaceRole;
  }

  removeWorkspaceRole(workspaceRole){
    // need to find index of the group
    let removeIndex = -1;
    for (var i = 0; i < this.selectedWorkspaceRoles.length; i++){
      if (this.selectedWorkspaceRoles[i].id == workspaceRole.id){
        removeIndex = i;
        break;
      }
    }
    if (removeIndex > -1){
      this.selectedWorkspaceRoles.splice(removeIndex, 1);
    }
  }


  getWorkspaceFromGroup(workspaceGroup){
    for (var i = 0; i < this.workspaces.length; i++){
      if (this.workspaces[i].id == workspaceGroup.workspace.id){
        return this.workspaces[i];
      }
    }
    return null;
  }

}