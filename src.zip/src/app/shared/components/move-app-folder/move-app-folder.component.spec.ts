import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MoveAppFolderComponent } from './move-app-folder.component';

describe('MoveAppFolderComponent', () => {
  let component: MoveAppFolderComponent;
  let fixture: ComponentFixture<MoveAppFolderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MoveAppFolderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MoveAppFolderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
