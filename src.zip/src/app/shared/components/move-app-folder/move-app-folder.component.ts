import { Component, OnInit, Inject } from '@angular/core';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { forkJoin, of } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';

import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { Apps } from 'src/app/shared/models/apps-models/apps.model';
import { AppFolder } from 'src/app/shared/models/app-folders/app-folder.model';
import { AppFolderUpdateRequest } from 'src/app/shared/models/requests-models/app-folder-update.model';
import { Pagination } from 'src/app/shared/models/common-models/pagination.model';

import { UtilService } from 'src/app/shared/services/util.service';
import { AppsService } from 'src/app/shared/services/apps.service';
import { AppFoldersService } from 'src/app/shared/services/app-folders.service';
import { StorageService } from 'src/app/shared/services/storage.service';

@Component({
  selector: 'app-move-app-folder',
  templateUrl: './move-app-folder.component.html',
  styleUrls: ['./move-app-folder.component.scss']
})
export class MoveAppFolderComponent extends CleanOnDestroy implements OnInit {

  currentWorkspace: Workspace;

  parentFolderId: number;
  currentParentFolder: AppFolder;
  selectedAppFolders: AppFolder[] = [];

  // Breadcrumbs
  folderTrails: AppFolder[] = [];

  folderImage: string = '';
  selectedFolder: AppFolder = null;
  foldersToMove: AppFolder[] = [];
  appFolders: AppFolder[];
  appFoldersPaginate: Pagination;
  appFoldersChildrenPaginate: Pagination;

  folderReq: { id: number; folderId: number; name: string }[] = [];

  selectedApps: Apps[] = [];
  appsToMove: Apps[] = [];
  apps: Apps[] = [];
  appsReq: { id: number; folderId: number; }[] = [];

  isDefaultAppFolder:boolean = false;
  isSelectedChildFolder: boolean = false;

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    private storageSrv: StorageService,
    private appsSrv: AppsService,
    private appFoldersSrv: AppFoldersService,
    public dialogRef: MatDialogRef<MoveAppFolderComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      selectedAppFolders: AppFolder[],
      selectedApps: Apps[],
      parentFolderId: number
    },
  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    if (this.data) {
      this.foldersToMove = this.data.selectedAppFolders;
      this.appsToMove = this.data.selectedApps;
      this.parentFolderId = this.data.parentFolderId;
      this.selectedAppFolders = this.data.selectedAppFolders;
      this.selectedApps = this.data.selectedApps;

      this.subscriber = this.storageSrv.selectedWorkspaceSubject
        .subscribe( workspace => {
          if (workspace) {
            this.currentWorkspace = workspace;
            this.getAppFolders();
            this.extractFolderIds();
          }
        });
    }

    this.folderImage = this.utilSrv.appImages.folder;
  }

  //-------------------------------------------------------------------------------
  // Common Methods
  //-------------------------------------------------------------------------------

  extractFolderIds() {
    this.folderReq = this.selectedAppFolders.map( folder => {
      return { id: folder.id, folderId: folder.parentFolder, name: folder.name };
    });

    this.appsReq = this.selectedApps.map( app => {
      return { id: app.id, folderId: null };
    });
  }

  removeFolderSelectionsFromList() {
    this.foldersToMove.forEach(  folder => {
      let index = this.appFolders.findIndex( (appFolder, index) => folder.id === appFolder.id);
      if(index != -1) {
        this.appFolders.splice(index, 1);
      }
    });
  }

  /**
   * calls from template
   * helper for a optimizing *ngFor
   * @param index is a current element index with type `number`
   * @param item is a current element info with type `Workspace`
   * @return `number`
   */
  onTrackById(index: number, item: { id: number }) {
    return item.id;
  }

  //-------------------------------------------------------------------------------
  // Common Methods
  //-------------------------------------------------------------------------------

  //-------------------------------------------------------------------------------
  // App Folder Methods
  //-------------------------------------------------------------------------------

  backToRootFolder() {
    this.folderTrails.length = 0;
    this.isSelectedChildFolder = false;
    this.selectedFolder = null;
    this.getAppFolders();
  }

  onTrailsClick(folder, index) {
    if(this.folderTrails && this.folderTrails.length != 0) {
      this.folderTrails.length = parseInt(index) + 1;
    } else {
      this.folderTrails.length = 0;
    }
    this.isSelectedChildFolder = true;
    this.selectedFolder = folder;
    this.getChildrenFoldersAndApps(folder.id);
  }

  /**
   * calls from template
   * when user clicked on the folder for a select it
   * @param folder is a user selected folder
   * @return `null`
   */
  onSelectFolder(selectedFolder: AppFolder) {
    if(selectedFolder == null) {
      this.isDefaultAppFolder = true;
      this.selectedFolder = null;
      this.folderReq = this.prepareFolderReq(0);
      this.appsReq = this.prepareAppsReq(0);
    } else {
      this.isDefaultAppFolder = false;
      this.selectedFolder = selectedFolder;
      this.folderReq = this.prepareFolderReq(this.selectedFolder.id);
      this.appsReq = this.prepareAppsReq(this.selectedFolder.id);
    }
  }

  /**
   * calls from template
   * store user opened folder
   * for a show those files which `parentFolder.id === currentParentFolder.id`
   * @param folderId with type `number` which should be opened
   * @return `null`
   */
  onOpenFolder(event: MouseEvent, folder: AppFolder) {
    event.stopPropagation();
    let folderTrails = this.folderTrails;
    let folderIndex = folderTrails.findIndex( index => index.id == folder.id);
    if(folderIndex == -1) {
      this.folderTrails.push(folder);
    }
    this.isSelectedChildFolder = true;
    this.selectedFolder = folder;
    this.getChildrenFoldersAndApps(folder.id);
  }

  getAppFolders() {
    this.subscriber = this.appFoldersSrv.getAppsFolders(
      this.currentWorkspace.account.id, 
      this.currentWorkspace.id
    )
      .subscribe( response => {
        if(response) {
          this.appFolders = response.message;
          this.appFoldersPaginate = response.pagination;
        }
      });
  }

  getAppFoldersNext() {
    this.subscriber = this.appFoldersSrv.getAppsFoldersNext(
      this.appFoldersPaginate.next
    )
      .subscribe( response => {
        if(response) {
          this.appFolders.push(...response.message);
          this.appFoldersPaginate = response.pagination;
        }
      });
  }

  getChildrenFoldersAndApps(folderId: number) {
    this.subscriber = this.appFoldersSrv.getAppsInFolders(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      folderId
    ).subscribe( response => {
      if(response) {
        let rawData: any = response.message;
        let apps: any = rawData.filter( app => app.type.name != 'folder');
        let folders: any = rawData.filter( app => app.type.name == 'folder');
        this.apps = apps;
        this.appFolders = folders;
        this.appFoldersChildrenPaginate = response.pagination;
      }
    }, err => {

    });
  }

  getChildrenFoldersAndAppsNext() {
    this.subscriber = this.appFoldersSrv.getAppsInFoldersNext(
      this.appFoldersChildrenPaginate.next
    )
      .subscribe( response => {
        if(response) {
          this.appFolders.push(...response.message);
          this.appFoldersChildrenPaginate = response.pagination;
        }
      });
  }

  updateAppFolders() {
    let appFoldersForUpdate: { folders: AppFolderUpdateRequest[] } = { folders: this.folderReq };
    this.subscriber = this.appFoldersSrv.updateAppFolders(
      this.currentWorkspace.account.id, 
      this.currentWorkspace.id, 
      appFoldersForUpdate
    )
      .subscribe( folders => {
        if(folders) {
          this.dialogRef.close({ continue: true, outputData: { folders: folders, apps: null } });
        }
      });
  }

  prepareFolderReq(folderId: number | null) {
    let folderReq = this.folderReq.map( folder => {
      return { id: folder.id, folderId: folderId, name: folder.name };
    });
    return folderReq;
  }
  //-------------------------------------------------------------------------------
  // App Folder Methods
  //-------------------------------------------------------------------------------

  //-------------------------------------------------------------------------------
  // Apps Methods
  //-------------------------------------------------------------------------------

  prepareAppsReq(folderId: number | null) {
    let appsReq = this.appsReq.map( app => {
      return { id: app.id, folderId: folderId };
    });
    return appsReq;
  }

  updateApps() {
    let appsForUpdate: { apps: { id: number; folderId: number }[] } = { apps: this.appsReq };
    this.subscriber = this.appsSrv.updateApps(
      this.currentWorkspace.account.id, 
      this.currentWorkspace.id, 
      appsForUpdate
    )
      .subscribe( apps => {
        if(apps) {
          this.dialogRef.close({ continue: true, outputData: { folders: null, apps: apps } });
        }
      });
  }

  updateAppsAndFolders() {
    let appFoldersForUpdate: { folders: AppFolderUpdateRequest[] } = { folders: this.folderReq };
    let appsForUpdate: { apps: { id: number; folderId: number }[] } = { apps: this.appsReq };
    forkJoin(
      {
        apps: of(this.appsSrv.updateApps(this.currentWorkspace.account.id, this.currentWorkspace.id, appsForUpdate)),
        folders: of(this.appFoldersSrv.updateAppFolders(this.currentWorkspace.account.id, this.currentWorkspace.id, appFoldersForUpdate))
      }
    ).subscribe(response => {

      response.apps.subscribe( apps => {
        if(apps) {
          this.dialogRef.close({ continue: true, outputData: null });
        }
      });
      
      response.folders.subscribe( folders => {
        if(folders) {
          this.dialogRef.close({ continue: true, outputData: null });
        }
      });
    });
  }

  //-------------------------------------------------------------------------------
  // Apps Methods
  //-------------------------------------------------------------------------------

  /**
   * close with selected folder
   * @param null
   * @return `null`
   */
  onContinue() {
    if(this.folderReq.length > 0 && this.appsReq.length > 0) {
      this.updateAppsAndFolders();
    } else {
      if(this.appsReq.length > 0) {
        this.updateApps();
      } else {
        this.updateAppFolders();
      }
    }
  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

}
