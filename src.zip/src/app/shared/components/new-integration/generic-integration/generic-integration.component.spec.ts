import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { GenericIntegrationComponent } from '.generic-integration.component';

describe('GenericIntegrationComponent', () => {
  let component: GenericIntegrationComponent;
  let fixture: ComponentFixture<GenericIntegrationComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ GenericIntegrationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenericIntegrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
