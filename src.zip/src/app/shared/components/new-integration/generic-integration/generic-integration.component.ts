import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment';
import { StorageService } from 'src/app/shared/services/storage.service';
import { IntegrationsService } from 'src/app/shared/services/integrations.service';
import { GenericIntegrationCreateRequest } from 'src/app/shared/models/requests-models/generic-integration-create.model';
import { IntegrationOption } from 'src/app/shared/models/integration-models/integration-option.model';
import { InputField } from 'src/app/shared/models/common-models/input-field.model';
import { ClientToken } from 'src/app/shared/models/integration-models/client-token.model';

// Utils
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

@Component({
  selector: 'app-generic-integration',
  templateUrl: './generic-integration.component.html',
  styleUrls: ['./generic-integration.component.scss']
})
export class GenericIntegrationComponent implements OnInit {

  newGenericIntegrationForm: FormGroup;
  integrationType: IntegrationOption;
  existingIntegration: ClientToken = null;
  formSubmitted: boolean = false;

  constructor(
    private fb: FormBuilder,
  	@Inject(MAT_DIALOG_DATA) public data: {
  	  integrationType: IntegrationOption,
  	  integration: ClientToken
  	},
  	public dialogRef: MatDialogRef<GenericIntegrationComponent>,
    private storageSrv: StorageService,
    private integrationsSrv: IntegrationsService
  ) {
  }

  ngOnInit() {
    this.integrationType = this.data.integrationType;
    if (this.data.integration != null){
      this.existingIntegration = this.data.integration;
    }

    this.generateIntegrationForm(this.integrationType);
  }

  generateIntegrationForm(integrationType: IntegrationOption) {
    if (this.existingIntegration != null){
      this.newGenericIntegrationForm = this.fb.group({
        name: [this.existingIntegration.name, [Validators.required, removeWhitespaceValidator]],
        expiresAt: [''],
        properties: this.fb.group({})
      });

      integrationType.fields.forEach(inputField => {
        // this is the logic we want to use for v3
        (this.newGenericIntegrationForm.get(['properties']) as FormGroup).setControl(
            inputField.name,
            this.fb.control(
              null,
              null
            )
        );

        if (inputField.disabled || !inputField.editable) {
          this.newGenericIntegrationForm.get(['properties', inputField.name]).disable();
        }
      });


    } else {
      this.newGenericIntegrationForm = this.fb.group({
        name: ['', [Validators.required, removeWhitespaceValidator]],
        expiresAt: [''],
        properties: this.fb.group({})
      });

      integrationType.fields.forEach(inputField => {

        // this is the logic we want to use for v3
        (this.newGenericIntegrationForm.get(['properties']) as FormGroup).setControl(
            inputField.name,
            this.fb.control(
              inputField.default != undefined ? inputField.default : null,
              inputField.required ? [Validators.required] : null
            )
        );

        if (inputField.disabled) {
          this.newGenericIntegrationForm.get(['properties', inputField.name]).disable();
        }
      });

    }

  }

  onGenericIntegration() {
    let formData:GenericIntegrationCreateRequest = this.newGenericIntegrationForm.getRawValue();
    let expiresAt = this.newGenericIntegrationForm.get('expiresAt').value;
    formData.workspaceId = this.storageSrv.selectedWorkspace.id;
    formData.expiresAt = moment(expiresAt).unix();
    if (formData.expiresAt == null || Number.isNaN(formData.expiresAt)){
      formData.expiresAt = 0;
    }

    // this should be removed when updatign to v3 endpoints
    Object.entries(formData["properties"]).map(([key, value]) => {
      formData[key] = value;
    })

    if (!this.formSubmitted){
      this.formSubmitted = true;

      if (this.existingIntegration != null){
        if (this.newGenericIntegrationForm.valid) {
          this.integrationsSrv.updateIntegration(this.existingIntegration.id, formData)
            .subscribe( updatedIntegration => {
              this.formSubmitted = false;
              if(updatedIntegration) {
                for (var i = 0; i < this.storageSrv.workspaceIntegrations.length; i++){
                  if (this.integrationType.form === "clientCredentials" && this.storageSrv.workspaceIntegrations[i].id == updatedIntegration.id){
                    this.storageSrv.workspaceIntegrations.splice(i, 1, updatedIntegration);
                    break;
                  }
                }
                this.dialogRef.close({ continue: false, outputData: null });
              }
            }, error => {
              this.formSubmitted = false;
            });
        }
      } else {
        if (this.newGenericIntegrationForm.valid) {
          this.integrationsSrv.createGenericIntegration(formData, this.integrationType)
            .subscribe( createdIntegration => {
              this.formSubmitted = false;
              if(createdIntegration) {
                this.storageSrv.workspaceIntegrations.push(createdIntegration);
                this.dialogRef.close({ continue: false, outputData: createdIntegration });
              }
            }, error => {
              this.formSubmitted = false;
            });
        }
      }
    }
  }

  onTrackById(index: number, item: InputField) {
    return item.id;
  }

  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

}
