import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { IntegrationInfoComponent } from './integration-info.component';

describe('IntegrationInfoComponent', () => {
  let component: IntegrationInfoComponent;
  let fixture: ComponentFixture<IntegrationInfoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ IntegrationInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntegrationInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
