import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { StorageService } from 'src/app/shared/services/storage.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { UtilService } from 'src/app/shared/services/util.service';

import { GenericIntegrationComponent } from 'src/app/shared/components/new-integration/generic-integration/generic-integration.component';

@Component({
  selector: 'app-integration-info',
  templateUrl: './integration-info.component.html',
  styleUrls: ['./integration-info.component.scss']
})
export class IntegrationInfoComponent implements OnInit {

	integration: any = [];

  constructor(
  	public dialogRef: MatDialogRef<IntegrationInfoComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
    	integration: any
    },
    public storageSrv: StorageService,
    private sharedSrv: SharedService,
    public utilSrv: UtilService,
  ) {

  }

  ngOnInit() {
  	this.integration = this.data.integration;
  }

  onIntegrate() {
  	if (this.integration.form === "clientCredentials"){
      this.sharedSrv.openDialog(
        {integrationType: this.integration},
        true,
        null,
        GenericIntegrationComponent
      ).subscribe(response => {
        if (response.outputData) {
          this.dialogRef.close({ continue: false, outputData: response.outputData });
        }
      });
    } else if (this.integration.form === "oauth"){
      window.open(
        (this.utilSrv.env.endPoint+"/"+this.integration.type+"/{id}/login/").replace(/{id}/g, ""+this.storageSrv.selectedWorkspace.id),
        'BOLDcast OAuth Integration',
        'width=720,height=600'
      );
    }
  }

  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

}
