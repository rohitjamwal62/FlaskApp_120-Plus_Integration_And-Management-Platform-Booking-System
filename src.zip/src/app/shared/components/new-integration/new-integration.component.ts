import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { UtilService } from 'src/app/shared/services/util.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { IntegrationsService } from 'src/app/shared/services/integrations.service';
import { IntegrationsOptService } from 'src/app/shared/services/integrations-opt.service';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { take } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import { IntegrationInfoComponent } from './integration-info/integration-info.component';

@Component({
  selector: 'app-new-integration',
  templateUrl: './new-integration.component.html',
  styleUrls: ['./new-integration.component.scss']
})
export class NewIntegrationComponent implements OnInit {

  inviteMemberForm: FormGroup;
  workspaces: Workspace[];
  selectedWorkspaceGroups = [];
  integrationOptions: any = [];
  currentLocale: any = '';

  constructor(
    public utilSrv: UtilService,
    private translate: TranslateService,
    private integrationSrv: IntegrationsService,
    private integrationsOptSrv: IntegrationsOptService,
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<NewIntegrationComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      defaultIntegrationKey: any
    },
    public storageSrv: StorageService,
    private sharedSrv: SharedService

  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.currentLocale = this.utilSrv.locale;
    this.integrationOptions = this.storageSrv.integrationOptions;

    if (this.data.defaultIntegrationKey != null && this.data.defaultIntegrationKey !== ""){

      // get the integration using the keys
      var selectedIntegration = this.integrationOptions.find(x => x.type === this.data.defaultIntegrationKey);
      if (selectedIntegration){
        this.onNewIntegration(selectedIntegration);
      }
    }
  }

  onNewIntegration(integration) {
    // if (integration.type === "keys"){
    //   this.sharedSrv.openDialog(
    //     {},
    //     true,
    //     null,
    //     integration.component
    //   ).subscribe(response => {
    //     if (response.outputData) {
    //       this.dialogRef.close({ continue: false, outputData: response.outputData });
    //     }
    //   });
    // } else if (integration.type === "oauth"){
    //     window.open(
    //       integration.loginRoute.replace(/{id}/g, this.storageSrv.selectedWorkspace.id),
    //       'BOLDcast OAuth Integration',
    //       'width=720,height=600'
    //     );
    // }
    this.sharedSrv.openDialog(
      {
        integration: integration
      },
      true,
      null,
      IntegrationInfoComponent
    ).subscribe(response => {
      if (response.outputData) {
        this.dialogRef.close({ continue: true, outputData: response.outputData });
      }
    });
  }

  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

}
