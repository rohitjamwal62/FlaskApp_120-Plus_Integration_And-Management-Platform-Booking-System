import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { UtilService } from 'src/app/shared/services/util.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { SchedulesService } from 'src/app/shared/services/schedules.service';
import { ScheduleCreateUpdateRequest } from 'src/app/shared/models/requests-models/schedule-create-update.model';
import { TranslateService } from '@ngx-translate/core';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

@Component({
  selector: 'app-new-schedules',
  templateUrl: './new-schedules.component.html',
  styleUrls: ['./new-schedules.component.scss']
})
export class NewSchedulesComponent implements OnInit {

	newSchedulesForm: FormGroup;
	workspaceId: number;

  constructor(
  	public utilSrv: UtilService,
    private translate: TranslateService,
  	private fb: FormBuilder,
    public dialogRef: MatDialogRef<NewSchedulesComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
    	workspaceId: number
    },
    public storageSrv: StorageService,
    private sharedSrv: SharedService,
    private schedulesSrv: SchedulesService
  ) { }

  ngOnInit() {
  	this.workspaceId = this.data.workspaceId;
  	this.createNewScheduleForm();
  }

  createNewScheduleForm() {
    this.newSchedulesForm = this.fb.group({
    	workspaceId: [this.workspaceId, [Validators.required]],
      scheduleName: ['', [Validators.required, removeWhitespaceValidator]]
    })
  }

  onCreateSchedules() {
  	let scheduleInfo:ScheduleCreateUpdateRequest = this.newSchedulesForm.getRawValue();
  	this.schedulesSrv.createWorkspaceSchedule(scheduleInfo)
      .subscribe(schedule => {
        if (schedule && schedule.id) {
          this.dialogRef.close({ continue: false, outputData: schedule });
        }
      });
  }

  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

}
