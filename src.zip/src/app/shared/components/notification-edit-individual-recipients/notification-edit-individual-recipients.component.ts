import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { NotificationTypeFull } from '../../models/notification-models/notification-type-full.model';
import { RecipientGroup } from '../../models/recipient-models/recipient-group.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UtilService } from '../../services/util.service';
import { InputField } from '../../models/common-models/input-field.model';
import { AmazingTimePickerService } from 'amazing-time-picker';
import { WorkspacesService } from '../../services/workspaces.service';
import { SharedService } from '../../services/shared.service';
import { OAuthConnection } from '../../models/common-models/o-auth-connection.model';
import { Calendar } from '../../models/common-models/calendar.model';
import { MatSelectChange, MatSelect } from '@angular/material/select';
import { UserBasic } from '../../models/user-models/user-basic.model';
import { ChooseFileComponent } from '../choose-file/choose-file.component';
import { AssetFile } from '../../models/asset-models/asset-file.model';
import { Notification } from '../../models/notification-models/notification.model';
import { MatChipInputEvent } from '@angular/material/chips';
import { ENTER, TAB } from '@angular/cdk/keycodes';
import { StorageService } from '../../services/storage.service';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { RecipientsService } from 'src/app/shared/services/recipients.service';
import { Recipient } from 'src/app/shared/models/recipient-models/recipient.model';
import { RecipientBrief } from 'src/app/shared/models/recipient-models/recipient-brief.model';


import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-notification-edit-individual-recipients',
  templateUrl: './notification-edit-individual-recipients.component.html',
  styleUrls: ['./notification-edit-individual-recipients.component.scss']
})
export class NotificationEditIndividualRecipientsComponent implements OnInit {
  addOnBlur = true;
  separatorKeysCodes: number[] = [ENTER, TAB];
  subscriber = null;

  recipientsForm: FormGroup;
  workspaceId: number;
  recipients: RecipientBrief[] = [];

  config = {}


  requestEndpoint: string = '';
  constructor(
    private translate: TranslateService,
    public dialogRef: MatDialogRef<NotificationEditIndividualRecipientsComponent>,
    private fb: FormBuilder,
    public utilSrv: UtilService,
    private sharedSrv: SharedService,
    private storageSrv: StorageService,
    private workspaceSrv: WorkspacesService,
    private recipientsSrv: RecipientsService,
    private atpSrv: AmazingTimePickerService,
    @Inject(MAT_DIALOG_DATA) public data: {
      recipients: number[],
      workspaceId: number
    },
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    
    this.requestEndpoint = this.utilSrv.env.endPoint;

    if (this.data) {
      this.workspaceId = this.data.workspaceId;
      this.generateForm();
      this.getRecipients();

    } else {
      this.dialogRef.close({ continue: false, outputData: null });
    }
  }


  generateForm(){
    this.recipientsForm = this.fb.group({
      recipientIds: [this.data.recipients]
    });
  }


  // load recipients
  getRecipients(){
    this.subscriber = this.recipientsSrv.getAllRecipients(this.workspaceId)
    .subscribe(recipients => {
      this.recipients = recipients;
    });
  }



  /**
   * close dialog without changes
   *
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }


  /**
   * close dialog with slide creation info
   *
   * @param null
   *
   * @return `null`
   */
  onContinue() {
    // get output data
    let outputData = this.recipientsForm.getRawValue();

    this.dialogRef.close({
      outputData: outputData
    })
  }


  canWrite(){
    return this.storageSrv.getWorkspaceWritePermission(Resource.notifications)
  }

  canUpdate(notification){
    if (notification && notification.isLocked){
      return false;
    }
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.notifications)
  }

  canDelete(notification){
    if (notification && notification.isLocked){
      return false;
    }
    return this.storageSrv.getWorkspaceDeletePermission(Resource.notifications)
  }

}
