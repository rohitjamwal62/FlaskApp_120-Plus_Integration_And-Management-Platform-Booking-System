import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UtilService } from '../../services/util.service';
import { AmazingTimePickerService } from 'amazing-time-picker';
import { MatSelectChange, MatSelect } from '@angular/material/select';
import { MatChipInputEvent } from '@angular/material/chips';
import { ENTER, TAB } from '@angular/cdk/keycodes';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { TranslateService } from '@ngx-translate/core';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

import { NotificationTypeFull } from '../../models/notification-models/notification-type-full.model';
import { RecipientGroup } from '../../models/recipient-models/recipient-group.model';
import { InputField } from '../../models/common-models/input-field.model';
import { OAuthConnection } from '../../models/common-models/o-auth-connection.model';
import { Calendar } from '../../models/common-models/calendar.model';
import { UserBasic } from '../../models/user-models/user-basic.model';
import { AssetFile } from '../../models/asset-models/asset-file.model';
import { Notification } from '../../models/notification-models/notification.model';
import { NotificationSchedule } from 'src/app/shared/models/notification-models/notification-schedule.model';
import { NotificationCreateRequest } from 'src/app/shared/models/requests-models/notification-create.model';
import { Playlist } from 'src/app/shared/models/playlist-models/playlist.model';
import { NotificationDisplayType } from 'src/app/shared/models/notification-models/notification-display-type.model';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';

import { WorkspacesService } from '../../services/workspaces.service';
import { SharedService } from '../../services/shared.service';
import { StorageService } from '../../services/storage.service';
import { NotificationsService } from 'src/app/shared/services/notifications.service';
import { PlaylistsService } from 'src/app/shared/services/playlists.service';

import { ChooseFileComponent } from '../choose-file/choose-file.component';
import { NotificationScheduleComponent } from 'src/app/shared/components/notification-schedule/notification-schedule.component';
import { NotificationEditIndividualRecipientsComponent } from 'src/app/shared/components/notification-edit-individual-recipients/notification-edit-individual-recipients.component';



@Component({
  selector: 'app-notification-edit',
  templateUrl: './notification-edit.component.html',
  styleUrls: ['./notification-edit.component.scss']
})
export class NotificationEditComponent extends CleanOnDestroy implements OnInit {

  currentWorkspace: Workspace;
  isLinear = false;
  addOnBlur = true;
  separatorKeysCodes: number[] = [ENTER, TAB];

  notificationForm: FormGroup;
  workspaceId: number;
  recipientGroups: RecipientGroup[];
  notificationTypes: NotificationTypeFull[] = [];
  displayTypes: NotificationDisplayType[] = []
  currentNotification: Notification = null;
  playlists: Playlist[] = [];
  publishTimestamp = null;
  schedules: NotificationSchedule[] = [];

  config = {}
  notificationType: NotificationTypeFull;
  requestEndpoint: string = '';
  formData: FormGroup;
  isFormSubmit = false;
  currentLocale: any = '';
  selectWorkspaceErr: string = '';
  selectAllFieldsErr: string = '';
  deliverImm: string = '';
  deliveredStream: string = '';

  constructor(
    private translate: TranslateService,
    public dialogRef: MatDialogRef<NotificationEditComponent>,
    private fb: FormBuilder,
    public utilSrv: UtilService,
    private sharedSrv: SharedService,
    private storageSrv: StorageService,
    private workspaceSrv: WorkspacesService,
    private notificationsSrv: NotificationsService,
    private atpSrv: AmazingTimePickerService,
    private playlistsSrv: PlaylistsService,
    @Inject(MAT_DIALOG_DATA) public data: {
      workspaceId: number,
      notification?: Notification,
      isNew: boolean
    },
  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.currentLocale = this.utilSrv.locale;
    this.requestEndpoint = this.utilSrv.env.endPoint;
    this.formData = this.fb.group({
      notificationName: '',
      publishTimestamp: '',
      workspaceId: '',
      notificationTypeId: '',
      recipientGroups: [[]],
      recipients: [[]],
      displayTypeId: '',
      schedules: [[]],
      tags: []
    });

    this.tsTranslations();

    if (this.data) {
      this.workspaceId = this.data.workspaceId;
      if (!this.data.isNew && this.data.notification) {
        this.generateNotificationFormFromNotification(this.data.notification);
        this.notificationType = this.data.notification.notificationType;
        this.currentNotification = this.data.notification;
      } else {
        if (this.data.notification){
          this.generateNotificationFormFromNotification(this.data.notification);
          this.notificationType = this.data.notification.notificationType;
          this.publishTimestamp = null;
        } else {
          this.generateNewNotificationForm();
        }
      }
    } else {
      this.dialogRef.close({ continue: false, outputData: null });
    }

    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe( workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;
          this.getPlaylists();
        }
      });
  }

  tsTranslations() {
    this.translate.get('NOTIFICATIONEDIT.SELECTWORKSPACE').subscribe((string) => {
      this.selectWorkspaceErr = string;
    });
    this.translate.get('NOTIFICATIONEDIT.ALLFIELDS').subscribe((string) => {
      this.selectAllFieldsErr = string;
    });
    this.translate.get('NOTIFICATIONEDIT.DELIVERIMM').subscribe((string) => {
      this.deliverImm = string;
    });
    this.translate.get('NOTIFICATIONEDIT.DELIVEREDSTREAM').subscribe((string) => {
      this.deliveredStream = string;
    });
  }

  getPlaylists() {
    this.subscriber = this.playlistsSrv.getPlaylists(
      this.currentWorkspace.account.id, 
      this.currentWorkspace.id
    )
    .subscribe(playlists => {
      if (playlists) {
        this.playlists = playlists.slice();
      }
    });
  }

  /**
   * create notificationForm reactive form with dynamic properties
   * from `notificationType.properties`
   *
   *
   * @return `null`
   */
  generateNewNotificationForm() {
    this.notificationForm = this.fb.group({
      stepOne: this.fb.group({
        notificationName: ['New Stream', [Validators.required, removeWhitespaceValidator]],
        notificationTypeId: ['', [Validators.required]],
        displayTypeId: ['', [Validators.required]],
        tags: [[]],
      }),
      stepTwo: this.fb.group({
        properties: this.fb.group({})
      }),
      stepThree: this.fb.group({
        recipientGroups: [[]],
        recipients: [[]],
      }),
      workspaceId: [this.workspaceId],
      schedules: [[]]
    });

    // publish recipientGroups using ids
    this.getRecipientGroups();

    // get notification types
    this.getNotificationTypes();

    // get the display types
    this.getNotificationDisplayTypes();
  }

  /**
   * create notificationForm reactive form with dynamic properties
   * from `notificatiion.properties`
   *
   * @return `null`
   */
  generateNotificationFormFromNotification(notification: Notification) {
    this.notificationForm = this.fb.group({
      stepOne: this.fb.group({
        notificationName: [notification.notificationName, Validators.required],
        notificationTypeId: [notification.notificationType.id, Validators.required],
        displayTypeId: ['', Validators.required],
        tags: [notification.tags],
      }),
      stepTwo: this.fb.group({
        properties: this.fb.group({})
      }),
      stepThree: this.fb.group({
        recipientGroups: [[]],
        recipients: [[]],
      }),
      workspaceId: [this.workspaceId],
      schedules: [[]],
    });

    this.publishTimestamp = notification.publishTimestamp;
    this.getRecipientGroups();
    this.getNotificationTypes();
    this.getNotificationDisplayTypes();

    // compress recipient groups and put into form
    var recipientGroupIds = [];
    notification.recipientGroups.forEach(recipientGroup => {
      recipientGroupIds.push(recipientGroup.id);
    });
    this.notificationForm.get(['stepThree','recipientGroups']).patchValue(recipientGroupIds);

    var recipientIds = [];
    notification.recipients.forEach(recipient => {
      recipientIds.push(recipient.id);
    });
    this.notificationForm.get(['stepThree','recipients']).patchValue(recipientIds);

    if (notification.displayType){
      this.notificationForm.get(['stepOne','displayTypeId']).patchValue(notification.displayType.id);
    }

    notification.notificationType.inputFields.forEach(inputField => {
      let propertyValue: any;
      switch (inputField.type.toLowerCase()) {
        case 'date':
          propertyValue = new Date(
            notification.properties[inputField.id].propertyValue
          );
          break;
        case 'time':
          propertyValue = notification.properties[inputField.id].propertyValue
          break;
        default:
          propertyValue = notification.properties[inputField.id] ?
            notification.properties[inputField.id].propertyValue
            : null;
          break;
      }

      (this.notificationForm.get(['stepTwo','properties']) as FormGroup).setControl(
        inputField.id,
        this.fb.control(
          propertyValue,
          inputField.required ? Validators.required : null
        )
      );

      if (inputField.disabled) {
        this.notificationForm.get(['stepTwo','properties', inputField.id]).disable();
      }
    });

    // advanced inputs not yet supported for notifications
    /*slide.slideType.advancedInput.forEach(inputField => {
      let propertyValue: any;
      switch (inputField.type.toLowerCase()) {
        case 'date':
          propertyValue = new Date(
            slide.properties[inputField.id].propertyValue
          );
          break;
        case 'time':
          propertyValue = slide.properties[inputField.id].propertyValue;
          break;
        case 'oauth':
          this.isExistOauthInput = true;
          break;
        case 'oauth-multiselect':
          this.isExistOauthMultiselectInput = true;
          break;
        default:
          propertyValue = slide.properties[inputField.id] ?
            slide.properties[inputField.id].propertyValue
            : null;
          break;8

      }
      (this.slideForm.get('properties') as FormGroup).setControl(
        inputField.id,
        this.fb.control(
          propertyValue,
          inputField.required ? Validators.required : null
        )
      );

      if (inputField.disabled) {
        this.slideForm.get(['properties', inputField.id]).disable();
      }
    });*/
  }

  setNotificationType(notificationType: NotificationTypeFull){
    // clear out old properties
    if (this.notificationType){
      this.notificationType.inputFields.forEach(inputField => {
        (this.notificationForm.get(['stepTwo','properties']) as FormGroup).removeControl(inputField.id);
      });
    }

    // set up properties
    notificationType.inputFields.forEach(inputField => {
      (this.notificationForm.get(['stepTwo','properties']) as FormGroup).setControl(
        inputField.id,
        this.fb.control(
          inputField.default != undefined ? inputField.default : null,
          inputField.required ? Validators.required : null
        )
      );

      if (inputField.disabled) {
        this.notificationForm.get(['stepTwo','properties', inputField.id]).disable();
      }
    });


    this.notificationType = notificationType;
  }


  // load notification types
  getNotificationTypes(){
    this.notificationsSrv.getNotificationTypes()
    .subscribe(types => {
      this.notificationTypes = types;
    });
  }


  // load recipient groups
  getRecipientGroups(){
    this.storageSrv.recipientGroupsSubject.subscribe(recipientGroups => {
      if (recipientGroups){
        this.recipientGroups = recipientGroups;
      }
    });
  }


  // get notification display types
  getNotificationDisplayTypes(){
    this.notificationsSrv.getNotificationDisplayTypes()
    .subscribe(types => {
      this.displayTypes = types;
    });
  }



  selectNotificationType(notificationType: NotificationTypeFull){
    this.notificationType = notificationType;

    // populate form properties
  }

  /**
  * calls from template
  * when user type new tag and press on the some keys from `separatorKeysCodes`
  *
  * add new tag into playlist tags
  *
  * @param event with type `MatChipInputEvent`
  *
  * @return `null`
  */
  onAddNewTag(event: MatChipInputEvent) {
    const input = event.input;
    const tagName = event.value;

    if ((tagName || '').trim()) {
      let tags = this.notificationForm.get(['stepOne','tags']).value;
      tags.push(tagName)
      this.notificationForm.get(['stepOne','tags']).patchValue(tags);
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }
  }

  /**
   * calls from template
   * when user type new tag and press on the some keys from `separatorKeysCodes`
   *
   * add new tag into playlist tags
   *
   * @param event with type `MatChipInputEvent`
   *
   * @return `null`
   */
  onRemoveTag(tagName: string) {
    let tags: string[] = this.notificationForm.get(['stepOne','tags']).value;
    let tagIndex = tags.indexOf(tagName);
    if (tagIndex >= 0) {
      tags.splice(tagIndex, 1);
      this.notificationForm.get(['stepOne','tags']).patchValue(tags);
    }
  }



  /**
   * open amazing time picker progromatically
   *
   * @param controlName is form control name
   *
   * @return `string`
   */
  onOpenTimePicker(controlName: number) {

    const amazingTimePicker = this.atpSrv.open({
      time: this.transformToTimeString(controlName),
      arrowStyle: {
        background: '#e5286a',
        color: 'white'
      }
    });
    let subscriber = amazingTimePicker.afterClose().subscribe(time => {
      this.notificationForm.get(['stepTwo','properties', controlName])
        .patchValue(this.transformToSeconds(time));
      subscriber.unsubscribe();
    })
  }


  setPublishTimeNow(){
    this.notificationForm.get('publishTime').patchValue(null);
    this.notificationForm.get('publishDate').patchValue(null);
  }


  transformToTimeString(controlName: number){
    let transformedTime: string = '';
    let time = this.notificationForm.get(['stepTwo','properties', controlName]).value;
    if (time) {
      var numHours = Math.floor(time / (60*60));
      var numMinutes = Math.floor(Math.floor(time % (60*60)) / 60);
      transformedTime = this.addZero(numHours) + ":" + this.addZero(numMinutes) + ":00 ";
    }
    return transformedTime;
  }

  transformToSeconds(time){
    var times = time.split(":");
    var hours = times[0];
    var minutes = times[1];

    var result = (hours * 60 * 60) + (minutes * 60)
    return result;
  }



  getDateFromTimestamp(timestamp){
    var date = new Date(timestamp);
    var month = date.getMonth()+1;
    var day = date.getDay();
    var year = date.getFullYear();
    return month+"/"+day+"/"+year;
  }


  getTimeFromTimestamp(timestamp){
    var date = new Date(timestamp);
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'pm' : 'am';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    if (minutes < 10){
      return hours + ':' + `0${minutes}` + ' ' + ampm;
    }
    else {
      return hours + ':' + minutes + ' ' + ampm;
    }
  }


  /**
   * add 0 in case of number less than 10
   *
   * @param number which should be transformed
   *
   * @return  `string`
   */
  addZero(number: number): string {
    let returnString = '';
    if (number < 10) {
      returnString = '0' + number.toString();
    } else {
      returnString = number.toString();
    }

    return returnString;
  }


  /**
   * open dialog with files and folders
   * for select file with allowed extension types
   *
   * @param inputName is a form control name
   * @param inputIndex is a posotion from inputfields
   *
   * @return `string`
   */
  onOpenWorkspaceFolder(input: InputField) {
    if (this.storageSrv.selectedWorkspace
      && this.storageSrv.selectedWorkspace.id >= 0) {
      this.sharedSrv.openDialog<AssetFile>(
        {
          allowedFileTypes: input.fileTypes,
          selectedFile: this.notificationForm.get(['stepTwo','properties', input.id]).value
        },
        true,
        {
          width: '90%',
          height: 'calc(100vh - 120px)'
        },
        ChooseFileComponent
      ).subscribe(response => {
        if (response.continue) {
          this.notificationForm.get(['stepTwo','properties', input.id])
            .patchValue(response.outputData.assetName);
        }
      })
    } else {
      this.sharedSrv
        .errorDialog(this.selectWorkspaceErr);
    }

  }

  /**
  * calls from template
  * when user change color from color picker
  *
  * @param event is a selected color
  * @param controlName is a form control name
  *
  * @return `string`
  */
  onChangeColor($event: string, controlName: string) {
    this.notificationForm.get(['stepTwo','properties', controlName]).patchValue($event);
  }

  /**
   * calls from template
   * helper for a optimizing *ngFor
   *
   * @param index is a current element index with type `number`
   * @param item is a current element info
   *        with type `InputField`
   *
   * @return `number`
   */
  onTrackById(index: number, item: InputField) {
    return item.id;
  }
  /**
   * calls from template
   * helper for a optimizing *ngFor
   *
   * @param index is a current element index with type `number`
   * @param item is a current element info
   *        with type `InputField`
   *
   * @return `number`
   */
  onTrackByValue(index: number, item: { value: number, name: string }) {
    return item.value;
  }

  /**
   * close dialog without changes
   *
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }


  onSchedule(){
    this.isFormSubmit = true;
    // open schedule component, and then do onContinue
    this.sharedSrv
      .openDialog(
        {
          notification: this.currentNotification
        },
        true,
        { width: '40%' },
        NotificationScheduleComponent
      ).subscribe(response => {
        if (response.outputData){
          this.publishTimestamp = response.outputData["publishTimestamp"];
          this.schedules = response.outputData["schedules"];
          this.onContinue();
        } else {
          this.isFormSubmit = false;
        }
      });
  }

  /**
   * close dialog with slide creation info
   *
   * @param null
   *
   * @return `null`
   */
  onContinue() {
    if (this.data.isNew){
      if (this.notificationForm.valid) {
        let formData = this.notificationForm.getRawValue();
        let outputData = this.formData.getRawValue();
        outputData.notificationName = formData.stepOne.notificationName;
        outputData.publishTimestamp = this.publishTimestamp;
        outputData.workspaceId = formData.workspaceId;
        outputData.notificationTypeId = formData.stepOne.notificationTypeId;
        outputData.recipientGroups = formData.stepThree.recipientGroups;
        outputData.recipients = formData.stepThree.recipients;
        outputData.displayTypeId = formData.stepOne.displayTypeId;
        outputData.schedules = this.schedules;
        outputData.tags = formData.stepOne.tags;

        // change properties to propValues
        let returnedValue = this.createProperties();
        if (returnedValue.isValid) {
          outputData.properties = returnedValue.properties;
          this.notificationsSrv.createNotification(outputData).subscribe(newNotification => {
            // close dialog with slide creation info
            this.dialogRef.close({
              outputData: { notification: newNotification }
            });
          }, (err) => {
            this.isFormSubmit = false;
          });
        } else {
          this.sharedSrv.errorDialog(this.selectAllFieldsErr);
        }
      }
    } else {
      if (this.notificationForm.valid) {
        let formData = this.notificationForm.getRawValue();
        let outputData = {
          notificationName: formData.stepOne.notificationName,
          publishTimestamp: this.publishTimestamp,
          recipientGroups: formData.stepThree.recipientGroups,
          recipients: formData.stepThree.recipients,
          tags: formData.stepOne.tags,
          schedules: this.schedules,
          displayTypeId: formData.stepOne.displayTypeId,
          properties: {}
        };

        // change properties to propValues
        let returnedValue = this.createProperties();
        if (returnedValue.isValid) {
          outputData.properties = returnedValue.properties;

          this.notificationsSrv.updateNotification(outputData, this.currentNotification.id)
          .subscribe(updatedNotification => {
            // close dialog with slide creation info
            this.dialogRef.close({
              outputData: {notification: updatedNotification}
            });
          }, (err) => {
            this.isFormSubmit = false;
          });

        } else {
          this.sharedSrv.errorDialog(this.selectAllFieldsErr);
        }
      }
    }
  }

  onContinueDeliverNow(){
    if (this.data.isNew){
      if (this.notificationForm.valid) {
        this.isFormSubmit = true;
        this.sharedSrv.openDialog<null>(
          {
            title: this.deliverImm,
            description: this.deliveredStream,
            template: 0,
            cancel: 'no',
            confirm: 'yes',
          },
          true
        ).subscribe(response => {
          if (response && response.continue){
            let formData = this.notificationForm.getRawValue();
            let outputData = this.formData.getRawValue();
            outputData.notificationName = formData.stepOne.notificationName;
            outputData.publishTimestamp = null;
            outputData.displayTypeId = formData.stepOne.displayTypeId;
            outputData.notificationTypeId = formData.stepOne.notificationTypeId;
            outputData.workspaceId = formData.workspaceId;
            outputData.recipientGroups = formData.stepThree.recipientGroups;
            outputData.recipients = formData.stepThree.recipients;
            outputData.schedules = this.schedules;
            outputData.tags = formData.stepOne.tags;
            //let outputData = this.notificationForm.getRawValue();

            // change properties to propValues
            let returnedValue = this.createProperties();
            if (returnedValue.isValid) {
              outputData.properties = returnedValue.properties;

              this.notificationsSrv.createNotification(outputData)
              .subscribe(newNotification => {
                // close dialog with slide creation info
                this.dialogRef.close({
                  outputData: {notification: newNotification}
                })
              });
            } else {
              this.sharedSrv.errorDialog(this.selectAllFieldsErr);
            }

          } else {
            this.isFormSubmit = false;
          }
        }, (err) => {
          this.isFormSubmit = false;
        });
      }
    } else {
      if (this.notificationForm.valid) {
        this.isFormSubmit = true;
        this.sharedSrv.openDialog<null>(
          {
            title: this.deliverImm,
            description: this.deliveredStream,
            template: 0,
            cancel: 'no',
            confirm: 'yes',
          },
          true
        ).subscribe(response => {
          if (response && response.continue){
            let formData = this.notificationForm.getRawValue();
            let outputData = this.formData.getRawValue();
            outputData.notificationName = formData.stepOne.notificationName;
            outputData.publishTimestamp = null;
            outputData.recipientGroups = formData.stepThree.recipientGroups;
            outputData.recipients = formData.stepThree.recipients;
            outputData.tags = formData.stepOne.tags;
            outputData.schedules = this.schedules;
            outputData.displayTypeId = formData.stepOne.displayTypeId;

            // change properties to propValues
            let returnedValue = this.createProperties();
            if (returnedValue.isValid) {
              outputData.properties = returnedValue.properties;

              this.notificationsSrv.updateNotification(outputData, this.currentNotification.id)
              .subscribe(updatedNotification => {
                // close dialog with slide creation info
                this.dialogRef.close({
                  outputData: {notification: updatedNotification}
                })
              });
            } else {
              this.sharedSrv.errorDialog(this.selectAllFieldsErr);
            }
          } else {
            this.isFormSubmit = false;
          }
        }, (err) => {
          this.isFormSubmit = false;
        });
      }
    }
  }


  getMillisFromTime(timeFormat){
    var hours = +timeFormat.split(":")[0];
    var remaining = timeFormat.split(":")[1];
    var minutes = +remaining.split(" ")[0];
    var amPm = remaining.split(" ")[1];

    if (amPm == "PM"){
      hours += 12;
    }
    return (minutes * 60 * 1000) + (hours * 60 * 60 * 1000);
  }

  /**
   * depends input type transform value of `input.id` control
   *
   * @param null
   *
   * @return `{ [key: number]: { propertyValue: string } }`
   */
  createProperties() {
    let propValues: {
      [key: number]: { propertyValue: string }
    } = {}
    let isValid: boolean = true;
    this.notificationType.inputFields.forEach(input => {
      // store the transformed value into property
      let propertyValue: string | number = '';
      // transform value depends on input type
      switch (input.type.toLowerCase()) {
        case 'date':
          let dateString = this.notificationForm.get(['stepTwo','properties', +input.id]).value;
          let date: Date = new Date(dateString);
          propertyValue = date.getTime();
          break;
        case 'time':
          // transformed to seconds
          propertyValue = this.notificationForm.get(['stepTwo','properties', +input.id]).value;
          break;
        default:
          propertyValue = this.notificationForm.get(['stepTwo','properties', +input.id]).value;
          break;
      }
      propertyValue = propertyValue === null ? null : propertyValue.toString();
      propValues[input.id] = {
        propertyValue: propertyValue
      }
    });

    /*this.slideType.advancedInput.forEach(input => {
      // store the transformed value into property
      let propertyValue: string | number = '';
      // transform value depends on input type
      switch (input.type.toLowerCase()) {
        case 'date':
          let dateString = this.slideForm.get(['properties', +input.id]).value;
          let date: Date = new Date(dateString);
          propertyValue = date.getTime();
          break;
        case 'time':
          // transformed to seconds
          propertyValue = this.notificationForm.get(['properties', +input.id]).value;
          break;
        case 'oauth':
          propertyValue = this.slideForm.get(['properties', +input.id]).value;
          break;
        case 'oauth-multiselect':
          let returnedValue = this.createCalendars(input);
          isValid = returnedValue.isValid;
          propertyValue = returnedValue.calendars;
          break;
        default:
          propertyValue = this.slideForm.get(['properties', +input.id]).value;
          break;
      }
      propertyValue = propertyValue === null ? null : propertyValue.toString();
      propValues[input.id] = {
        propertyValue: propertyValue
      }
    });
    */

    return { properties: propValues, isValid: isValid };
  }


  /**
   * redirect user to the page where he can create slide
   *
   * @param slideId is a slide id
   *
   * @return `null`
   */
  onCopyToClipboard(element: HTMLInputElement) {
    const el = document.createElement('textarea');
    el.value = element.value;
    el.setAttribute('readonly', '');
    el.style.position = 'absolute';
    el.style.left = '-9999px';
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
  }

  dateFormat(timestamp){
    var d = new Date(0);
    d.setUTCMilliseconds(timestamp);
    var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    var hours = d.getHours();
    var ampm = hours >= 12 ? 'PM' : 'AM';
    var minutes = d.getMinutes();
    hours = hours % 12;
    hours = hours ? hours : 12;
    var finalMinutes = minutes < 10 ? '0'+minutes : minutes;

    // March 20, 2020 2:00 PM
    return months[d.getMonth()]+" "+d.getDate()+", "+d.getFullYear()+" "+hours+":"+finalMinutes+" "+ampm;
  }


  toggleSelectedField(event, allOptions){
    var itemId = event.value;
    if(allOptions != undefined) {
      // unset and hide other fields
      for (var i = 0; i < allOptions.length; i++){
        this.notificationForm.get(['stepTwo','properties', allOptions[i].value]).patchValue('');
        //(this.notificationForm.get("properties") as FormGroup).get(allOptions[i].value).patchValue('');
        var e = document.getElementsByClassName("select-field-id-"+allOptions[i].value);
        if (e.length > 0){
          (e[0] as HTMLElement).style.display = "none";
        }
      }

      // show this element
      var e = document.getElementsByClassName("select-field-id-"+itemId);
      if (e.length > 0){
        (e[0] as HTMLElement).style.display = "block";
      }
    }
  }

  onAddIndividualRecipients(){
    this.sharedSrv
    .openDialog<number[]>(
      {
        recipients: this.notificationForm.get(['stepThree','recipients']).value,
        workspaceId: this.workspaceId
      },
      true,
      { width: '60%' },
      NotificationEditIndividualRecipientsComponent
    ).subscribe(response => {
      if (response.outputData){
        this.notificationForm.get(['stepThree','recipients']).patchValue(response.outputData["recipientIds"]);
      }
    });
  }


  isMessageDelivered(){
    if (this.currentNotification == null || this.currentNotification.publishTimestamp == null){
      return false;
    }

    var currentTime = new Date().getTime();
    if (this.currentNotification.publishTimestamp < currentTime){
      return true;
    }
    return false;
  }


  isMessageScheduled(){
    if (this.currentNotification == null || this.currentNotification.publishTimestamp == null){
      return false;
    }

    var currentTime = new Date().getTime();
    if (this.currentNotification.publishTimestamp >= currentTime){
      return true;
    }
    return false;
  }


  isMessageRepeatScheduled(){
    if (this.currentNotification == null){
      return false;
    }

    if (this.currentNotification.publishTimestamp == null && this.currentNotification.schedules.length > 0){
      return true;
     } else {
      return false;
     }
  }


  canWrite(){
    return this.storageSrv.getWorkspaceWritePermission(Resource.notifications)
  }

  canUpdate(notification){
    if (notification && notification.isLocked){
      return false;
    }
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.notifications)
  }

  canDelete(notification){
    if (notification && notification.isLocked){
      return false;
    }
    return this.storageSrv.getWorkspaceDeletePermission(Resource.notifications)
  }

}
