import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { NotificationTypeFull } from '../../models/notification-models/notification-type-full.model';
import { RecipientGroup } from '../../models/recipient-models/recipient-group.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UtilService } from '../../services/util.service';
import { InputField } from '../../models/common-models/input-field.model';
import { AmazingTimePickerService } from 'amazing-time-picker';
import { WorkspacesService } from '../../services/workspaces.service';
import { SharedService } from '../../services/shared.service';
import { OAuthConnection } from '../../models/common-models/o-auth-connection.model';
import { Calendar } from '../../models/common-models/calendar.model';
import { MatSelectChange, MatSelect } from '@angular/material/select';
import { UserBasic } from '../../models/user-models/user-basic.model';
import { ChooseFileComponent } from '../choose-file/choose-file.component';
import { AssetFile } from '../../models/asset-models/asset-file.model';
import { Notification } from '../../models/notification-models/notification.model';
import { MatChipInputEvent } from '@angular/material/chips';
import { ENTER, TAB } from '@angular/cdk/keycodes';
import { StorageService } from '../../services/storage.service';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { NotificationsService } from 'src/app/shared/services/notifications.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-notification-schedule',
  templateUrl: './notification-schedule.component.html',
  styleUrls: ['./notification-schedule.component.scss']
})
export class NotificationScheduleComponent implements OnInit {
  addOnBlur = true;
  separatorKeysCodes: number[] = [ENTER, TAB];

  notificationScheduleForm: FormGroup;
  workspaceId: number;
  currentNotification: Notification;
  repeatSchedule: boolean = false;
  config = {}
  requestEndpoint: string = '';
  isFormSubmit = false;
  currentLocale: any = '';

  constructor(
    private translate: TranslateService,
    public dialogRef: MatDialogRef<NotificationScheduleComponent>,
    private fb: FormBuilder,
    public utilSrv: UtilService,
    private sharedSrv: SharedService,
    private storageSrv: StorageService,
    private workspaceSrv: WorkspacesService,
    private notificationsSrv: NotificationsService,
    private atpSrv: AmazingTimePickerService,
    @Inject(MAT_DIALOG_DATA) public data: {
      notification: Notification,
    },
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.currentLocale = this.utilSrv.locale;
    this.requestEndpoint = this.utilSrv.env.endPoint;

    if (this.data) {
      if (this.data.notification) {
        this.generateForm(this.data.notification);
        this.currentNotification = this.data.notification;
      } else {
        this.generateNewForm();
      }

    } else {
      this.dialogRef.close({ continue: false, outputData: null });
    }
  }

  /**
   * create notificationScheduleForm reactive form with dynamic properties
   * from `notificationType.properties`
   *
   *
   * @return `null`
   */
  generateNewForm() {
    this.notificationScheduleForm = this.fb.group({
      publishDate: [''],
      publishTime: [''],
      onMonday: [false],
      onTuesday: [false],
      onWednesday: [false],
      onThursday: [false],
      onFriday: [false],
      onSaturday: [false],
      onSunday: [false],
      mondayTime: [''],
      tuesdayTime: [''],
      wednesdayTime: [''],
      thursdayTime: [''],
      fridayTime: [''],
      saturdayTime: [''],
      sundayTime: ['']
    });
  }

  /**
   * create notificationScheduleForm reactive form with dynamic properties
   * from `notificatiion.properties`
   *
   *
   * @return `null`
   */
  generateForm(notification: Notification) {
    this.notificationScheduleForm = this.fb.group({
      publishDate: [notification.publishTimestamp],
      publishTime: [notification.publishTimestamp],
      onMonday: [false],
      onTuesday: [false],
      onWednesday: [false],
      onThursday: [false],
      onFriday: [false],
      onSaturday: [false],
      onSunday: [false],
      mondayTime: [''],
      tuesdayTime: [''],
      wednesdayTime: [''],
      thursdayTime: [''],
      fridayTime: [''],
      saturdayTime: [''],
      sundayTime: ['']
    });

    // set publishTime and publishDate using publishTimestamp from notification
    if (notification.publishTimestamp != null){
      var d = new Date(0);
      d.setUTCMilliseconds(notification.publishTimestamp);
      this.notificationScheduleForm.get('publishDate').patchValue(d);

      // publishTime needs to be the number of seconds in the publishTimestamp for this day
      var secs = 0;
      secs += d.getHours()*60*60;
      secs += d.getMinutes()*60;
      this.notificationScheduleForm.get('publishTime').patchValue(secs);
    }

    // populate times and days based on schedules
    if (notification.schedules.length > 0){
      this.repeatSchedule = true;
    }

    for (var i = 0; i < notification.schedules.length; i++){
      var publishDay = notification.schedules[i].publishDay;
      var publishTime = notification.schedules[i].publishTimestamp;

      if (publishDay == 0){
        this.notificationScheduleForm.get('onMonday').patchValue(true);
        this.notificationScheduleForm.get('mondayTime').patchValue(publishTime);
      } else if (publishDay == 1){
        this.notificationScheduleForm.get('onTuesday').patchValue(true);
        this.notificationScheduleForm.get('tuesdayTime').patchValue(publishTime);
      } else if (publishDay == 2){
        this.notificationScheduleForm.get('onWednesday').patchValue(true);
        this.notificationScheduleForm.get('wednesdayTime').patchValue(publishTime);
      } else if (publishDay == 3){
        this.notificationScheduleForm.get('onThursday').patchValue(true);
        this.notificationScheduleForm.get('thursdayTime').patchValue(publishTime);
      } else if (publishDay == 4){
        this.notificationScheduleForm.get('onFriday').patchValue(true);
        this.notificationScheduleForm.get('fridayTime').patchValue(publishTime);
      } else if (publishDay == 5){
        this.notificationScheduleForm.get('onSaturday').patchValue(true);
        this.notificationScheduleForm.get('saturdayTime').patchValue(publishTime);
      } else if (publishDay == 6){
        this.notificationScheduleForm.get('onSunday').patchValue(true);
        this.notificationScheduleForm.get('sundayTime').patchValue(publishTime);
      }
    }
  }




  /**
   * open amazing time picker progromatically
   *
   * @param controlName is form control name
   *
   * @return `string`
   */
  onOpenTimePicker(controlName: number) {
    const amazingTimePicker = this.atpSrv.open({
      time: this.transformToTimeString(controlName),
      arrowStyle: {
        background: '#e5286a',
        color: 'white'
      }
    });
    let subscriber = amazingTimePicker.afterClose().subscribe(time => {
      this.notificationScheduleForm.get(['properties', controlName]).patchValue(this.transformToSeconds(time));
      subscriber.unsubscribe();
    })
  }

  onOpenTimePickerRepeat(controlName: string) {

    const amazingTimePicker = this.atpSrv.open({
      time: this.transformToTimeStringRepeat(controlName),
      arrowStyle: {
        background: '#e5286a',
        color: 'white'
      }
    });
    let subscriber = amazingTimePicker.afterClose().subscribe(time => {
      this.notificationScheduleForm.get(controlName).patchValue(this.transformToSeconds(time));
      subscriber.unsubscribe();
    })
  }

  onOpenTimePickerRequired(controlName: number) {
    const amazingTimePicker = this.atpSrv.open({
      time: this.transformToTimeStringRequired(),
      arrowStyle: {
        background: '#e5286a',
        color: 'white'
      }
    });
    let subscriber = amazingTimePicker.afterClose().subscribe(time => {
      this.notificationScheduleForm.get('publishTime').patchValue(this.transformToSeconds(time));
      subscriber.unsubscribe();
    })
  }

  transformToTimeStringRequired(){
    let transformedTime: string = '';
    let time = this.notificationScheduleForm.get("publishTime").value;
    if (time) {
      var numHours = Math.floor(time / (60*60));
      var numMinutes = Math.floor(Math.floor(time % (60*60)) / 60);
      transformedTime = this.addZero(numHours) + ":" + this.addZero(numMinutes) + ":00 ";
    }
    return transformedTime;
  }

  transformToTimeString(controlName: number){
    let transformedTime: string = '';
    let time = this.notificationScheduleForm.get(['properties', controlName]).value;
    if (time) {
      var numHours = Math.floor(time / (60*60));
      var numMinutes = Math.floor(Math.floor(time % (60*60)) / 60);
      transformedTime = this.addZero(numHours) + ":" + this.addZero(numMinutes) + ":00 ";
    }
    return transformedTime;
  }

    transformToTimeStringRepeat(controlName: string){
    let transformedTime: string = '';
    let time = this.notificationScheduleForm.get(controlName).value;
    if (time) {
      var numHours = Math.floor(time / (60*60));
      var numMinutes = Math.floor(Math.floor(time % (60*60)) / 60);
      transformedTime = this.addZero(numHours) + ":" + this.addZero(numMinutes) + ":00 ";
    }
    return transformedTime;
  }


  transformToSeconds(time){
    var times = time.split(":");
    var hours = times[0];
    var minutes = times[1];

    var result = (hours * 60 * 60) + (minutes * 60)
    return result;
  }

  setPublishTimeNow(){
    this.notificationScheduleForm.get('publishTime').patchValue(null);
    this.notificationScheduleForm.get('publishDate').patchValue(null);
  }

  getDateFromTimestamp(timestamp){
    var date = new Date(timestamp);
    var month = date.getMonth()+1;
    var day = date.getDay();
    var year = date.getFullYear();
    return month+"/"+day+"/"+year;
  }

  getTimeFromTimestamp(timestamp){
    var date = new Date(timestamp);
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'pm' : 'am';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    if (minutes < 10){
      return hours + ':' + `0${minutes}` + ' ' + ampm;
    }
    else {
      return hours + ':' + minutes + ' ' + ampm;
    }
  }


  /**
   * add 0 in case of number less than 10
   *
   * @param number which should be transformed
   *
   * @return  `string`
   */
  addZero(number: number): string {
    let returnString = '';
    if (number < 10) {
      returnString = '0' + number.toString();
    } else {
      returnString = number.toString();
    }

    return returnString;
  }



  /**
   * calls from template
   * helper for a optimizing *ngFor
   *
   * @param index is a current element index with type `number`
   * @param item is a current element info
   *        with type `InputField`
   *
   * @return `number`
   */
  onTrackById(index: number, item: InputField) {
    return item.id;
  }
  /**
   * calls from template
   * helper for a optimizing *ngFor
   *
   * @param index is a current element index with type `number`
   * @param item is a current element info
   *        with type `InputField`
   *
   * @return `number`
   */
  onTrackByValue(index: number, item: { value: number, name: string }) {
    return item.value;
  }

  /**
   * close dialog without changes
   *
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * close dialog with slide creation info
   *
   * @param null
   *
   * @return `null`
   */
  onContinue() {
    if (this.notificationScheduleForm.valid) {
      let outputData = this.notificationScheduleForm.getRawValue();
      var returnData = {};

      this.isFormSubmit = true;

      // if we have schedules, compile and send them
      if (!this.repeatSchedule){
        // combine publishDate and publishTime into publishTimestamp
        var d = new Date(outputData.publishDate);
        d.setHours(0);
        d.setMinutes(0);
        d.setSeconds(0);
        d.setMilliseconds(0);

        var time = d.getTime();
        var timeMillis = outputData.publishTime*1000;
        time += timeMillis;

        returnData["publishTimestamp"] = time;
        returnData["schedules"] = [];

      } else {
        var schedules = [];
        if (outputData.onMonday){
          schedules.push({"publishDay":0, "publishTimestamp":outputData.mondayTime});
        }
        if (outputData.onTuesday){
          schedules.push({"publishDay":1, "publishTimestamp":outputData.tuesdayTime});
        }
        if (outputData.onWednesday){
          schedules.push({"publishDay":2, "publishTimestamp":outputData.wednesdayTime});
        }
        if (outputData.onThursday){
          schedules.push({"publishDay":3, "publishTimestamp":outputData.thursdayTime});
        }
        if (outputData.onFriday){
          schedules.push({"publishDay":4, "publishTimestamp":outputData.fridayTime});
        }
        if (outputData.onSaturday){
          schedules.push({"publishDay":5, "publishTimestamp":outputData.saturdayTime});
        }
        if (outputData.onSunday){
          schedules.push({"publishDay":6, "publishTimestamp":outputData.sundayTime});
        }

        returnData["publishTimestamp"] = null;
        returnData["schedules"] = schedules;
      }

      // close dialog with slide creation info
      this.dialogRef.close({
        outputData: returnData
      });

      this.isFormSubmit = false;

      } else {
        this.sharedSrv.errorDialog('Please fill all required fields.');
      }
  }


  getMillisFromTime(timeFormat){
    if (timeFormat == null || timeFormat.length == 0){
      return null;
    }

    var hours = +timeFormat.split(":")[0];
    var remaining = timeFormat.split(":")[1];
    var minutes = +remaining.split(" ")[0];
    var amPm = remaining.split(" ")[1];

    if (amPm == "PM" || amPm == "pm"){
      hours += 12;
    }
    return (minutes * 60 * 1000) + (hours * 60 * 60 * 1000);
  }


  toggleRepeatSchedule(){
    this.repeatSchedule = !this.repeatSchedule;

  }

  isMessageDelivered(){
    var currentTime = new Date().getTime();
    if (this.currentNotification && this.currentNotification.publishTimestamp < currentTime){
      return true;
    }
    return false;
  }

  canWrite(){
    return this.storageSrv.getWorkspaceWritePermission(Resource.notifications)
  }

  canUpdate(){
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.notifications)
  }

  canDelete(){
    return this.storageSrv.getWorkspaceDeletePermission(Resource.notifications)
  }

}
