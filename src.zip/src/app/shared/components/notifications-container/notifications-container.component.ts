import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UtilService } from '../../services/util.service';
import { StorageService } from '../../services/storage.service';

import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-notifications-container',
  templateUrl: './notifications-container.component.html',
  styleUrls: ['./notifications-container.component.scss']
})
export class NotificationsContainerComponent implements OnInit {

  currentLocale: any = '';

  constructor(
    public utilSrv: UtilService,
    private translate: TranslateService,
    public storageSrv: StorageService,
    private router: Router
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.currentLocale = this.utilSrv.locale;
  }

  onGoToTheCurrentAccount() {
    this.router.navigate(['/accounts/' + this.storageSrv.currentAccount.id+'/billing']);
  }

  /**
   * calculate and return remaining days until trial end
   *
   * @param dateInNumber is a trial end date in miliseconds
   *
   * @return `Date`
   */
  onTakeTheRemainingDays(dateInNumber: number) {
    let now = new Date().getTime();
    return new Date(now + dateInNumber);
  }

  takeNumberToDate(dateInSeconds: number){
    return new Date(dateInSeconds * 1000);
  }


  onTakeTheRemainingDaysForSubscriptionEnd(dateInSeconds: number) {
    let date = new Date().getTime();
    return new Date(date + dateInSeconds);
  }

  onCloseTrialNotification() {
    this.storageSrv.shouldShowTrialNotification = 'true';
    this.storageSrv.disableTrialNotifications();
  }

  onCloseSubscriptionNotification() {
    this.storageSrv.shouldShowSubscriptionNotification = 'true';
    this.storageSrv.disableSubscribtionEndNotifications();
  }

  expiresInXDays(dateInSeconds: number, days: number){
    if (dateInSeconds == null){
      return false;
    }

    var currentDateInSeconds = new Date().getTime();
    var dateDiff = currentDateInSeconds - ((dateInSeconds - (days*24*60*60))*1000);
    if (dateDiff > 0){
      return true;
    }
  }

}
