import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OACFilestackComponent } from './ssrs-filestack.component';

describe('OACFilestackComponent', () => {
  let component: OACFilestackComponent;
  let fixture: ComponentFixture<OACFilestackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OACFilestackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OACFilestackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
