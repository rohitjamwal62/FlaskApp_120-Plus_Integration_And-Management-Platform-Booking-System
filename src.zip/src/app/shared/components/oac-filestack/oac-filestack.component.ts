import { Component, OnInit, Inject } from '@angular/core';
import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { IntegrationsService } from 'src/app/shared/services/integrations.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';

import { OAuthResourceOption } from '../../models/common-models/oauth-resource-option.model';

@Component({
  selector: 'app-oac-filestack',
  templateUrl: './oac-filestack.component.html',
  styleUrls: ['./oac-filestack.component.scss']
})
export class OACFilestackComponent implements OnInit {

	integrationId: number = 0;

	oacFolders: OAuthResourceOption[] = [];
  oacFolderTrails: OAuthResourceOption[] = [];
  selectedFolder: OAuthResourceOption;

  constructor(
  	private translate: TranslateService,
    public utilSrv: UtilService,
    private storageSrv: StorageService,
    private sharedSrv: SharedService,
    private integrationsSrv: IntegrationsService,
    public dialogRef: MatDialogRef<OACFilestackComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
    	integrationId: number;
      folders: OAuthResourceOption[];
    }
  ) { }

  ngOnInit() {
  	if(this.data) {
  		this.oacFolders = this.data.folders;
  		this.integrationId = this.data.integrationId;
  	}
  }

  onSelectFolder(folder) {
    this.selectedFolder = folder;
  }
  onSelectChildFolder(folder) {
    let filteredFolder = this.oacFolderTrails.filter( f => f.id == folder.id);
    if(filteredFolder.length == 0) {
      this.oacFolderTrails.push(folder);
    }
    this.integrationsSrv.getOACFolderOptions(this.integrationId, folder.id).subscribe( assets => {
      if(assets) {
        this.oacFolders = assets;
      }
    });
  }
  onCurrentFolderClick() {
    this.oacFolderTrails = [];
    this.integrationsSrv.getOACFolderOptions(this.integrationId, null).subscribe( folders => {
      if(folders) {
        this.oacFolders = folders;
      }
    });
  }
  onOACFolderTrailsClick(folderId, trailIndex) {
    this.oacFolderTrails.length = trailIndex + 1;
    this.integrationsSrv.getOACFolderOptions(this.integrationId, folderId).subscribe( assets => {
      if(assets) {
        this.oacFolders = assets;
      }
    });
  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  onContinue() {
    if (this.selectedFolder) {
      this.dialogRef.close({ continue: true, outputData: this.selectedFolder });
    }
  }

}
