import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { OfficeDriveFilestackComponent } from './office-drive-filestack.component';

describe('OfficeDriveFilestackComponent', () => {
  let component: OfficeDriveFilestackComponent;
  let fixture: ComponentFixture<OfficeDriveFilestackComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ OfficeDriveFilestackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfficeDriveFilestackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
