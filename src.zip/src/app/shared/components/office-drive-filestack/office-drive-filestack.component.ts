import { Component, OnInit, Inject } from '@angular/core';
import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { IntegrationsService } from 'src/app/shared/services/integrations.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';

import { OAuthResourceOption } from '../../models/common-models/oauth-resource-option.model';
import { OfficeDriveFolder } from '../../models/integration-models/office-drive-folder.model';

@Component({
  selector: 'app-office-drive-filestack',
  templateUrl: './office-drive-filestack.component.html',
  styleUrls: ['./office-drive-filestack.component.scss']
})
export class OfficeDriveFilestackComponent implements OnInit {

  integrationId: number = 0;
  driveId: string = '';

	currentDrive: OAuthResourceOption;
	driveFolders: OfficeDriveFolder[] = [];
  driveFolderTrails: OfficeDriveFolder[] = [];
  selectedFolder: OfficeDriveFolder;

  constructor(
  	private translate: TranslateService,
    public utilSrv: UtilService,
    private storageSrv: StorageService,
    private sharedSrv: SharedService,
    private integrationsSrv: IntegrationsService,
    public dialogRef: MatDialogRef<OfficeDriveFilestackComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
    	integrationId: number;
    	drive: OAuthResourceOption;
    	driveId: string;
      driveFolders: OfficeDriveFolder[];
    }
  ) { }

  ngOnInit() {
  	if(this.data) {
  		this.driveFolders = this.data.driveFolders;
  		this.integrationId = this.data.integrationId;
  		this.driveId = this.data.driveId;
  		this.currentDrive = this.data.drive;
      this.sortFolders();
  	}
  }

  onSelectDriveFolder(folder) {
    this.selectedFolder = folder;
  }
  onSelectDriveChildFolder(folder) {
    let filteredFolder = this.driveFolderTrails.filter( f => f.id == folder.id);
    if(filteredFolder.length == 0) {
      this.driveFolderTrails.push(folder);
    }
    this.integrationsSrv.getOfficeDriveChildFolders(this.integrationId, this.driveId, folder.id).subscribe( assets => {
      if(assets) {
        this.driveFolders = assets;
        this.sortFolders();
      }
    });
  }
  onCurrentDriveClick() {
    this.driveFolderTrails = [];
    this.integrationsSrv.getOfficeDriveFolders(this.integrationId, this.driveId).subscribe( folders => {
      if(folders) {
        this.driveFolders = folders;
        this.sortFolders();
      }
    });
  }
  onDriveFolderTrails(folderId, trailIndex) {
    this.driveFolderTrails.length = trailIndex + 1;
    this.integrationsSrv.getOfficeDriveChildFolders(this.integrationId, this.driveId, folderId).subscribe( assets => {
      if(assets) {
        this.driveFolders = assets;
        this.sortFolders();
      }
    });
  }

  sortFolders() {
    this.driveFolders.sort((a, b) => a.name.localeCompare(b.name));
  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  onContinue() {
    if (this.selectedFolder) {
      this.dialogRef.close({ continue: true, outputData: this.selectedFolder });
    }
  }

}
