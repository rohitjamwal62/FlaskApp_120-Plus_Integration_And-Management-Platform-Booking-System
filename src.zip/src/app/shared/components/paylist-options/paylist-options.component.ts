import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Playlist } from '../../models/playlist-models/playlist.model';
import { ENTER, TAB } from '@angular/cdk/keycodes';
import { MatChipInputEvent } from '@angular/material/chips';
import { UtilService } from 'src/app/shared/services/util.service';

import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-paylist-options',
  templateUrl: './paylist-options.component.html',
  styleUrls: ['./paylist-options.component.scss']
})
export class PaylistOptionsComponent implements OnInit {
  playlistForm: FormGroup;
  addOnBlur = true;
  separatorKeysCodes: number[] = [ENTER, TAB];

  currentLocale: any = '';

  constructor(
    public utilSrv: UtilService,
    private translate: TranslateService,
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<PaylistOptionsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { playlist: Playlist },
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {

    this.currentLocale = this.utilSrv.locale;
    
    this.generatePlaylistForm();
    if (this.data) {
      this.playlistForm.patchValue(this.data.playlist);
    }
  }


  /**
   * generate `playlistForm`
   *
   * @param null
   *
   * @return `null`
   */
  generatePlaylistForm() {
    this.playlistForm = this.fb.group({
      tags: []
    });
  }


  /**
   * calls from template
   * when user type new tag and press on the some keys from `separatorKeysCodes`
   *
   * add new tag into playlist tags
   *
   * @param event with type `MatChipInputEvent`
   *
   * @return `null`
   */
  onAddNewTag(event: MatChipInputEvent) {
    const input = event.input;
    const tagName = event.value;

    if ((tagName || '').trim()) {
      let tags = this.playlistForm.get('tags').value;
      tags.push(tagName)
      this.playlistForm.get('tags').patchValue(tags);
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }
  }

  /**
   * calls from template
   * when user type new tag and press on the some keys from `separatorKeysCodes`
   *
   * add new tag into playlist tags
   *
   * @param event with type `MatChipInputEvent`
   *
   * @return `null`
   */
  onRemoveTag(tagName: string) {
    let tags: string[] = this.playlistForm.get('tags').value;
    let tagIndex = tags.indexOf(tagName);
    if (tagIndex >= 0) {
      tags.splice(tagIndex, 1);
      this.playlistForm.get('tags').patchValue(tags);
    }
  }

  /**
   * close dialog without changes
   *
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * close dialog with playlist changed data
   *
   * @param null
   *
   * @return `null`
   */
  onChangePlaylistOptions() {
    if (this.playlistForm.valid) {
      this.dialogRef.close({
        continue: true,
        outputData: this.playlistForm.getRawValue()
      });
    }
  }

}
