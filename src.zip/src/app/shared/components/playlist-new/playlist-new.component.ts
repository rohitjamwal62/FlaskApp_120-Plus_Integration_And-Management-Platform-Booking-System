import { Component, OnInit, Inject } from '@angular/core';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { MatSelectChange } from '@angular/material/select';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { TemplatesService } from '../../services/templates.service';
import { PlaylistsService } from 'src/app/shared/services/playlists.service';

import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { PlaylistTemplate } from '../../models/playlist-models/playlist-template.model';
import { WorkspaceFavorite } from '../../models/workspace-models/workspace-favorite.model';
import { UserFavorite } from '../../models/user-models/user-favorite.model';

import { Playlist } from '../../models/playlist-models/playlist.model';
import { PlaylistCreateRequest } from '../../models/requests-models/playlist-create.model';
import { PlaylistUpdateRequest } from 'src/app/shared/models/requests-models/playlist-update.model';
import { AccountFavorite } from '../../models/account-models/account-favorite.model';
import { TranslateService } from '@ngx-translate/core';
// Utils
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

@Component({
  selector: 'app-playlist-new',
  templateUrl: './playlist-new.component.html',
  styleUrls: ['./playlist-new.component.scss']
})
export class PlaylistNewComponent extends CleanOnDestroy implements OnInit {

  currentWorkspace: Workspace;
  playlistTemplates: PlaylistTemplate[] = [];
  playlistForm: FormGroup;
  //templateInfo: PlaylistCreateRequest['template'];
  templateInfo: {
    type: 'playlist' | 'template',
    value: number,
    recource?: Playlist
  }
  playlist: Playlist;
  playlists: Playlist[];
  playlistsByIds: { [key: number]: Playlist } = {};
  currentLocale: any = '';

  constructor(
    public utilSrv: UtilService,
    private playlistsSrv: PlaylistsService,
    public storageSrv: StorageService,
    private translate: TranslateService,
    private templatesSrv: TemplatesService,
    public dialogRef: MatDialogRef<PlaylistNewComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      workspace: Workspace,
      userFavorites: UserFavorite[],
      playlists: Playlist[]
      //workspaceFavorites: WorkspaceFavorite[],
      //accountFavorites: AccountFavorite[]
    },
    private fb: FormBuilder
  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.currentLocale = this.utilSrv.locale;
    if(this.data) {
      this.currentWorkspace = this.data.workspace;
      this.playlists = this.data.playlists;

      this.data.userFavorites.forEach( favorite => {
        let favPlaylist: Playlist = this.playlists.find( playlist => playlist.id == favorite.resourceId);
        if(favPlaylist != undefined) {
          this.playlistsByIds[favPlaylist.id] = favPlaylist;
        }
      });

      this.generatePlaylistForm(this.currentWorkspace.id);
      this.getPlaylistTemplates();
    }
  }


  /**
   * generate `playlistForm`
   * @param workspaceId: selected workspaceId
   * @return `null`
   */
  generatePlaylistForm(workspaceId: number) {
    this.playlistForm = this.fb.group({
      name: ['', [Validators.required, removeWhitespaceValidator]],
      description: ''
    });
  }

  /**
   * send request to the server for a get playlist templates
   * @param null
   * @return `null`
   */
   getPlaylistTemplates() {
    this.subscriber = this.templatesSrv.getTemplatesList()
    .subscribe(templates => {
      if(templates) {
        this.playlistTemplates = templates;
      }
    })
  }
  // getPlaylistTemplates() {
  //   this.subscriber = this.templatesSrv.getTemplatesList(
  //     this.currentWorkspace.account.id,
  //     this.currentWorkspace.id
  //   ).subscribe(templates => {
  //     if(templates) {
  //       this.playlistTemplates = templates;
  //     }
  //   })
  // }

  /**
   * output event of mat select option
   * store the selected template info into property
   * @param event with type `MatSelectChange`
   * @return `null`
   */
  onSelectFavoriteOrTemplate(event: MatSelectChange) {
    this.templateInfo = event.value;
  }

  /**
   * calls from template
   * helper for a optimizing *ngFor
   *
   * @param index is a current element index with type `number`
   * @param item is a current element info
   *        with type `PlaylistTemplate`
   *
   * @return `number`
   */
  onTrackById(index: number, item: PlaylistTemplate) {
    return item.id;
  }

  /**
   * calls from template
   * helper for a optimizing *ngFor
   *
   * @param index is a current element index with type `number`
   * @param item is a current element info
   *        with type `WorkspaceFavorite | UserFavorite`
   *
   * @return `number`
   */
  onTrackByresourceId(index: number, item: WorkspaceFavorite | UserFavorite) {
    // Commented Temporarily
    //return item.resource.id;
  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * close dialog with playlist create info
   * @param null
   * @return `null`
   */
  onContinue() {
    if (this.playlistForm.valid) {
      let playlistInfo = this.playlistForm.getRawValue();
      playlistInfo.template = this.templateInfo;
      if (!playlistInfo.template || (playlistInfo.template && playlistInfo.template.type === 'template')) {
        if (playlistInfo.template) {
          playlistInfo.templateId = playlistInfo.template.value;
          delete playlistInfo.template;
        } else {
          delete playlistInfo.template;
        }
        this.createPlaylist(playlistInfo);
      } else {
        this.copyPlaylist(playlistInfo);
      }
    }
  }

  createPlaylist(playlistInfo) {
    this.subscriber = this.playlistsSrv.createPlaylist(
        this.currentWorkspace.account.id,
        this.currentWorkspace.id,
        playlistInfo
      ).subscribe(createdPlaylist => {
        if(createdPlaylist) {
          this.dialogRef.close({ continue: true, outputData: createdPlaylist });
        }
      });
  }

  copyPlaylist(playlistInfo) {
    let data = { workspaceId: this.storageSrv.selectedWorkspace.id };
    this.subscriber = this.playlistsSrv.copyPlaylist(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      playlistInfo.template.value
    ).subscribe(copiedPlaylist => {
      if (copiedPlaylist && copiedPlaylist.id >= 0) {

        let updatableInfo: PlaylistUpdateRequest = {
          name: playlistInfo.name,
          description: playlistInfo.description
        }

        this.subscriber = this.playlistsSrv.updatePlaylist(
          this.currentWorkspace.account.id,
          this.currentWorkspace.id,
          copiedPlaylist.id,
          updatableInfo,
        ).subscribe(updatedPlaylist => {
          if (updatedPlaylist && updatedPlaylist.id >= 0) {
            this.dialogRef.close({ continue: true, outputData: updatedPlaylist });
          }
        });

      }
    })
  }
}
