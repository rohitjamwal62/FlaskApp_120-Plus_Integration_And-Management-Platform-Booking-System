import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { NotificationTypeFull } from '../../models/notification-models/notification-type-full.model';
import { RecipientGroup } from '../../models/recipient-models/recipient-group.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UtilService } from '../../services/util.service';
import { InputField } from '../../models/common-models/input-field.model';
import { AmazingTimePickerService } from 'amazing-time-picker';
import { WorkspacesService } from '../../services/workspaces.service';
import { SharedService } from '../../services/shared.service';
import { OAuthConnection } from '../../models/common-models/o-auth-connection.model';
import { Calendar } from '../../models/common-models/calendar.model';
import { MatSelectChange, MatSelect } from '@angular/material/select';
import { UserBasic } from '../../models/user-models/user-basic.model';
import { ChooseFileComponent } from '../choose-file/choose-file.component';
import { AssetFile } from '../../models/asset-models/asset-file.model';
import { Notification } from '../../models/notification-models/notification.model';
import { MatChipInputEvent } from '@angular/material/chips';
import { ENTER, TAB } from '@angular/cdk/keycodes';
import { StorageService } from '../../services/storage.service';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { NotificationsService } from 'src/app/shared/services/notifications.service';
import { NotificationReadConfirmation } from 'src/app/shared/models/notification-models/notification-read-confirmation.model';
import { MatTableDataSource } from '@angular/material/table';
import { LocalRequestsService }  from 'src/app/shared/services/local-requests.service';

import { TranslateService } from '@ngx-translate/core';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-read-confirmations',
  templateUrl: './read-confirmations.component.html',
  styleUrls: ['./read-confirmations.component.scss']
})
export class ReadConfirmationsComponent implements OnInit {
  addOnBlur = true;
  separatorKeysCodes: number[] = [ENTER, TAB];

  currentNotification: Notification;
  readConfirmations: NotificationReadConfirmation[];
  dataSource = null;
  displayedColumns: string[] = ["recipientEmail", "hasReceived", "hasRead", "responseJSON"];

  config = {}
  requestEndpoint: string = '';

  resendStream: string = '';
  resendStreamAll: string = '';
  resendNotif: string = '';
  success: string = '';
  
  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    public dialogRef: MatDialogRef<ReadConfirmationsComponent>,
    private fb: FormBuilder,
    private sharedSrv: SharedService,
    private storageSrv: StorageService,
    private workspaceSrv: WorkspacesService,
    private notificationsSrv: NotificationsService,
    private atpSrv: AmazingTimePickerService,
    private localRequestsSrv: LocalRequestsService,
    public datepipe: DatePipe,
    @Inject(MAT_DIALOG_DATA) public data: {
      notification: Notification
    },
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.requestEndpoint = this.utilSrv.env.endPoint;

    this.translate.get('READCONFIRMATIONS.RESENDSTREAM').subscribe((string) => {
      this.resendStream = string;
    });
    this.translate.get('READCONFIRMATIONS.RESENDSTREAMALL').subscribe((string) => {
      this.resendStreamAll = string;
    });
    this.translate.get('READCONFIRMATIONS.RESENDNOTIF').subscribe((string) => {
      this.resendNotif = string;
    });
    this.translate.get('READCONFIRMATIONS.SUCCESS').subscribe((string) => {
      this.success = string;
    });

    if (this.data) {
      this.currentNotification = this.data.notification;

      // get notification read data
      this.getReadRecords(this.currentNotification);

    } else {
      this.dialogRef.close({ continue: false, outputData: null });
    }
  }

  getReadRecords(notification){
    this.notificationsSrv.getNotificationReadRecords(notification.id)
      .subscribe(results => {
        this.readConfirmations = results;
        this.dataSource = new MatTableDataSource(this.readConfirmations);
        //let receivedTimestamp = results[0].receivedTimestamp;
      });
  }

  /**
   * calls from template
   * helper for a optimizing *ngFor
   *
   * @param index is a current element index with type `number`
   * @param item is a current element info
   *        with type `InputField`
   *
   * @return `number`
   */
  onTrackById(index: number, item: InputField) {
    return item.id;
  }
  /**
   * calls from template
   * helper for a optimizing *ngFor
   *
   * @param index is a current element index with type `number`
   * @param item is a current element info
   *        with type `InputField`
   *
   * @return `number`
   */
  onTrackByValue(index: number, item: { value: number, name: string }) {
    return item.value;
  }

  /**
   * close dialog without changes
   *
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * close dialog with slide creation info
   *
   * @param null
   *
   * @return `null`
   */
  onContinue() {
    this.dialogRef.close({
      continue: true
    });
  }

  formatResponseData(object){
    for (var i = 0; i < object.length; i++){
      if (object[i].hasOwnProperty("timestamp")){
        var d = new Date(object[i].timestamp);
        object[i].timestamp = (d.getUTCMonth()+1)+"/"+d.getUTCDate()+"/"+d.getUTCFullYear() + " "+d.getUTCHours()+":"+d.getUTCMinutes()+":"+d.getUTCSeconds()+" GMT";
      }
    }
    return JSON.stringify(object);
  }

  onDownload(notification){
    this.localRequestsSrv.downloadFile(`${this.notificationsSrv.notificationsPath}${notification.id}/records/download/`, "read_records.csv");
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }


  formatTimestamp(timestamp){
    if (timestamp){
      // var date = new Date(timestamp);
      // var month = date.getMonth()+1;
      // var day = date.getDay();
      // var year = date.getFullYear();
      // var hours = date.getHours();
      // var minutes = date.getMinutes();
      // var ampm = hours >= 12 ? 'pm' : 'am';
      // hours = hours % 12;
      // hours = hours ? hours : 12; // the hour '0' should be '12'
      // if (minutes < 10){
      //   return month+"/"+day+"/"+year + " " + hours + ':' + `0${minutes}` + ' ' + ampm;
      // }
      // else {
      //   return month+"/"+day+"/"+year + " " + hours + ':' + minutes + ' ' + ampm;
      // }
      return this.datepipe.transform(timestamp, 'medium');
    } else {
      return "No timestamp"
    }
  }

  resendNotification(baseNotification){
      this.sharedSrv.openDialog<null>(
      {
        title: this.resendStream,
        description: this.resendStreamAll,
        template: 0,
        cancel: 'no',
        confirm: 'confirm',
      },
      true
    ).subscribe(response => {
      if (response.continue){
        this.notificationsSrv.resendNotification(baseNotification.id)
        .subscribe(newNotification => {
          this.sharedSrv.openDialog<null>(
          {
            title: this.resendNotif,
            description: this.success,
            template: 0
          },
          false
        )
        });
      }
    });
  }


  isMessageDelivered(){
    var currentTime = new Date().getTime();
    if (this.currentNotification && this.currentNotification.publishTimestamp < currentTime){
      return true;
    }
    return false;
  }

  canWrite(){
    return this.storageSrv.getWorkspaceWritePermission(Resource.notifications)
  }

  canUpdate(){
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.notifications)
  }

  canDelete(){
    return this.storageSrv.getWorkspaceDeletePermission(Resource.notifications)
  }

}
