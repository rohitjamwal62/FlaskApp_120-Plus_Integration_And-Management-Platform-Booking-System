import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RecipientGroup } from '../../models/recipient-models/recipient-group.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UtilService } from '../../services/util.service';
import { InputField } from '../../models/common-models/input-field.model';
import { AmazingTimePickerService } from 'amazing-time-picker';
import { WorkspacesService } from '../../services/workspaces.service';
import { SharedService } from '../../services/shared.service';
import { OAuthConnection } from '../../models/common-models/o-auth-connection.model';
import { Calendar } from '../../models/common-models/calendar.model';
import { MatSelectChange, MatSelect } from '@angular/material/select';
import { UserBasic } from '../../models/user-models/user-basic.model';
import { ChooseFileComponent } from '../choose-file/choose-file.component';
import { AssetFile } from '../../models/asset-models/asset-file.model';
import { MatChipInputEvent } from '@angular/material/chips';
import { ENTER, TAB } from '@angular/cdk/keycodes';
import { StorageService } from '../../services/storage.service';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { RecipientsService } from 'src/app/shared/services/recipients.service';
import { RecipientInvitationRequest } from 'src/app/shared/models/requests-models/recipient-invite.model';
import { RecipientImportComponent } from 'src/app/shared/components/recipient-import/recipient-import.component';
import { Recipient } from 'src/app/shared/models/recipient-models/recipient.model';

import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-recipient-edit',
  templateUrl: './recipient-edit.component.html',
  styleUrls: ['./recipient-edit.component.scss']
})
export class RecipientEditComponent implements OnInit {
  addOnBlur = true;
  separatorKeysCodes: number[] = [ENTER, TAB];

  recipientForm: FormGroup;

  recipientGroups: RecipientGroup[];
  recipient: Recipient;
  config = {}

  requestEndpoint: string = '';
  allFields: string = '';

  constructor(
    private translate: TranslateService,
    public dialogRef: MatDialogRef<RecipientEditComponent>,
    private fb: FormBuilder,
    public utilSrv: UtilService,
    private sharedSrv: SharedService,
    private storageSrv: StorageService,
    private workspaceSrv: WorkspacesService,
    private recipientsSrv: RecipientsService,
    @Inject(MAT_DIALOG_DATA) public data: {
      recipient: Recipient
    },
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.requestEndpoint = this.utilSrv.env.endPoint;

    this.translate.get('RECIPIENTEDIT.ALLFIELDS').subscribe((string) => {
      this.allFields = string;
    });

    if (this.data) {
      this.recipient = this.data.recipient;
      this.generateEditRecipientForm(this.recipient);
      this.getRecipientGroups();

    } else {
      this.dialogRef.close({ continue: false, outputData: null });
    }
  }


  getRecipientGroups(){
    this.recipientGroups = this.storageSrv.recipientGroups;
  }


  /**
   * create recipientGroupForm reactive form with dynamic properties
   * from `notificationType.properties`
   *
   *
   * @return `null`
   */
  generateEditRecipientForm(recipient: Recipient) {
    var currentIds = [];
    for (var i = 0; i < recipient.recipientGroups.length; i++){
      currentIds.push(recipient.recipientGroups[i].id);
    }

    this.recipientForm = this.fb.group({
      recipientGroups: [currentIds],
    });

  }



  /**
   * close dialog without changes
   *
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * close dialog with slide creation info
   *
   * @param null
   *
   * @return `null`
   */
  onContinue() {
    if (this.recipientForm.valid) {

      let outputData = this.recipientForm.getRawValue();
      this.recipientsSrv.updateRecipient(outputData, this.recipient.id).subscribe(response => {
        this.dialogRef.close({
          continue: true,
          outputData: response
        })
      });
    } else {
      this.sharedSrv.errorDialog(this.allFields);
    }
  }

  canWrite(){
    return this.storageSrv.getWorkspaceWritePermission(Resource.recipients)
  }

  canUpdate(){
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.recipients)
  }

  canDelete(){
    return this.storageSrv.getWorkspaceDeletePermission(Resource.recipients)
  }

}
