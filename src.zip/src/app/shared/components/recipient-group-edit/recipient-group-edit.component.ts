import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UtilService } from '../../services/util.service';
import { AmazingTimePickerService } from 'amazing-time-picker';
import { MatSelectChange, MatSelect } from '@angular/material/select';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { MatChipInputEvent } from '@angular/material/chips';
import { ENTER, TAB } from '@angular/cdk/keycodes';
import { TranslateService } from '@ngx-translate/core';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

import { RecipientGroup } from '../../models/recipient-models/recipient-group.model';
import { InputField } from '../../models/common-models/input-field.model';
import { OAuthConnection } from '../../models/common-models/o-auth-connection.model';
import { Calendar } from '../../models/common-models/calendar.model';
import { UserBasic } from '../../models/user-models/user-basic.model';
import { ChooseFileComponent } from '../choose-file/choose-file.component';
import { AssetFile } from '../../models/asset-models/asset-file.model';
import { Playlist } from 'src/app/shared/models/playlist-models/playlist.model';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';

import { WorkspacesService } from '../../services/workspaces.service';
import { SharedService } from '../../services/shared.service';
import { StorageService } from '../../services/storage.service';
import { RecipientsService } from 'src/app/shared/services/recipients.service';
import { PlaylistsService } from 'src/app/shared/services/playlists.service';


@Component({
  selector: 'app-recipient-group-edit',
  templateUrl: './recipient-group-edit.component.html',
  styleUrls: ['./recipient-group-edit.component.scss']
})
export class RecipientGroupEditComponent extends CleanOnDestroy implements OnInit {

  currentWorkspace: Workspace;

  addOnBlur = true;
  separatorKeysCodes: number[] = [ENTER, TAB];
  recipientGroupForm: FormGroup;
  recipientGroup: RecipientGroup;
  playlists: Playlist[];
  showTags: boolean = false;
  config = {}
  requestEndpoint: string = '';
  currentLocale: any = '';
  allFields: string = '';

  constructor(
    private translate: TranslateService,
    public dialogRef: MatDialogRef<RecipientGroupEditComponent>,
    private fb: FormBuilder,
    public utilSrv: UtilService,
    private sharedSrv: SharedService,
    private storageSrv: StorageService,
    private workspaceSrv: WorkspacesService,
    private recipientsSrv: RecipientsService,
    private atpSrv: AmazingTimePickerService,
    private playlistsSrv: PlaylistsService,
    @Inject(MAT_DIALOG_DATA) public data: {
      workspaceId: number,
      recipientGroup?: RecipientGroup,
      isNew: boolean
    },
  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.currentLocale = this.utilSrv.locale;
    this.requestEndpoint = this.utilSrv.env.endPoint;

    this.translate.get('RECIPIENTGROUPEDIT.ALLFIELDS').subscribe((string) => {
      this.allFields = string;
    });

    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe(workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;

          if (this.data) {
            if (this.data.recipientGroup) {
              this.recipientGroup = this.data.recipientGroup;
              this.generateRecipientGroupForm();
            } else {
              this.generateNewRecipientGroupForm();
            }
          }

          this.getPlaylists();
        }
      });
  }


  getPlaylists(){
    this.subscriber = this.playlistsSrv.getPlaylists(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    ).subscribe(playlists => {
      if (playlists) {
        this.playlists = playlists;
      }
    })
  }

  /**
   * create recipientGroupForm reactive form with dynamic properties
   * from `notificationType.properties`
   * @return `null`
   */
  generateNewRecipientGroupForm() {
    this.recipientGroupForm = this.fb.group({
      groupName: ['', [Validators.required, removeWhitespaceValidator]],
      playlistId: [],
      workspaceId: [this.currentWorkspace.id]
    });

    this.showTags = false;
  }


  /**
   * create notificationForm reactive form with dynamic properties
   * from `notificatiion.properties`
   * @return `null`
   */
  generateRecipientGroupForm() {
    this.recipientGroupForm = this.fb.group({
      groupName: [this.recipientGroup.groupName, [Validators.required, removeWhitespaceValidator]],
      playlistId: [0, [Validators.required]],
      tags: [this.recipientGroup.tags],
    });

    this.showTags = true;

    if (this.recipientGroup.playlist){
      this.recipientGroupForm.get("playlistId").patchValue(this.recipientGroup.playlist.id);
    }

  }


  /**
  * calls from template
  * when user type new tag and press on the some keys from `separatorKeysCodes`
  * add new tag into playlist tags
  * @param event with type `MatChipInputEvent`
  * @return `null`
  */
  onAddNewTag(event: MatChipInputEvent) {
    const input = event.input;
    const tagName = event.value;

    if ((tagName || '').trim()) {
      let tags = this.recipientGroupForm.get('tags').value;
      tags.push(tagName)
      this.recipientGroupForm.get('tags').patchValue(tags);
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }
  }

  /**
   * calls from template
   * when user type new tag and press on the some keys from `separatorKeysCodes`
   * add new tag into playlist tags
   * @param event with type `MatChipInputEvent`
   * @return `null`
   */
  onRemoveTag(tagName: string) {
    let tags: string[] = this.recipientGroupForm.get('tags').value;
    let tagIndex = tags.indexOf(tagName);
    if (tagIndex >= 0) {
      tags.splice(tagIndex, 1);
      this.recipientGroupForm.get('tags').patchValue(tags);
    }
  }


  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * close dialog with slide creation info
   * @param null
   * @return `null`
   */
  onContinue() {
    if (this.recipientGroupForm.valid) {
      let outputData = this.recipientGroupForm.getRawValue();
      if(this.data.isNew) {
        this.createNewGroup(outputData);
      } else {
        this.updateGroup(outputData);
      }
    } else {
      this.sharedSrv.errorDialog(this.allFields);
    }
  }

  createNewGroup(formData) {
    this.subscriber = this.recipientsSrv.createRecipientGroup(formData)
      .subscribe(newGroup => {
        if(newGroup) {
          this.dialogRef.close({
            continue: true,
            outputData: newGroup
          });
        }
      });
  }

  updateGroup(formData) {
    this.subscriber = this.recipientsSrv.updateRecipientGroup(
      this.recipientGroup.id, 
      formData
    )
      .subscribe(updatedGroup => {
        if(updatedGroup) {
          this.dialogRef.close({
            continue: true,
            outputData: updatedGroup
          });
        }
      });
  }

  canWrite(){
    return this.storageSrv.getWorkspaceWritePermission(Resource.recipients)
  }

  canUpdate(){
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.recipients)
  }

  canDelete(){
    return this.storageSrv.getWorkspaceDeletePermission(Resource.recipients)
  }

}
