import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RecipientGroup } from '../../models/recipient-models/recipient-group.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UtilService } from '../../services/util.service';
import { InputField } from '../../models/common-models/input-field.model';
import { AmazingTimePickerService } from 'amazing-time-picker';
import { WorkspacesService } from '../../services/workspaces.service';
import { SharedService } from '../../services/shared.service';
import { OAuthConnection } from '../../models/common-models/o-auth-connection.model';
import { Calendar } from '../../models/common-models/calendar.model';
import { MatSelectChange, MatSelect } from '@angular/material/select';
import { UserBasic } from '../../models/user-models/user-basic.model';
import { ChooseFileComponent } from '../choose-file/choose-file.component';
import { AssetFile } from '../../models/asset-models/asset-file.model';
import { MatChipInputEvent } from '@angular/material/chips';
import { ENTER, TAB } from '@angular/cdk/keycodes';
import { StorageService } from '../../services/storage.service';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { RecipientsService } from 'src/app/shared/services/recipients.service';
import { Notification } from 'src/app/shared/models/notification-models/notification.model';

import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-recipient-group-history',
  templateUrl: './recipient-group-history.component.html',
  styleUrls: ['./recipient-group-history.component.scss']
})
export class RecipientGroupHistoryComponent implements OnInit {
  addOnBlur = true;
  separatorKeysCodes: number[] = [ENTER, TAB];

  recipientGroup: RecipientGroup;
  notifications: Notification[];
  displayedColumns: string[] = ["notificationName", "author", "publishTimestamp", "notificationType"];

  config = {}

  requestEndpoint: string = '';
  constructor(
    private translate: TranslateService,
    public dialogRef: MatDialogRef<RecipientGroupHistoryComponent>,
    private fb: FormBuilder,
    public utilSrv: UtilService,
    private sharedSrv: SharedService,
    private storageSrv: StorageService,
    private workspaceSrv: WorkspacesService,
    private recipientsSrv: RecipientsService,
    private atpSrv: AmazingTimePickerService,
    @Inject(MAT_DIALOG_DATA) public data: {
      recipientGroup: RecipientGroup
    },
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.requestEndpoint = this.utilSrv.env.endPoint;

    if (this.data) {
      this.recipientGroup = this.data.recipientGroup;

      // populate list of notifications
      this.getGroupNotifications(this.recipientGroup);

    } else {
      this.dialogRef.close({ continue: false, outputData: null });
    }
  }


  getGroupNotifications(recipientGroup: RecipientGroup){
    this.recipientsSrv.getRecipientGroupNotifications(recipientGroup.id)
    .subscribe(notifications => {
      this.notifications = notifications;
    });
  }


  /**
   * close dialog without changes
   *
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * close dialog with slide creation info
   *
   * @param null
   *
   * @return `null`
   */
  onContinue() {

    // close dialog with slide createion info
    this.dialogRef.close({
      continue: true,
    })

  }

  isMessageDelivered(message){
    var currentTime = new Date().getTime();
    if (message.publishTimestamp < currentTime){
      return true;
    }
    return false;
  }



}
