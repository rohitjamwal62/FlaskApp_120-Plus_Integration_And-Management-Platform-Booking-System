import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Recipient } from '../../models/recipient-models/recipient.model';
import { RecipientGroup } from '../../models/recipient-models/recipient-group.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UtilService } from '../../services/util.service';
import { InputField } from '../../models/common-models/input-field.model';
import { AmazingTimePickerService } from 'amazing-time-picker';
import { WorkspacesService } from '../../services/workspaces.service';
import { SharedService } from '../../services/shared.service';
import { OAuthConnection } from '../../models/common-models/o-auth-connection.model';
import { Calendar } from '../../models/common-models/calendar.model';
import { MatSelectChange, MatSelect } from '@angular/material/select';
import { UserBasic } from '../../models/user-models/user-basic.model';
import { ChooseFileComponent } from '../choose-file/choose-file.component';
import { AssetFile } from '../../models/asset-models/asset-file.model';
import { MatChipInputEvent } from '@angular/material/chips';
import { ENTER, TAB } from '@angular/cdk/keycodes';
import { StorageService } from '../../services/storage.service';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { RecipientsService } from 'src/app/shared/services/recipients.service';
import { Notification } from 'src/app/shared/models/notification-models/notification.model';
import { RecipientUpdateRequest } from 'src/app/shared/models/requests-models/recipient-update.model';


import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-recipient-group-recipients',
  templateUrl: './recipient-group-recipients.component.html',
  styleUrls: ['./recipient-group-recipients.component.scss']
})
export class RecipientGroupRecipientsComponent implements OnInit {
  addOnBlur = true;
  separatorKeysCodes: number[] = [ENTER, TAB];

  removeRecipientHeaderString: string = '';
  removeRecipientBodyString: string = '';
  confirmString: string = '';
  cancelString: string = '';

  recipientGroup: RecipientGroup;
  recipients: Recipient[];

  requestEndpoint: string = '';
  allFields: string = '';

  constructor(
    public dialogRef: MatDialogRef<RecipientGroupRecipientsComponent>,
    private translate: TranslateService,
    private fb: FormBuilder,
    public utilSrv: UtilService,
    private sharedSrv: SharedService,
    private storageSrv: StorageService,
    private workspaceSrv: WorkspacesService,
    private recipientsSrv: RecipientsService,
    private atpSrv: AmazingTimePickerService,
    @Inject(MAT_DIALOG_DATA) public data: {
      recipientGroup: RecipientGroup
    },
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.requestEndpoint = this.utilSrv.env.endPoint;

    this.translate.get('RECIPIENTMOVE.ALLFIELDS').subscribe((string) => {
      this.allFields = string;
    });
    this.translate.get("RECIPIENTGROUP.REMOVERECIPIENT").subscribe((string) => {
      this.removeRecipientHeaderString = string;
    });
    this.translate.get("RECIPIENTGROUP.REMOVERECIPIENTCONFIRM").subscribe((string) => {
      this.removeRecipientBodyString = string;
    });
    this.translate.get("RECIPIENTS.CANCEL").subscribe((string) => {
      this.cancelString = string;
    });
    this.translate.get("RECIPIENTS.CONFIRM").subscribe((string) => {
      this.confirmString = string;
    });

    if (this.data) {
      this.recipientGroup = this.data.recipientGroup;

      // populate list of recipients
      this.getRecipients(this.recipientGroup);

    } else {
      this.dialogRef.close({ continue: false, outputData: null });
    }
  }


  getRecipients(recipientGroup: RecipientGroup){
    this.recipientsSrv.getRecipientGroupRecipients(recipientGroup.id)
    .subscribe(recipients => {
      this.recipients = recipients;
    });
  }


  removeRecipientFromCurrentGroup(recipient: Recipient, i: number){
    this.sharedSrv.openDialog<null>(
      {
        title: this.removeRecipientHeaderString,
        description: this.removeRecipientBodyString,
        template: 0,
        cancel: this.cancelString,
        confirm: this.confirmString
      }, true
    ).subscribe(response => {
      if (response && response.continue){

        // construct recipient group ids to stay in (skip this one)
        var groupIds: number[] = [];
        for (var i = 0; i < recipient.recipientGroups.length; i++){
          if (recipient.recipientGroups[i].id != this.recipientGroup.id){
            groupIds.push(recipient.recipientGroups[i].id);
          }
        }

        this.recipientsSrv.updateRecipient({recipientGroups: groupIds}, recipient.id)
        .subscribe(updatedRecipient => {
          this.recipients.splice(i, 1);

          // update the recipient in the stored recipients
          for (var i = 0; i < this.storageSrv.recipients.length; i++){
            if (this.storageSrv.recipients[i].id == recipient.id){
              this.storageSrv.recipients[i] = updatedRecipient;
              break;
            }
          }
        });
      }
    });
  }


  /**
   * close dialog without changes
   *
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }


}
