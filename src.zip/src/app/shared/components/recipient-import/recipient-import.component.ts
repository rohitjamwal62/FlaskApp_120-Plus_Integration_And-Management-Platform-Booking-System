import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RecipientGroup } from '../../models/recipient-models/recipient-group.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UtilService } from '../../services/util.service';
import { InputField } from '../../models/common-models/input-field.model';
import { AmazingTimePickerService } from 'amazing-time-picker';
import { WorkspacesService } from '../../services/workspaces.service';
import { SharedService } from '../../services/shared.service';
import { OAuthConnection } from '../../models/common-models/o-auth-connection.model';
import { Calendar } from '../../models/common-models/calendar.model';
import { MatSelectChange, MatSelect } from '@angular/material/select';
import { UserBasic } from '../../models/user-models/user-basic.model';
import { ChooseFileComponent } from '../choose-file/choose-file.component';
import { AssetFile } from '../../models/asset-models/asset-file.model';
import { MatChipInputEvent } from '@angular/material/chips';
import { ENTER, TAB } from '@angular/cdk/keycodes';
import { StorageService } from '../../services/storage.service';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { RecipientsService } from 'src/app/shared/services/recipients.service';
import { Playlist } from 'src/app/shared/models/playlist-models/playlist.model';
import { LocalRequestsService }  from 'src/app/shared/services/local-requests.service';
import { RecipientImportResultsComponent } from 'src/app/shared/components/recipient-import-results/recipient-import-results.component';
import { TranslateService } from '@ngx-translate/core';
// Utils
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

@Component({
  selector: 'app-recipient-import',
  templateUrl: './recipient-import.component.html',
  styleUrls: ['./recipient-import.component.scss']
})
export class RecipientImportComponent implements OnInit {
  addOnBlur = true;
  separatorKeysCodes: number[] = [ENTER, TAB];
  recipientImportForm: FormGroup;
  workspaceId: number;
  fileData: any;

  config = {}

  requestEndpoint: string = '';
  allFields: string = '';

  constructor(
    private translate: TranslateService,
    public dialogRef: MatDialogRef<RecipientImportComponent>,
    private fb: FormBuilder,
    public utilSrv: UtilService,
    private sharedSrv: SharedService,
    private storageSrv: StorageService,
    private workspaceSrv: WorkspacesService,
    private recipientsSrv: RecipientsService,
    private atpSrv: AmazingTimePickerService,
    private localRequestsSrv: LocalRequestsService,
    @Inject(MAT_DIALOG_DATA) public data: {
      workspaceId: number
    },
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.requestEndpoint = this.utilSrv.env.endPoint;

    this.translate.get('RECIPIENTIMPORT.ALLFIELDS').subscribe((string) => {
      this.allFields = string;
    });

    if (this.data) {
      this.workspaceId = this.data.workspaceId;
      this.generateImportForm();
    } else {
      this.dialogRef.close({ continue: false, outputData: null });
    }
  }

  generateImportForm(){
    this.recipientImportForm = this.fb.group({
      emailColumnName: ['', [Validators.required, removeWhitespaceValidator]],
      recipientGroupColumnName: ['', [Validators.required, removeWhitespaceValidator]],
      workspaceId: [this.workspaceId],
    });
  }

  csvInputChange(fileInputEvent: any) {
    this.fileData = fileInputEvent.target.files[0];
  }


  import(){
    if (this.recipientImportForm.valid && this.fileData) {
      let outputData = this.recipientImportForm.getRawValue();
      // take form and upload to service
      this.localRequestsSrv.uploadFile(`${this.recipientsSrv.recipientsPath}import/`, outputData, this.fileData)
      .subscribe(response => {
        if (response["success"]){
          // open window ot display the results
          this.sharedSrv
          .openDialog(
            {
              importResults: response["message"]
            },
            true,
            { width: '80%' },
            RecipientImportResultsComponent
          ).subscribe(response => {
            if (response.continue){

            }
          });
        } else {
          this.sharedSrv.errorDialog(response["message"]);
        }
      });
    } else {
      this.sharedSrv.errorDialog(this.allFields);
    }
  }

  /**
   * close dialog without changes
   *
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }


  canWrite(){
    return this.storageSrv.getWorkspaceWritePermission(Resource.recipients)
  }

  canUpdate(){
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.recipients)
  }

  canDelete(){
    return this.storageSrv.getWorkspaceDeletePermission(Resource.recipients)
  }

}
