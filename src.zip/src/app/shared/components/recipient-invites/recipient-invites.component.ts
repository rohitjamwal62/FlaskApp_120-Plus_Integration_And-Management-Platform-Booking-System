import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RecipientGroup } from '../../models/recipient-models/recipient-group.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UtilService } from '../../services/util.service';
import { InputField } from '../../models/common-models/input-field.model';
import { AmazingTimePickerService } from 'amazing-time-picker';
import { WorkspacesService } from '../../services/workspaces.service';
import { SharedService } from '../../services/shared.service';
import { OAuthConnection } from '../../models/common-models/o-auth-connection.model';
import { Calendar } from '../../models/common-models/calendar.model';
import { MatSelectChange, MatSelect } from '@angular/material/select';
import { UserBasic } from '../../models/user-models/user-basic.model';
import { ChooseFileComponent } from '../choose-file/choose-file.component';
import { AssetFile } from '../../models/asset-models/asset-file.model';
import { MatChipInputEvent } from '@angular/material/chips';
import { ENTER, TAB } from '@angular/cdk/keycodes';
import { StorageService } from '../../services/storage.service';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { RecipientsService } from 'src/app/shared/services/recipients.service';
import { RecipientInvitationRequest } from 'src/app/shared/models/requests-models/recipient-invite.model';
import { RecipientImportComponent } from 'src/app/shared/components/recipient-import/recipient-import.component';
import { TranslateService } from '@ngx-translate/core';
// Utils
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

@Component({
  selector: 'app-recipient-invitation',
  templateUrl: './recipient-invites.component.html',
  styleUrls: ['./recipient-invites.component.scss']
})
export class RecipientInvitesComponent implements OnInit {
  addOnBlur = true;
  separatorKeysCodes: number[] = [ENTER, TAB];

  recipientInviteForm: FormGroup;
  workspaceId: number;
  recipientGroups: RecipientGroup[];

  requestEndpoint: string = '';

  // Form submit flagg
  isFormSubmit = false;

  constructor(
    private translate: TranslateService,
    public dialogRef: MatDialogRef<RecipientInvitesComponent>,
    private fb: FormBuilder,
    public utilSrv: UtilService,
    private sharedSrv: SharedService,
    private storageSrv: StorageService,
    private workspaceSrv: WorkspacesService,
    private recipientsSrv: RecipientsService,
    @Inject(MAT_DIALOG_DATA) public data: {
      workspaceId: number,
      recipientGroup?: RecipientGroup,
      isNew: boolean
    },
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.requestEndpoint = this.utilSrv.env.endPoint;

    if (this.data) {
      this.workspaceId = this.data.workspaceId;
      this.generateNewRecipientInviteForm();

      this.getRecipientGroups();

    } else {
      this.dialogRef.close({ continue: false, outputData: null });
    }
  }


  getRecipientGroups(){
    this.recipientGroups = this.storageSrv.recipientGroups;
  }


  /**
   * create recipientGroupForm reactive form with dynamic properties
   * from `notificationType.properties`
   *
   *
   * @return `null`
   */
  generateNewRecipientInviteForm() {
    this.recipientInviteForm = this.fb.group({
      email: ['', [Validators.required, removeWhitespaceValidator]],
      recipientGroups: [[]],
      workspaceId: [this.workspaceId]
    });

  }


  onImportRecipients(){
    if (
      this.storageSrv.selectedWorkspace
      && this.storageSrv.selectedWorkspace.id >= 0
    ) {
      this.sharedSrv
        .openDialog(
          {
            workspaceId: this.storageSrv.selectedWorkspace.id
          },
          true,
          { width: '80%' },
          RecipientImportComponent
        ).subscribe(response => {
          if (response.continue){
            this.onContinueImport();
          }
        });
    } else {
      this.sharedSrv.errorDialog('Please choose your workspace before creating a new Recipient Group.');
    }
  }




  /**
   * close dialog without changes
   *
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * close dialog with slide creation info
   *
   * @param null
   *
   * @return `null`
   */
  onContinue() {
    if (this.recipientInviteForm.valid) {
      this.isFormSubmit = true;
      let outputData = this.recipientInviteForm.getRawValue();
      this.recipientsSrv.inviteRecipient(outputData).subscribe(response => {
        this.dialogRef.close({
          continue: true,
          outputData: response
        });
      }, (err) => {
        this.isFormSubmit = false;
      });
    } else {
      this.sharedSrv.errorDialog('Please fill all required fields.');
    }
  }

  onContinueImport(){
    this.dialogRef.close({
        continue: true,
        outputData: null
      })
  }

  canWrite(){
    return this.storageSrv.getWorkspaceWritePermission(Resource.recipients)
  }

  canUpdate(){
    return this.storageSrv.getWorkspaceUpdatePermission(Resource.recipients)
  }

  canDelete(){
    return this.storageSrv.getWorkspaceDeletePermission(Resource.recipients)
  }

}
