import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UtilService } from 'src/app/shared/services/util.service';
import { UserRequestType } from '../../models/user-models/user-request-type.model';
import { TranslateService } from '@ngx-translate/core';
// Utils
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

@Component({
  selector: 'app-request-new',
  templateUrl: './request-new.component.html',
  styleUrls: ['./request-new.component.scss']
})
export class RequestNewComponent implements OnInit {
  requestTypes: UserRequestType[] = [
    {
      id: 1,
      typeName: 'Bug',
      location: ''
    },
    {
      id: 2,
      typeName: 'Help',
      location: ''
    },
    {
      id: 3,
      typeName: 'Suggestion',
      location: ''
    },
  ];
  userRequestForm: FormGroup;

  constructor(
    public translate: TranslateService,
    public utilSrv: UtilService,
    public dialogRef: MatDialogRef<RequestNewComponent>,
    private fb: FormBuilder
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.generateUserRequestForm();
  }

  generateUserRequestForm() {
    this.userRequestForm = this.fb.group({
      requestTypeId: [null, [Validators.required]],
      summary: ['', [Validators.required, removeWhitespaceValidator]],
    });
  }

  /**
   * calls from template
   * helper function for *ngFor optimization
   *
   * @param index is a index of current item
   * @param item is a current item
   *
   * @return `number`
   */
  onTrackById(index: number, item: { id: number }) {
    return item.id
  }

  /**
   * close dialog without changes
   *
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * close dialog and continue
   *
   * @param null
   *
   * @return `null`
   */
  onContinue() {
    if (this.userRequestForm.valid) {
      this.dialogRef.close({
        continue: true,
        outputData: this.userRequestForm.getRawValue()
      });
    }
  }

}
