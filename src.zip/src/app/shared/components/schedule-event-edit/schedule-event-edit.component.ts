import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormGroup, FormBuilder, Validators, ValidatorFn, AbstractControl, ValidationErrors, FormControl } from '@angular/forms';
import { MatSelectChange } from '@angular/material/select';
import { CleanOnDestroy } from '../../classes/clean-destroy';
import { TranslateService } from '@ngx-translate/core';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

import { PlaylistsService } from '../../services/playlists.service';
import { StorageService } from '../../services/storage.service';
import { UtilService } from 'src/app/shared/services/util.service';

import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { Playlist } from '../../models/playlist-models/playlist.model';
import { ScheduleWeekDay } from '../../models/event-scheduler-models/schedule-weekday.model';


@Component({
  selector: 'app-schedule-event-edit',
  templateUrl: './schedule-event-edit.component.html',
  styleUrls: ['./schedule-event-edit.component.scss']
})
export class ScheduleEventEditComponent extends CleanOnDestroy implements OnInit {

  currentWorkspace: Workspace;
  playlists: Playlist[] = [];

  // Form fields
  startHour: string = '';
  startMin: string = '';
  endHour: string = '';
  endMin: string = '';

  // Form controlName
  startSeconds: number = 0;
  endSeconds: number = 0;

  hoursInMillisec: number = 60 * 60 * 1000;
  minutesInMillisec: number = 60 * 1000;

  hours: string[] = new Array("1:00 AM", "2:00 AM", "3:00 AM", "4:00 AM", "5:00 AM", "6:00 AM", "7:00 AM", "8:00 AM", "9:00 AM", "10:00 AM", "11:00 AM", "NOON",
    "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM", "6:00 PM", "7:00 PM", "8:00 PM", "9:00 PM", "10:00 PM", "11:00 PM", "MIDNIGHT");
  minutes: string[] = ["00","05","10","15","20","25","30","35","40","45","50","55"];

  scheduleEventForm: FormGroup;
  daysCount: number = 0;
  currentLocale: any = '';

  constructor(
    public utilSrv: UtilService,
    private translate: TranslateService,
    public dialogRef: MatDialogRef<ScheduleEventEditComponent>,
    private storageSrv: StorageService,
    private playlistsSrv: PlaylistsService,
    @Inject(MAT_DIALOG_DATA) public data: {
      scheduleData: {
        startDate: number;
        endDate: number;
        id: string;
        color: string;
        playlistName: string;
      },
      isNew: boolean,
    },
    private fb: FormBuilder
  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }


  ngOnInit() {
    this.currentLocale = this.utilSrv.locale;
    this.generateScheduleEventForm();

    if (this.data.scheduleData) {
      let data = this.data.scheduleData;
      this.patchFormValues();
    }
    
    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe(workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;
          this.getPlaylists();
        }
      });
  }

  /**
   * generate scheduleEvent form
   * @param null
   * @return `null`
   */
  generateScheduleEventForm() {
    this.scheduleEventForm = this.fb.group({
      playlistId: [null, [Validators.required]],
      playlistName: null,
      color: null,
      startSeconds: 0,
      endSeconds: 0,
      onMonday: true,
      onTuesday: true,
      onWednesday: true,
      onThursday: true,
      onFriday: true,
      onSaturday: true,
      onSunday: true
    });
  }

  patchFormValues() {
    let scheduleData = this.data.scheduleData;

    // Patch form controls value
    this.scheduleEventForm.patchValue(this.data.scheduleData);

    this.startHour = this.patchHourField(this.data.scheduleData, true);
    this.endHour = this.patchHourField(this.data.scheduleData, false);
    this.startMin = this.patchMinsField(this.data.scheduleData, true);
    this.endMin = this.patchMinsField(this.data.scheduleData, false);

    this.updateStartSeconds();
    this.updateEndSeconds();
  }

  onWeekDaysChange(event, controlName: string) {
    if(event.checked) {
      this.getControl(controlName).patchValue(true);
    } else {
      this.getControl(controlName).patchValue(false);
    }
  }

  /**
   * get playlists from api
   * @param null
   * @return `null`
   */
  getPlaylists() {
    this.subscriber = this.playlistsSrv.getPlaylists(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    ).subscribe(playlists => {
      if (playlists) {
        this.playlists = playlists;
      }
    })
  }

  /**
   * calls from template
   * helper function for a get playlist name
   *
   * @param event is a mat select output event object
   *
   * @return `null`
   */
  onChangeSelectedPlaylist(event: MatSelectChange) {
    // Commented Temporarily
    // if (event.value >= 0) {
    //   let i = 0;
    //   this.playlists.every(playlist => {
    //     i = i++;
    //     if (event.value === playlist.id) {
    //       this.getControl('playlistName').patchValue(playlist.playlistName);
    //       this.getControl('color').patchValue(playlist.color);
    //       return false;
    //     }
    //     return true;
    //   });
    // }
  }

  /**
   * set date with user selected weekday
   *
   * @param event is a Output event of Mat Select
   * @param controlName is a name of control with type `string`
   *
   * @return `AbstractControl`
   */
  onChangeWeekDay(event: MatSelectChange, controlName: string) {
    let control = this.getControl(controlName);
    let date = null
    if (control.value) {
      date = new Date(control.value);
    } else {
      date = new Date(
        new Date().getFullYear(),
        new Date().getMonth(),
        new Date().getDate(),
        0,
        0,
        0
      );
    }
    let day = date.getDate();
    let weekDayInNumber = this.getWeekDayOfDate(date);
    let selectedDayDiference = event.value - weekDayInNumber;
    let generatedDate = date.setDate(date.getDate() + selectedDayDiference);
    control.patchValue(generatedDate);
  }

  /**
   * set user selected hour on the control value
   *
   * @param event is a Output event of Mat Select
   * @param controlName is a name of control with type `string`
   *
   * @return `AbstractControl`
   */
  onChangeHours(event: MatSelectChange, controlName: string) {
    let control = this.getControl(controlName);
    if(controlName == 'startSeconds') {
      this.startHour = event.value;
      this.updateStartSeconds();
    } else {
      this.endHour = event.value;
      this.updateEndSeconds();
    }
  }

  checkEndHourSelection(hour: string) {
    let startHour = this.getHour(this.startHour);
    let endHour = this.getHour(hour);
    let startSeconds = this.hourToSeconds(startHour) + this.minutesToSeconds(Number(this.startMin));
    let endSeconds = this.hourToSeconds(endHour) + this.minutesToSeconds(Number(this.endMin));
    if(startSeconds > endSeconds) {
      return true;
    } else {
      return false;
    }
  }

  /**
   *  set user selected minutes on the control value
   *
   * @param event is a Output event of Mat Select
   * @param controlName is a name of control with type `string`
   *
   * @return `AbstractControl`
   */
  onChangeMinutes(event: MatSelectChange, controlName: string) {
    let control = this.getControl(controlName);
    let minutes = event.value;
    if(controlName == 'startSeconds') {
      this.startMin = minutes;
      this.updateStartSeconds();
    } else {
      this.endMin = minutes;
      this.updateEndSeconds();
    }
  }

  updateStartSeconds() {
    let control = this.getControl('startSeconds');
    let hour = this.getHour(this.startHour);
    let startMin = Number(this.startMin);
    this.startSeconds = this.hourToSeconds(hour) + this.minutesToSeconds(startMin);
    control.patchValue(this.startSeconds);
  }

  updateEndSeconds() {
    let control = this.getControl('endSeconds');
    let hour = this.getHour(this.endHour);
    let endMin = Number(this.endMin);
    this.endSeconds = this.hourToSeconds(hour) + this.minutesToSeconds(endMin);
    control.patchValue(this.endSeconds);
  }

  getHour(value: string) {
    let hourIndex = this.hours.indexOf(value);
    let hour = hourIndex + 1;
    return hour;
  }

  hourToSeconds(value: number) {
    return value * 3600;
  }

  minutesToSeconds(value: number) {
    return value * 60;
  }

  /**
   * return FormControl with name `name`
   *
   * @param name is a FormControl name with type string
   *
   * @return `AbstractControl`
   */
  getControl(name: string) {
    return this.scheduleEventForm.get(name);
  }

  /**
   * transform number to date
   *
   * @param value is a date in miliseconds with type number
   *
   * @return `Date`
   */
  toDate(value: number) {
    return new Date(value);
  }

  patchHourField(event: any, isStart: boolean) {
    let hour = 0;
    let date = isStart ? event.startDate : event.endDate;
    let seconds = isStart ? event.startSeconds : event.endSeconds;
    if(event.startSeconds == undefined && event.endSeconds == undefined) {
      let newDate = new Date(date);
      hour = newDate.getHours();
      return this.to24HoursFormat(hour);
    } else {
      hour = Math.floor(seconds / 60 / 60);
      return this.to24HoursFormat(hour);
    }
  }

  patchMinsField(event: any, isStart: boolean) {
    let minutes = 0;
    let date = isStart ? event.startDate : event.endDate;
    let seconds = isStart ? event.startSeconds : event.endSeconds;
    let hours = Math.floor(seconds / 60 / 60);
    if(event.startSeconds == undefined && event.endSeconds == undefined) {
      let newDate = new Date(date);
      minutes = newDate.getMinutes();
      return this.toMinutesInterval(minutes);
    } else {
      minutes = Math.floor(seconds / 60) - (hours * 60);
      return this.toMinutesInterval(minutes);
    }
  }

  to24HoursFormat(hour: number) {
    let formattedHour = '';
    if(hour < 12) {
      formattedHour = `${hour}:00 AM`;
    } else if (hour == 12) {
      formattedHour = `NOON`;
    } else if (hour == 24) {
      formattedHour = `MIDNIGHT`;
    } else {
      formattedHour = (hour % 12) +`:00 PM`;
    }
    return formattedHour;
  }

  toMinutesInterval(minutes: number) {
    let minutesArr = this.minutes;
    let _minutes = "";
    for(let i = 0; i < 12; i++) {
      if(minutes <= Number(minutesArr[i])) {
        _minutes = minutesArr[i];
        break;
      } else if(minutes > 55) {
        _minutes = "55";
        break;
      } else {
        // Do nothing
      }
    }
    return _minutes;
  }

  /**
   * get week Day number from date
   *
   * @param date is date which weekday should be getted
   *
   * @return `Date`
   */
  getWeekDayOfDate(date: Date) {
    return date.getDay() - 1 < 0 ? 6 : date.getDay() - 1;
  }

  /**
   * close dialog and continue
   *
   * @param null
   *
   * @return `null`
   */
  onContinue() {
    if (this.scheduleEventForm.valid) {
      this.dialogRef.close({
        continue: true,
        outputData: this.scheduleEventForm.getRawValue()
      });
    }
  }

  /**
   * close dialog without changes
   *
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * helper validator for a make invalid in case of start date is more than end
   *
   * @param null
   *
   * @return `ValidationErrors`
   */
  validateDates(): ValidatorFn {

    return (control: AbstractControl): ValidationErrors => {
      if (this.scheduleEventForm) {
        let startDate = this.getControl('startDate');
        let endDate = this.getControl('endDate');
        startDate.setErrors(null);
        endDate.setErrors(null);
        if (startDate.value && endDate.value && startDate.value > endDate.value) {
          control.setErrors({ inValidDate: true });
          return { inValidDate: true };
        }
        return null;
      }

    }
  }

}
