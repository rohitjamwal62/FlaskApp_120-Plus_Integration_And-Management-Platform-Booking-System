import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSelectChange } from '@angular/material/select';
import { ScheduleCreateUpdateRequest } from '../../models/requests-models/schedule-create-update.model';
import { UtilService } from 'src/app/shared/services/util.service';
import { TranslateService } from '@ngx-translate/core';
// Utils
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

@Component({
  selector: 'app-schedule-new',
  templateUrl: './schedule-new.component.html',
  styleUrls: ['./schedule-new.component.scss']
})
export class ScheduleNewComponent implements OnInit {
  scheduleForm: FormGroup;

  currentLocale: any = '';

  constructor(
    public utilSrv: UtilService,
    private translate: TranslateService,
    public dialogRef: MatDialogRef<ScheduleNewComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      workspaceId: number
    },
    private fb: FormBuilder
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {

    this.currentLocale = this.utilSrv.locale;

    this.generateScheduleForm(this.data.workspaceId);
  }


  /**
   * generate `scheduleForm`
   *
   * @param workspaceId: selected workspaceId
   *
   * @return `null`
   */
  generateScheduleForm(workspaceId: number) {
    this.scheduleForm = this.fb.group({
      workspaceId: [workspaceId, [Validators.required]],
      scheduleName: ['', [Validators.required, removeWhitespaceValidator]]
    });
  }

  /**
   * close dialog without changes
   *
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * close dialog with playlist create info
   *
   * @param null
   *
   * @return `null`
   */
  onContinue() {
    if (this.scheduleForm.valid) {
      let outputData = this.scheduleForm.getRawValue();
      this.dialogRef.close(
        { continue: true, outputData: outputData }
      );
    }
  }
}
