import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { FormBuilder, FormGroup, FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { AmazingTimePickerService } from 'amazing-time-picker';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';
import { MatChipInputEvent } from '@angular/material/chips';
import { MatSelectChange, MatSelect } from '@angular/material/select';
import { ENTER, TAB } from '@angular/cdk/keycodes';
import { environment } from 'src/environments/environment';
import { forkJoin, of } from 'rxjs';
import { debounceTime } from 'rxjs/operators';

import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { AccountFeatures } from 'src/app/shared/models/account-models/account-features.model';
import { Apps } from 'src/app/shared/models/apps-models/apps.model';
import { AppFolder } from 'src/app/shared/models/app-folders/app-folder.model';
import { AppsType } from 'src/app/shared/models/apps-models/apps-type.model';
import { AppsTypes } from 'src/app/shared/models/apps-models/apps-types.model';
import { AppsProperty } from 'src/app/shared/models/apps-models/apps-property.model';
import { AppsInputfields } from 'src/app/shared/models/apps-models/apps-inputfields.model';
import { Calendar } from 'src/app/shared/models/common-models/calendar.model';
import { OAuthConnection } from 'src/app/shared/models/common-models/o-auth-connection.model';
import { OAuthResourceOption } from 'src/app/shared/models/common-models/oauth-resource-option.model';
import { ClientToken } from 'src/app/shared/models/integration-models/client-token.model';
import { AssetFile } from 'src/app/shared/models/asset-models/asset-file.model';
import { AppsCreateRequest } from 'src/app/shared/models/requests-models/apps-create.model';
import { AppsUpdateRequest } from 'src/app/shared/models/requests-models/apps-update.model';

import { AssetFileV3 } from 'src/app/shared/models/asset-models/asset-file-v3.model';

import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { IntegrationsService } from 'src/app/shared/services/integrations.service';
import { AppsService } from 'src/app/shared/services/apps.service';

import { ChooseFileComponent } from 'src/app/shared/components/choose-file/choose-file.component';
import { GenericIntegrationComponent } from 'src/app/shared/components/new-integration/generic-integration/generic-integration.component';
import { FilestackComponent } from 'src/app/shared/components/filestack/filestack.component';
import { NewIntegrationComponent } from 'src/app/shared/components/new-integration/new-integration.component';

interface appFieldsDic<T> {
  [key:string]: T
}

@Component({
  selector: 'app-select-app',
  templateUrl: './select-app.component.html',
  styleUrls: ['./select-app.component.scss']
})
export class SelectAppComponent extends CleanOnDestroy implements OnInit {

  protected baseUrl = environment.endPoint;

  @ViewChild('slideDiv') slideDiv : ElementRef;

  currentWorkspace: Workspace;
  accountFeatures: AccountFeatures;

  requestEndpoint: string = '';
  appTypes: AppsTypes[];
  storedAppTypes: AppsTypes[];
  selectedAppType: AppsType;
  isSelectApp: boolean = true;

  appForm: FormGroup;
  separatorKeysCodes: number[] = [ENTER, TAB];
  addOnBlur = true;
  loader = false;
  loaderFor = '';
  fieldsDic: appFieldsDic<string | number | boolean | object | OAuthResourceOption[]> = {};
  inputFields: AppsInputfields[] = [];
  calendars: Calendar[] = [];
  connectionId: number = 0;
  workspaceConnections: OAuthConnection[];
  workspaceIntegrations: ClientToken[];

  searchControl = new FormControl();

  // Stored seleceted OauthResourceMultiSelect
  selectedOauthRMS: {
    id: string;
    name: string;
    isSelected?: boolean;
    fieldId?: string;
  }[] = [];

  selectWorkspace: string = '';
  allFields: string = '';
  selectedFolder: string = '';
  folderId: number = null;
  allowSelectApp: boolean = true;

  intervalMinutes: { name: string, value: number }[] = [
    { name: '1 Minute', value: 1 },
    { name: "3 Minutes", value: 3 },
    { name: '5 Minutes', value: 5 },
    { name: '10 Minutes', value: 10 },
    { name: '30 Minutes', value: 30 },
    { name: "1 Hour", value: 60 }
  ];

  matGridCols: number = 2;

  isAppTypesLoader: boolean = false;

  constructor(
    private appsSrv: AppsService,
    public utilSrv: UtilService,
    private storageSrv: StorageService,
    private sharedSrv: SharedService,
    private integrationsSrv: IntegrationsService,
    private fb: FormBuilder,
    private atpSrv: AmazingTimePickerService,
  	public dialogRef: MatDialogRef<SelectAppComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      isNew: string;
      app: Apps;
      parentFolderId?: number;
      appType?: AppsTypes;
      index?: number;
      allowSelectApp: boolean;
    }
  ) {
    super();
  }

  ngOnInit(): void {
    this.requestEndpoint = this.utilSrv.env.endPoint;

    this.generateAppForm();

    this.subscriber = this.storageSrv.accountFeaturesSubject.subscribe( accountFeatures => {
      if (accountFeatures) {
        this.accountFeatures = accountFeatures;
      }
    });
    
    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe(workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;
          this.getWorkspaceIntegrations();
          this.getWorkspaceConnections();
          this.getAppsType();
          if(this.data) {
            this.folderId = this.data.parentFolderId;
            this.allowSelectApp = this.data.allowSelectApp;
            if(!this.data.isNew) {
              this.isSelectApp = false;
              if(this.data.app) {
                //console.log('data', this.data.app);
                this.selectedAppType = this.data.app.type;
                this.generateEditAppFieldsDictionary();
              }
            } else {
              if(this.data.appType) {
                this.onSelectApp(this.data.appType);
              }
            }
          }
        }
      });

    this.onScreenSize();
  }

  //------------------------------------------------------------
  // Commons
  //------------------------------------------------------------

  onScreenSize() {
    if(window.innerWidth > 992) {
      this.matGridCols = 4;
    }
  }

  goBack() {
    this.isSelectApp = true;
    this.resetForm();
  }

  onSearchByWord(word: string) {
    let storedAppTypes = this.storedAppTypes;
    this.isAppTypesLoader = true;
    this.searchControl.valueChanges
      .pipe(
        debounceTime(1000)
      )
      .subscribe(data => {
        if (data) {
          word = data.toLowerCase();
          // let appTypes = this.appTypes;
          let appTypes = storedAppTypes;
          this.appTypes = appTypes.filter(app => {
            let appName = app.name.toLowerCase();
            let appDesc = app.description.toLowerCase();
            // return appName.indexOf(word) >= 0 || appDesc.indexOf(word) >= 0 || app.tags.indexOf(word) >= 0;
            return appName.indexOf(word) >= 0 || appDesc.indexOf(word) >= 0;
          });
          this.isAppTypesLoader = false;
        } else {
          this.appTypes = storedAppTypes;
          this.isAppTypesLoader = false;
        }
      });
  }

  generateAppForm() {
    this.appForm = this.fb.group({
      name: [null, [Validators.required, removeWhitespaceValidator]],
      refreshInterval: [],
      inputFields: this.fb.group({}),
      advancedInput: this.fb.group({})
    });
  }

  populateAppForm(){

    this.appForm.get('refreshInterval').patchValue(this.selectedAppType.refreshIntervalMinutes);
    //this.appForm.get('tags').patchValue(this.selectedAppType.tags);

    // Loop inputfields
    this.selectedAppType.inputFields.forEach(inputField => {
      if(inputField.key == 'text') {
        (this.appForm.get('inputFields') as FormGroup).setControl(
          inputField.id.toString(),
          this.fb.control(
            inputField.default != undefined ? inputField.default : null,
            inputField.required ? [Validators.required, removeWhitespaceValidator] : null
          )
        );
      } else {
        (this.appForm.get('inputFields') as FormGroup).setControl(
          inputField.id.toString(),
          this.fb.control(
            inputField.default != undefined ? inputField.default : null,
            inputField.required ? [Validators.required] : null
          )
        );
      }
      if(inputField.hasOwnProperty('disabled')) {
        if(inputField.disabled == true) {
          this.appForm.get(['inputFields', inputField.id]).disable();
        }
      }
    });

    // Loop advanced field
    this.selectedAppType.advancedInput.forEach(advInput => {
      if(advInput.key == 'text') {
        (this.appForm.get('advancedInput') as FormGroup).setControl(
          advInput.id.toString(),
          this.fb.control(
            advInput.default != undefined ? advInput.default : null,
            advInput.required ? [Validators.required, removeWhitespaceValidator] : null
          )
        );
      } else {
        (this.appForm.get('advancedInput') as FormGroup).setControl(
          advInput.id.toString(),
          this.fb.control(
            advInput.default != undefined ? advInput.default : null,
            advInput.required ? [Validators.required] : null
          )
        );
      }
    });
  }

  resetForm() {
    this.selectedAppType.inputFields.forEach(inputField => {
      (this.appForm.get('inputFields') as FormGroup).removeControl(inputField.id.toString());
    });
    this.selectedAppType.advancedInput.forEach(advInput => {
      (this.appForm.get('advancedInput') as FormGroup).removeControl(advInput.id.toString());
    });
    this.appForm.reset();
    this.appForm.get('name').patchValue(null);
    this.selectedAppType = null;
  }

  onShowAppImage(app: AppsType) {
    if(app) {
      return this.requestEndpoint + app.icon;
    }
  }

  onCopyToClipboard(element: HTMLInputElement) {
    const el = document.createElement('textarea');
    el.value = element.value;
    el.setAttribute('readonly', '');
    el.style.position = 'absolute';
    el.style.left = '-9999px';
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
  }

  onPreview() {
    let orgId = this.currentWorkspace.account.id;
    let workspaceId = this.currentWorkspace.id;
    let appId = this.data.app.id;
    window.open(
      `${this.baseUrl}/api/v3/orgs/${orgId}/workspaces/${workspaceId}/apps/${appId}/preview/`,
      'RocketScreens Preview',
      'width=1280,height=720'
    );
  }

  getWorkspaceIntegrations(){
    this.workspaceIntegrations = this.storageSrv.workspaceIntegrations;
    this.storageSrv.workspaceIntegrationsSubject.subscribe(message => {
      this.workspaceIntegrations = message;
    });
  }

  getWorkspaceConnections() {
    this.workspaceConnections = this.storageSrv.workspaceConnections;
    this.storageSrv.workspaceConnectionsSubject.subscribe(message => {
      this.workspaceConnections = message;
    });
  }

  getAppsType() {
    this.isAppTypesLoader = true;
    this.subscriber = this.appsSrv.getAppTypes(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    )
      .subscribe(appsType => {
        if (appsType) {
          appsType.sort( (itemA, itemB) => {
            const appNameA = itemA.name.toLowerCase();
            const appNameB = itemB.name.toLowerCase();
            if(appNameA < appNameB) {
              return -1;
            }
            if(appNameA > appNameB) {
              return 1;
            }
            return 0;
          });
          this.appTypes = appsType;
          this.storedAppTypes = appsType;
          this.isAppTypesLoader = false;
        }
      }, 
      err => {
        this.isAppTypesLoader = false;
      }
    );
  }

  //------------------------------------------------------------
  // Commons
  //------------------------------------------------------------

  onSelectApp(appType: AppsTypes) {
    this.isSelectApp = false;
    this.getAppsTypeFields(appType.id);
  }

  getAppsTypeFields(appTypeId: number) {
    this.subscriber = this.appsSrv.getAppTypeFields(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id,
      appTypeId
    ).subscribe(appType => {
      if (appType) {
        this.selectedAppType = appType;
        this.generateAppsFieldsDictionary();
        this.populateAppForm();
      }
    });
  }

  /* ---------- New App ---------- */
  generateAppsFieldsDictionary() {
    let currentWorkspaceId = this.storageSrv.selectedWorkspace.id;
    let inputFields:Array<any> = this.selectedAppType.inputFields;
    this.fieldsDic['workspaceId'] = currentWorkspaceId.toString();
    for(let i in inputFields) {
      let field = inputFields[i];
      if(field.hasOwnProperty('key')) {
        if(field.type == 'oauth-resource') {
          this.fieldsDic[field.key] = [];
        } else if(field.type == 'oauth-resource-search') {
          this.fieldsDic[field.key] = { id: '', name: '' };
        } else {
          this.fieldsDic[field.key] = '';
        }
      }
    }
  }

  /* ---------- End New App ---------- */

  /* ---------- Editing/Updating App ---------- */
  generateEditAppFieldsDictionary() {
    let app = this.data.app;
    let fieldValue: any;
    let currentWorkspaceId = this.storageSrv.selectedWorkspace.id;
    this.fieldsDic['workspaceId'] = currentWorkspaceId.toString();

    // Define Slide Form
    this.appForm.get('name').patchValue(app.name);
    this.appForm.get('refreshInterval').patchValue(app.refreshInterval);
    //this.appForm.get('tags').patchValue(app.tags);

    // Populate internal dictionary
    app.type.inputFields.forEach( field => {
      let property: AppsProperty = app.properties.find( prop => prop.propertyId == field.id);
      switch (field.type.toLowerCase()) {
        case 'date':
          let propertyValue:any = property.value;
          fieldValue = (property && property.value !== null) ? new Date(propertyValue) : field.default;
          break;
        case 'oauth-resource':
          this.fieldsDic[field.key] = field.hasOwnProperty('key') ? [] : null;
          this.sendApiReqInputFieldFromUrl(field);
          fieldValue = (property && property.value !== null) ? property.value : field.default;
          break;
        case 'oauth-resource-search':
          if(property != undefined) {
            if (typeof property.value === 'object'){
              let propertyValue:any = property.value;
              this.fieldsDic[field.key] = { id: '', name: '' };
              fieldValue = propertyValue.name;
              this.fieldsDic[field.key]['id'] = propertyValue.id;
              this.fieldsDic[field.key]['name'] = propertyValue.name;
            } else {
              fieldValue = property.value;
              this.fieldsDic[field.key] = field.hasOwnProperty('key') ? property.value : null;
            }
          }
          break;
        case 'oauth-resource-multiselect':
          fieldValue = [];
          this.fieldsDic[field.key] = field.hasOwnProperty('key') ? [] : null;
          this.sendApiReqInputFieldFromUrl(field);
          break;
        default:
          if(property) {
            if(property.value !== null && typeof property.value === 'object') {
              let propertyValue:any = property.value;
              fieldValue = propertyValue.id;
            } else {
              fieldValue = property.value;
            }
            this.fieldsDic[field.key] = field.hasOwnProperty('key') ? fieldValue : field.default;
          } else {
            fieldValue = field.default;
          }
          break;
      }

      let inputFields = this.appForm.get('inputFields') as FormGroup;
      if(field.key == 'text') {
        (inputFields).setControl(
          field.id.toString(),
          this.fb.control(fieldValue, field.required ? [Validators.required, removeWhitespaceValidator] : null)
        );
      } else {
        (inputFields).setControl(
          field.id.toString(),
          this.fb.control(fieldValue, field.required ? [Validators.required] : null)
        );
      }

      if(field.hasOwnProperty('disabled')) {
        if(field.disabled == true) {
          this.appForm.get(['inputFields', field.id]).disable();
        }
      }
    });

    // Advanced input
    let advFieldValue: any;
    app.type.advancedInput.forEach(advField => {
      let property: AppsProperty = app.properties.find( prop => prop.propertyId == advField.id);
      switch (advField.type.toLowerCase()) {
        case 'date':
          advFieldValue = (property && property.value !== null) ? new Date(property.value) : advField.default;
          break;
        default:
          if(property) {
            if(property.value !== null && typeof property.value === 'object') {
              let propertyValue:any = property.value;
              advFieldValue = propertyValue.id;
            } else {
              advFieldValue = property.value;
            }
          } else {
            advFieldValue = advField.default;
          }
          break;
      }
      if(advField.key == 'text') {
        (this.appForm.get('advancedInput') as FormGroup).setControl(
          advField.id.toString(),
          this.fb.control(advFieldValue, advField.required ? [Validators.required, removeWhitespaceValidator] : null)
        );
      } else {
        (this.appForm.get('advancedInput') as FormGroup).setControl(
          advField.id.toString(),
          this.fb.control(advFieldValue, advField.required ? [Validators.required] : null)
        );
      }
    });
  }

  sendApiReqInputFieldFromUrl(field: AppsInputfields) {
    let app: Apps = this.data.app;
    let property: AppsProperty = app.properties.find( prop => prop.propertyId == field.id);
    let apiUrl = this.parseInputFieldFromUrl(field);
    this.loader = true;
    this.loaderFor = field.key;

    if(property != undefined) {
      this.integrationsSrv.getFromUrlRequest(apiUrl).subscribe( res => {
        if(res) {

          // Format the response
          let fieldOptions = res.map( option => {
            let propertyId: string | number;
            let propertyValue: any = property.value;
            if(property.value != null && typeof property.value === 'object') {
              propertyId = propertyValue.id;
            } else {
              propertyId = property.value;
            }
            if(propertyId == option.id) {
              if(field.type != 'oauth-resource-multiselect') {
                this.appForm.get(['inputFields', field.id]).setValue(option.id);
              }
              return { id: option.id, name: option.name, isSelected: true, fieldId: field.id }
            } else {
              return { id: option.id, name: option.name, isSelected: false, fieldId: field.id }
            }
          });

          this.fieldsDic[field.key] = fieldOptions;

          if(field.key == 'calendars') {
            this.calendars = res;
            this.extractSelectedCalendars(field);
          }

          if(field.type == 'oauth-resource-multiselect') {
            this.setOrmValue(field);
          }

          this.loader = false;
          this.loaderFor = '';
        }
      },
      err => {
        this.loader = false;
        this.loaderFor = '';
      });
    }
  }

  parseInputFieldFromUrl(field: AppsInputfields) {
    let url = field['from'];
    let app: Apps = this.data.app;
    //let pattern = /(?<=\{).+?(?=\})/g; // Not working in safari
    let pattern = /(?:(?!\{))([a-zA-Z0-9_-]+?)(?=\})/g;
    let strLiteralsArray = url.match(pattern);
    let paramsObj = {};
    let inputFields = this.selectedAppType.inputFields;
    let property: any;

    for(let i in strLiteralsArray) {
      let str = strLiteralsArray[i];
      let filteredField: AppsInputfields[] = inputFields.filter( f => f.key == str);
      property = app.properties.find( prop => prop.propertyId == filteredField[0].id);
      if(property != undefined) {
        if (typeof property.value === 'object'){
          paramsObj[str] = property.value.id;
        } else {
          paramsObj[str] = property.value;
        }
      }
    }

    let tpl = url.replace(/\${(?!this\.)/g, "${this.");
    let tplFunc = new Function(`return \`${tpl}\``);
    return tplFunc.call(paramsObj);
  }

  setOrmValue(field: AppsInputfields) {
    let app: Apps = this.data.app;
    let property: any = app.properties.find( prop => prop.propertyId == field.id);
    let orMultiselect: any = [];
    let internalDict: any = this.fieldsDic[field.key];
    let newOrmSelect: any[] = [];

    if(typeof property.value === 'object') {
      let propertyValue = property.value;
      orMultiselect = (property != undefined) ? propertyValue.id.split(',') : null;
    } else {
      orMultiselect = (property != undefined) ? property.value.split(',') : null;
    }

    // newOrmSelect = orMultiselect.map( orm => parseInt(orm) );
    newOrmSelect = orMultiselect.map( orm => {
      return isNaN(orm) ? orm : parseInt(orm);
    });

    orMultiselect.forEach(id => {
      for(let i in internalDict) {
        if(internalDict[i]['id'] == id) {
          internalDict[i]['isSelected'] = true;
          let findORMS = this.selectedOauthRMS.find( orms => orms.id == internalDict[i]['id'] && orms.fieldId == field.id.toString());
          if(!findORMS) {
            internalDict[i]['fieldId'] = field.id;
            this.selectedOauthRMS.push(internalDict[i]);
          }
          this.toggleSelectOauthRM(id, true, field.key);
        }
      }
    });
    this.appForm.get(['inputFields', field.id]).setValue(newOrmSelect);
    this.fieldsDic[field.key] = internalDict;
  }
  /* ---------- End Editing/Updating App ---------- */

  /* ---------- Generic field selection ---------- */
  onAddNewTag(event: MatChipInputEvent) {
    const input = event.input;
    const tagName = event.value;
    if ((tagName || '').trim()) {
      let tags = this.appForm.get('tags').value;
      tags.push(tagName)
      this.appForm.get('tags').patchValue(tags);
    }
    // Reset the input value
    if (input) {
      input.value = '';
    }
  }

  onRemoveTag(tagName: string) {
    let tags: string[] = this.appForm.get('tags').value;
    let tagIndex = tags.indexOf(tagName);
    if (tagIndex >= 0) {
      tags.splice(tagIndex, 1);
      this.appForm.get('tags').patchValue(tags);
    }
  }

  /**
   * open dialog with files and folders
   * for select file with allowed extension types
   * @param inputName is a form control name
   * @param inputIndex is a posotion from inputfields
   * @return `string`
   */
  onSelectAsset(field: AppsInputfields) {
    let affectedField = ['inputFields', field.id];
    if (this.storageSrv.selectedWorkspace
      && this.storageSrv.selectedWorkspace.id >= 0) {
      this.sharedSrv.openDialog<AssetFileV3>(
        {
          allowedFileTypes: field.fileTypes,
          selectedFile: this.appForm.get(affectedField).value
        },
        true,
        {
          width: '90%',
          height: 'calc(100vh - 120px)'
        },
        ChooseFileComponent
      ).subscribe(response => {
        if (response.continue) {
          let data = response.outputData;
          this.appForm.get(affectedField).patchValue(data.name);
          this.fieldsDic[field.key] = data.name;
        }
      })
    } else {
      this.sharedSrv.errorDialog(this.selectWorkspace);
    }
  }

  onSelectAssetAdv(field: AppsInputfields) {
    let affectedField = ['advancedInput', field.id];
    if (this.storageSrv.selectedWorkspace
      && this.storageSrv.selectedWorkspace.id >= 0) {
      this.sharedSrv.openDialog<AssetFileV3>(
        {
          allowedFileTypes: field.fileTypes,
          selectedFile: this.appForm.get(affectedField).value
        },
        true,
        {
          width: '90%',
          height: 'calc(100vh - 120px)'
        },
        ChooseFileComponent
      ).subscribe(response => {
        if (response.continue) {
          let data = response.outputData;
          this.appForm.get(affectedField).patchValue(data.name);
        }
      })
    } else {
      this.sharedSrv.errorDialog(this.selectWorkspace);
    }
  }

  onChangeDatePicker($event: string, field: AppsInputfields) {
    this.fieldsDic[field.key] = $event;
  }

  onTextareaChange($event: string, field: AppsInputfields) {
    this.fieldsDic[field.key] = $event;
  }

  onChangeColor($event: string, field: AppsInputfields) {
    this.fieldsDic[field.key] = $event;
    this.appForm.get(['inputFields', field.id]).patchValue($event);
  }

  onToggleCheckboxField(event, field: AppsInputfields) {
    if(this.fieldsDic.hasOwnProperty(field.key)) {
      this.fieldsDic[field.key] = event;
    }
  }

  onSelectField(event, field: AppsInputfields) {
    this.fieldsDic[field.key] = event.value;
  }

  onSelectClientTokenField(event, field: AppsInputfields) {
    this.fieldsDic[field.key] = event;
    // Search current field if it has a "for" key
    if(field.hasOwnProperty('for')) {
      let foundField = this.searchFieldType(field['for']);
      if(foundField) {
        this.oauthFromUrlRequest(foundField);
      }
    }
  }

  getFieldsDictionaryByKey(key:string) {
    if(this.fieldsDic.hasOwnProperty(key)) {
      return this.fieldsDic[key];
    }
  }

  /* ---------- End Generic field selection ---------- */

  /* ---------- Oauth field ---------- */
  getOAuthConnectionsByType(type: string){
    return this.workspaceConnections.filter((element, index, array) => {
      if (element.type === type){
        return true;
      } else {
        return false;
      }
    });
  }

  onSelectOauth(event, field: AppsInputfields) {
    this.fieldsDic[field.key] = event;
    this.connectionId = event;
    // Search current field if it has a "for" key
    if(field.hasOwnProperty('for')) {
      let foundField = this.searchFieldType(field['for']);
      if(foundField) {
        this.oauthFromUrlRequest(foundField);
      }
    }
  }

  onOpenIntegration(key: String) {
    this.subscriber = this.sharedSrv.openDialog(
      { defaultIntegrationKey: key},
      true,
      null,
      NewIntegrationComponent
    ).subscribe(response => {
      if (response.outputData) {
        // Do nothing
      }
    });
  }

  oauthFromUrlRequest(field: AppsInputfields) {
    let apiUrl = this.parseFromUrl(field['from']);
    this.loader = true;
    this.loaderFor = field.key;
    this.integrationsSrv.getFromUrlRequest(apiUrl).subscribe( res => {
      if(res) {
        if(field.key == 'calendars') {
          this.calendars = res;
          this.extractSelectedCalendars(field);
        }
        this.formatOauthResourceOptions(field['key'], res);
        this.loader = false;
        this.loaderFor = '';
      }
    },
    err => {
      this.loader = false;
      this.loaderFor = '';
    });
  }

  /* ---------- Oauth resource field ---------- */
  getOauthResourcesByType(key:string) {
    if(this.fieldsDic.hasOwnProperty(key)) {
      if(this.fieldsDic[key] == '') {
        return [];
      } else {
        return this.fieldsDic[key];
      }
    } else {
      return [];
    }
  }

  onSelectOauthResource(event, selectedField: AppsInputfields) {
    let dictionaryKey = selectedField['key'];
    if(this.fieldsDic.hasOwnProperty(dictionaryKey)) {

      this.toggleSelectOauthResourceOption(event, dictionaryKey);

      // Check if this field has a for key.
      if(selectedField.hasOwnProperty('for')) {
        let foundField = this.searchFieldType(selectedField['for']);
        if(foundField && foundField.type !== 'oauth-resource-search') {
          this.oauthResourceFromUrlRequest(foundField);
        }
      }
    }
  }

  oauthResourceFromUrlRequest(field: AppsInputfields) {
    let apiUrl = this.parseFromUrl(field['from']);
    this.loader = true;
    this.loaderFor = field.key;
    this.integrationsSrv.getFromUrlRequest(apiUrl)
      .subscribe( res => {
        if(res) {
          if(field.type == 'oauth-resource-multiselect') {
            this.formatORMSOptions(field, res);
          } else {
            this.formatOauthResourceOptions(field['key'], res);
          }
          this.loader = false;
          this.loaderFor = '';
        }
      });
  }

  /**
   * Toggle Select Oauth Resource options.
   * @param dictionary key: value;
   * @return `null`
   */
  toggleSelectOauthResourceOption(event, dictionaryKey: string) {
    let fieldOptions:any = this.fieldsDic[dictionaryKey];
    for(let i in fieldOptions) {
      if(fieldOptions[i]['id'] == event) {
        fieldOptions[i]['isSelected'] = true;
      } else {
        fieldOptions[i]['isSelected'] = false;
      }
    }
    this.fieldsDic[dictionaryKey] = fieldOptions;
  }
  /* ---------- End Oauth resource field ---------- */

  /* ---------- Oauth resource multi field ---------- */
  onSelectOauthRMS(event, inputField: AppsInputfields) {
    let fieldOptArr:any = this.fieldsDic[inputField.key];
    if (event.value) {
      event.value.forEach((id: string) => {
        fieldOptArr.every(opt => {
          if (opt.id === id) {
            opt['fieldId'] = inputField.id;
            opt['isSelected'] = true;
            let findORMS = this.selectedOauthRMS.find( orms => orms.id == opt.id.toString() && orms.fieldId == inputField.id.toString());
            if(!findORMS) {
              this.selectedOauthRMS.push(opt);
            }
            //this.toggleSelectOauthRM(id, true, inputField.key);
            return false;
          }
          return true;
        })
      });

      // Check if this field has a for key.
      if(inputField.hasOwnProperty('for')) {
        let foundField = this.searchFieldType(inputField['for']);
        if(foundField) {
          this.oauthResourceFromUrlRequest(foundField);
        }
      }
    }
  }

  onRemoveOauthRMS(
    event,
    inputField: AppsInputfields,
    select: MatSelect
  ) {

    let updatedOauthRMS = [];
    let selectedOauthRMS:any = this.selectedOauthRMS;
    let ormIndex = selectedOauthRMS.findIndex( orm => orm.id == event.id);
    if(ormIndex != -1) {
      this.selectedOauthRMS.splice(ormIndex, 1);
    }
    this.selectedOauthRMS.forEach(item => {
      updatedOauthRMS.push(item.id);
    });
    this.toggleSelectOauthRM(event.id, false, inputField.key);
    select.writeValue(updatedOauthRMS);
    this.appForm.get(['inputFields', inputField.id]).setValue(updatedOauthRMS);
  }

  toggleSelectOauthRM(id, value, dictionaryKey: string) {
    let fieldOptions:any = this.fieldsDic[dictionaryKey];
    for(let i in fieldOptions) {
      if(fieldOptions[i]['id'] == id) {
        fieldOptions[i]['isSelected'] = value;
      }
    }
    this.fieldsDic[dictionaryKey] = fieldOptions;
  }

  getSelectedOauthRMS(field) {
    let selectedORMS:any = this.selectedOauthRMS;
    let filteredORMS = selectedORMS.filter( orms => orms.fieldId == field.id);
    return filteredORMS;
  }

  extractSelectedCalendars(field) {
    let fieldValue = this.appForm.get(['inputFields', field.id]).value;
    this.selectedOauthRMS = [];
    for(let i in fieldValue) {
      this.calendars.forEach( cal => {
        if(fieldValue[i].toString() === cal.id) {
          this.selectedOauthRMS.push(cal);
        }
      });
    }
  }

  /* ---------- Oauth Resource Search ---------- */
  onSearchFolderFilestack(field) {
    let drives:any = [];
    let selectedDrive = '';
    let apiUrl = this.parseFromUrl(field.from);
    this.sharedSrv.openDialog<OAuthResourceOption>(
      {
        fromUrl: apiUrl,
        fieldKey: field.key
      },
      true,
      {
        width: '90%',
        height: 'calc(100vh - 120px)'
      },
      FilestackComponent
    ).subscribe(response => {
      if (response.continue) {
        this.appForm.get(['inputFields', field.id]).patchValue(response.outputData.name);
        this.fieldsDic[field.key] = { id: response.outputData.id, name: response.outputData.name }
        // Check if this field has a for key.
        if(field.hasOwnProperty('for')) {
          let foundField = this.searchFieldType(field['for']);
          if(foundField) {
            this.oauthResourceFromUrlRequest(foundField);
          }
        }
      }
    });
  }
  /* ---------- End Oauth Resource Search ---------- */

  /* ---------- Oauth & Oauth Resource Helpers ---------- */
  parseFromUrl(url) {
    //let pattern = /(?<=\{).+?(?=\})/g; // Not working in safari
    let pattern = /(?:(?!\{))([a-zA-Z0-9_-]+?)(?=\})/g;
    let strLiteralsArray = url.match(pattern);
    let paramsObj = {};
    for(let i in strLiteralsArray) {
      let str = strLiteralsArray[i];
      if(this.fieldsDic.hasOwnProperty(str)) {
        if(Array.isArray(this.fieldsDic[str])){
          paramsObj[str] = this.getSelectedOauthResource(str);
        } else if(typeof this.fieldsDic[str] === 'object') {
          paramsObj[str] = this.fieldsDic[str]['id'];
        } else {
          paramsObj[str] = this.fieldsDic[str];
        }
      }
    }

    let tpl = url.replace(/\${(?!this\.)/g, "${this.");
    let tplFunc = new Function(`return \`${tpl}\``);
    return tplFunc.call(paramsObj);
  }

  getSelectedOauthResource(key:string) {
    let dictionary:any = this.fieldsDic[key];
    for(let i in dictionary) {
      let field = dictionary[i];
      if(field['isSelected'] == true) {
        return field['id'];
        break;
      }
    }
  }

  formatOauthResourceOptions(fieldKey: string, options:OAuthResourceOption[]) {
    let fieldOptions = options.map( option => {
      return { id: option.id, name: option.name, isSelected: false };
    });
    this.fieldsDic[fieldKey] = fieldOptions;
  }

  formatORMSOptions(field: AppsInputfields, options:OAuthResourceOption[]) {
    let fieldOptions = options.map( option => {
      return { id: option.id, name: option.name, isSelected: false, fieldId: field.id };
    });
    this.fieldsDic[field.key] = fieldOptions;
  }

  searchFieldType(forValue) {
    //let inputFields = this.inputFields;
    let inputFields = this.selectedAppType.inputFields;
    for(let i in inputFields) {
      let field = inputFields[i];
      if(field.key == forValue) {
        return field;
        break;
      }
    }
  }
  /* ---------- End Oauth & Oauth Resource Helpers ---------- */

  /* ---------- Client token methods ---------- */
  getIntegrationsByType(type: string){
    return this.workspaceIntegrations.filter((element, index, array) => {
      if (element.type === type){
        return true;
      } else {
        return false;
      }
    });
  }
  /* ---------- End Client token methods ---------- */

  /* ---------- Canva methods ---------- */

  openCanva(){
    if (this.data.isNew){
      this.newCanvaDesign();
    } else {
      let objValue = this.data.app.properties[0].value;
      this.editCanvaDesign(objValue);
    }
  }

  editCanvaDesign(designId){
    var appForm = this.appForm;
    var component = this;
    window["canvaApi"].editDesign({
      designId: designId,
      publishLabel: "Publish to RocketScreens",
      fileType: "png",
      onDesignPublish: function(response){
        // patch into form
        appForm.get(['inputFields', 1]).patchValue(response.designId);
        appForm.get(['inputFields', 2]).patchValue(response.exportUrl);
        appForm.updateValueAndValidity();
        component.slideDiv.nativeElement.click();
      }
    });
  }

  newCanvaDesign(){
    var appForm = this.appForm;
    var component = this;

    // get selected format
    var slideFormatId = appForm.get(['inputFields', 3]).value;
    var slideFormat = "Presentation";
    if (slideFormatId == 2){
      slideFormat = "Poster";
    }

    window["canvaApi"].createDesign({
      type: slideFormat,
      publishLabel: "Publish to RocketScreens",
      fileType: "png",
      onDesignPublish: function(response){
        // patch into form
        appForm.get(['inputFields', 1]).patchValue(response.designId);
        appForm.get(['inputFields', 2]).patchValue(response.exportUrl);
        appForm.updateValueAndValidity();
        component.slideDiv.nativeElement.click();
      }
    });
  }
  /* ---------- End Canva methods ---------- */

  /* ---------- Calendar methods ---------- */

  createCalendars(input: AppsInputfields) {
    let isValid: boolean = false;
    let calendars: string = '';
    let selectedCalendars = this.appForm.get(['inputFields', +input.id]).value;
    if (input.required && selectedCalendars.length > 0) {
      isValid = true;
      calendars = selectedCalendars.join(',');
    }
    return { isValid: isValid, calendars: calendars };
  }

  createCalendarsAdv(input: AppsInputfields) {
    let isValid: boolean = false;
    let calendars: string = '';
    let selectedCalendars = this.appForm.get(['advancedInput', +input.id]).value;
    if (input.required && selectedCalendars.length > 0) {
      isValid = true;
      calendars = selectedCalendars.join(',');
    }
    return { isValid: isValid, calendars: calendars };
  }

  /**
   * open amazing time picker progromatically
   * @param controlName is form control name
   * @return `string`
   */
  onOpenTimePicker(controlName: number) {
    const amazingTimePicker = this.atpSrv.open({
      time: this.transformToTimeString(controlName),
      arrowStyle: {
        background: '#e5286a',
        color: 'white'
      }
    });
    let subscriber = amazingTimePicker.afterClose().subscribe(time => {
      this.appForm.get(['inputFields', controlName]).patchValue(this.transformToSeconds(time));
      //let twelveHourTime = this.formatTime(this.transformToSeconds(time));
      //this.appForm.get(['inputFields', controlName]).patchValue(twelveHourTime);
      subscriber.unsubscribe();
    });
  }

  transformToTimeString(controlName: number){
    let transformedTime: string = '';
    let time = this.appForm.get(['inputFields', controlName]).value;
    if (time) {
      var numHours = Math.floor(time / (60*60));
      var numMinutes = Math.floor(Math.floor(time % (60*60)) / 60);
      transformedTime = this.addZero(numHours) + ":" + this.addZero(numMinutes) + ":00 ";
    }
    return transformedTime;
  }

  transformToSeconds(time){
    var times = time.split(":");
    var hours = times[0];
    var minutes = times[1];
    var result = (hours * 60 * 60) + (minutes * 60)
    return result;
  }

  /**
   * add 0 in case of number less than 10
   * @param number which should be transformed
   * @return  `string`
   */
  addZero(number: number): string {
    let returnString = '';
    if (number < 10) {
      returnString = '0' + number.toString();
    } else {
      returnString = number.toString();
    }
    return returnString;
  }

  formatTime(rawTime: number) {
    let transformedTime = '';
    let time = +rawTime;
    if (time) {
      var numHours = Math.floor(time / (60*60));
      var numMinutes = Math.floor(Math.floor(time % (60*60)) / 60);
      var ampm = "AM";
      if (numHours >= 12){
        ampm = "PM";
        if (numHours == 24){
          numHours = 12;
        } else if (numHours > 12){
          numHours = numHours % 12;
        }
      } else if (numHours == 0){
        numHours = 12;
      }
      transformedTime = this.addZeroToTime(numHours) + ":" + this.addZeroToTime(numMinutes) + " " + ampm;
    }
    return transformedTime;
  }

  addZeroToTime(number: number) {
    return number > 9 ? number + '' : '0' + number;
  }

  /* ---------- End Calendar methods ---------- */

  /**
   * depends input type transform value of `input.id` control
   * @param null
   * @return `{ [key: number]: { propertyValue: string } }`
   */
  createProperties() {
    //let propValues: { id: number; value: string; }[] = [];
    let propValues: { id: number; value: any; }[] = [];
    let isValid: boolean = true;
    let returnedValue: any = {};

    this.selectedAppType.inputFields.forEach(input => {
      // store the transformed value into property
      let propertyValue: string | number = '';
      let orObj = this.fieldsDic[input.key];
      // transform value depends on input type
      switch (input.type.toLowerCase()) {
        case 'date':
          let date = this.appForm.get(['inputFields',+input.id]).value;
          var fullDate = new Date(date);
          var year = fullDate.getFullYear()+"";
          var month = (fullDate.getMonth()+1)+"";
          if (month.length == 1){
            month = "0"+month;
          }
          var day = fullDate.getDate()+"";
          if (day.length == 1){
            day = "0"+day;
          }
          propertyValue = month+"/"+day+"/"+year;
          break;
        case 'time':
          // transformed to seconds
          propertyValue = this.appForm.get(['inputFields',+input.id]).value;
          break;
        case 'oauth':
          propertyValue = this.appForm.get(['inputFields',+input.id]).value;
          break;
        case 'oauth-resource':
          // let orsField:any = this.fieldsDic[input.key];
          // let orObj = orsField.find( orField => orField.isSelected == true);
          // if(orObj != undefined) {
          //   propertyValue = JSON.stringify( { id: orObj.id, name: orObj.name } );
          // } else {
          //   propertyValue = JSON.stringify( { id: '', name: '' } );
          // }
          propertyValue = this.appForm.get(['inputFields',+input.id]).value;
          break;
        case 'oauth-resource-search':
          //let orsName = this.appForm.get(['inputFields',+input.id]).value;
          //let orsObj = { id: input.id, name: orsName }
          let orsObj = this.fieldsDic[input.key];
          propertyValue = JSON.stringify(orsObj);
          break;
        case 'oauth-multiselect':
          returnedValue = this.createCalendars(input);
          isValid = returnedValue.isValid;
          propertyValue = returnedValue.calendars;
          break;
        case 'oauth-resource-multiselect':
          returnedValue = this.createCalendars(input);
          isValid = returnedValue.isValid;
          propertyValue = returnedValue.calendars;
          break;
        default:
          propertyValue = this.appForm.get(['inputFields',+input.id]).value;
          break;
      }
      if(propertyValue === null) {
        propValues.push({ id: input.id, value: null });
      } else {
        // propValues.push({ id: input.id, value: propertyValue.toString() });
        propValues.push({ id: input.id, value: propertyValue });
      }
    });

    this.selectedAppType.advancedInput.forEach(input => {
      // store the transformed value into property
      let propertyValue: string | number = '';
      // transform value depends on input type
      switch (input.type.toLowerCase()) {
        case 'date':
          let dateString = this.appForm.get(['advancedInput',+input.id]).value;
          var fullDate = new Date(dateString);
          var year = fullDate.getFullYear()+"";
          var month = (fullDate.getMonth()+1)+"";
          if (month.length == 1){
            month = "0"+month;
          }
          var day = fullDate.getDate()+"";
          if (day.length == 1){
            day = "0"+day;
          }
          propertyValue = month+"/"+day+"/"+year;
          break;
        case 'time':
          // transformed to seconds
          propertyValue = this.appForm.get(['advancedInput',+input.id]).value;
          break;
        case 'oauth':
          propertyValue = this.appForm.get(['advancedInput',+input.id]).value;
          break;
        case 'oauth-multiselect':
          let returnedValue = this.createCalendarsAdv(input);
          isValid = returnedValue.isValid;
          propertyValue = returnedValue.calendars;
          break;
        default:
          propertyValue = this.appForm.get(['advancedInput',+input.id]).value;
          break;
      }
      if(propertyValue === null) {
        propValues.push({ id: input.id, value: null });
      } else {
        propValues.push({ id: input.id, value: propertyValue.toString() });
      }

    });

    return { properties: propValues, isValid: isValid };
  }

  onSave() {
    if (this.appForm.valid) {
      let formData = this.appForm.getRawValue();
      let returnedValue = this.createProperties();
      if (returnedValue.isValid) {
        if(this.data.isNew) {
          // let appCreateInfo:AppsCreateRequest = {
          //   name: formData.name,
          //   typeId: this.selectedAppType.id,
          //   folderId: this.folderId,
          //   workspaceId: this.currentWorkspace.id,
          //   tags: formData.tags,
          //   properties: returnedValue.properties
          // };

          let appCreateInfo:AppsCreateRequest = {
            name: formData.name,
            refreshInterval: formData.refreshInterval,
            typeId: this.selectedAppType.id,
            folderId: this.folderId,
            workspaceId: this.currentWorkspace.id,
            properties: returnedValue.properties
          };

          this.subscriber = this.appsSrv.createApp(
            this.currentWorkspace.account.id,
            this.currentWorkspace.id,
            appCreateInfo
          )
            .subscribe( app => {
              if(app) {
                this.storageSrv.apps.push(app);
                this.dialogRef.close({ continue: true, outputData: app });
              }
            },
              error => {
                //this.sharedSrv.errorDialog(error.error.message);
              }
            );
        } else {

          let appUpdateInfo:AppsUpdateRequest = {
            name: formData.name,
            refreshInterval: formData.refreshInterval,
            folderId: this.folderId,
            properties: returnedValue.properties
          };

          this.subscriber = this.appsSrv.updateAppInAWorkspace(
            this.currentWorkspace.account.id,
            this.currentWorkspace.id,
            appUpdateInfo,
            this.data.app.id
          )
            .subscribe( updatedApp => {
              if(updatedApp) {
                this.storageSrv.apps[this.data.index] = updatedApp;
                this.dialogRef.close({ continue: true, outputData: updatedApp });
              }
            });
        }
      }
    }
  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

}
