import { Component, OnInit, Inject, ElementRef } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { ENTER, TAB } from '@angular/cdk/keycodes';
import { Resource } from 'src/app/shared/enums/resource.enum';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';

// Models
import { DialogOutputData } from 'src/app/shared/models/common-models/dialog-output-data.model';
import { SlideUpdateRequestV3 } from 'src/app/shared/models/requests-models/slide-update-v3.model';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';
import { Slide } from 'src/app/shared/models/slide-models/slide.model';
import { Apps } from 'src/app/shared/models/apps-models/apps.model';

// Services
import { UtilService } from 'src/app/shared/services/util.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { SlidesService } from 'src/app/shared/services/slides.service';

import { SelectAppComponent } from 'src/app/shared/components/select-app/select-app.component';

@Component({
  selector: 'slide-slide-edit',
  templateUrl: './slide-edit.component.html',
  styleUrls: ['./slide-edit.component.scss']
})
export class SlideEditComponent extends CleanOnDestroy implements OnInit {

  slideForm: FormGroup;
  slide: Slide;
  currentWorkspace: Workspace;
  selectedApp: Apps;
  playlistId: number;
  requestEndpoint: string;
  testSeconds: number = 16220;

  protected baseUrl = environment.endPoint;

  constructor(
    private translate: TranslateService,
    public dialogRef: MatDialogRef<SlideEditComponent>,
    private fb: FormBuilder,
    public utilSrv: UtilService,
    private sharedSrv: SharedService,
    private storageSrv: StorageService,
    private slidesSrv: SlidesService,
    @Inject(MAT_DIALOG_DATA) public data: {
      slide?: Slide,
      currentPlaylistId: number
    },
  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.requestEndpoint = this.utilSrv.env.endPoint;
    this.tsTranslator();

    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe(workspace => {
        if (workspace) {
          this.currentWorkspace = workspace;
          if(this.data) {
            this.slide = this.data.slide;
            this.selectedApp = this.data.slide.app;
            this.playlistId = this.data.currentPlaylistId;
            this.generateAppForm();
            //this.slideForm.get('name').patchValue(this.slide.app?.name);
            //this.slideForm.get('name').disable();
            //this.slideForm.get('durationInSeconds').patchValue(this.slide.durationInSeconds);
            let durationInSeconds: string = this.transformSecTo24hrFormat(this.slide.durationInSeconds);
            this.slideForm.get('durationInSeconds').patchValue(durationInSeconds);
          }
        }
      });
  }

  tsTranslator() {

  }

  onEditApp() {
    this.subscriber = this.sharedSrv.openDialog(
      {
        isNew: false,
        app: this.selectedApp,
        allowSelectApp: false
      },
      true,
      { width: '50%' },
      SelectAppComponent
    )
    .subscribe(response => {
      // Do nothing
    });
  }

  generateAppForm() {
    this.slideForm = this.fb.group({
      durationInSeconds: ['']
    });
  }

  transformSecTo24hrFormat(sec: number) {
    let hours = (sec < 3600) ? 0 : Math.floor(sec / 3600);
    let minutes = (sec < 60) ? 0 : Math.floor((sec - (hours * 3600)) / 60);
    let seconds = Math.floor(sec - ((hours * 3600) + (minutes * 60)));
    return this.addZero(hours)+':'+this.addZero(minutes)+':'+this.addZero(seconds);
  }

  addZero(number: number) {
    return number > 9 ? number + '' : '0' + number;
  }

  timeStrToSeconds(time: string) {
    let timeArr: string[] = time.split(':');
    let hr = Number(timeArr[0]) * 3600;
    let min = Number(timeArr[1]) * 60;
    let sec = Number(timeArr[2]);
    //console.log(time, timeArr, hr, min, sec);
    return (hr+min+sec);
  }

  /**
   * create and return slideType image
   * @param null
   * @return `string`
   */
  onShowSlideImage(slide: Slide) {
    let slideImageUrl: string = '';
    let endpoint = `${this.utilSrv.env.endPoint}/api/v3/orgs/${this.currentWorkspace.account.id}/workspaces/${this.currentWorkspace.id}/apps/`;
    slideImageUrl = endpoint + slide.app.id + '/thumbnail/';
    slideImageUrl += "?t="+(slide.modifiedTimestamp);
    return slideImageUrl;
  }


  /**
   * close dialog with slide creation info
   * @param null
   * @return `null`
   */
  onSave() {
    if (this.slideForm.valid) {
      let formData = this.slideForm.getRawValue();
      let slideInfo: SlideUpdateRequestV3 = {
        durationInSeconds: this.timeStrToSeconds(formData.durationInSeconds)
      };
      this.slidesSrv.updateSlide(
        this.currentWorkspace.account.id,
        this.currentWorkspace.id,
        this.playlistId,
        this.slide.id,
        slideInfo
      )
        .subscribe(updatedSlide => {
          if(updatedSlide) {
            let slide: Slide = updatedSlide;
            this.dialogRef.close({ continue: true, outputData: slide });
          }
        });
    }
  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`F
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

}
