import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { SlideErrorsComponent } from './slide-errors.component';

describe('SlideErrorsComponent', () => {
  let component: SlideErrorsComponent;
  let fixture: ComponentFixture<SlideErrorsComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ SlideErrorsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SlideErrorsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
