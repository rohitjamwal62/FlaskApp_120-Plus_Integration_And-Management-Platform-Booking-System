import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SlideError } from 'src/app/shared/models/slide-models/slide-error.model';
import { SlidesService } from 'src/app/shared/services/slides.service';
import { UtilService } from 'src/app/shared/services/util.service';
import { AppsService } from 'src/app/shared/services/apps.service';

import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-slide-errors',
  templateUrl: './slide-errors.component.html',
  styleUrls: ['./slide-errors.component.scss']
})
export class SlideErrorsComponent implements OnInit {

	slideId: number;
	slideErrors: SlideError[] = [];

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
  	public slidesSrv: SlidesService,
    private appsSrv: AppsService,
  	public dialogRef: MatDialogRef<SlideErrorsComponent>,
  	@Inject(MAT_DIALOG_DATA) public data: any
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
  	this.slideId = this.data.slide.id;
  	this.slideErrors = this.data.slide.errors;
  }

  deleteSlideError(
    slideId: number, 
    errorId: number,
    errorIndex: number
  ) {
  	// this.slidesSrv.deleteSlideErrorByErrorId(slideId, errorId).subscribe(isDeleted => {
   //    if (isDeleted) {
   //      this.slideErrors.splice(errorIndex, 1);
   //    }
   //  });
    this.appsSrv.deleteAppError(
      this.data.currentWorkspace.account.id,
      this.data.currentWorkspace.id,
      slideId, 
      errorId
    )
      .subscribe(isDeleted => {
      if (isDeleted) {
        this.slideErrors.splice(errorIndex, 1);
      }
    });
  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

}
