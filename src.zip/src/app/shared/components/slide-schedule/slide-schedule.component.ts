import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormGroup, FormBuilder, ValidatorFn, ValidationErrors, AbstractControl, FormsModule } from '@angular/forms';
import * as moment from 'moment';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { SlideUpdateRequest } from '../../models/requests-models/slide-update.model';
import { SlideUpdateRequestV3 } from 'src/app/shared/models/requests-models/slide-update-v3.model';
import { Slide } from '../../models/slide-models/slide.model';
import { SlideSchedule } from '../../models/slide-models/slide-schedule.model';
import { AmazingTimePickerService } from 'amazing-time-picker';
import { UtilService } from 'src/app/shared/services/util.service';

import { TranslateService } from '@ngx-translate/core';

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-slide-schedule',
  templateUrl: './slide-schedule.component.html',
  styleUrls: ['./slide-schedule.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ]
})


export class SlideScheduleComponent implements OnInit {

  states = [{"id":1, "stateName":"Show"}, {"id":2, "stateName":"Hide"}]
  slide: Slide;
  slideSchedules = [];

  errorMessage: string = "";

  slideScheduleForm: FormGroup;

  currentLocale: any = '';
  timesOutOrder: string = '';

  constructor(
    public utilSrv: UtilService,
    private translate: TranslateService,
    public dialogRef: MatDialogRef<SlideScheduleComponent>,
    private fb: FormBuilder,
    private atpSrv: AmazingTimePickerService,
    @Inject(MAT_DIALOG_DATA) public data: {
      slide?: Slide,
    },
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {

    this.currentLocale = this.utilSrv.locale;

    this.translate.get('SLIDESCHEDULE.TIMESOUTORDER').subscribe((string) => {
      this.timesOutOrder = string;
    });

    this.slide = this.data.slide;

    // reorganize into the correct format
    for (var i = 0; i < this.slide.schedules.length; i++){
      var state = this.slide.schedules[i].state.id;
      var date = new Date(0);
      date.setUTCMilliseconds(this.slide.schedules[i].stateTimestamp);
      var seconds = date.getUTCHours()*60*60;
      seconds += date.getUTCMinutes()*60;
      var item = {"state":state, "date":date, "time":seconds}
      this.slideSchedules.push(item);
    }
  }


  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * helper for ng for optimization
   * @param index of item
   * @param item currnt item of ngfor
   * @return `null`
   */
  onTrackByIndex(index: number, item: number) {
    return item;
  }

  /**
   * calls from template
   * when user clicked on the submit button
   * close dialog with changed data
   * @param null
   * @return `null`
   */
  onContinue() {

    // validate to ensure no subsequent dates/times are used
    // convert slide schedules to format we need
    var newSlideSchedules = [];
    for (var i = 0; i < this.slideSchedules.length; i++){
      var d = this.slideSchedules[i].date;
      d.setUTCHours(0);
      d.setUTCMinutes(0);
      d.setUTCSeconds(0);
      var tempDate = new Date(0);
      tempDate.setUTCMilliseconds(d.getTime()+(+this.slideSchedules[i].time*1000));
      d = tempDate;

      // make sure this time is not less than the previous time. If so, throw an error
      if (i > 0){
        var previousTime = this.slideSchedules[i-1].date;
        previousTime.setUTCHours(0);
        previousTime.setUTCMinutes(0);
        previousTime.setUTCSeconds(0);
        tempDate = new Date(0);
        tempDate.setUTCMilliseconds(previousTime.getTime()+(this.slideSchedules[i-1].time*1000));
        previousTime = tempDate;

        if (previousTime > d){
          this.errorMessage = this.timesOutOrder;
          return;
        }
      }

      newSlideSchedules.push({"stateId":this.slideSchedules[i].state, "stateTimestamp":d.getTime()});
    }

    this.errorMessage = "";

    let outputData: SlideUpdateRequestV3 = {"schedules":newSlideSchedules};
    this.dialogRef.close({ continue: true, outputData: outputData });
  }

  addNewSchedule(){
    var currentDate = new Date();
    this.slideSchedules.push({"state":1, "date":currentDate, "time":this.transformToTimeString(0)});

    setTimeout(function(){
      var e = document.getElementsByClassName("scrollable-window");
      if (e.length > 0){
        e[0].scrollTop = e[0].scrollHeight;
      }
    }, 200);
  }

  deleteSchedule(index){
    this.slideSchedules.splice(index, 1);
  }

  deleteAllSchedules(){
    this.slideSchedules = [];
  }

  onReorderSchedules(e){
    var previousIndex = e.previousIndex;
    var currentIndex = e.currentIndex;

    if (previousIndex == null || previousIndex == -1 || currentIndex == null || currentIndex == -1){
      return;
    }

    var element = this.slideSchedules[previousIndex];
    this.slideSchedules.splice(previousIndex, 1);
    this.slideSchedules.splice(currentIndex, 0, element);
  }


  onChangeDate($event, schedule){
    if ($event.target.value != null){
      schedule.date = new Date($event.target.value);
    }
  }

    /**
   * open amazing time picker progromatically
   * @param controlName is form control name
   * @return `string`
   */
  onOpenTimePicker(index) {
    const amazingTimePicker = this.atpSrv.open({
      changeToMinutes: true,
      time: this.transformToTimeString(this.slideSchedules[index].time),
      arrowStyle: {
        background: '#e5286a',
        color: 'white'
      }
    });
    let subscriber = amazingTimePicker.afterClose().subscribe(time => {
      this.slideSchedules[index].time = this.transformToSeconds(time);
      subscriber.unsubscribe();
    })
  }

  transformToTimeString(time: number){
  let transformedTime = '';
    if (time) {
      var numHours = Math.floor(time / (60*60));
      var numMinutes = Math.floor(Math.floor(time % (60*60)) / 60);
      transformedTime = this.addZero(numHours) + ":" + this.addZero(numMinutes) + ":00 ";
    }
    return transformedTime;
  }

  transformToSeconds(time){
    var times = time.split(":");
    var hours = times[0];
    var minutes = times[1];
    var result = (hours * 60 * 60) + (minutes * 60)
    return result;
  }

    /**
   * add 0 in case of number less than 10
   * @param number which should be transformed
   * @return  `string`
   */
  addZero(number: number): string {
    let returnString = '';
    if (number < 10) {
      returnString = '0' + number.toString();
    } else {
      returnString = number.toString();
    }
    return returnString;
  }

}

