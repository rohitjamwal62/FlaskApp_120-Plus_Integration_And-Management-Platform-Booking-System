import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { SSRSFilestackComponent } from './ssrs-filestack.component';

describe('SSRSFilestackComponent', () => {
  let component: SSRSFilestackComponent;
  let fixture: ComponentFixture<SSRSFilestackComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ SSRSFilestackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SSRSFilestackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
