import { Component, OnInit, Inject } from '@angular/core';
import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { IntegrationsService } from 'src/app/shared/services/integrations.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';

import { OAuthResourceOption } from '../../models/common-models/oauth-resource-option.model';

@Component({
  selector: 'app-ssrs-filestack',
  templateUrl: './ssrs-filestack.component.html',
  styleUrls: ['./ssrs-filestack.component.scss']
})
export class SSRSFilestackComponent implements OnInit {

	integrationId: number = 0;

	ssrsFolders: OAuthResourceOption[] = [];
  ssrsFolderTrails: OAuthResourceOption[] = [];
  selectedFolder: OAuthResourceOption;

  constructor(
  	private translate: TranslateService,
    public utilSrv: UtilService,
    private storageSrv: StorageService,
    private sharedSrv: SharedService,
    private integrationsSrv: IntegrationsService,
    public dialogRef: MatDialogRef<SSRSFilestackComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
    	integrationId: number;
      folders: OAuthResourceOption[];
    }
  ) { }

  ngOnInit() {
  	if(this.data) {
  		this.ssrsFolders = this.data.folders;
  		this.integrationId = this.data.integrationId;
  	}
  }

  onSelectFolder(folder) {
    this.selectedFolder = folder;
  }
  onSelectChildFolder(folder) {
    let filteredFolder = this.ssrsFolderTrails.filter( f => f.id == folder.id);
    if(filteredFolder.length == 0) {
      this.ssrsFolderTrails.push(folder);
    }
    this.integrationsSrv.getSSRSFolderOptions(this.integrationId, folder.id).subscribe( assets => {
      if(assets) {
        this.ssrsFolders = assets;
      }
    });
  }
  onCurrentFolderClick() {
    this.ssrsFolderTrails = [];
    this.integrationsSrv.getSSRSFolderOptions(this.integrationId, null).subscribe( folders => {
      if(folders) {
        this.ssrsFolders = folders;
      }
    });
  }
  onSSRSFolderTrailsClick(folderId, trailIndex) {
    this.ssrsFolderTrails.length = trailIndex + 1;
    this.integrationsSrv.getSSRSFolderOptions(this.integrationId, folderId).subscribe( assets => {
      if(assets) {
        this.ssrsFolders = assets;
      }
    });
  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  onContinue() {
    if (this.selectedFolder) {
      this.dialogRef.close({ continue: true, outputData: this.selectedFolder });
    }
  }

}
