import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Message } from 'src/app/shared/models/message-models/message.model';
import { MessageType } from 'src/app/shared/models/message-models/message-type.model';
import { MessageService } from 'src/app/shared/services/messagecenter.service';

@Component({
  selector: 'app-system-messages',
  templateUrl: './system-messages.component.html',
  styleUrls: ['./system-messages.component.scss']
})
export class SystemMessagesComponent implements OnInit {

	systemMessages = [];

  constructor(
    private messageSrv: MessageService,
  	public dialogRef: MatDialogRef<SystemMessagesComponent>,
  	@Inject(MAT_DIALOG_DATA) public data: {
  		systemMessages: []
  	}
  ) { }

  ngOnInit() {
  	this.systemMessages = this.data.systemMessages;
  	this.listSystemMessages();
  }

  listSystemMessages() {

  }

  // onMarkAsRead(id, index) {
  //   this.messageSrv.deleteMessage(id)
  //     .subscribe(message => {
  //       if (message) {
  //         this.systemMessages.splice(index, 1);
  //       }
  //     });
  // }

  onMarkAsRead(message: Message) {
    let _message = message;

    _message.read = true;
    
    this.messageSrv.updateMessage(_message).subscribe(message => {
      if (message) {
        
      }
    });
  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

}
