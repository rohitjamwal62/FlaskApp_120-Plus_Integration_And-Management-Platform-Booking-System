import { Component, Input, OnInit, Output, EventEmitter, SimpleChanges, OnChanges } from '@angular/core';
import { CleanOnDestroy } from 'src/app/shared/classes/clean-destroy';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

import { TimelineEvent } from '../../models/timeline-models/timeline-event';
import { TimelineOptions } from '../../models/timeline-models/timeline-options.model';
import { ScheduleEvent } from '../../models/event-scheduler-models/schedule-event';
import { Workspace } from 'src/app/shared/models/workspace-models/workspace.model';

import { UtilService } from 'src/app/shared/services/util.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { SchedulesService } from 'src/app/shared/services/schedules.service';

@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.comopnent.html',
  styleUrls: ['./timeline.comopnent.scss']
})
export class TimelineComponent extends CleanOnDestroy implements OnInit, OnChanges {

  currentWorkspace: Workspace;
  timeLineDates: {
    dayFormat1: string,
    dayFormat2?: string,
    date: number
  }[];

  @Input() startDate: number = this.getThisMonday();
  @Input() endDate: number = new Date(
    new Date(this.startDate).getFullYear(),
    new Date(this.startDate).getMonth(),
    new Date(this.startDate).getDate() + 6,
    0, 0, 0
  ).getTime();

  @Input() timelineRowHeight: number = 300;  // in pixels
  //@Input() timelineRowHeight: number = 60;
  hoursInMiliseconds: number = 60 * 60 * 1000;

  @Input() timelineOptions: TimelineOptions = {
    directionsName: 'Horizontal/Vertical',
    dayFormat1: 'EEEE',
    dayFormat2: 'MMM dd',
    directionDescription: 'test',
    showPlayers: false
  };

  @Input() timelineItems: TimelineEvent[] = [];

  playerOverlapping: string = '';
  bestResults: string = '';

  schedules: any[] = [];

  constructor(
    public utilSrv: UtilService,
    private translate: TranslateService,
    private router: Router,
    private storageSrv: StorageService,
    private schedulesSrv: SchedulesService
  ) {
    super();
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.tsTranslation();
    this.subscriber = this.storageSrv.selectedWorkspaceSubject
      .subscribe(workspace => {
        if (workspace) {  
          this.currentWorkspace = workspace;
          this.getDeviceAssignedSchedules();
        }
      });
  }

  ngOnChanges(changes: SimpleChanges) {

    if (
      changes.startDate && this.endDate
      || changes.endDate && this.startDate
    ) {
      this.startDate = this.resetDate(new Date(this.startDate)).getTime();
      this.endDate = this.resetDate(new Date(this.endDate)).getTime();
      this.generateDays();
    }

    if(this.currentWorkspace && changes.timelineItems) {
      this.getDeviceAssignedSchedules();
    }
  }

  tsTranslation() {
    this.translate.get('TIMELINE.PLAYEROVERLAPPING').subscribe((string) => {
      this.playerOverlapping = string;
    });
    this.translate.get('TIMELINE.BESTRESULTS').subscribe((string) => {
      this.bestResults = string;
    });
  }

  getDeviceAssignedSchedules() {
    this.subscriber = this.schedulesSrv.getSchedules(
      this.currentWorkspace.account.id,
      this.currentWorkspace.id
    ).subscribe(schedules => {
      if(schedules) {
        this.schedules = schedules;
      }
    });
  }

  timelineEventsStyle(event, index, day) {
    let eventStyle: {
      left: string;
      width: string;
      top: string;
      height: string;
      background: string
    } = {
      left: '',
      width: '100%',
      top: '0px',
      height: '30px',
      background: '#efefef'
    };
    let rowHeight = 300;
    let minEventHeight = 30;
    let maxSeconds = 24 * 60 * 60;
    let eventLeft = 0;

    switch (day) {
      case 'monday':
        eventLeft = 0;
        break;
      case 'tuesday':
        eventLeft = 1;
        break;
      case 'wednesday':
        eventLeft = 2;
        break;
      case 'thursday':
        eventLeft = 3;
        break;
      case 'friday':
        eventLeft = 4;
        break;
      case 'saturday':
        eventLeft = 5;
        break;
      default:
        eventLeft = 6;
        break;
    }

    let _top = (event.start / maxSeconds) * rowHeight;
    let _height = ((event.end / maxSeconds) * rowHeight) - _top;
    let _left = (100 / this.timeLineDates.length) * eventLeft;
    let _width = 100 / this.timeLineDates.length;

    if (_height < minEventHeight){
      _height = minEventHeight;
    }

    eventStyle['left'] = _left.toString()+'%';
    eventStyle['width'] = _width.toString()+'%';
    eventStyle['top'] = _top.toString()+'px';
    eventStyle['height'] = _height.toString()+'px';
    eventStyle['background'] = event.color;
    return eventStyle;
  }

  getEventsByDay(key) {

  }
  /**
   * get current monday
   * @param null
   * @return `number`
   * monday date in miliseconds
   */
  getThisMonday() {
    let date = new Date();

    let today = date.getDate();
    let dayOfWeek = date.getDay() - 1;
    return new Date(
      date.getFullYear(),
      date.getMonth(),
      today - dayOfWeek,
      0, 0, 0
    ).getTime();
  }

  /**
   * generate days from starDate to endDate
   * @param null
   * @return `null`
   */
  generateDays() {
    this.timeLineDates = [];
    let dayInMiliseconds = 24 * this.hoursInMiliseconds;
    for (let i = this.startDate; i <= this.endDate; i = i + dayInMiliseconds) {
      this.timeLineDates.push({
        dayFormat1: this.timelineOptions.dayFormat1,
        dayFormat2: this.timelineOptions.dayFormat2
          ? this.timelineOptions.dayFormat2
          : null,
        date: i
      })
    }
  }

  /**
   * calculate left of item
   * @param event is a event which left should be calculated
   * @return `number`
   */
  calculateLeft(event: ScheduleEvent) {
    let hundredPercent =
      (this.endDate + (24 * this.hoursInMiliseconds)) - this.startDate;
    let left = (event.startDate - this.startDate) * 100 / hundredPercent;
    return left;
  }

  /**
   * helper function for *ngFor optimozation
   * @param event is a event which width should be calculated
   * @return `number`
   */
  calculateEndOfWidthInPercent(event: ScheduleEvent) {
    let hundredPercent =
      (this.endDate + (24 * this.hoursInMiliseconds)) - this.startDate;
    let endOfWidth = (event.endDate - this.startDate) * 100 / hundredPercent;
    return endOfWidth;
  }

  overlappedMessage(event: ScheduleEvent) {
    let message = this.playerOverlapping;
    message = message + this.bestResults;
    const schedules = [];
    const map = new Map();
    for (const item of event.overlappedEvents) {
      if (!map.has(item.schedule.id)) {
        map.set(item.schedule.id, true);    // set any value to Map
        schedules.push({
          id: item.schedule.id,
          name: item.schedule.name
        });
      }
    }
    schedules.forEach(schedule => {
      message = message + schedule.name + ', ';
    });
    message = message.slice(0, -2);
    return message;
  }

  /**
   * helper function for *ngFor optimozation
   * @param index is a index of current item
   * @param item is a current item
   * @return `any`
   */
  onTrackById(index: number, item: any) {
    return item.id;
  }

  /**
   * reset and return `Date`
   * @param date is a `Date` which should be transformted
   * @return `Date`
   */
  resetDate(date: Date) {
    return new Date(
      date.getFullYear(),
      date.getMonth(),
      date.getDate(),
      0, 0, 0
    );
  }

  onGoToTheRoute(deviceId) {
    this.router.navigate(["/devices/"+deviceId])
  }

  /** 
  * @param id is a player id. 
  */
  onGoToScheduleRoute(id, eventId) {
    let route = "/schedules/";
    for(let s in this.schedules) {
      let _schedule = this.schedules[s];
      let foundDevice = _schedule['assignedDevices'].filter( d => d.id == id);
      if(foundDevice.length > 0) {
        route = `/schedules/edit/${_schedule.id}`;
        this.router.navigate([route]);
        break;
      }
    }
  }

}
