import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { TryMobileAppComponent } from './try-mobile-app.component';

describe('TryMobileAppComponent', () => {
  let component: TryMobileAppComponent;
  let fixture: ComponentFixture<TryMobileAppComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ TryMobileAppComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TryMobileAppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
