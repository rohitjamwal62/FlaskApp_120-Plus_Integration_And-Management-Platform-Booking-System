import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';
import { UtilService } from 'src/app/shared/services/util.service';

@Component({
  selector: 'app-try-mobile-app',
  templateUrl: './try-mobile-app.component.html',
  styleUrls: ['./try-mobile-app.component.scss']
})
export class TryMobileAppComponent implements OnInit {

  constructor(
  	public utilSrv: UtilService,
  	private translate: TranslateService,
  	public dialogRef: MatDialogRef<TryMobileAppComponent>,
  	@Inject(MAT_DIALOG_DATA) public data: any
  ) {
  	translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {

  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

}
