import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { UpdateIntegrationComponent } from './update-integration.component';

describe('UpdateIntegrationComponent', () => {
  let component: UpdateIntegrationComponent;
  let fixture: ComponentFixture<UpdateIntegrationComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateIntegrationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateIntegrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
