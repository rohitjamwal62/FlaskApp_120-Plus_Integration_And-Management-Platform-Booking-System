import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as moment from 'moment';
import { ClientToken } from 'src/app/shared/models/integration-models/client-token.model';
import { IntegrationUpdate } from 'src/app/shared/models/requests-models/integration-update.model';
import { StorageService } from 'src/app/shared/services/storage.service';
import { IntegrationsService } from 'src/app/shared/services/integrations.service';
// Utils
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

@Component({
  selector: 'app-update-integration',
  templateUrl: './update-integration.component.html',
  styleUrls: ['./update-integration.component.scss']
})
export class UpdateIntegrationComponent implements OnInit {

	updateIntegrationForm: FormGroup;
  integration: any = {
    integration: {}
  };

  constructor(
  	private fb: FormBuilder,
    public dialogRef: MatDialogRef<UpdateIntegrationComponent>,
    private storageSrv: StorageService,
    private integrationsSrv: IntegrationsService,
    @Inject(MAT_DIALOG_DATA) public data: { }
  ) { }

  ngOnInit() {
    this.integration = this.data;
  	this.createIntegrationForm();
  }

  createIntegrationForm() {
    this.updateIntegrationForm = this.fb.group({
      clientId: ['', [Validators.required, removeWhitespaceValidator]],
      clientSecret: ['', [Validators.required, removeWhitespaceValidator]],
      expiresAt: ['']
    })
  }

  onUpdateIntegration() {
    let integrationId = this.integration.integration.id;
    let formData:IntegrationUpdate = this.updateIntegrationForm.getRawValue();
    let expiresAt = this.updateIntegrationForm.get('expiresAt').value;

    formData.expiresAt = moment(expiresAt).unix();
    if (formData.expiresAt == null || Number.isNaN(formData.expiresAt)){
      formData.expiresAt = 0;
    }

    if (this.updateIntegrationForm.valid) {
      this.integrationsSrv.updateIntegration(integrationId, formData).subscribe( update => {
        if(update) {
          this.integration.integration = update;
          this.updateStorageServiceIntegrations();
          this.onCloseWithoutChanges();
        }
      });
    }
  }

  updateStorageServiceIntegrations() {
    let integrationId = this.integration.integration.id;
    let storageIntegrations = this.storageSrv.workspaceIntegrations;
    let elementIndex = storageIntegrations.findIndex( element => element.id == integrationId);

    this.storageSrv.workspaceIntegrations[elementIndex] = this.integration.integration;
  }

  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }
}
