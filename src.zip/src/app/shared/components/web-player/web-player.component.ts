import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Device } from 'src/app/shared/models/device-models/device.model';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-web-player',
  templateUrl: './web-player.component.html',
  styleUrls: ['./web-player.component.scss']
})
export class WebPlayerComponent implements OnInit {

	webPlayerForm: FormGroup;
	device: Device;
	url: string = '';
	embedCode: string = '';
	inputDisabled: boolean = true;

  constructor(
  	private fb: FormBuilder,
  	public dialogRef: MatDialogRef<WebPlayerComponent>,
  	@Inject(MAT_DIALOG_DATA) public data: {
      device: Device
    }
  ) {

  }

  ngOnInit() {
  	this.device = this.data.device;
  	this.url = window.location.protocol+ "//live."+window.location.hostname+"/player/embed/"+this.device.secretCode+"/";
  	this.embedCode = '<iframe id="boldcast" src="'+this.url+'" style="width:100vw;height:56.25vw;border: 0px solid;" sandbox="allow-scripts"></iframe>';
  	this.createWebPlayerForm();
  }

  createWebPlayerForm() {
  	this.webPlayerForm = this.fb.group({
      embedCode: [{ value: this.embedCode, disabled: true }],
      url: [{ value: this.url, disabled: true }]
    })
  }

  onCopyUrl() {
  	var e = document.createElement("textarea");
    e.innerHTML = this.url;
    document.body.appendChild(e);
    e.select();
    document.execCommand("copy");
    document.body.removeChild(e);
  }

  /**
   * close dialog without changes
   * @param null
   * @return `null`F
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

}
