import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSelectChange } from '@angular/material/select';
import { UtilService } from 'src/app/shared/services/util.service';
import { TranslateService } from '@ngx-translate/core';
// Utils
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

@Component({
  selector: 'workspace-group-new',
  templateUrl: './workspace-group-new.component.html',
  styleUrls: ['./workspace-group-new.component.scss']
})
export class WorkspaceGroupNewComponent implements OnInit {
  workspaceGroupForm: FormGroup;

  constructor(
    private translate: TranslateService,
    public utilSrv: UtilService,
    public dialogRef: MatDialogRef<WorkspaceGroupNewComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      workspaceId: number
    },
    private fb: FormBuilder
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {
    this.generateWorkspaceGroupForm(this.data.workspaceId);
  }


  /**
   * generate `scheduleForm`
   *
   * @param workspaceId: selected workspaceId
   *
   * @return `null`
   */
  generateWorkspaceGroupForm(workspaceId: number) {
    this.workspaceGroupForm = this.fb.group({
      workspaceId: [workspaceId, [Validators.required]],
      workspaceGroupName: ['', [Validators.required, removeWhitespaceValidator]]
    });
  }

  /**
   * close dialog without changes
   *
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * close dialog with playlist create info
   *
   * @param null
   *
   * @return `null`
   */
  onContinue() {
    if (this.workspaceGroupForm.valid) {
      let outputData = this.workspaceGroupForm.getRawValue();
      this.dialogRef.close(
        { continue: true, outputData: outputData }
      );
    }
  }
}
