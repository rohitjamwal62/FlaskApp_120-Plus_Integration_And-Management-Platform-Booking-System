import { Component, OnInit, Inject, ViewChild, AfterViewInit } from '@angular/core';
import { UserBasic } from '../../models/user-models/user-basic.model';
import { WorkspaceGroup } from '../../models/workspace-models/workspace-group.model';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSelectChange, MatSelect } from '@angular/material/select';
import { UtilService } from 'src/app/shared/services/util.service';
import { TranslateService } from '@ngx-translate/core';
// Utils
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

@Component({
  selector: 'app-workspace-members',
  templateUrl: './workspace-members.component.html',
  styleUrls: ['./workspace-members.component.scss']
})
export class WorkspaceMembersComponent implements OnInit, AfterViewInit {

  form: FormGroup;
  accountMembers: UserBasic[] = [];
  workspaceGroups: WorkspaceGroup[] = [];

  @ViewChild('multiSelect') multiSelect: MatSelect;

  currentLocale: any = '';

  constructor(
    public utilSrv: UtilService,
    private translate: TranslateService,
    public dialogRef: MatDialogRef<WorkspaceMembersComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      members: UserBasic[],
      workspaceGroups: WorkspaceGroup[];
    },
    private fb: FormBuilder
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {

    this.currentLocale = this.utilSrv.locale;

    if (this.data) {
      this.accountMembers = this.data["members"];
      this.workspaceGroups = this.data.workspaceGroups;
    }

    this.generateForm();
  }

  generateForm(){
    this.form = this.fb.group({
      userId: ['', [Validators.required]],
      groupId: ['', [Validators.required]]
    });
  }

  ngAfterViewInit() {

  }

  /**
   * calls from template
   * helper for a optimizing *ngFor
   *
   * @param index is a current element index with type `number`
   * @param item is a current element info
   *        with type `{id: number}`
   *
   * @return `number`
   */
  onTrackById(index: number, item: { id: number }) {
    return item.id;
  }

  /**
   * close dialog without changes
   *
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * close dialog with selected members Info
   *
   * @param null
   *
   * @return `null`
   */
  onContinue() {
    if (this.form.valid){
      let outputData = this.form.getRawValue();
      this.dialogRef.close({ continue: true, outputData: outputData });
    }
  }
}
