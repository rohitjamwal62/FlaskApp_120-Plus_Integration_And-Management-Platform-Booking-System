import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { removeWhitespaceValidator } from 'src/app/shared/utils/remove-whitespace-validator';

import { UserBasic } from '../../models/user-models/user-basic.model';
import { UserBasicV3 } from '../../models/user-models/user-basic-v3.model';
import { MatSelectChange, MatSelect } from '@angular/material/select';
import { UserPersonal } from '../../models/user-models/user-personal.model';
import { WorkspaceCreateRequest } from 'src/app/shared/models/requests-models/workspace-create.model';
import { Pagination } from 'src/app/shared/models/common-models/pagination.model';

import { UtilService } from 'src/app/shared/services/util.service';
import { AccountsService } from 'src/app/shared/services/accounts.service';
import { WorkspacesService } from 'src/app/shared/services/workspaces.service';

@Component({
  selector: 'app-workspace-new',
  templateUrl: './workspace-new.component.html',
  styleUrls: ['./workspace-new.component.scss']
})
export class WorkspaceNewComponent implements OnInit {

  accountMembers: UserBasicV3[] = [];
  accountUsersPaginate: Pagination;
  initialMembers: UserBasicV3[] = [];
  newWorkspaceForm: FormGroup;

  currentLocale: any = '';

  constructor(
    public utilSrv: UtilService,
    private translate: TranslateService,
    private fb: FormBuilder,
    private accountsSrv: AccountsService,
    private workspacesSrv: WorkspacesService,
    public dialogRef: MatDialogRef<WorkspaceNewComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      currentUser: UserPersonal,
      accountId: number
    },
  ) {
    translate.setDefaultLang(this.utilSrv.locale);
  }

  ngOnInit() {

    this.currentLocale = this.utilSrv.locale;

    this.generateNewWorkspaceForm();
    if (this.data) {
      this.newWorkspaceForm.get('accountId').patchValue(this.data.accountId);
      this.getAccountMembers(this.data.accountId)
    }
  }

  getAccountMembers(accountId) {
    this.accountsSrv.retrieveAccountUsers(accountId)
      .subscribe(response => {
        if (response.message) {
          this.accountMembers = response.message;
          this.accountUsersPaginate = response.pagination;
        }
      })

  }
  /**
   * generate `newWorkspaceForm`
   *
   * @param null
   *
   * @return `null`
   */
  generateNewWorkspaceForm() {
    this.newWorkspaceForm = this.fb.group({
      accountId: [null, [Validators.required]],
      name: ['', [Validators.required, removeWhitespaceValidator]],
    });
  }

  /**
   * generate `newWorkspaceForm`
   *
   * @param null
   *
   * @return `null`
   */
  onSelectMember(event: MatSelectChange) {
    this.initialMembers = event.value as UserBasicV3[];
  }

  /**
   * calls from template
   * when user clicked on the chip delete button
   * delete selected member and update mat-select selected options
   *
   * @param null
   *
   * @return `null`
   */
  onRemoveSelectedMember(member: UserBasicV3, memberIndex: number, select: MatSelect) {
    this.initialMembers.splice(memberIndex, 1);
    select.writeValue(this.initialMembers);
  }


  /**
   * close dialog without changes
   *
   * @param null
   *
   * @return `null`
   */
  onCloseWithoutChanges() {
    this.dialogRef.close({ continue: false, outputData: null });
  }

  /**
   * close dialog with new workspace creation data
   * @param null
   * @return `null`
   */
  onCreateNewWorkspace() {
    let workspaceForm = this.newWorkspaceForm.getRawValue();
    workspaceForm.initialMembers = [];
    this.initialMembers.forEach(member => {
      workspaceForm.initialMembers.push(member.id)
    })
  
    // Send request to API
    // Wait for the response before closing the form
    this.workspacesSrv.createWorkspace(this.data.accountId, workspaceForm as WorkspaceCreateRequest)
      .subscribe(createdWorkspace => {
        if (createdWorkspace) {
          this.dialogRef.close({
            continue: true,
            outputData: createdWorkspace
          });
        }
      })
  }

}
