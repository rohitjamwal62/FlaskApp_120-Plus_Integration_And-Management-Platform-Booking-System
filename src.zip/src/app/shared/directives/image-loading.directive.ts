import { Directive, ElementRef, Renderer2, OnInit, OnDestroy, OnChanges, Input } from '@angular/core';
import { UtilService } from '../services/util.service';

@Directive({
  selector: '[appImageLoading]'
})
export class ImageLoadingDirective implements OnInit, OnChanges, OnDestroy {
  // containst the support status of lazy loading images as boolean value
  isSupportedLazyLoad = false;

  // current html Image element
  imageElement: HTMLImageElement;

  tryLoadCount = 0;
  maxLoadCount = 3;
  // image url which should be set into image src value
  @Input() appImageLoading: string;

  // image url which should be set into image src value
  @Input() defaultImage: string = this.utilSrv.appImages.websiteDefault;

  intersectionObserver: IntersectionObserver;
  constructor(
    private element: ElementRef,
    private renderer: Renderer2,
    private utilSrv: UtilService) {
    // store the current image element
    this.imageElement = element.nativeElement as HTMLImageElement;
    if ('IntersectionObserver' in window) {
      this.isSupportedLazyLoad = true;
    }
  }

  ngOnInit() {
    // first set loading styles
    // this.renderer.setStyle(
    //   this.imageElement, 'background-size', `contain`
    // );
    // this.renderer.setStyle(
    //   this.imageElement, 'background-position', `center center`
    // );
    // this.renderer.setStyle(
    //   this.imageElement, 'background-repeat', `no-repeat`
    // );
    this.renderer.setAttribute(this.imageElement, 'src', this.utilSrv.appImages.loading);
    // listen to the load event
    this.imageElement.addEventListener('load', this.onTurnOffLoading.bind(this));
    this.imageElement.addEventListener('error', this.onImageNotFound.bind(this));

  }

  ngOnChanges() {
    // when changes the src of img should turn on loading
    this.addLoadingToTheElement();
    if (this.isSupportedLazyLoad) {
      this.intersectionObserver = new IntersectionObserver(entries => {
        this.checkForIntersection(entries);
      }, {});
      this.intersectionObserver.observe(this.imageElement as Element);
    } else {
      // get image by changed url
      this.renderer.setAttribute(this.imageElement, 'src', this.appImageLoading);
    }

  }

  /**
   * set loading when image is downloading
   *
   * @param null
   *
   * @return `null`
   */
  addLoadingToTheElement() {
    // this.renderer.setStyle(
    //   this.imageElement,
    //   'background-image',
    //   `url(${this.utilSrv.appImages.loading})`
    // );
    this.renderer.setAttribute(this.imageElement, 'src', this.utilSrv.appImages.loading);
  }

  /**
   * set Default image in case of wrong url
   *
   * @param null
   *
   * @return `null`
   */
  onImageNotFound() {
    if (this.tryLoadCount < this.maxLoadCount) {
      this.renderer.setAttribute(this.imageElement, 'src', this.defaultImage);
      this.tryLoadCount = this.tryLoadCount + 1;
    }
  }

  /**
   * set loading when image is downloading
   *
   * @param null
   *
   * @return `null`
   */
  onTurnOffLoading() {
    //this.renderer.setStyle(this.imageElement, 'background-image', '');
  }

  /**
   * downlaod the image only in case of user see the image
   *
   * @param entry
   *
   * @return `boolean`
   */
  private checkForIntersection = (entries: Array<IntersectionObserverEntry>) => {
    entries.forEach((entry: IntersectionObserverEntry) => {
      if (this.checkIfIntersecting(entry)) {
        // get image by changed url
        this.renderer.setAttribute(this.imageElement, 'src', this.appImageLoading);
        this.intersectionObserver.unobserve(this.imageElement as Element);
        this.intersectionObserver.disconnect();
      }
    });
  }

  /**
   * is user see the current image
   *
   * @param entry
   *
   * @return `boolean`
   */
  private checkIfIntersecting(entry: IntersectionObserverEntry) {
    return (entry).isIntersecting && entry.target === this.imageElement;
  }


  ngOnDestroy() {
    // remove event listeners when destroys a directive
    this.imageElement.removeEventListener(
      'load',
      this.onTurnOffLoading.bind(this)
    );
  }

}
