export enum OnboardingProcess {
  loading = 1,
	setupFirstPlayer = 2,
	customizeChannel = 3,
	uploadContent = 4,
	default = 5
}
