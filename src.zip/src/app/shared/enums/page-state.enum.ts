export enum PageState {
  loading = 1,
	noReadPermission = 2,
	noItems = 3,
	withItems = 4
}
