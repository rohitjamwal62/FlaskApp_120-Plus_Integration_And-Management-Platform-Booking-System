export enum Resource {
  channels = 1,
	devices = 2,
	schedules = 3,
	content = 4,
	notifications = 5,
	recipients = 6
}
