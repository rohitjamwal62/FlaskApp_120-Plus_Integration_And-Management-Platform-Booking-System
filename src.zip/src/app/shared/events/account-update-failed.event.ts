

export class AccountUpdateFailedEvent {
  message: string;
}
