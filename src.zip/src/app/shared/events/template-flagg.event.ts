export class TemplateFlaggEvent {
  flagg: boolean;
}
