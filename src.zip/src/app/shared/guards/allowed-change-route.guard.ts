
import { Injectable } from '@angular/core';

import { CanDeactivate, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { StorageService } from '../services/storage.service';

export interface CanComponentDeactivate {
    canDeactivate: () => Observable<boolean> | Promise<boolean> | boolean;
}

@Injectable({
    providedIn: 'root'
})
export class AllowedChangeRouteGuard implements CanDeactivate<CanComponentDeactivate> {

    constructor(
        private storageSrv: StorageService,
        private router: Router
    ) {

    }

    /**
     * ignore user navigations in case of user is new and have not any accounts
     * 
     * @param component is a current component
     *
     * @return `boolean`
     */
    canDeactivate(component: CanComponentDeactivate) {
        // if(this.router.url == '/accounts/new') {
        //     return false;
        // } else {
        //     return this.storageSrv.currentUserAccounts.length > 0;
        // }   
        return this.storageSrv.currentUserAccounts.length > 0;
    }

}
