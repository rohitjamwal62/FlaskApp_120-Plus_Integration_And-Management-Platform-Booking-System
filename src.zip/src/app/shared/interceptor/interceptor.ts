
import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { SharedService } from '../services/shared.service';
import { NGXLogger } from 'ngx-logger';

@Injectable()
export class Interceptor implements HttpInterceptor {

    constructor(
        private sharedSrv: SharedService,
        private logger:NGXLogger
    ) { }

    intercept(request: HttpRequest<any>, next: HttpHandler) {
        request = request.clone({
            withCredentials: true
        });

        // Log error
        this.logger.debug(request.urlWithParams);

        //this.logger.debug(request);

        // handle error and return parsed object with status
        return next.handle(request).pipe(

            catchError((error: HttpErrorResponse) => {

                // set error messages
                let errorMessage = error.error.message;
                let dialogErrorMessage = errorMessage;
                let showDialog = true;

                // if no info provided from server, error is due to HTTP issue. Try to log it, but nothing we can do
                if (!errorMessage) {
                    errorMessage = `Error - ${error.message}, `;
                    errorMessage += ` URL - ${error.url}, `;
                    errorMessage += ` Request Method - ${request.method}`;
                    dialogErrorMessage = 'Unable to perform action, the server is unreachable. Please try again at a later time.';
                }

                // open error dialog
                if (showDialog){
                    this.sharedSrv.openDialog({
                      title: 'Warning',
                      description: dialogErrorMessage,
                      template: 1,
                      confirm: 'ok'
                    }, true);
                }

                // send out an event that this failed
                this.sharedSrv.accountFailed.emit({message: "Account failed"});

                // sending an event to update template flagg
                this.sharedSrv.templateFlagg.emit({flagg: true});

                return throwError(errorMessage);
            })
        );
    }
}
