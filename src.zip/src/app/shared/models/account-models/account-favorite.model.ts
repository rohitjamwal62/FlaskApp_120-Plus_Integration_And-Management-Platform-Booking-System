import { Playlist } from '../playlist-models/playlist.model';
import { Slide } from '../slide-models/slide.model';

export type AccountFavorite = {
    accountId: number;
    resourceType: string;
    resourceId: number;
    resource: Slide | Playlist;
} 