
export type AccountFeaturesFlags = {
    key: string;
    name: string;
    description: string;
    value: boolean;
    editable: boolean;
} 