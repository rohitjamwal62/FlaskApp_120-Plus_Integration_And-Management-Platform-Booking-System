
export type AccountFeatures = {
    web_player?: boolean;
    streams?: boolean;
    premium_casts?: boolean;
    schedules?: boolean;
    announcements?: boolean;
    offline_notifications?: boolean;
    onboarding?: boolean;
    sso?: boolean;
    whitelabel?: boolean;
    api_access?: boolean;
    custom_refresh_rate?: boolean;
    num_channels?: number;
    num_apps?: number;
    num_users?: number;
    num_workspaces?: number;
    num_storage_gbs?: number;
    num_integrations?: number;
    change_management?: boolean;
} 