import { Location } from '../common-models/location.model';

export type AccountGroup = {
    id: string;
    location: string;
    groupName: string;
    users: Location[];
    account: Location
}