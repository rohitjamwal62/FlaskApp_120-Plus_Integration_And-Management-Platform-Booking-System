import { Location } from '../common-models/location.model';

export type AccountInvitationFull = {
    id: number;
    location: string;
    email: string;
    isAccepted: boolean;
    account: Location;
    accountName: string;
    inviter: Location;
    registrationCode: string;
}
