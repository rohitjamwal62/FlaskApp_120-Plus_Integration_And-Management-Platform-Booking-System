export type AccountInvitationV3 = {
    id: number;
    email: string;
    isAccepted: boolean;
    account: number;
}