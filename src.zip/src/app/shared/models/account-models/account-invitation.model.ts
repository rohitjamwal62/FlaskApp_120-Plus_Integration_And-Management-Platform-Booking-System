import { Location } from '../common-models/location.model';

export type AccountInvitation = {
    id: number;
    location: string;
    email: string;
    isAccepted: boolean;
    account: Location;
    inviter: Location;
}