import { Location } from '../common-models/location.model';
import { CustomTerm } from '../common-models/custom-term.model';
import { AccountInvitation } from './account-invitation.model';

export type Account = {
    id: number;
    location: string;
    accountName: string;
    isActive: boolean;
    isTrial: boolean;
    isEnterprise: boolean;
    trialEndTimestamp: number;
    company: string;
    industry: string;
    customCSS: string;
    customTerms: CustomTerm[];
    users: Location[];
    workspaces: Location[];
    groups: Location[];
    invitations: AccountInvitation[];
    ssoEnabled: boolean;
}
