
export type BillDiscount = {
  amountOff: number;
  percentOff: number;
  name: string;
}
