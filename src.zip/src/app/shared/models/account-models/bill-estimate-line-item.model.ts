export type BillEstimateLineItem = {
  quantity: number;
  amount: number;
  name: string;
}
