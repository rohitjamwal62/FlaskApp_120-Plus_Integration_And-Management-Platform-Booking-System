import { BillDiscount } from './bill-discount.model';
import { BillEstimateLineItem } from './bill-estimate-line-item.model';

export type BillEstimate = {
    total: number;
    items: BillEstimateLineItem[];
    periodStart: number;
    periodEnd: number;
    discount: BillDiscount;
    balance: number;
}
