
export type BillHistory = {
    total: number;
    created: number;
    number: string;
    paid: boolean;
    invoiceUrl: string;
}
