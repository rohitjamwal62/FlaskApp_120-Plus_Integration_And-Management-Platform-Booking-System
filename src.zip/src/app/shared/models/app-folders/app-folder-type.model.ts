export type AppFolderType = {
  id: number;
  name: string;
}