import { AppFolderType } from './app-folder-type.model';

export type AppFolder = {
  id: number;
  name: string;
  type: AppFolderType;
  createdTimestamp: number;
  modifiedTimestamp: number;
  parentFolder: number;
}