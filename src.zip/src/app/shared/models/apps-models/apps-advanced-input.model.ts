import { AppsInputfieldsOptions } from './apps-inputfields-options.model';

export type AppsAdvancedInput = {
  id: number;
  name: string;
  key: string;
  type: string;
  description: string;
  required: boolean;
  default: string;
  fileTypes: string[];
  options: AppsInputfieldsOptions;
}
