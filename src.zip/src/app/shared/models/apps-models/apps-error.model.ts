export type AppsError = {
  id: number;
  message: string;
  createdTimestamp: number;
}