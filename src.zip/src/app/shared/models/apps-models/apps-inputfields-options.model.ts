
export type AppsInputfieldsOptions = {
    name: string;
    value: number;
}
