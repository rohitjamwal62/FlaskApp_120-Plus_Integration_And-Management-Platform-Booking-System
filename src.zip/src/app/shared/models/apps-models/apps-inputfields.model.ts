import { AppsInputfieldsOptions } from './apps-inputfields-options.model';

export type AppsInputfields = {
  id: number;
  name: string;
  key: string;
  type: string;
  description: string;
  required: boolean;
  default: string;
  disabled?: boolean;
  fileTypes?: string[];
  options?: AppsInputfieldsOptions;
  for?: string;
  from?: string;
}
