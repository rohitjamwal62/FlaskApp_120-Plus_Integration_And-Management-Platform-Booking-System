export type AppsProperty = {
  id: number;
  propertyId: number;
  value: string | number;
}