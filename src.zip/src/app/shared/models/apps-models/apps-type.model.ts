import { AppsInputfields } from './apps-inputfields.model';
import { AppsAdvancedInput } from './apps-advanced-input.model';

export type AppsType = {
  id: number;
  name: string;
  description: string;
  icon: string;
  defaultName: string;
  position: number;
  help: string;
  tags: string[],
  isBeta: boolean;
  refreshIntervalMinutes: number;
  category: string;
  requiresProfessional: boolean;
  allowOnMobile: boolean;
  inputFields: AppsInputfields[];
  advancedInput: AppsAdvancedInput[];
}
