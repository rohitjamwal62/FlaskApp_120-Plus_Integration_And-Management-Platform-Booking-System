export type AppsTypes = {
  id: number;
  name: string;
  description: string;
  icon: string;
  position: number;
  help: string;
  tags: string[],
  isBeta: boolean;
  category: string;
  requiresProfessional: boolean;
}
