import { AppsProperty } from './apps-property.model';
import { AppsType } from './apps-type.model';
import { AppsError } from './apps-error.model';

export type Apps = {
    id: number;
    refreshInterval: number;
    name: string;
    properties: AppsProperty[];
    createdTimestamp: string;
    modifiedTimestamp: string;
    refreshedTimestamp: string;
    type: AppsType;
    isProcessed: boolean;
    isRefreshing: boolean;
    workspace: number;
    tags: string[];
    errors: AppsError[]
}
