export type AssetFileV3 = {
    id: number;
    name: string;
    type: string;
    key: string;
    createdTimestamp: number;
    modifiedTimestamp: number;
    workspace: number;
    parentFolder: number;
    size: number;
}