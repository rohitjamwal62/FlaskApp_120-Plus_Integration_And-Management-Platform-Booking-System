import { Location } from '../common-models/location.model';

export type AssetFile = {
    id: number;
    location: string;
    assetExtension: string;
    assetKey: string;
    assetName: string;
    assetPath: string;
    createdTimestamp: string;
    workspace: Location;
    parentFolder: Location;
}