export type AssetFolderV3 = {
    id: number;
    name: string;
    type: string,
    key: string,
    createdTimestamp: number,
    modifiedTimestamp: number,
    parentFolder: number,
    size: number
}