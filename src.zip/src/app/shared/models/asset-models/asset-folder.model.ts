import { Location } from '../common-models/location.model';

export type AssetFolder = {
    id: number;
    location: string;
    folderName: string;
    nodes: Location[];
    assets: Location[];
    createdTimestamp: string;
    parentFolder: Location;
}