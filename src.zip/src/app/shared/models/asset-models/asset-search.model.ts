import { AssetFile } from './asset-file.model';
import { AssetFolder } from './asset-folder.model';
import { UserFavorite } from '../user-models/user-favorite.model';

export type AssetSearch = {
    files: AssetFile[],
    folders: AssetFolder[],
    favorites: UserFavorite[],
}