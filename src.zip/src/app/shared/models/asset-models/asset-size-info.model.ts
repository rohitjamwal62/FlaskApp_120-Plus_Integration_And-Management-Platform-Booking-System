export type AssetSizeInfo = {
    used: number;
    total: number;
}