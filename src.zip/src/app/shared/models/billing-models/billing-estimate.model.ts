export type BillingEstimate = {
    items: {
        quantity: number;
        amount: number;
        name: string;
    }[];
    periodStart: number;
    periodEnd: number;
    discount: {
        amountOff: number;
        percentOff: number;
        name: string;
    };
    total: number;
    balance: number;
}