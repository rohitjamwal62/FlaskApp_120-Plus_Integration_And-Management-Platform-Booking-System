export type BillingHistory = {
    total: number;
    number: string;
    paid: boolean;
    created: number;
    invoiceUrl: string;
}