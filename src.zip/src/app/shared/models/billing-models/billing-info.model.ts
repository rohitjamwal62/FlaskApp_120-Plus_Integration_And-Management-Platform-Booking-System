export type BillingInfo = {
    subscription: number;
    billingName: string;
    billingEmail: string;
    billingPhone: string;
    billingAddressLine1: string;
    billingAddressLine2: string;
    billingAddressCity: string;
    billingAddressState: string;
    billingAddressCountry: string;
    billingAddressPostalCode: string;
    numPhysicalLicenses: number;
    numWebLicenses: number;
    numVirtualLicenses: number;
    numStreamLicenses: number;
    reason: string;
    trialEnd: number;
    subscriptionEnd: number;
    collectionMethod: string;
    isActive: boolean;
    account: number;
}