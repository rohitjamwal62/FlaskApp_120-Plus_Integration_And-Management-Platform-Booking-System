export type BillingStatus = {
  active: boolean;
  reason: string;
}
