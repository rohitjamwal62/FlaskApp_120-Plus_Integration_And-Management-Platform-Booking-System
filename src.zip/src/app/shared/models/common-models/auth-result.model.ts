export type AuthResult = {
    expiresIn?: number;
    accessToken?: string;
    idToken?: string;
}