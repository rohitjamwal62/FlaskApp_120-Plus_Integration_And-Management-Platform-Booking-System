import { Subscription } from './subscription.model';
import { Location } from './location.model';

export type BillingInfo = {
    id: number;
    location: string;
    billingName: string;
    billingEmail: string;
    billingPhone: string;
    subscription: Subscription;
    billingAddressLine1: string;
    billingAddressLine2: string;
    billingAddressCity: string;
    billingAddressState: string;
    billingAddressCountry: string;
    billingAddressPostalCode: string;
    account: Location;
    isActive: boolean;
    trialEnd: number;
    subscriptionEnd: number;
    cardPreview: string;
    numStreamLicenses: number;
    numPhysicalLicenses: number;
    numVirtualLicenses: number;
    numWebLicenses: number;
    reason: string;
}
