export type Calendar = {
    id: string,
    name: string
}