export type Country = {
    name: string,
    code: string
}