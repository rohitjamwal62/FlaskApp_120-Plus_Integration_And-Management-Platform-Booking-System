export type CustomTerm = {
    term: {
        id: number
        default: string
    },
    value: string
}

