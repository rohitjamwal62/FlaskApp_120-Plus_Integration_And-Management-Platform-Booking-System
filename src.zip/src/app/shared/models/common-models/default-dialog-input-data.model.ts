export type DefaultDialogInputData = {
    title?: string;
    description?: string;
    secondaryDescription?: string;
    template: 0 | 1;
    confirm?: string;
    cancel?: string;
}