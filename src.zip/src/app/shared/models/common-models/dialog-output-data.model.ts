export type DialogOutputData<T> = {
    continue?: boolean;
    outputData?: T
}