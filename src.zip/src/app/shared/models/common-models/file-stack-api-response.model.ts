export type PickerResponse = {
    filename: string,
    handle: string,
    mimetype: string,
    originalPath: string,
    size: number,
    source: string,
    url: string,
    uploadId: string,
    originalFile: {
        name: string,
        type: string,
        size: number
    },
    status: string,
    key?: any
}