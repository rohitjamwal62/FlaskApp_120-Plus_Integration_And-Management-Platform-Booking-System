export type GoogleDrive = {
  id: string,
  name: string
}