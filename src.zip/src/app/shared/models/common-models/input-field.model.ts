export type InputField = {
    default?: any;
    id: string;
    name: string;
    key: string;
    type: string;
    description: string;
    required: boolean;
    fileTypes: string[];
    options: { name: string; value: number }[];
    warning?: string;
    disabled?: boolean;
    editable: boolean;
}