export type Location = {
    id: number;
    location: string;
}