
export type OAuthConnection = {
  id: number,
  name: string,
  type: string
}
