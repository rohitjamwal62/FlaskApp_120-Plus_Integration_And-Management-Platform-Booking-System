
export type OAuthResourceOption = {
  id: string,
  name: string
}
