export type Pagination = {
  count: number; 
  limit: number; 
  next: string; 
  offset: number
}