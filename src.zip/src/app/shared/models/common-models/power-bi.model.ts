export type PowerBi = {
  id: string,
  name: string
}