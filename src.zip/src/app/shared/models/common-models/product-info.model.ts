export type ProductInfo = {
  amount: number;
	active: boolean;
	billing_scheme: string;
  currency: string;
	interval: string;
	intervalCount: number;
	nickname: string;
	trialPeriodDays: number;
	tiers: string;
	usageType: string;
	groupSize: number;
}
