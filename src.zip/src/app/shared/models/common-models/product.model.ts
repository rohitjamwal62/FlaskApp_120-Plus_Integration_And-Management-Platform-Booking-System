import { ProductInfo } from './product-info.model';

export type Product = {
  id: number;
  productName: string;
  productInfo: ProductInfo;
}
