export type RegisterDeviceRequest = {
    playlistId: number;
    groupId: number;
    deviceName: string;
    code: string;
    deviceImage: File;
    workspaceId: number
}