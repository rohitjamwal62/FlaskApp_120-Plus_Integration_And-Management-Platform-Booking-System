export type ResponsePaginate<T> = {
    success: boolean;
    message: T;
    pagination: T;
}