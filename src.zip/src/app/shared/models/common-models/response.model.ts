export type Response<T> = {
    success: boolean;
    message: T;
}