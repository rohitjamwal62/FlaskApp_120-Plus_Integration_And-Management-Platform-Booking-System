import { SitebarItemSub } from './sitebar-item-sub.model';

export type SitebarItem = {
  id: string,
  name: string,
  route: string,
  icon: string,
  activeIcon: string,
  exact: boolean,
  shouldShowOnSitebar: boolean,
  requiresProfessional: boolean,
  submenu: SitebarItemSub[],
  featuresFlag: string
}
