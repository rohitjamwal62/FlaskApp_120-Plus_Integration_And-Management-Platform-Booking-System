export type Store = {
    name: string;
    keyPathInfo: {
        keyPath: string,
        [key: string]: any
    }

}