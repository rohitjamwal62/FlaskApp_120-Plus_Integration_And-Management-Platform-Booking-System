export type StripeChangeEvent = {
    brand: string;
    complete: boolean
    elementType: "card"
    empty: boolean,
    value: {
        postalCode: string
    },
    error?: {
        code: string,
        type: string,
        message: string
    }
}