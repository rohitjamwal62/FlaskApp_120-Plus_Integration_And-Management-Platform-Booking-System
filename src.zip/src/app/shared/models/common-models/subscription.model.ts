import { Product } from './product.model';

export type Subscription = {
    id: number;
    location: string;
    subscriptionName: string;
    trialLength: number;
    hasTrial: boolean;
    interval: string;
    tier: string;
    products: Product[];
}
