import { Location } from './location.model';

export type Tag = {
    id: number;
    tagValue: string
    playlist?: Location;
    slide?: Location;
}