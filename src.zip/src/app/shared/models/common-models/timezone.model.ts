export type Timezone = {
    "1"?: number,
    "AD": string,
    "Europe/Andorra": string
}