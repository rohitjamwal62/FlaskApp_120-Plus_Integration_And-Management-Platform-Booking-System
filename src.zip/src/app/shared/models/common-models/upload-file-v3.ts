export type UploadFileV3 = {
    mimeType: string;
    name: string;
    assetKey: string;
    assetPath: string;
    folderId: number;
    handle: string;
    size: number;
}
