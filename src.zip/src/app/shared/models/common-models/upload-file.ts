export type UploadFile = {
    assetExtension: string
    assetName: string
    assetKey: string
    assetPath: string
    size: number
    parentId: number
    handle: string
}
