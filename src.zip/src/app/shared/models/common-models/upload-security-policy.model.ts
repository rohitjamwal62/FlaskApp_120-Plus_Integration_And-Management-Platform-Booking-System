export type UploadSecurityPolicy = {
    policy: string;
    signature: string;
}