export type DeviceCoordinates = {
  latitude: number;
  longitude: number;
}
