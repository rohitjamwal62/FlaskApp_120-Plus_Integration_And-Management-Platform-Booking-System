export type DeviceGroupV3 = {
    id: number;
    name: string;
    createdTimestamp: string;
    positionNumber: number;
    modifiedTimestamp: string;
    workspace: number;
    parentFolder: number;
}