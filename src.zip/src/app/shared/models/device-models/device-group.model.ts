export type DeviceGroup = {
    id: number;
    location: string;
    groupName: string;
    positionNumber: number
    devices: Location[];
    createdTimestamp: string;
    modifiedTimestamp: string;
    workspace: Location;
}