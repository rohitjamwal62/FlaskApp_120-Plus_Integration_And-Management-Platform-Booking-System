export type DeviceOrientationV3 = {
    id: number;
    name: string;
}