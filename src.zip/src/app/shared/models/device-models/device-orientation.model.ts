export type DeviceOrientation = {
    id: number;
    location: string;
    orientationName: string;
}