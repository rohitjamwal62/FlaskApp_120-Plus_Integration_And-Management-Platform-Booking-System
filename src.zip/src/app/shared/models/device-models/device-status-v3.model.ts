// export type DeviceStatus = {
//     id: number;
//     location: string;
//     statusName: string;
// }

export type DeviceStatusV3 = {
    id: number;
    name: string;
}