export type DeviceStatus = {
    id: number;
    location: string;
    statusName: string;
}