export type DeviceTypeV3 = {
  id: number;
  name: string;
}
