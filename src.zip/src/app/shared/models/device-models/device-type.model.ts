export type DeviceType = {
  id: number;
  typeName: string;
}
