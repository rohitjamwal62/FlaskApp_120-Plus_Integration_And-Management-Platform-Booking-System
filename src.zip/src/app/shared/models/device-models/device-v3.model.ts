import { DeviceOrientationV3 } from './device-orientation-v3.model';
import { DeviceStatusV3 } from './device-status-v3.model';

export type DeviceV3 = {
    id: number;
    name: string;
    ipv4: string;
    ipv6: string;
    notificationsEnabled: boolean;
    deviceOrientation: DeviceOrientationV3;
    secretCode: string;
    model: string;
    positionNumber: number;
    isDisconnected: boolean;
    workspace: number;
    isLocked: boolean;
    deviceType: number;
    modifiedTimestamp: number;
    createdTimestamp: number;
    sources: string[];
    url: string;
    timezoneKey: string;
    lastCheckinTimestamp: number;
    playlist: number;
    deviceGroup: number;
    deviceStatus: DeviceStatusV3;
}
