import { DeviceOrientation } from './device-orientation.model';
import { Location } from '../common-models/location.model';
import { DeviceStatus } from './device-status.model';
import { DeviceType } from './device-type.model';
import { DeviceCoordinates } from './device-coordinates.model';

export type Device = {
    id: number;
    location: string;
    deviceName: string;
    ipv4: string;
    ipv6: string;
    notificationsEnabled: boolean;
    model: string;
    macAddress: string;
    deviceOrientation: DeviceOrientation;
    secretCode: string;
    timezoneKey: string;
    lastCheckinTimestamp: number;
    createdTimestamp: number;
    modifiedTimestamp: number;
    positionNumber: number;
    playlist: Location;
    deviceStatus: DeviceStatus;
    deviceGroup: Location;
    assignedSchedules: Location[];
    isVirtual: boolean;
    isLocked: boolean;
    isDisconnected: boolean;
    deviceType: DeviceType;
    sources: string[];
    standalone: boolean;
    latlng: DeviceCoordinates;
}
