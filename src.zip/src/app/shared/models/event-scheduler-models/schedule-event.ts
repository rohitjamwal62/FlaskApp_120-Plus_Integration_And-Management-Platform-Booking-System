import { UUID } from 'angular2-uuid';

export class ScheduleEvent {
  schedule?: {
    id: number,
    name: string
  }
  startDate: number;
  endDate: number;
  startSeconds: number;
  endSeconds: number;
  onMonday: boolean;
  onTuesday: boolean;
  onWednesday: boolean;
  onThursday: boolean;
  onFriday: boolean;
  onSaturday: boolean;
  onSunday: boolean;
  playlistName: String;
  id: string;
  color: string;
  playlistId: number;
  overlapped: boolean;
  overlappedEvents: ScheduleEvent[];
  modifiedTimestamp: number

  constructor(data: any) {
    this.startDate = data['startDate'] instanceof Date ? data['startDate'].getTime() : (data['startDate'] >= 0 ? data['startDate'] : 0);
    this.endDate = data['endDate'] instanceof Date ? data['endDate'].getTime() : (data['endDate'] >= 0 ? data['endDate'] : 0);
    this.startSeconds = data.startSeconds;
    this.endSeconds = data.endSeconds;
    this.onMonday = (data.onMonday != undefined) ? data.onMonday : true;
    this.onTuesday = (data.onTuesday != undefined) ? data.onTuesday : true;
    this.onWednesday = (data.onWednesday != undefined) ? data.onWednesday : true;
    this.onThursday = (data.onThursday != undefined) ? data.onThursday : true;
    this.onFriday = (data.onFriday != undefined) ? data.onFriday : true;
    this.onSaturday = (data.onSaturday != undefined) ? data.onSaturday : true;
    this.onSunday = (data.onSunday != undefined) ? data.onSunday : true;
    this.playlistName = data['playlistName'];
    this.id = data['id'] ? data['id'].toString() : UUID.UUID();
    //this.color = data['color'] ? data['color'] : this.getRandomColor();
    this.color = data.color ? data.color : this.getRandomColor();
    this.playlistId = data.playlistId >= 0 ? data.playlistId : null;
    this.overlapped = data.overlapped ? data.overlapped : false;
    this.overlappedEvents = data.overlappedEvents ? data.overlappedEvents : [];
    this.schedule = data['schedule'];
    this.modifiedTimestamp = data['modifiedTimestamp'];
  }

  private getRandomColor = function () {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  }
}
