import { ScheduleEvent } from './schedule-event';

export type ScheduleItem = {
    scheduleName: string;
    scheduleId: number,
    scheduledPlaylists: ScheduleEvent[];
}