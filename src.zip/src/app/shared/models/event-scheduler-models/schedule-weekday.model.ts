export type ScheduleWeekDay = {
    date: number,
    id: number,
    shortName: string,
    name: string,
    disabled: boolean,
    name2: string,
    shouldShowName2: boolean
}