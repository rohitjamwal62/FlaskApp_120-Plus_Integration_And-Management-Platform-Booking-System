export type ScheduleOptionsForWeek = {
    view: 'week',
    directionsName: string,
    dayName: 'name' | 'shortName' | 'dayInFormat',
    dayFormat?: string,
    dayFormat2?: string,
}

export type ScheduleOptionsForMonth = {
    view: 'month',
    directionsName: string,
    monthName: 'name' | 'shortName',
    dayFormat?: string,
}