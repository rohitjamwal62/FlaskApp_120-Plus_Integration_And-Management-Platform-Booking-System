import { IntegrationOption } from './integration-option.model';


export type ClientToken = {
  id: number
  name: string;
  type: string;
  expired: boolean;
  integrationType: IntegrationOption;
}
