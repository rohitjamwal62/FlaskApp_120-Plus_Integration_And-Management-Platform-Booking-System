export type GoogleDriveFolder = {
  id: string;
  mimeType: string;
  modifiedTime: number;
  name: string;
}
