import { InputField } from '../common-models/input-field.model';

export type IntegrationOption = {
  id: number;
  name: string;
  type: string;
  form: string;
  description: string;
  icon: string;
  loginButton: string;
  fields: InputField[];
}
