import { InputField } from '../common-models/input-field.model';

export type IntegrationTypes = {
  id: number;
  name: string;
  description: string;
  icon: string;
  type: string;
  fields: InputField[];
  form: string;
  help: string;
  loginButton: string;
}
