import { IntegrationOption } from './integration-option.model';


export type Integrations = {
  image: string;
  title: string;
  loginRoute: string;
  revokeRoute: string;
  loginText: string;
  revokeText: string;
  name: string;
  integrationType: IntegrationOption;
}
