export type OfficeDriveFolder = {
  id: string;
  mimeType: string;
  modifiedTime: number;
  name: string;
}
