import { MessageType } from './message-type.model';

export type Message = {
  id: number;
  title: string;
  message: string;
  displayDate: number;
  hideDate: number;
  type: MessageType;
  priority: number;
  read: boolean;
}
